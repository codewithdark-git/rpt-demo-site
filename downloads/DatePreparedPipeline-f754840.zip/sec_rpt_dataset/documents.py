from __future__ import annotations

import logging
from datetime import date
from pathlib import Path
from typing import Iterable

from .config import PipelineConfig
from .exporters import write_table_pair
from .http_client import SecHttpClient
from .io_utils import ensure_dir, read_text, safe_filename, write_csv, write_text
from .logging_utils import ProgressLogger
from .nlp import load_lm_dictionary, score_text
from .parser import (
    extract_item,
    extract_proxy_rpt_section,
    extract_rp_note,
    html_to_text,
    icfr_flags,
    is_incorporated_by_reference,
    word_count,
)

LOGGER = logging.getLogger(__name__)
PROXY_WINDOW_DAYS = 480  # DEF 14A for fiscal year t is filed within ~4-16 months after year end
MAX_PROXIES_TRIED = 3


def download_extract_score_filings(
    config: PipelineConfig,
    client: SecHttpClient,
    manifest_rows: Iterable[dict[str, object]],
    limit_filings: int | None = None,
    proxy_rows: Iterable[dict[str, object]] | None = None,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    extraction_rows: list[dict[str, object]] = []
    score_rows: list[dict[str, object]] = []
    dictionary = load_lm_dictionary(config.lm_dictionary)
    manifest_rows = [row for row in manifest_rows if row.get("document_url")]
    if limit_filings:
        manifest_rows = manifest_rows[:limit_filings]
    proxies_by_cik: dict[str, list[dict[str, object]]] = {}
    for proxy in proxy_rows or []:
        proxies_by_cik.setdefault(str(proxy.get("cik")), []).append(proxy)
    LOGGER.info("Phase 3/6 documents + Phase 4/6 NLP: processing %s filing documents", len(manifest_rows))
    progress = ProgressLogger(LOGGER, "Filing downloads/extraction", total=len(manifest_rows), every=config.progress_interval)
    partial_extraction_path = config.output_dir / "extraction_manifest_partial.csv"
    partial_scores_path = config.output_dir / "nlp_scores_partial.csv"
    for count, row in enumerate(manifest_rows, start=1):
        extraction, scores = process_filing(config, client, row, dictionary, proxies_by_cik.get(str(row.get("cik")), []))
        extraction_rows.append(extraction)
        score_rows.append(scores)
        progress.log(count, extra=f"latest accession={row.get('accession_number')} rpt_source={extraction.get('rpt_text_source')}")
        if config.checkpoint_interval and count % config.checkpoint_interval == 0:
            write_csv(partial_extraction_path, extraction_rows)
            write_csv(partial_scores_path, score_rows)
            LOGGER.info("Checkpoint written: %s extractions, %s scores", len(extraction_rows), len(score_rows))

    LOGGER.info("Writing final extraction and NLP score files")
    write_table_pair(config.output_dir / "extraction_manifest", extraction_rows)
    write_table_pair(config.output_dir / "nlp_scores", score_rows)
    LOGGER.info("Document extraction/NLP complete: %s filings", len(extraction_rows))
    return extraction_rows, score_rows


def process_filing(
    config: PipelineConfig,
    client: SecHttpClient,
    row: dict[str, object],
    dictionary: dict[str, set[str]],
    proxies: list[dict[str, object]],
) -> tuple[dict[str, object], dict[str, object]]:
    base_dir = ensure_dir(filing_output_dir(config, row))
    paths = {name: base_dir / f"{name}.txt" for name in ("filing", "item1", "item9a", "item13", "rp_note", "rpt_disclosure")}
    texts = {name: "" for name in paths if name != "filing"}
    statuses = {f"{name}_status": "" for name in texts}
    extraction: dict[str, object] = {**row, "extraction_status": "ok", "extraction_error": ""}
    try:
        if not paths["filing"].exists():
            write_text(paths["filing"], html_to_text(client.get_text(str(row["document_url"]))))
        text = read_text(paths["filing"])
        texts["item1"], statuses["item1_status"] = extract_item(text, "1")
        texts["item9a"], statuses["item9a_status"] = extract_item(text, "9A")
        texts["item13"], statuses["item13_status"] = extract_item(text, "13")
        texts["rp_note"], statuses["rp_note_status"] = extract_rp_note(text)
        item13_ibr = is_incorporated_by_reference(texts["item13"])
        if item13_ibr:
            statuses["item13_status"] = "incorporated_by_reference"
        extraction["item13_incorporated_by_reference"] = int(item13_ibr)

        # Related-party disclosure text: the Item 13 body when it is substantive,
        # otherwise the related-party section of the matching proxy statement.
        rpt_source, proxy_accession = "none", ""
        if statuses["item13_status"] == "ok":
            texts["rpt_disclosure"], rpt_source = texts["item13"], "10k_item13"
        elif config.include_proxies:
            proxy_text, proxy_accession = find_proxy_rpt_section(config, client, row, proxies)
            if proxy_text:
                texts["rpt_disclosure"], rpt_source = proxy_text, "def14a"
        statuses["rpt_disclosure_status"] = "ok" if word_count(texts["rpt_disclosure"]) >= config.min_text_words else "missing"
        extraction["rpt_text_source"] = rpt_source if statuses["rpt_disclosure_status"] == "ok" else "none"
        extraction["proxy_accession_number"] = proxy_accession

        for name, value in texts.items():
            write_text(paths[name], value)
        write_csv(base_dir / "filing_metadata.csv", [row])
    except Exception as exc:
        extraction["extraction_status"] = "error"
        extraction["extraction_error"] = str(exc)
        extraction.setdefault("rpt_text_source", "none")
        statuses = {key: "error" for key in statuses}

    extraction.update(statuses)
    extraction["raw_filing_path"] = str(paths["filing"])
    for name, value in texts.items():
        extraction[f"{name}_path"] = str(paths[name])
        extraction[f"{name}_words"] = word_count(value)
    extraction.update(icfr_flags(texts["item9a"]))

    scores: dict[str, object] = {
        key: row.get(key, "")
        for key in ["cik", "ticker", "company_name", "year", "fiscal_year", "form", "filing_date", "report_date", "accession_number"]
    }
    scores["rpt_text_source"] = extraction.get("rpt_text_source", "none")
    for name in ("item1", "item13", "rpt_disclosure", "rp_note"):
        scores.update(score_text(texts[name], dictionary, prefix=name, min_words=config.min_text_words))
    return extraction, scores


def find_proxy_rpt_section(
    config: PipelineConfig,
    client: SecHttpClient,
    filing: dict[str, object],
    proxies: list[dict[str, object]],
) -> tuple[str, str]:
    """Return the longest related-party section among proxies filed after the 10-K's year end."""
    candidates = candidate_proxies(filing, proxies)
    best_text, best_accession = "", ""
    for proxy in candidates[:MAX_PROXIES_TRIED]:
        proxy_dir = ensure_dir(config.raw_proxies_dir / safe_filename(str(proxy.get("cik"))) / safe_filename(str(proxy.get("accession_number"))))
        proxy_path = proxy_dir / "proxy.txt"
        try:
            if not proxy_path.exists():
                write_text(proxy_path, html_to_text(client.get_text(str(proxy["document_url"]))))
            section, status = extract_proxy_rpt_section(read_text(proxy_path))
        except Exception as exc:
            LOGGER.debug("Proxy fetch failed %s: %s", proxy.get("document_url"), exc)
            continue
        write_text(proxy_dir / "proxy_rpt.txt", section)
        if status == "ok" and word_count(section) > word_count(best_text):
            best_text, best_accession = section, str(proxy.get("accession_number"))
    return best_text, best_accession


def candidate_proxies(filing: dict[str, object], proxies: list[dict[str, object]]) -> list[dict[str, object]]:
    report = _parse_date(filing.get("report_date")) or _parse_date(filing.get("filing_date"))
    if report is None:
        return []
    out = []
    for proxy in proxies:
        filed = _parse_date(proxy.get("filing_date"))
        if filed and 0 < (filed - report).days <= PROXY_WINDOW_DAYS and proxy.get("document_url"):
            out.append(proxy)
    return sorted(out, key=lambda p: str(p.get("filing_date")))


def _parse_date(value: object) -> date | None:
    text = str(value or "")
    try:
        return date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (ValueError, IndexError):
        return None


def filing_output_dir(config: PipelineConfig, row: dict[str, object]) -> Path:
    cik = safe_filename(str(row.get("cik", "")))
    year = safe_filename(str(row.get("year", "")))
    accession = safe_filename(str(row.get("accession_number", "")))
    return config.raw_filings_dir / cik / year / accession
