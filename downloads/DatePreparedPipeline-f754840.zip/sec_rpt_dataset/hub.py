"""Hugging Face Hub publishing and retrieval for the SEC-RPT-Panel dataset.

The CSV/JSON tables are the canonical dataset; raw filing texts live under
``raw/``. Uploads are idempotent (the Hub skips files whose hash is already
present) and downloads are resume-safe (``snapshot_download`` skips unchanged
local files), so a run can be stopped and resumed at any point.

``huggingface_hub`` is imported lazily so the core pipeline works without it.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .io_utils import cik10, read_csv

LOGGER = logging.getLogger(__name__)

DEFAULT_REPO_ID = "codewithdark/SEC-RPT-Panel"
TABLE_FILES = (
    "company_universe",
    "filing_manifest",
    "proxy_manifest",
    "extraction_manifest",
    "nlp_scores",
    "xbrl_financials",
    "aaer_manifest",
    "aaer_company_matches",
    "fraud_labels",
    "master_panel",
)
TABLE_DESCRIPTIONS = {
    "company_universe": "One row per company (CIK): SEC metadata, SIC, case role.",
    "filing_manifest": "One row per annual report (10-K family) with fiscal year and `is_primary_filing`.",
    "proxy_manifest": "DEF 14A proxy statements used for related-party text when Item 13 is incorporated by reference.",
    "extraction_manifest": "Per-filing extraction status, word counts, `rpt_text_source`, Item 9A internal-control flags.",
    "nlp_scores": "Readability and dictionary scores for Item 1, Item 13, the related-party disclosure and the RP note.",
    "xbrl_financials": "Annual XBRL values as first reported (FY2009+).",
    "aaer_manifest": "SEC Accounting and Auditing Enforcement Releases crawled from the official listing.",
    "aaer_company_matches": "Automatic AAER-to-company name matches: candidates for manual review, not labels.",
    "fraud_labels": "Company x fiscal-year labels (`fraud_aaer_label`, `event_time`, `misconduct_period`).",
    "master_panel": "Everything joined: one row per annual report.",
}
METADATA_PATTERNS = ["*.csv", "*.json", "README.md"]
IGNORE_ALWAYS = ["*_partial.csv", "raw/aaer/**/*.html", "raw/aaer/**/*.htm", "**/.cache/**", ".gitattributes", "*.lock"]


# --------------------------------------------------------------------------
# Credentials
# --------------------------------------------------------------------------

def resolve_token(explicit: str | None = None) -> str | None:
    """Explicit token, then ``HF_TOKEN``, then the local ``hf auth login`` credential.

    The value is returned to the caller only; it is never logged or printed.
    """
    if explicit:
        return explicit
    env = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if env:
        return env
    try:
        from huggingface_hub import get_token

        return get_token()
    except Exception:
        return None


# --------------------------------------------------------------------------
# Dataset card
# --------------------------------------------------------------------------

def _git_sha() -> str:
    try:
        return subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, check=True,
            cwd=Path(__file__).resolve().parent.parent,
        ).stdout.strip()
    except Exception:
        return "unknown"


def _qa_table(qa: dict[str, Any] | None) -> str:
    if not qa:
        return "_No `dataset_qa.json` was available when this card was generated._"
    lines = ["| Metric | Value |", "|---|---|"]
    for key, value in qa.items():
        if isinstance(value, dict):
            value = ", ".join(f"{k}: {v}" for k, v in value.items())
        lines.append(f"| `{key}` | {value} |")
    return "\n".join(lines)


def build_dataset_card(output_dir: Path, repo_id: str, version: str, qa: dict[str, Any] | None = None) -> str:
    present = [name for name in TABLE_FILES if (output_dir / f"{name}.csv").exists()]
    configs = "\n".join(
        f"  - config_name: {name}\n    data_files: {name}.csv" for name in present
    )
    tables = "\n".join(f"| `{name}.csv` | {TABLE_DESCRIPTIONS.get(name, '')} |" for name in present)
    rows = qa.get("filings") if qa else None
    size = "n<1K" if not rows else ("n<1K" if rows < 1000 else "1K<n<10K" if rows < 10_000 else "10K<n<100K")
    header = f"""---
pretty_name: SEC-RPT-Panel
license: other
license_name: sec-public-domain
license_link: https://www.sec.gov/privacy#dissemination
language:
  - en
task_categories:
  - tabular-classification
  - text-classification
tags:
  - finance
  - accounting
  - sec-edgar
  - related-party-transactions
  - fraud-detection
size_categories:
  - {size}
configs:
{configs}
---
"""
    body = f"""# SEC-RPT-Panel v{version}

A firm-year research panel for studying related-party-transaction (RPT) fraud
risk, built only from official SEC sources: EDGAR 10-K filings, DEF 14A proxy
statements, XBRL company facts and Accounting and Auditing Enforcement Releases
(AAERs). Published as `{repo_id}`.

Built with `sec_rpt_dataset` v{version} (git `{_git_sha()}`) on
{datetime.now(timezone.utc).strftime('%Y-%m-%d')}.

## Tables

| File | Content |
|---|---|
{tables}

All tables are keyed on the 10-digit `cik`. Firm-year tables use `fiscal_year`
(Compustat convention: fiscal years ending January-May belong to the previous
calendar year). `master_panel.csv` has one row per annual report; use
`is_primary_filing == 1` for one row per company-year (first original 10-K,
as-first-reported).

## Labels (`fraud_labels.csv`)

- `fraud_aaer_label`: 1 for a **case** firm's fiscal years inside the
  assessment window (the five fiscal years before the first public revelation
  of the misconduct), 0 for matched peers and for years outside the window.
  Case firms, misconduct periods and revelation dates come from a hand-verified
  cases file, not from automatic matching.
- `event_time`: fiscal year minus revelation year (peers inherit their matched
  case's revelation year). Negative values are pre-revelation.
- `misconduct_period`: 1 inside the misconduct period named in the SEC order.
- `case_role`: `case` or `peer`; `case_id` / `matched_case_id` link them.
- `aaer_release_in_year`, `aaer_numbers`: **unverified** automatic name
  matches of AAERs *released* in that calendar year. These are an
  enforcement-date flag, not a misconduct label; review
  `aaer_company_matches.csv` before using them.

Enforcement data capture detected and pursued misconduct only. For most
cases the window overlaps the misconduct period, so signals are
pre-*detection*, not pre-*misconduct*.

## Related-party text (`rpt_text_source`)

| value | meaning |
|---|---|
| `10k_item13` | Item 13 body of the 10-K was substantive |
| `def14a` | Item 13 was incorporated by reference; the related-party section of the matching proxy statement was used |
| `none` | no related-party text of at least the minimum length was found |

Texts shorter than the minimum word count are treated as missing: their NLP
scores are blank and `*_text_available` is 0.

## Raw files

```text
raw/filings/<CIK>/<FY>/<ACCESSION>/{{filing,item1,item9a,item13,rp_note,rpt_disclosure}}.txt
raw/proxies/<CIK>/<ACCESSION>/{{proxy,proxy_rpt}}.txt
raw/xbrl/CIK<CIK>.json
raw/aaer/<YEAR>/<AAER_NO>.{{pdf,txt}}
```

## Coverage (dataset_qa.json)

{_qa_table(qa)}

## Citation

If you use this dataset, cite the accompanying thesis / working paper and this
repository. SEC filings are public domain; this compilation is released for
research use.
"""
    return header + body


# --------------------------------------------------------------------------
# Upload
# --------------------------------------------------------------------------

def upload_dataset(
    output_dir: Path,
    repo_id: str = DEFAULT_REPO_ID,
    *,
    version: str | None = None,
    token: str | None = None,
    private: bool = False,
    include_xlsx: bool = False,
    include_raw: bool = True,
    dry_run: bool = False,
) -> dict[str, object]:
    """Publish ``output_dir`` to a Hub dataset repo. Returns a summary dict."""
    from huggingface_hub import HfApi

    if version is None:
        from .pipeline import DATASET_VERSION

        version = DATASET_VERSION
    output_dir = Path(output_dir)
    qa_path = output_dir / "dataset_qa.json"
    qa = json.loads(qa_path.read_text(encoding="utf-8")) if qa_path.exists() else None
    card = build_dataset_card(output_dir, repo_id, version, qa)
    metadata_patterns = METADATA_PATTERNS + (["*.xlsx"] if include_xlsx else [])
    planned = plan_upload(output_dir, metadata_patterns, include_raw)
    summary: dict[str, object] = {
        "repo_id": repo_id,
        "version": version,
        "metadata_files": len(planned["metadata"]),
        "raw_files": len(planned["raw"]),
        "dry_run": dry_run,
    }
    if dry_run:
        LOGGER.info("Dry run: would upload %s metadata files and %s raw files to %s", summary["metadata_files"], summary["raw_files"], repo_id)
        summary["files"] = planned
        return summary

    (output_dir / "README.md").write_text(card, encoding="utf-8")
    api = HfApi(token=resolve_token(token))
    api.create_repo(repo_id, repo_type="dataset", exist_ok=True, private=private)
    n_filings = (qa or {}).get("filings", "?")
    n_companies = (qa or {}).get("companies", "?")
    message = f"SEC-RPT-Panel v{version}: {n_filings} filings, {n_companies} companies"
    if include_raw and planned["raw"]:
        LOGGER.info("Uploading %s raw files (resumable)", len(planned["raw"]))
        api.upload_large_folder(
            repo_id=repo_id,
            repo_type="dataset",
            folder_path=str(output_dir),
            allow_patterns=["raw/**"],
            ignore_patterns=IGNORE_ALWAYS,
            print_report=False,
        )
    LOGGER.info("Uploading %s metadata files", len(planned["metadata"]))
    api.upload_folder(
        repo_id=repo_id,
        repo_type="dataset",
        folder_path=str(output_dir),
        allow_patterns=metadata_patterns,
        ignore_patterns=IGNORE_ALWAYS,
        commit_message=message,
    )
    summary["url"] = f"https://huggingface.co/datasets/{repo_id}"
    LOGGER.info("Upload complete: %s", summary["url"])
    return summary


def _matches(path: str, patterns: Iterable[str]) -> bool:
    from fnmatch import fnmatch

    return any(fnmatch(path, p) or fnmatch(path, p.replace("**/", "")) or fnmatch(Path(path).name, p) for p in patterns)


def plan_upload(output_dir: Path, metadata_patterns: list[str], include_raw: bool) -> dict[str, list[str]]:
    """List the files an upload would send, relative to ``output_dir``."""
    metadata: list[str] = []
    raw: list[str] = []
    for path in sorted(Path(output_dir).rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(output_dir).as_posix()
        if _matches(rel, IGNORE_ALWAYS):
            continue
        if rel.startswith("raw/"):
            if include_raw:
                raw.append(rel)
        elif _matches(rel, metadata_patterns):
            metadata.append(rel)
    return {"metadata": metadata, "raw": raw}


# --------------------------------------------------------------------------
# Download
# --------------------------------------------------------------------------

def cik_patterns(ciks: Iterable[str]) -> list[str]:
    patterns: list[str] = []
    for cik in ciks:
        c = cik10(cik)
        patterns += [f"raw/filings/{c}/**", f"raw/proxies/{c}/**", f"raw/xbrl/CIK{c}.json"]
    return patterns


def download_dataset(
    local_dir: Path,
    repo_id: str = DEFAULT_REPO_ID,
    *,
    mode: str = "metadata",
    ciks: Iterable[str] | None = None,
    token: str | None = None,
    revision: str | None = None,
) -> Path:
    """Fetch the dataset (or part of it) into ``local_dir``, keeping repo paths.

    mode: ``metadata`` (tables only), ``full`` (everything), ``ciks`` (tables
    plus raw files for the given CIKs). Files already present and unchanged are
    skipped, so this is safe to re-run.
    """
    from huggingface_hub import snapshot_download

    if mode == "metadata":
        allow: list[str] | None = list(METADATA_PATTERNS)
    elif mode == "full":
        allow = None
    elif mode == "ciks":
        if not ciks:
            raise ValueError("mode='ciks' needs at least one CIK")
        allow = list(METADATA_PATTERNS) + cik_patterns(ciks)
    else:
        raise ValueError(f"unknown mode {mode!r}")
    local_dir = Path(local_dir)
    local_dir.mkdir(parents=True, exist_ok=True)
    LOGGER.info("Downloading %s (%s) into %s", repo_id, mode, local_dir)
    snapshot_download(
        repo_id=repo_id,
        repo_type="dataset",
        local_dir=str(local_dir),
        allow_patterns=allow,
        token=resolve_token(token),
        revision=revision,
    )
    return local_dir


def ciks_from_cases(cases_csv: Path) -> list[str]:
    return [cik10(row["cik"]) for row in read_csv(Path(cases_csv)) if row.get("cik")]
