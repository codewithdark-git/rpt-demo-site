from __future__ import annotations

import logging
from typing import Any, Iterable

from .config import ARCHIVES_BASE_URL, PipelineConfig, SUBMISSIONS_BASE_URL
from .exporters import write_table_pair
from .http_client import SecHttpClient
from .io_utils import cik10, cik_int, write_csv
from .logging_utils import ProgressLogger

# 10-KSB/10-KSB40 cover small issuers before March 2009 (many reverse-merger cases);
# 10-KT is a transition-period annual report.
BASE_FORMS = {"10-K", "10-K405", "10-KSB", "10-KSB40", "10-KT"}
AMENDMENT_FORMS = {"10-K/A", "10-K405/A", "10-KSB/A", "10-KSB40/A", "10-KT/A"}
PROXY_FORMS = {"DEF 14A"}
LOGGER = logging.getLogger(__name__)


def build_filing_manifest(
    config: PipelineConfig,
    client: SecHttpClient,
    companies: Iterable[dict[str, object]],
) -> list[dict[str, object]]:
    return build_manifests(config, client, companies)[0]


def build_manifests(
    config: PipelineConfig,
    client: SecHttpClient,
    companies: Iterable[dict[str, object]],
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    """Return (annual-report rows, proxy rows) and write both manifests."""
    companies = list(companies)
    rows: list[dict[str, object]] = []
    proxy_rows: list[dict[str, object]] = []
    LOGGER.info("Phase 2/6 filing manifest: scanning 10-K filings for %s companies", len(companies))
    progress = ProgressLogger(LOGGER, "Filing manifest companies", total=len(companies), every=config.progress_interval)
    partial_path = config.output_dir / "filing_manifest_partial.csv"
    for index, company in enumerate(companies, start=1):
        try:
            submission = client.get_json(f"{SUBMISSIONS_BASE_URL}/CIK{cik10(company['cik'])}.json")
            filing_rows = list(iter_submission_filings(client, submission))
        except Exception as exc:
            rows.append(
                {
                    "cik": cik10(company.get("cik", "")),
                    "company_name": company.get("name", ""),
                    "manifest_error": str(exc),
                }
            )
            progress.log(index, extra=f"latest CIK={company.get('cik')} manifest_error")
            if config.checkpoint_interval and index % config.checkpoint_interval == 0:
                write_csv(partial_path, rows)
                LOGGER.info("Checkpoint written: %s rows -> %s", len(rows), partial_path)
            continue
        company_filing_count = 0
        cik_no_zeros = cik_int(company["cik"])
        for filing in filing_rows:
            form = str(filing.get("form", ""))
            if form in PROXY_FORMS and config.include_proxies:
                filed_year = int(str(filing.get("filingDate", "0000"))[:4] or 0)
                if config.start_year <= filed_year <= config.end_year + 2:
                    proxy_rows.append(_document_row(company, filing, cik_no_zeros))
                continue
            forms = BASE_FORMS | (AMENDMENT_FORMS if config.include_amendments else set())
            if form not in forms:
                continue
            year = fiscal_year(filing)
            if year is None or not (config.start_year <= year <= config.end_year):
                continue
            row = _document_row(company, filing, cik_no_zeros)
            row["year"] = year
            row["fiscal_year"] = year
            rows.append(row)
            company_filing_count += 1
        progress.log(index, extra=f"latest CIK={company.get('cik')} filings_found={company_filing_count} total_filings={len(rows)}")
        if config.checkpoint_interval and index % config.checkpoint_interval == 0:
            write_csv(partial_path, rows)
            LOGGER.info("Checkpoint written: %s rows -> %s", len(rows), partial_path)
    rows.sort(key=lambda r: (str(r.get("cik")), str(r.get("year")), str(r.get("filing_date"))))
    rows = flag_duplicate_fiscal_years(rows)
    LOGGER.info("Writing final filing manifest files")
    write_table_pair(config.output_dir / "filing_manifest", rows)
    if config.include_proxies:
        proxy_rows.sort(key=lambda r: (str(r.get("cik")), str(r.get("filing_date"))))
        write_table_pair(config.output_dir / "proxy_manifest", proxy_rows)
        LOGGER.info("Proxy manifest complete: %s DEF 14A rows", len(proxy_rows))
    LOGGER.info("Filing manifest complete: %s rows", len(rows))
    return rows, proxy_rows


def iter_submission_filings(client: SecHttpClient, submission: dict[str, Any]) -> Iterable[dict[str, object]]:
    recent = submission.get("filings", {}).get("recent", {})
    yield from columnar_to_rows(recent)
    for file_info in submission.get("filings", {}).get("files", []) or []:
        name = file_info.get("name")
        if not name:
            continue
        older = client.get_json(f"{SUBMISSIONS_BASE_URL}/{name}")
        yield from columnar_to_rows(older)


def columnar_to_rows(columnar: dict[str, list[Any]]) -> list[dict[str, object]]:
    if not columnar:
        return []
    keys = list(columnar.keys())
    n = max((len(columnar.get(key, [])) for key in keys), default=0)
    rows = []
    for idx in range(n):
        row = {}
        for key in keys:
            values = columnar.get(key, [])
            row[key] = values[idx] if idx < len(values) else ""
        rows.append(row)
    return rows


def _document_row(company: dict[str, object], filing: dict[str, object], cik_no_zeros: str) -> dict[str, object]:
    accession = str(filing.get("accessionNumber", ""))
    primary_doc = str(filing.get("primaryDocument", ""))
    accession_no_dashes = accession.replace("-", "")
    return {
        "cik": cik10(company["cik"]),
        "ticker": company.get("ticker", ""),
        "company_name": company.get("name", ""),
        "form": str(filing.get("form", "")),
        "filing_date": filing.get("filingDate", ""),
        "report_date": filing.get("reportDate", ""),
        "acceptance_datetime": filing.get("acceptanceDateTime", ""),
        "accession_number": accession,
        "primary_document": primary_doc,
        "primary_doc_description": filing.get("primaryDocDescription", ""),
        "size": filing.get("size", ""),
        "is_xbrl": filing.get("isXBRL", ""),
        "is_inline_xbrl": filing.get("isInlineXBRL", ""),
        "document_url": f"{ARCHIVES_BASE_URL}/{cik_no_zeros}/{accession_no_dashes}/{primary_doc}" if primary_doc else "",
        "filing_index_url": f"{ARCHIVES_BASE_URL}/{cik_no_zeros}/{accession_no_dashes}/",
    }


def fiscal_year(filing: dict[str, object]) -> int | None:
    """Fiscal year using the Compustat convention.

    A fiscal year ending January-May is assigned to the previous calendar year
    (e.g. FYE 2024-05-31 -> FY2023). Without a report date, the filing date
    minus one year is used, because 10-Ks are filed after the year ends.
    """
    report = str(filing.get("reportDate", ""))
    if len(report) >= 7 and report[:4].isdigit() and report[5:7].isdigit():
        year, month = int(report[:4]), int(report[5:7])
        return year - 1 if month <= 5 else year
    filed = str(filing.get("filingDate", ""))
    if len(filed) >= 4 and filed[:4].isdigit():
        return int(filed[:4]) - 1
    return None


def flag_duplicate_fiscal_years(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    """Mark the primary 10-K per (cik, fiscal year): the earliest original filing.

    Later duplicates (re-filed reports, transition reports, amendments) are kept
    but flagged so analyses can use as-first-reported data and avoid look-ahead.
    """
    seen: set[tuple[str, str]] = set()
    for row in sorted(rows, key=lambda r: (str(r.get("cik")), str(r.get("year")), "/A" in str(r.get("form")), str(r.get("filing_date")))):
        key = (str(row.get("cik")), str(row.get("year")))
        row["is_primary_filing"] = int(key not in seen)
        seen.add(key)
    return rows
