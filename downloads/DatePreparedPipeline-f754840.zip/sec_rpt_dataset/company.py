from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from .config import COMPANY_TICKERS_FALLBACK, COMPANY_TICKERS_URL, PipelineConfig, SUBMISSIONS_BASE_URL
from .exporters import write_table_pair
from .http_client import SecHttpClient
from .io_utils import cik10, ensure_dir, read_csv, read_json, write_csv
from .logging_utils import ProgressLogger
from .triggers import company_matches_trigger, extract_trigger_values

LOGGER = logging.getLogger(__name__)


def fetch_company_tickers(client: SecHttpClient) -> list[dict[str, object]]:
    LOGGER.info("Fetching SEC company ticker universe")
    try:
        payload = client.get_json(COMPANY_TICKERS_URL)
    except Exception:
        LOGGER.warning("Primary company ticker URL failed; trying SEC fallback")
        payload = client.get_json(COMPANY_TICKERS_FALLBACK)
    rows: list[dict[str, object]] = []
    for item in payload.values() if isinstance(payload, dict) else payload:
        rows.append(
            {
                "cik": cik10(item.get("cik_str", item.get("cik", ""))),
                "ticker": str(item.get("ticker", "")).upper(),
                "name": item.get("title", item.get("name", "")),
            }
        )
    rows = sorted(rows, key=lambda r: (str(r["ticker"]), str(r["cik"])))
    LOGGER.info("Fetched %s SEC company ticker records", len(rows))
    return rows


def dedupe_by_cik(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    """SEC's ticker file lists one row per share class; keep one row per CIK."""
    seen: dict[str, dict[str, object]] = {}
    for row in rows:
        cik = cik10(row.get("cik", ""))
        if cik not in seen:
            seen[cik] = dict(row)
        elif row.get("ticker"):
            existing = str(seen[cik].get("all_tickers") or seen[cik].get("ticker", ""))
            seen[cik]["all_tickers"] = "|".join(t for t in [existing, str(row["ticker"])] if t)
    return list(seen.values())


def load_cases(path: Path) -> list[dict[str, str]]:
    """Verified case/peer file. Required column: cik. See README for the schema."""
    rows = read_csv(path)
    for row in rows:
        if not row.get("cik"):
            raise ValueError(f"{path}: every row needs a cik")
        row["cik"] = cik10(row["cik"])
        row["role"] = (row.get("role") or "case").strip().lower()
    return rows


def submission_url(cik: str) -> str:
    return f"{SUBMISSIONS_BASE_URL}/CIK{cik10(cik)}.json"


def fetch_submission(client: SecHttpClient, cik: str) -> dict[str, Any]:
    return client.get_json(submission_url(cik))


def flatten_company_metadata(ticker_row: dict[str, object], submission: dict[str, Any] | None = None) -> dict[str, object]:
    submission = submission or {}
    addresses = submission.get("addresses") or {}
    business_addr = addresses.get("business") or {}
    mailing_addr = addresses.get("mailing") or {}
    former_names = submission.get("formerNames") or []
    return {
        "cik": cik10(ticker_row.get("cik", submission.get("cik", ""))),
        "ticker": ticker_row.get("ticker", ""),
        "name": submission.get("name") or ticker_row.get("name", ""),
        "entity_type": submission.get("entityType", ""),
        "sic": submission.get("sic", ""),
        "sic_description": submission.get("sicDescription", ""),
        "category": submission.get("category", ""),
        "fiscal_year_end": submission.get("fiscalYearEnd", ""),
        "state_of_incorporation": submission.get("stateOfIncorporation", ""),
        "state_of_incorporation_description": submission.get("stateOfIncorporationDescription", ""),
        "tickers": join_clean(submission.get("tickers") or ([ticker_row.get("ticker", "")] if ticker_row.get("ticker") else [])),
        "exchanges": join_clean(submission.get("exchanges") or []),
        "ein": submission.get("ein", ""),
        "phone": submission.get("phone", ""),
        "business_address": format_address(business_addr),
        "mailing_address": format_address(mailing_addr),
        "former_names": join_clean(item.get("name", "") for item in former_names if isinstance(item, dict)),
        "sec_submission_url": submission_url(str(ticker_row.get("cik", submission.get("cik", "")))),
    }


def join_clean(values: Any) -> str:
    if isinstance(values, (str, int, float)):
        values = [values]
    return "|".join(str(value).strip() for value in values or [] if value is not None and str(value).strip())


def format_address(address: dict[str, Any]) -> str:
    parts = [
        address.get("street1", ""),
        address.get("street2", ""),
        address.get("city", ""),
        address.get("stateOrCountry", ""),
        address.get("zipCode", ""),
    ]
    return ", ".join(str(part) for part in parts if part)


def build_company_universe(
    config: PipelineConfig,
    client: SecHttpClient,
    limit: int | None = None,
    trigger_card_json: Path | None = None,
    trigger_card_url: str | None = None,
) -> list[dict[str, object]]:
    ensure_dir(config.output_dir)
    cases = load_cases(config.cases_csv) if config.cases_csv else None
    if cases is not None:
        # Case-driven universe: works for delisted firms (Enron, Puda Coal, ...),
        # which are missing from SEC's current company_tickers.json.
        ticker_rows = [
            {"cik": c["cik"], "ticker": c.get("ticker", ""), "name": c.get("company_name", ""),
             "case_id": c.get("case_id", ""), "case_role": c["role"], "matched_case_id": c.get("matched_case_id", "")}
            for c in cases
        ]
        LOGGER.info("Using cases file %s: %s companies", config.cases_csv, len(ticker_rows))
    else:
        ticker_rows = fetch_company_tickers(client)
        LOGGER.warning("Universe = SEC current company_tickers.json; delisted firms are absent (survivorship bias)")
    ticker_rows = dedupe_by_cik(ticker_rows)
    trigger_values = None
    if trigger_card_json:
        trigger_values = extract_trigger_values(read_json(trigger_card_json))
    elif trigger_card_url:
        trigger_values = extract_trigger_values(client.get_json(trigger_card_url))

    if trigger_values:
        before = len(ticker_rows)
        ticker_rows = [row for row in ticker_rows if company_matches_trigger({"cik": row["cik"], "tickers": row["ticker"], "name": row["name"]}, trigger_values)]
        LOGGER.info("Applied trigger-card filter: %s -> %s companies", before, len(ticker_rows))

    if limit:
        ticker_rows = ticker_rows[:limit]
        LOGGER.info("Applied company limit: %s companies", len(ticker_rows))

    rows: list[dict[str, object]] = []
    LOGGER.info("Phase 1/6 company metadata: requesting SEC submissions for %s companies", len(ticker_rows))
    progress = ProgressLogger(LOGGER, "Company metadata", total=len(ticker_rows), every=config.progress_interval)
    partial_path = config.output_dir / "company_universe_partial.csv"
    for index, row in enumerate(ticker_rows, start=1):
        try:
            submission = fetch_submission(client, str(row["cik"]))
        except Exception as exc:
            submission = {}
            row["metadata_error"] = str(exc)
        flattened = flatten_company_metadata(row, submission)
        for key in ("case_id", "case_role", "matched_case_id"):
            if key in row:
                flattened[key] = row[key]
        if "metadata_error" in row:
            flattened["metadata_error"] = row["metadata_error"]
        rows.append(flattened)
        progress.log(index, extra=f"latest CIK={flattened.get('cik')} ticker={flattened.get('ticker')}")
        if config.checkpoint_interval and index % config.checkpoint_interval == 0:
            write_csv(partial_path, rows)
            LOGGER.info("Checkpoint written: %s rows -> %s", len(rows), partial_path)

    LOGGER.info("Writing final company universe files")
    write_table_pair(config.output_dir / "company_universe", rows)
    LOGGER.info("Company universe complete: %s rows", len(rows))
    return rows


def print_company_preview(rows: list[dict[str, object]], display_limit: int | None) -> None:
    shown = rows if display_limit is None or display_limit < 0 else rows[:display_limit]
    print(f"Available companies written: {len(rows)}")
    for row in shown:
        print(f"{row.get('cik')}\t{row.get('ticker')}\t{row.get('name')}\t{row.get('sic')}\t{row.get('exchanges')}")
