from __future__ import annotations

import html as html_lib
import logging
import re
from pathlib import Path
from typing import Iterable

from .config import AAER_BASE_URL, AAER_LEGACY_URL_TEMPLATE, PipelineConfig
from .exporters import write_table_pair
from .http_client import SecHttpClient
from .io_utils import cik10, ensure_dir, safe_filename, write_csv, write_text
from .logging_utils import ProgressLogger
from .triggers import normalize_name

AAER_RE = re.compile(r"AAER[-\s]?(\d{1,5})", re.IGNORECASE)
ROW_RE = re.compile(r'<tr[^>]*class="[^"]*pr-list-page-row[^"]*"[^>]*>(.*?)</tr>', re.IGNORECASE | re.DOTALL)
TIME_RE = re.compile(r'<time[^>]*datetime="(\d{4}-\d{2}-\d{2})', re.IGNORECASE)
RESPONDENTS_RE = re.compile(r"release-view__respondents['\"]>(.*?)</div>", re.IGNORECASE | re.DOTALL)
HREF_RE = re.compile(r"""href=['"]([^'"]+)['"]""", re.IGNORECASE)
RELEASE_NO_RE = re.compile(r"subfield_release_number.*?subfield_value\">(.*?)</span>", re.IGNORECASE | re.DOTALL)
SEE_ALSO_RE = re.compile(r"subfield_see_also(.*?)</div>", re.IGNORECASE | re.DOTALL)
MAX_PAGES_PER_YEAR = 20
LOGGER = logging.getLogger(__name__)


def _strip_tags(fragment: str) -> str:
    return " ".join(html_lib.unescape(re.sub(r"<[^>]+>", " ", fragment)).split())


# --------------------------------------------------------------------------
# AAER manifest
# --------------------------------------------------------------------------

def build_aaer_manifest(config: PipelineConfig, client: SecHttpClient) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    years = list(range(config.aaer_start_year, config.end_year + 1))
    LOGGER.info("AAER manifest: crawling %s SEC AAER years (%s-%s)", len(years), years[0], years[-1])
    for year in years:
        year_rows = fetch_aaer_year(config, client, year)
        rows.extend(year_rows)
        LOGGER.info("AAER year %s complete: %s releases, %s total", year, len(year_rows), len(rows))
        if config.checkpoint_interval:
            write_csv(config.output_dir / "aaer_manifest_partial.csv", rows)
    rows = dedupe_aaer_rows(rows)
    write_table_pair(config.output_dir / "aaer_manifest", rows)
    LOGGER.info("AAER manifest complete: %s rows", len(rows))
    return rows


def fetch_aaer_year(config: PipelineConfig, client: SecHttpClient, year: int) -> list[dict[str, object]]:
    """Fetch every page of the SEC AAER listing for one year (100 releases per page)."""
    year_dir = ensure_dir(config.raw_aaer_dir / str(year))
    rows: list[dict[str, object]] = []
    for page in range(MAX_PAGES_PER_YEAR):
        url = f"{AAER_BASE_URL}?year={year}&month=All&order=field_publish_date&sort=desc&page={page}"
        try:
            page_html = client.get_text(url)
        except Exception as exc:
            LOGGER.warning("AAER page fetch failed for %s page %s: %s", year, page, exc)
            break
        write_text(year_dir / f"aaer_page_{page}.html", page_html)
        page_rows = parse_aaer_listing(page_html, page_url=url, year=year, client=client)
        if not page_rows:
            break
        rows.extend(page_rows)
    if not rows:
        url = AAER_LEGACY_URL_TEMPLATE.format(year=year)
        try:
            legacy_html = client.get_text(url)
            write_text(year_dir / "aaer_page_legacy.html", legacy_html)
            rows = parse_legacy_aaer_page(legacy_html, page_url=url, year=year, client=client)
        except Exception as exc:
            LOGGER.warning("Legacy AAER page fetch failed for %s: %s", year, exc)
    if config.download_aaer_documents:
        for row in rows:
            save_aaer_document(config, client, row)
    return rows


def parse_aaer_listing(page_html: str, page_url: str, year: int, client: SecHttpClient | None = None) -> list[dict[str, object]]:
    """Parse the current SEC listing table: one ``<tr>`` per release.

    A release can carry several AAER numbers; one output row is written per
    AAER number, all sharing the row's own date, respondents and document.
    """
    rows: list[dict[str, object]] = []
    for row_html in ROW_RE.findall(page_html):
        release_numbers_match = RELEASE_NO_RE.search(row_html)
        release_numbers = _strip_tags(release_numbers_match.group(1)) if release_numbers_match else ""
        aaer_numbers = [f"AAER-{n}" for n in AAER_RE.findall(release_numbers)]
        if not aaer_numbers:
            continue
        respondents_match = RESPONDENTS_RE.search(row_html)
        respondents_html = respondents_match.group(1) if respondents_match else ""
        doc_match = HREF_RE.search(respondents_html)
        document_url = _absolute(client, page_url, doc_match.group(1)) if doc_match else ""
        see_also_match = SEE_ALSO_RE.search(row_html)
        see_also = [_absolute(client, page_url, h) for h in HREF_RE.findall(see_also_match.group(1))] if see_also_match else []
        date_match = TIME_RE.search(row_html)
        other_numbers = [n.strip() for n in release_numbers.split(",") if n.strip() and not AAER_RE.search(n)]
        for aaer_no in aaer_numbers:
            rows.append(
                {
                    "year": year,
                    "aaer_no": aaer_no,
                    "release_date": date_match.group(1) if date_match else "",
                    "release_no": "|".join(other_numbers),
                    "respondents": _strip_tags(respondents_html),
                    "document_url": document_url,
                    "see_also_urls": "|".join(see_also),
                    "source_page_url": page_url,
                    "parse_method": "listing_row",
                }
            )
    return rows


def parse_legacy_aaer_page(page_html: str, page_url: str, year: int, client: SecHttpClient | None = None) -> list[dict[str, object]]:
    """Fallback for archived friactions pages: one table row per release."""
    rows: list[dict[str, object]] = []
    for row_html in re.findall(r"<tr[^>]*>(.*?)</tr>", page_html, re.IGNORECASE | re.DOTALL):
        text = _strip_tags(row_html)
        aaer_numbers = [f"AAER-{n}" for n in AAER_RE.findall(text)]
        if not aaer_numbers:
            continue
        doc_match = HREF_RE.search(row_html)
        cells = [_strip_tags(c) for c in re.findall(r"<td[^>]*>(.*?)</td>", row_html, re.IGNORECASE | re.DOTALL)]
        respondents = max(cells, key=len) if cells else text
        for aaer_no in aaer_numbers:
            rows.append(
                {
                    "year": year,
                    "aaer_no": aaer_no,
                    "release_date": "",
                    "release_no": "",
                    "respondents": AAER_RE.sub("", respondents).strip(" ,"),
                    "document_url": _absolute(client, page_url, doc_match.group(1)) if doc_match else "",
                    "see_also_urls": "",
                    "source_page_url": page_url,
                    "parse_method": "legacy_row",
                }
            )
    return rows


def _absolute(client: SecHttpClient | None, base: str, href: str) -> str:
    if client is not None:
        return client.absolute_url(base, href)
    from urllib.parse import urljoin

    return urljoin(base, href)


def save_aaer_document(config: PipelineConfig, client: SecHttpClient, row: dict[str, object]) -> None:
    """Download the release document (usually a PDF) and, if possible, its text."""
    url = str(row.get("document_url", ""))
    year_dir = config.raw_aaer_dir / str(row.get("year", "unknown"))
    stem = safe_filename(str(row.get("aaer_no", "aaer")))
    row["aaer_document_path"] = ""
    row["aaer_text_path"] = ""
    if not url:
        return
    try:
        if url.lower().endswith(".pdf"):
            pdf_path = client.download_bytes(url, year_dir / f"{stem}.pdf")
            row["aaer_document_path"] = str(pdf_path)
            text = pdf_to_text(pdf_path)
        else:
            text = re.sub(r"<[^>]+>", " ", client.get_text(url))
        if text:
            text_path = year_dir / f"{stem}.txt"
            write_text(text_path, text)
            row["aaer_text_path"] = str(text_path)
    except Exception as exc:
        row["aaer_document_error"] = str(exc)


def pdf_to_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""
    try:
        reader = PdfReader(str(path))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception:
        return ""


def dedupe_aaer_rows(rows: Iterable[dict[str, object]]) -> list[dict[str, object]]:
    seen = set()
    out = []
    for row in rows:
        key = (row.get("aaer_no"), row.get("respondents"))
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


# --------------------------------------------------------------------------
# Company matching (candidates for manual review, never final labels)
# --------------------------------------------------------------------------

PARTY_SPLIT_RE = re.compile(r",|;|\band\b|\bet\s+al\b|\(|\)", re.IGNORECASE)
GENERIC_NAME_TOKENS = {"group", "international", "global", "the", "of", "systems", "technologies", "technology", "industries", "enterprises", "capital", "financial"}


def respondent_parties(respondents: str) -> list[str]:
    parties = []
    for part in PARTY_SPLIT_RE.split(respondents or ""):
        norm = normalize_name(part)
        if norm and norm not in {"cpa", "cpas", "inc", "llp", "llc", "pc", "p c"}:
            parties.append(norm)
    return parties


def match_aaer_company(aaer_row: dict[str, object], company: dict[str, object]) -> tuple[str, str]:
    """Return (match_method, matched_party) or ("", "").

    Only respondent party names are compared, at whole-party level. Tickers
    and substring containment are not used: they produced false positives
    such as Copa Holdings (ticker CPA) matching every "..., CPA" respondent.
    """
    parties = respondent_parties(str(aaer_row.get("respondents", "")))
    if not parties:
        return "", ""
    names = [("exact_name", company.get("name", ""))]
    names += [("former_name", n) for n in str(company.get("former_names", "")).split("|")]
    for method, name in names:
        norm = normalize_name(str(name))
        if len(norm) < 4:
            continue
        for party in parties:
            if party == norm:
                return method, party
    for method, name in names:
        norm = normalize_name(str(name))
        tokens = [t for t in norm.split() if t not in GENERIC_NAME_TOKENS]
        if len(tokens) < 2:
            continue
        for party in parties:
            party_tokens = party.split()
            if len(party_tokens) >= 2 and (norm.startswith(party + " ") or party.startswith(norm + " ")):
                return f"{method}_prefix", party
    return "", ""


def build_aaer_company_matches(
    config: PipelineConfig,
    companies: Iterable[dict[str, object]],
    aaer_rows: Iterable[dict[str, object]],
) -> list[dict[str, object]]:
    aaer_list = list(aaer_rows)
    matches: list[dict[str, object]] = []
    for company in companies:
        for row in aaer_list:
            method, party = match_aaer_company(row, company)
            if not method:
                continue
            matches.append(
                {
                    "cik": cik10(company.get("cik", "")),
                    "company_name": company.get("name", ""),
                    "aaer_no": row.get("aaer_no", ""),
                    "release_date": row.get("release_date", ""),
                    "release_year": row.get("year", ""),
                    "respondents": row.get("respondents", ""),
                    "matched_party": party,
                    "match_method": method,
                    "needs_review": int(method.endswith("_prefix") or method.startswith("former")),
                    "document_url": row.get("document_url", ""),
                }
            )
    write_table_pair(config.output_dir / "aaer_company_matches", matches)
    LOGGER.info("AAER-company candidate matches: %s", len(matches))
    return matches


# --------------------------------------------------------------------------
# Labels
# --------------------------------------------------------------------------

def _year(value: object) -> int | None:
    match = re.search(r"(\d{4})", str(value or ""))
    return int(match.group(1)) if match else None


def build_fraud_labels(
    config: PipelineConfig,
    companies: Iterable[dict[str, object]],
    aaer_rows: Iterable[dict[str, object]],
    cases: list[dict[str, str]] | None = None,
) -> list[dict[str, object]]:
    """Company x fiscal-year labels.

    * ``aaer_release_in_year`` / ``aaer_numbers``: automatic name matches of
      AAERs *released* in that calendar year. This is an enforcement-date flag,
      not a misconduct-period label, and it is unverified.
    * When a verified cases file is supplied (see README), case columns are
      added and ``fraud_aaer_label`` is 1 for a case firm's fiscal years inside
      the assessment window before the first public revelation. Peers are 0.
      Without a cases file ``fraud_aaer_label`` falls back to the unverified
      enforcement-year flag and ``label_source`` says so.
    """
    company_list = list(companies)
    matches = build_aaer_company_matches(config, company_list, aaer_rows)
    matches_by_cik: dict[str, list[dict[str, object]]] = {}
    for match in matches:
        matches_by_cik.setdefault(str(match["cik"]), []).append(match)

    cases_by_cik = {cik10(c["cik"]): c for c in (cases or []) if c.get("cik")}
    case_rows_by_id = {c.get("case_id", ""): c for c in (cases or []) if c.get("role", "case") == "case"}

    labels: list[dict[str, object]] = []
    progress = ProgressLogger(LOGGER, "Fraud-label companies", total=len(company_list), every=config.progress_interval)
    for index, company in enumerate(company_list, start=1):
        cik = cik10(company.get("cik", ""))
        company_matches = matches_by_cik.get(cik, [])
        case = cases_by_cik.get(cik)
        anchor = None
        if case:
            anchor = case if case.get("role", "case") == "case" else case_rows_by_id.get(case.get("matched_case_id", ""))
        for year in range(config.start_year, config.end_year + 1):
            in_year = [m for m in company_matches if _year(m.get("release_date")) == year or str(m.get("release_year")) == str(year)]
            row: dict[str, object] = {
                "cik": cik,
                "ticker": company.get("ticker", ""),
                "company_name": company.get("name", ""),
                "fiscal_year": year,
                "aaer_release_in_year": int(bool(in_year)),
                "aaer_numbers": "|".join(str(m["aaer_no"]) for m in in_year),
                "aaer_release_dates": "|".join(str(m["release_date"]) for m in in_year),
                "aaer_match_methods": "|".join(str(m["match_method"]) for m in in_year),
                "ever_aaer_matched": int(bool(company_matches)),
            }
            if cases is not None:
                row.update(_case_columns(case, anchor, year, config.assessment_window_years))
                if case and row["event_time"] == "":
                    # No revelation date for this cluster yet: the label is unknown, not 0.
                    row["fraud_aaer_label"] = ""
                    row["label_source"] = "cases_file_missing_revelation_date"
                else:
                    row["fraud_aaer_label"] = row["in_assessment_window"] if row["case_role"] == "case" else 0
                    row["label_source"] = "verified_cases_file" if case else "not_in_cases_file"
            else:
                row["fraud_aaer_label"] = row["aaer_release_in_year"]
                row["label_source"] = "auto_aaer_name_match_unverified_enforcement_year"
            labels.append(row)
        progress.log(index, extra=f"latest CIK={cik}")
    write_table_pair(config.output_dir / "fraud_labels", labels)
    LOGGER.info("Fraud labels complete: %s rows", len(labels))
    return labels


def _case_columns(case: dict[str, str] | None, anchor: dict[str, str] | None, year: int, window: int) -> dict[str, object]:
    if not case:
        return {
            "case_id": "", "case_role": "", "matched_case_id": "", "rpt_relevance": "",
            "misconduct_period": "", "event_time": "", "in_assessment_window": 0,
        }
    role = case.get("role", "case") or "case"
    revelation_year = _year((anchor or {}).get("revelation_date"))
    event_time = year - revelation_year if revelation_year else ""
    misconduct = ""
    if role == "case":
        start, end = _year(case.get("misconduct_start_fy")), _year(case.get("misconduct_end_fy"))
        if start and end:
            misconduct = int(start <= year <= end)
    in_window: object = int(-window <= event_time <= -1) if isinstance(event_time, int) else ""
    return {
        "case_id": case.get("case_id", "") if role == "case" else case.get("matched_case_id", ""),
        "case_role": role,
        "matched_case_id": case.get("matched_case_id", ""),
        "rpt_relevance": (anchor or {}).get("rpt_relevance", ""),
        "misconduct_period": misconduct,
        "event_time": event_time,
        "in_assessment_window": in_window,
    }

