from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse


URL_RE = re.compile(r"https?://[^\s\"'<>]+", re.IGNORECASE)
CIK_RE = re.compile(r"\bCIK\s*[:#-]?\s*(\d{1,10})\b", re.IGNORECASE)
TICKER_RE = re.compile(r"\b[A-Z]{1,5}(?:\.[A-Z])?\b")


def extract_trigger_values(data: Any) -> dict[str, set[str]]:
    values = {"urls": set(), "ciks": set(), "tickers": set(), "company_names": set()}
    _walk(data, values)
    return values


def _walk(value: Any, values: dict[str, set[str]]) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            key_l = str(key).lower()
            if key_l in {"cik", "central_index_key"}:
                values["ciks"].add(str(item).zfill(10))
            elif key_l in {"ticker", "symbol"}:
                values["tickers"].add(str(item).upper())
            elif key_l in {"company", "company_name", "name", "issuer"}:
                if isinstance(item, str) and len(item.strip()) > 2:
                    values["company_names"].add(item.strip())
            _walk(item, values)
    elif isinstance(value, list):
        for item in value:
            _walk(item, values)
    elif isinstance(value, str):
        for url in URL_RE.findall(value):
            values["urls"].add(url.rstrip(".,);]"))
            parsed = urlparse(url)
            host_parts = parsed.netloc.split(".")
            if host_parts:
                possible = host_parts[0].upper()
                if 1 <= len(possible) <= 5 and possible.isalpha():
                    values["tickers"].add(possible)
        for cik in CIK_RE.findall(value):
            values["ciks"].add(cik.zfill(10))


def company_matches_trigger(row: dict[str, object], trigger_values: dict[str, set[str]]) -> bool:
    cik = str(row.get("cik", "")).zfill(10)
    tickers = {t.strip().upper() for t in str(row.get("tickers", "")).split("|") if t.strip()}
    name = normalize_name(str(row.get("name", "")))
    trigger_names = {normalize_name(n) for n in trigger_values.get("company_names", set())}
    if cik in trigger_values.get("ciks", set()):
        return True
    if tickers & trigger_values.get("tickers", set()):
        return True
    return any(name and (name in t or t in name) for t in trigger_names)


def normalize_name(name: str) -> str:
    value = re.sub(r"[^a-z0-9 ]+", " ", name.lower())
    value = re.sub(
        r"\b(incorporated|inc|corp|corporation|co|company|ltd|limited|plc|llc|lp|holdings|holding)\b",
        " ",
        value,
    )
    return re.sub(r"\s+", " ", value).strip()

