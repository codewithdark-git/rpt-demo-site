from __future__ import annotations

import logging
import sys
from time import monotonic


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
        force=True,
    )


class ProgressLogger:
    def __init__(self, logger: logging.Logger, label: str, total: int | None = None, every: int = 100) -> None:
        self.logger = logger
        self.label = label
        self.total = total
        self.every = max(1, every)
        self.started_at = monotonic()

    def log(self, count: int, extra: str = "") -> None:
        if count != 1 and count != self.total and count % self.every != 0:
            return
        elapsed = monotonic() - self.started_at
        rate = count / elapsed if elapsed > 0 else 0
        total_text = f"/{self.total}" if self.total else ""
        extra_text = f" | {extra}" if extra else ""
        self.logger.info("%s: %s%s complete | %.2f/sec%s", self.label, count, total_text, rate, extra_text)

