"""SEC EDGAR RPT / AAER research dataset pipeline."""

__version__ = "0.1.0"

