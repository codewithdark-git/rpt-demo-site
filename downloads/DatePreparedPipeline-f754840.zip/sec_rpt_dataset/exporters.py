from __future__ import annotations

from pathlib import Path
from typing import Mapping, Sequence

from .io_utils import ensure_dir, write_csv

EXCEL_MAX_ROWS = 1_048_000


def write_table_pair(base_path_without_suffix: Path, rows: Sequence[Mapping[str, object]]) -> None:
    csv_path = base_path_without_suffix.with_suffix(".csv")
    xlsx_path = base_path_without_suffix.with_suffix(".xlsx")
    write_csv(csv_path, rows)
    write_excel_workbook(xlsx_path, {base_path_without_suffix.name[:31]: rows})


def write_excel_workbook(path: Path, sheets: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    # CSV is the canonical output; Excel copies are a convenience and are skipped
    # (not fatal) when pandas/openpyxl are not installed.
    try:
        import openpyxl  # noqa: F401
        import pandas as pd
    except ImportError:
        return

    ensure_dir(path.parent)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for sheet_name, rows in sheets.items():
            rows = list(rows)
            if not rows:
                pd.DataFrame().to_excel(writer, index=False, sheet_name=safe_sheet_name(sheet_name))
                continue
            for index, start in enumerate(range(0, len(rows), EXCEL_MAX_ROWS)):
                chunk = rows[start : start + EXCEL_MAX_ROWS]
                name = safe_sheet_name(sheet_name if index == 0 else f"{sheet_name}_{index + 1}")
                pd.DataFrame(chunk).to_excel(writer, index=False, sheet_name=name)


def safe_sheet_name(name: str) -> str:
    bad = "[]:*?/\\"
    cleaned = "".join("_" if ch in bad else ch for ch in str(name))
    return (cleaned or "Sheet")[:31]

