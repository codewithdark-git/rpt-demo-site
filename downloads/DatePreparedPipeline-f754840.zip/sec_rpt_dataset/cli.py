from __future__ import annotations

import argparse
from pathlib import Path

from .aaer import build_aaer_manifest, build_fraud_labels
from .company import build_company_universe, load_cases, print_company_preview
from .config import PipelineConfig
from .documents import download_extract_score_filings
from .filings import build_manifests
from .financials import build_xbrl_financials
from .hub import DEFAULT_REPO_ID, ciks_from_cases, download_dataset, upload_dataset
from .logging_utils import setup_logging
from .pipeline import build_master_panel, build_qa_report, load_rows, make_client, run_all
from .exporters import write_excel_workbook
from .io_utils import write_csv


def main() -> None:
    parser = argparse.ArgumentParser(description="SEC EDGAR RPT / AAER dataset pipeline")
    sub = parser.add_subparsers(dest="command", required=True)

    add_common(sub.add_parser("companies", help="Fetch and display SEC company universe"))
    sub.choices["companies"].add_argument("--display-limit", type=int, default=25, help="Rows to print; use -1 for all")

    add_common(sub.add_parser("manifest", help="Build 10-K filing manifest"))
    add_common(sub.add_parser("download-filings", help="Download filings, extract Item 1/13, and score NLP"))
    sub.choices["download-filings"].add_argument("--limit-filings", type=int, default=None)

    add_common(sub.add_parser("xbrl", help="Build annual XBRL financials (as first reported)"))
    add_common(sub.add_parser("aaer", help="Build AAER manifest, candidate matches and fraud labels"))
    add_common(sub.add_parser("merge", help="Rebuild master_panel and dataset_qa.json from existing CSVs"))
    add_common(sub.add_parser("run-sample", help="Run a small end-to-end smoke test"))
    sub.choices["run-sample"].add_argument("--limit-filings", type=int, default=2)
    sub.choices["run-sample"].set_defaults(limit_companies=2, limit_filings=2)

    add_common(sub.add_parser("run-all", help="Run the full pipeline"))
    for name in ("run-sample", "run-all"):
        sub.choices[name].add_argument("--upload", action="store_true", help="Publish the output directory to the Hugging Face Hub when the run finishes")
        sub.choices[name].add_argument("--resume-from-hub", action="store_true", help="Download already-published files for the cases-file CIKs first, so finished work is skipped")

    upload = add_common(sub.add_parser("upload", help="Publish an existing output directory to the Hugging Face Hub"))
    upload.add_argument("--private", action="store_true")
    upload.add_argument("--include-xlsx", action="store_true", help="Also upload the Excel copies")
    upload.add_argument("--no-raw", action="store_true", help="Upload the tables only, not raw/ texts")
    upload.add_argument("--dry-run", action="store_true", help="List what would be uploaded; no network writes")

    download = add_common(sub.add_parser("download", help="Fetch the published dataset (or part of it) into --output-dir"))
    download.add_argument("--mode", choices=["metadata", "full", "ciks"], default="metadata")
    download.add_argument("--ciks", nargs="*", default=None, help="CIKs whose raw files to fetch (mode=ciks); defaults to the --cases-csv CIKs")
    download.add_argument("--revision", default=None, help="Hub revision (branch, tag or commit)")

    args = parser.parse_args()
    config = config_from_args(args)
    setup_logging(config.log_level)

    if args.command == "upload":
        summary = upload_dataset(
            config.output_dir, args.repo_id, private=args.private, include_xlsx=args.include_xlsx,
            include_raw=not args.no_raw, dry_run=args.dry_run,
        )
        if args.dry_run:
            for group, files in summary.pop("files", {}).items():
                print(f"{group}: {len(files)} files")
                for f in files[:50]:
                    print("  ", f)
                if len(files) > 50:
                    print(f"   ... {len(files) - 50} more")
        print(summary)
        return
    if args.command == "download":
        ciks = args.ciks or (ciks_from_cases(config.cases_csv) if config.cases_csv else None)
        path = download_dataset(config.output_dir, args.repo_id, mode=args.mode, ciks=ciks, revision=args.revision)
        print(f"Downloaded {args.repo_id} ({args.mode}) into {path}")
        return

    client = make_client(config)

    if args.command == "companies":
        rows = build_company_universe(config, client, limit=args.limit_companies, trigger_card_json=args.trigger_card_json, trigger_card_url=args.trigger_card_url)
        print_company_preview(rows, args.display_limit)
    elif args.command == "manifest":
        companies = load_rows(config.output_dir / "company_universe.csv")
        rows, proxies = build_manifests(config, client, companies)
        print(f"Wrote {len(rows)} filing manifest rows and {len(proxies)} proxy rows")
    elif args.command == "download-filings":
        manifest = load_rows(config.output_dir / "filing_manifest.csv")
        proxy_path = config.output_dir / "proxy_manifest.csv"
        proxies = load_rows(proxy_path) if config.include_proxies and proxy_path.exists() else []
        extraction, scores = download_extract_score_filings(config, client, manifest, limit_filings=args.limit_filings, proxy_rows=proxies)
        print(f"Wrote {len(extraction)} extraction rows and {len(scores)} NLP score rows")
    elif args.command == "aaer":
        companies = load_rows(config.output_dir / "company_universe.csv")
        aaer_rows = build_aaer_manifest(config, client)
        cases = load_cases(config.cases_csv) if config.cases_csv else None
        labels = build_fraud_labels(config, companies, aaer_rows, cases=cases)
        print(f"Wrote {len(aaer_rows)} AAER rows and {len(labels)} fraud-label rows")
    elif args.command == "xbrl":
        companies = load_rows(config.output_dir / "company_universe.csv")
        rows = build_xbrl_financials(config, client, companies)
        print(f"Wrote {len(rows)} XBRL company-year rows")
    elif args.command == "merge":
        out = config.output_dir
        optional = lambda name: load_rows(out / name) if (out / name).exists() else []
        master = build_master_panel(
            load_rows(out / "company_universe.csv"), load_rows(out / "filing_manifest.csv"),
            optional("extraction_manifest.csv"), optional("nlp_scores.csv"),
            optional("fraud_labels.csv"), optional("xbrl_financials.csv"),
        )
        write_csv(out / "master_panel.csv", master)
        write_excel_workbook(out / "master_panel.xlsx", {"master_panel": master})
        print(build_qa_report(config, master))
    elif args.command in {"run-sample", "run-all"}:
        counts = run_all(
            config,
            limit_companies=args.limit_companies,
            limit_filings=args.limit_filings if args.command == "run-sample" else None,
            trigger_card_json=args.trigger_card_json,
            trigger_card_url=args.trigger_card_url,
            upload=args.upload,
            repo_id=args.repo_id,
            resume_from_hub=args.resume_from_hub,
        )
        print(counts)


def add_common(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    parser.add_argument("--output-dir", type=Path, default=Path("data"))
    parser.add_argument("--repo-id", default=DEFAULT_REPO_ID, help="Hugging Face dataset repo id")
    parser.add_argument("--start-year", type=int, default=2000)
    parser.add_argument("--end-year", type=int, default=2026)
    parser.add_argument("--include-amendments", action="store_true")
    parser.add_argument("--request-delay-seconds", type=float, default=0.2)
    parser.add_argument("--timeout-seconds", type=int, default=60)
    parser.add_argument("--max-retries", type=int, default=4)
    parser.add_argument("--progress-interval", type=int, default=100, help="Log progress every N companies/filings")
    parser.add_argument("--checkpoint-interval", type=int, default=100, help="Write partial CSV checkpoints every N companies/filings; use 0 to disable")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
    parser.add_argument("--quiet", action="store_true", help="Only show errors")
    parser.add_argument("--user-agent", default=None)
    parser.add_argument("--lm-dictionary", type=Path, default=None)
    parser.add_argument("--limit-companies", type=int, default=None)
    parser.add_argument("--trigger-card-json", type=Path, default=None)
    parser.add_argument("--trigger-card-url", default=None)
    parser.add_argument("--cases-csv", type=Path, default=None, help="Verified case/peer file; drives the universe and labels (see README)")
    parser.add_argument("--aaer-start-year", type=int, default=None, help="First AAER listing year to crawl (default: --start-year)")
    parser.add_argument("--assessment-window", type=int, default=5, help="Years before first public revelation labelled 1 for case firms")
    parser.add_argument("--min-text-words", type=int, default=40, help="Texts shorter than this are treated as missing")
    parser.add_argument("--no-proxies", action="store_true", help="Skip DEF 14A related-party sections")
    parser.add_argument("--no-xbrl", action="store_true", help="Skip XBRL company facts")
    parser.add_argument("--no-aaer-documents", action="store_true", help="Do not download AAER release PDFs")
    return parser


def config_from_args(args: argparse.Namespace) -> PipelineConfig:
    kwargs = {
        "output_dir": args.output_dir,
        "start_year": args.start_year,
        "end_year": args.end_year,
        "include_amendments": args.include_amendments,
        "request_delay_seconds": args.request_delay_seconds,
        "timeout_seconds": args.timeout_seconds,
        "max_retries": args.max_retries,
        "progress_interval": args.progress_interval,
        "checkpoint_interval": args.checkpoint_interval,
        "log_level": "ERROR" if args.quiet else args.log_level,
        "lm_dictionary": args.lm_dictionary,
        "cases_csv": args.cases_csv,
        "aaer_start_year_override": args.aaer_start_year,
        "assessment_window_years": args.assessment_window,
        "min_text_words": args.min_text_words,
        "include_proxies": not args.no_proxies,
        "include_xbrl": not args.no_xbrl,
        "download_aaer_documents": not args.no_aaer_documents,
    }
    if args.user_agent:
        kwargs["user_agent"] = args.user_agent
    return PipelineConfig(**kwargs)


if __name__ == "__main__":
    main()
