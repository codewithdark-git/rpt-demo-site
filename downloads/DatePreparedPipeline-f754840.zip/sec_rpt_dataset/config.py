from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


COMPANY_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
COMPANY_TICKERS_FALLBACK = "https://efts.sec.gov/LATEST/search-index/company_tickers.json"
SUBMISSIONS_BASE_URL = "https://data.sec.gov/submissions"
ARCHIVES_BASE_URL = "https://www.sec.gov/Archives/edgar/data"
AAER_BASE_URL = "https://www.sec.gov/enforcement-litigation/accounting-auditing-enforcement-releases"
COMPANY_FACTS_URL_TEMPLATE = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik10}.json"
AAER_LEGACY_URL_TEMPLATE = "https://www.sec.gov/divisions/enforce/friactions/friactions{year}.shtml"


@dataclass(frozen=True)
class PipelineConfig:
    output_dir: Path = Path("data")
    start_year: int = 2000
    end_year: int = 2026
    include_amendments: bool = False
    request_delay_seconds: float = 0.2
    timeout_seconds: int = 60
    max_retries: int = 4
    progress_interval: int = 100
    checkpoint_interval: int = 100
    log_level: str = "INFO"
    user_agent: str = field(
        default_factory=lambda: os.environ.get(
            "SEC_USER_AGENT",
            "SEC RPT Dataset Builder contact@example.com",
        )
    )
    lm_dictionary: Path | None = None
    # Thesis-panel options
    cases_csv: Path | None = None
    aaer_start_year_override: int | None = None
    assessment_window_years: int = 5
    include_proxies: bool = True
    include_xbrl: bool = True
    download_aaer_documents: bool = True
    min_text_words: int = 40

    @property
    def aaer_start_year(self) -> int:
        return self.aaer_start_year_override or self.start_year

    @property
    def raw_dir(self) -> Path:
        return self.output_dir / "raw"

    @property
    def raw_filings_dir(self) -> Path:
        return self.raw_dir / "filings"

    @property
    def raw_aaer_dir(self) -> Path:
        return self.raw_dir / "aaer"

    @property
    def raw_proxies_dir(self) -> Path:
        return self.raw_dir / "proxies"

    @property
    def raw_xbrl_dir(self) -> Path:
        return self.raw_dir / "xbrl"
