from __future__ import annotations

import csv
import re
from pathlib import Path

WORD_RE = re.compile(r"[A-Za-z][A-Za-z'-]*")
SENTENCE_RE = re.compile(r"[.!?]+(?:\s+|$)")

UNCERTAINTY_WORDS = {
    "approximate", "approximately", "contingent", "could", "depend", "depends",
    "fluctuate", "indefinite", "may", "might", "possible", "possibly",
    "risk", "risks", "uncertain", "uncertainties", "uncertainty", "unknown",
    "vary", "volatile", "volatility", "would",
}

NEGATIVE_WORDS = {
    "adverse", "breach", "decline", "default", "deficiency", "delay", "fail",
    "failed", "failure", "fraud", "impairment", "investigation", "loss",
    "losses", "penalty", "restatement", "violation", "weakness",
}

POSITIVE_WORDS = {
    "achieve", "benefit", "effective", "favorable", "gain", "growth",
    "improve", "improved", "opportunity", "positive", "profit", "success",
    "successful",
}


def load_lm_dictionary(path: Path | None) -> dict[str, set[str]]:
    if not path:
        return {
            "uncertainty": set(UNCERTAINTY_WORDS),
            "negative": set(NEGATIVE_WORDS),
            "positive": set(POSITIVE_WORDS),
            "source": {"built_in_lightweight"},
        }
    buckets = {"uncertainty": set(), "negative": set(), "positive": set(), "source": {str(path)}}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            word = (row.get("Word") or row.get("word") or "").strip().lower()
            if not word:
                continue
            for key, column in (("negative", "Negative"), ("positive", "Positive"), ("uncertainty", "Uncertainty")):
                value = row.get(column) or row.get(column.lower()) or ""
                if str(value).strip() not in {"", "0"}:
                    buckets[key].add(word)
    return buckets


def score_text(
    text: str,
    dictionary: dict[str, set[str]] | None = None,
    prefix: str = "",
    min_words: int = 0,
) -> dict[str, object]:
    """Readability and dictionary scores.

    When the text has fewer than ``min_words`` words (missing section, TOC line,
    "incorporated by reference" stub), every score is blank rather than 0 and
    ``text_available`` is 0, so missing text cannot masquerade as plain text.
    """
    dictionary = dictionary or load_lm_dictionary(None)
    words = [w.lower().strip("'") for w in WORD_RE.findall(text)]
    word_count = len(words)
    if min_words and word_count < min_words:
        values = {key: "" for key in SCORE_KEYS}
        values.update({"word_count": word_count, "text_available": 0, "dictionary_source": "|".join(sorted(dictionary.get("source", set())))})
        return {f"{prefix}_{key}": value for key, value in values.items()} if prefix else values
    sentence_count = max(1, len(SENTENCE_RE.findall(text)) or (1 if text.strip() else 0))
    syllables = sum(count_syllables(word) for word in words)
    complex_words = sum(1 for word in words if count_syllables(word) >= 3)
    uncertainty = sum(1 for word in words if word in dictionary["uncertainty"])
    negative = sum(1 for word in words if word in dictionary["negative"])
    positive = sum(1 for word in words if word in dictionary["positive"])
    fog = 0.0
    fk = 0.0
    if word_count:
        fog = 0.4 * ((word_count / sentence_count) + 100 * (complex_words / word_count))
        fk = 0.39 * (word_count / sentence_count) + 11.8 * (syllables / word_count) - 15.59
    values = {
        "word_count": word_count,
        "text_available": 1,
        "sentence_count": 0 if not text.strip() else sentence_count,
        "avg_words_per_sentence": round(word_count / sentence_count, 4) if sentence_count else 0,
        "complex_word_count": complex_words,
        "fog_index": round(fog, 4),
        "flesch_kincaid_grade": round(fk, 4),
        "uncertainty_word_count": uncertainty,
        "vagueness_ratio": round(uncertainty / word_count, 6) if word_count else 0,
        "negative_word_count": negative,
        "negative_ratio": round(negative / word_count, 6) if word_count else 0,
        "positive_word_count": positive,
        "positive_ratio": round(positive / word_count, 6) if word_count else 0,
        "net_sentiment_ratio": round((positive - negative) / word_count, 6) if word_count else 0,
        "dictionary_source": "|".join(sorted(dictionary.get("source", set()))),
    }
    if prefix:
        return {f"{prefix}_{key}": value for key, value in values.items()}
    return values


SCORE_KEYS = (
    "word_count", "text_available", "sentence_count", "avg_words_per_sentence", "complex_word_count",
    "fog_index", "flesch_kincaid_grade", "uncertainty_word_count", "vagueness_ratio",
    "negative_word_count", "negative_ratio", "positive_word_count", "positive_ratio",
    "net_sentiment_ratio", "dictionary_source",
)


def count_syllables(word: str) -> int:
    word = re.sub(r"[^a-z]", "", word.lower())
    if not word:
        return 0
    vowels = "aeiouy"
    groups = 0
    prev_is_vowel = False
    for char in word:
        is_vowel = char in vowels
        if is_vowel and not prev_is_vowel:
            groups += 1
        prev_is_vowel = is_vowel
    if word.endswith("e") and groups > 1:
        groups -= 1
    return max(groups, 1)

