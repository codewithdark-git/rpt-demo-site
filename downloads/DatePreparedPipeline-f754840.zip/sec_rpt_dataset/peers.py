"""Rule-based peer matching (design decision D4).

For each case firm: candidates share the 4-digit SIC code (3-digit if fewer
than ``min_pool`` candidates), are not themselves cases or AAER-matched firms,
have a total-assets observation in every window year (proxy for an annual
report each year, verified against EDGAR submissions afterwards), and are the
``k`` nearest in log total assets measured in the calendar year before the
revelation year. Matching is without replacement across cases.
"""
from __future__ import annotations

import logging
from typing import Iterable

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)


def match_peers(
    cases: pd.DataFrame,
    universe_assets: pd.DataFrame,
    universe_sic: pd.DataFrame,
    exclude_ciks: Iterable[str] = (),
    k: int = 5,
    min_pool: int = 8,
    window: int = 5,
) -> pd.DataFrame:
    """Return peer rows: cik, matched_case_id, sic_level, ln_assets_gap, size_year, pool_size.

    ``cases`` needs columns cik, case_id, sic, revelation_date (YYYY-MM-DD).
    ``universe_assets`` needs cik, cal_year, total_assets; ``universe_sic`` needs cik, sic.
    """
    ua = universe_assets.copy()
    ua["cik"] = ua["cik"].str.zfill(10)
    ua["cal_year"] = ua["cal_year"].astype(int)
    ua["total_assets"] = pd.to_numeric(ua["total_assets"], errors="coerce")
    sic_of = dict(zip(universe_sic["cik"].str.zfill(10), universe_sic["sic"].astype(str)))
    years_of = ua.groupby("cik")["cal_year"].agg(set).to_dict()
    assets = ua.set_index(["cik", "cal_year"])["total_assets"]
    excluded = set(str(c).zfill(10) for c in exclude_ciks) | set(cases["cik"].str.zfill(10))
    used: set[str] = set()
    out = []
    for _, c in cases.iterrows():
        cik, sic4 = str(c["cik"]).zfill(10), str(c["sic"])
        rev_year = int(str(c["revelation_date"])[:4])
        size_year = rev_year - 1
        window_years = set(range(rev_year - window, rev_year))
        target = assets.get((cik, size_year), np.nan)
        if np.isnan(target):
            # fall back to the latest observation inside the window
            obs = [assets.get((cik, y), np.nan) for y in sorted(window_years, reverse=True)]
            target = next((v for v in obs if not np.isnan(v)), np.nan)
        for level, test in (("sic4", lambda s: s == sic4), ("sic3", lambda s: s[:3] == sic4[:3]), ("sic2", lambda s: s[:2] == sic4[:2])):
            pool = [p for p, s in sic_of.items() if test(s) and p not in excluded and p not in used
                    and window_years <= years_of.get(p, set()) and not np.isnan(assets.get((p, size_year), np.nan))]
            if len(pool) >= min_pool or level == "sic2":
                break
        if np.isnan(target) or not pool:
            LOGGER.warning("%s: no size anchor or empty pool (level %s)", c["case_id"], level)
            continue
        gaps = sorted(((abs(np.log(assets[(p, size_year)]) - np.log(target)), p) for p in pool if assets[(p, size_year)] > 0), key=lambda t: t[0])
        for gap, p in gaps[:k]:
            used.add(p)
            out.append({"cik": p, "matched_case_id": c["case_id"], "sic_level": level, "peer_sic": sic_of[p],
                        "ln_assets_gap": round(float(gap), 3), "size_year": size_year, "pool_size": len(pool),
                        "peer_assets": float(assets[(p, size_year)]), "case_assets": float(target)})
    return pd.DataFrame(out)
