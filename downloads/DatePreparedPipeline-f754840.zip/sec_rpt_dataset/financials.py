"""Annual financial variables from SEC XBRL company facts (FY2009 onwards).

Values are taken *as first reported*: for each fiscal year the earliest-filed
10-K value is kept, so later restatements do not leak into pre-revelation
years. Note that SEC company facts only contain non-dimensional facts; RPT
amounts tagged on a related-party axis are not available here and must be
hand-collected from the related-party note (see ``rp_note.txt``).
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Iterable

from .config import COMPANY_FACTS_URL_TEMPLATE, PipelineConfig
from .exporters import write_table_pair
from .http_client import SecHttpClient
from .io_utils import cik10, read_json, write_csv, write_json
from .logging_utils import ProgressLogger

LOGGER = logging.getLogger(__name__)
ANNUAL_FORMS = {"10-K", "10-K405", "10-KT", "10-KSB", "10-KSB40"}

# variable: (period type, candidate us-gaap tags in priority order)
XBRL_VARIABLES: dict[str, tuple[str, list[str]]] = {
    "total_assets": ("instant", ["Assets"]),
    "total_liabilities": ("instant", ["Liabilities"]),
    "stockholders_equity": ("instant", ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"]),
    "long_term_debt": ("instant", ["LongTermDebt", "LongTermDebtNoncurrent"]),
    "revenue": ("duration", ["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet", "RevenueFromContractWithCustomerIncludingAssessedTax", "SalesRevenueGoodsNet"]),
    "net_income": ("duration", ["NetIncomeLoss", "ProfitLoss"]),
    "operating_cash_flow": ("duration", ["NetCashProvidedByUsedInOperatingActivities", "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"]),
    "rp_transaction_amount": ("duration", ["RelatedPartyTransactionAmountsOfTransaction"]),
    "rp_revenue": ("duration", ["RevenueFromRelatedParties"]),
    "rp_expenses": ("duration", ["RelatedPartyTransactionExpensesFromTransactionsWithRelatedParty", "CostsAndExpensesRelatedParty"]),
    "due_from_related_parties_current": ("instant", ["DueFromRelatedPartiesCurrent", "AccountsReceivableRelatedPartiesCurrent", "DueFromRelatedPartiesCurrentAndNoncurrent", "DueFromRelatedParties"]),
    "due_from_related_parties_noncurrent": ("instant", ["DueFromRelatedPartiesNoncurrent", "AccountsReceivableRelatedPartiesNoncurrent"]),
    "notes_receivable_related_parties": ("instant", ["NotesReceivableRelatedPartiesCurrent", "NotesReceivableRelatedPartiesNoncurrent", "NotesAndLoansReceivableNetCurrentRelatedParties"]),
    "due_to_related_parties_current": ("instant", ["DueToRelatedPartiesCurrent", "AccountsPayableRelatedPartiesCurrent", "DueToRelatedPartiesCurrentAndNoncurrent"]),
}


def build_xbrl_financials(
    config: PipelineConfig,
    client: SecHttpClient,
    companies: Iterable[dict[str, object]],
) -> list[dict[str, object]]:
    companies = list(companies)
    rows: list[dict[str, object]] = []
    progress = ProgressLogger(LOGGER, "XBRL company facts", total=len(companies), every=config.progress_interval)
    for index, company in enumerate(companies, start=1):
        cik = cik10(company.get("cik", ""))
        cache = config.raw_xbrl_dir / f"CIK{cik}.json"
        try:
            if cache.exists():
                facts = read_json(cache)
            else:
                facts = client.get_json(COMPANY_FACTS_URL_TEMPLATE.format(cik10=cik))
                write_json(cache, facts)
        except Exception as exc:
            LOGGER.debug("No XBRL company facts for %s: %s", cik, exc)
            facts = {}
        rows.extend(extract_annual_values(facts, cik, config.start_year, config.end_year))
        progress.log(index, extra=f"latest CIK={cik}")
        if config.checkpoint_interval and index % config.checkpoint_interval == 0:
            write_csv(config.output_dir / "xbrl_financials_partial.csv", rows)
    write_table_pair(config.output_dir / "xbrl_financials", rows)
    LOGGER.info("XBRL financials complete: %s company-years", len(rows))
    return rows


def extract_annual_values(facts: dict[str, Any], cik: str, start_year: int, end_year: int) -> list[dict[str, object]]:
    gaap = (facts or {}).get("facts", {}).get("us-gaap", {})
    by_year: dict[int, dict[str, object]] = {}
    for variable, (period_type, tags) in XBRL_VARIABLES.items():
        # Tags are tried in priority order; later tags only fill years the earlier ones miss.
        for tag in tags:
            for year, (value, accession, _filed) in _first_reported_by_year(gaap.get(tag, {}), period_type).items():
                if not (start_year <= year <= end_year):
                    continue
                row = by_year.setdefault(year, {"cik": cik, "fiscal_year": year})
                if variable not in row:
                    row[variable] = value
                    row[f"{variable}_tag"] = tag
                    row[f"{variable}_accession"] = accession
    return [by_year[y] for y in sorted(by_year)]


def _first_reported_by_year(tag_facts: dict[str, Any], period_type: str) -> dict[int, tuple[float, str, str]]:
    out: dict[int, tuple[float, str, str]] = {}
    for entry in tag_facts.get("units", {}).get("USD", []):
        if entry.get("form") not in ANNUAL_FORMS:
            continue
        end = _parse(entry.get("end"))
        if end is None:
            continue
        if period_type == "duration":
            start = _parse(entry.get("start"))
            if start is None or not (300 <= (end - start).days <= 400):
                continue
        year = end.year - 1 if end.month <= 5 else end.year
        filed = str(entry.get("filed", ""))
        if year not in out or filed < out[year][2]:
            out[year] = (entry.get("val"), str(entry.get("accn", "")), filed)
    return out


def _parse(value: object) -> date | None:
    text = str(value or "")
    try:
        return date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (ValueError, IndexError):
        return None
