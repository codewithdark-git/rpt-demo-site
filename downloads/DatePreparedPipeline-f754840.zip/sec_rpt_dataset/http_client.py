from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from .io_utils import ensure_dir


class SecHttpClient:
    def __init__(
        self,
        user_agent: str,
        delay_seconds: float = 0.2,
        timeout_seconds: int = 60,
        max_retries: int = 4,
    ) -> None:
        self.user_agent = user_agent
        self.delay_seconds = delay_seconds
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self._last_request_at = 0.0

    def absolute_url(self, base_url: str, href: str) -> str:
        return urljoin(base_url, href)

    def _request(self, url: str, accept: str) -> bytes:
        wait = self.delay_seconds - (time.monotonic() - self._last_request_at)
        if wait > 0:
            time.sleep(wait)

        headers = {
            "User-Agent": self.user_agent,
            "Accept-Encoding": "identity",
            "Accept": accept,
        }
        request = Request(url, headers=headers)

        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with urlopen(request, timeout=self.timeout_seconds) as response:
                    self._last_request_at = time.monotonic()
                    return response.read()
            except HTTPError as exc:
                last_error = exc
                if exc.code in {403, 404}:
                    raise
                retry_after = exc.headers.get("Retry-After")
                if retry_after and retry_after.isdigit():
                    time.sleep(float(retry_after))
                else:
                    time.sleep(min(2 ** attempt, 30))
            except URLError as exc:
                last_error = exc
                time.sleep(min(2 ** attempt, 30))
        if last_error:
            raise last_error
        raise RuntimeError(f"Failed to request {url}")

    def get_text(self, url: str) -> str:
        data = self._request(url, "text/html,text/plain,application/xhtml+xml,*/*")
        return data.decode("utf-8", errors="replace")

    def get_json(self, url: str) -> Any:
        data = self._request(url, "application/json,*/*")
        return json.loads(data.decode("utf-8", errors="replace"))

    def download_bytes(self, url: str, path: Path, overwrite: bool = False) -> Path:
        if path.exists() and not overwrite:
            return path
        data = self._request(url, "*/*")
        ensure_dir(path.parent)
        path.write_bytes(data)
        return path

    def download_text(self, url: str, path: Path, overwrite: bool = False) -> Path:
        if path.exists() and not overwrite:
            return path
        text = self.get_text(url)
        ensure_dir(path.parent)
        path.write_text(text, encoding="utf-8", errors="replace")
        return path

