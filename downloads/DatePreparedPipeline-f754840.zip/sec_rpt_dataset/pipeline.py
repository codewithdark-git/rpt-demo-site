from __future__ import annotations

import logging
from collections import Counter
from pathlib import Path

from .aaer import build_aaer_manifest, build_fraud_labels
from .company import build_company_universe, load_cases
from .config import PipelineConfig
from .documents import download_extract_score_filings
from .exporters import write_excel_workbook
from .filings import build_manifests
from .financials import build_xbrl_financials
from .http_client import SecHttpClient
from .hub import DEFAULT_REPO_ID
from .io_utils import read_csv, write_csv, write_json

LOGGER = logging.getLogger(__name__)
DATASET_VERSION = "2.0.0"


def make_client(config: PipelineConfig) -> SecHttpClient:
    return SecHttpClient(
        user_agent=config.user_agent,
        delay_seconds=config.request_delay_seconds,
        timeout_seconds=config.timeout_seconds,
        max_retries=config.max_retries,
    )


def run_all(
    config: PipelineConfig,
    limit_companies: int | None = None,
    limit_filings: int | None = None,
    trigger_card_json: Path | None = None,
    trigger_card_url: str | None = None,
    upload: bool = False,
    repo_id: str = DEFAULT_REPO_ID,
    resume_from_hub: bool = False,
) -> dict[str, object]:
    """Run every phase. With ``resume_from_hub`` the published files for the
    cases-file CIKs are fetched first, so already-processed filings are skipped;
    with ``upload`` the finished output directory is pushed back to the Hub."""
    client = make_client(config)
    LOGGER.info("Starting SEC RPT dataset run: years=%s-%s output_dir=%s", config.start_year, config.end_year, config.output_dir)
    cases = load_cases(config.cases_csv) if config.cases_csv else None
    if resume_from_hub:
        from .hub import download_dataset

        ciks = [c["cik"] for c in cases] if cases else None
        try:
            download_dataset(config.output_dir, repo_id, mode="ciks" if ciks else "metadata", ciks=ciks)
        except Exception as exc:  # a missing/empty repo is not an error on the first run
            LOGGER.warning("Resume from %s skipped: %s", repo_id, exc)
    companies = build_company_universe(config, client, limit=limit_companies, trigger_card_json=trigger_card_json, trigger_card_url=trigger_card_url)
    manifest, proxies = build_manifests(config, client, companies)
    extraction, scores = download_extract_score_filings(config, client, manifest, limit_filings=limit_filings, proxy_rows=proxies)
    financials = build_xbrl_financials(config, client, companies) if config.include_xbrl else []
    aaer_rows = build_aaer_manifest(config, client)
    labels = build_fraud_labels(config, companies, aaer_rows, cases=cases)
    master = build_master_panel(companies, manifest, extraction, scores, labels, financials)
    write_csv(config.output_dir / "master_panel.csv", master)
    write_excel_workbook(config.output_dir / "master_panel.xlsx", {"master_panel": master})
    qa = build_qa_report(config, master)
    LOGGER.info("Run complete: master panel rows=%s", len(master))
    counts: dict[str, object] = {
        "companies": len(companies),
        "filings": len(manifest),
        "extractions": len(extraction),
        "xbrl_company_years": len(financials),
        "aaer_rows": len(aaer_rows),
        "fraud_labels": len(labels),
        "master_rows": len(master),
        "rpt_text_available": qa["rpt_text_available"],
    }
    if upload:
        from .hub import upload_dataset

        summary = upload_dataset(config.output_dir, repo_id, version=DATASET_VERSION)
        counts["uploaded_metadata_files"] = summary["metadata_files"]
        counts["uploaded_raw_files"] = summary["raw_files"]
        counts["hub_url"] = summary.get("url", "")
    return counts


def build_master_panel(
    companies: list[dict[str, object]],
    manifest: list[dict[str, object]],
    extraction: list[dict[str, object]],
    scores: list[dict[str, object]],
    labels: list[dict[str, object]],
    financials: list[dict[str, object]] | None = None,
) -> list[dict[str, object]]:
    """One row per 10-K (accession). Labels and XBRL join on (cik, fiscal_year)."""
    company_by_cik = {str(row.get("cik")): row for row in companies}
    extraction_by_accession = {str(row.get("accession_number")): row for row in extraction}
    scores_by_accession = {str(row.get("accession_number")): row for row in scores}
    labels_by_key = {(str(row.get("cik")), str(row.get("fiscal_year", row.get("year")))): row for row in labels}
    financials_by_key = {(str(row.get("cik")), str(row.get("fiscal_year"))): row for row in financials or []}
    master: list[dict[str, object]] = []
    for filing in manifest:
        if not filing.get("accession_number"):
            continue
        cik = str(filing.get("cik"))
        fiscal_year = str(filing.get("fiscal_year", filing.get("year")))
        accession = str(filing.get("accession_number"))
        row: dict[str, object] = {"dataset_version": DATASET_VERSION}
        row.update(company_by_cik.get(cik, {}))
        row.update(filing)
        row.update({f"extract_{k}": v for k, v in extraction_by_accession.get(accession, {}).items() if k not in row})
        row.update({k: v for k, v in scores_by_accession.get(accession, {}).items() if k not in row})
        row.update({f"xbrl_{k}": v for k, v in financials_by_key.get((cik, fiscal_year), {}).items() if k not in {"cik", "fiscal_year"}})
        row.update({k: v for k, v in labels_by_key.get((cik, fiscal_year), {}).items() if k not in row})
        master.append(row)
    return master


def build_qa_report(config: PipelineConfig, master: list[dict[str, object]]) -> dict[str, object]:
    """Coverage summary written to dataset_qa.json; publish it with the dataset card."""
    total = len(master)

    def share(predicate) -> float:
        return round(sum(1 for r in master if predicate(r)) / total, 4) if total else 0.0

    report: dict[str, object] = {
        "dataset_version": DATASET_VERSION,
        "filings": total,
        "companies": len({r.get("cik") for r in master}),
        "fiscal_years": dict(sorted(Counter(str(r.get("fiscal_year", r.get("year"))) for r in master).items())),
        "forms": dict(Counter(str(r.get("form")) for r in master)),
        "primary_filings": sum(1 for r in master if str(r.get("is_primary_filing")) == "1"),
        "rpt_text_available": sum(1 for r in master if str(r.get("rpt_disclosure_text_available")) == "1"),
        "rpt_text_source": dict(Counter(str(r.get("rpt_text_source", "none")) for r in master)),
        "share_item13_incorporated_by_reference": share(lambda r: str(r.get("extract_item13_incorporated_by_reference")) == "1"),
        "share_item9a_available": share(lambda r: str(r.get("extract_icfr_text_available")) == "1"),
        "share_rp_note_found": share(lambda r: str(r.get("extract_rp_note_status")) == "ok"),
        "share_xbrl_total_assets": share(lambda r: r.get("xbrl_total_assets") not in (None, "")),
        "extraction_errors": sum(1 for r in master if r.get("extract_extraction_status") == "error"),
        "fraud_label_positive_rows": sum(1 for r in master if str(r.get("fraud_aaer_label")) == "1"),
        "label_source": dict(Counter(str(r.get("label_source", "")) for r in master)),
    }
    write_json(config.output_dir / "dataset_qa.json", report)
    return report


def load_rows(path: Path) -> list[dict[str, str]]:
    return read_csv(path)
