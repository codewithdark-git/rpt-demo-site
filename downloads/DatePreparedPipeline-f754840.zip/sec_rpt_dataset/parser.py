from __future__ import annotations

import html
import re
from html.parser import HTMLParser


class TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() in {"script", "style", "noscript"}:
            self._skip_depth += 1
        if tag.lower() in {"p", "div", "br", "tr", "li", "table", "h1", "h2", "h3"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"script", "style", "noscript"} and self._skip_depth:
            self._skip_depth -= 1
        if tag.lower() in {"p", "div", "tr", "li", "table", "h1", "h2", "h3"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._skip_depth:
            self.parts.append(data)

    def text(self) -> str:
        return normalize_text(" ".join(self.parts))


def html_to_text(raw: str) -> str:
    head = raw[:2000].lower()
    if "<html" not in head and "<document" not in head and "<p" not in head and "<?xml" not in head:
        return normalize_text(raw)
    parser = TextExtractor()
    try:
        parser.feed(raw)
        return parser.text()
    except Exception:
        return normalize_text(re.sub(r"<[^>]+>", " ", html.unescape(raw)))


def normalize_text(text: str) -> str:
    text = html.unescape(text)
    text = text.replace("\xa0", " ").replace("​", "")
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t\f\v]+", " ", text)
    text = re.sub(r"\n\s+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z][A-Za-z'-]*", text))


# --------------------------------------------------------------------------
# 10-K items
# --------------------------------------------------------------------------

ITEM_SPECS = {
    # item: (end items, minimum words for a substantive section)
    "1": (["1A", "1B", "2"], 150),
    "9A": (["9B", "10"], 40),
    "13": (["14", "15"], 40),
}

INCORPORATED_BY_REFERENCE_RE = re.compile(
    r"incorporated\s+(?:herein\s+)?(?:in\s+its\s+entirety\s+)?by\s+(?:this\s+)?reference|"
    r"will\s+be\s+(?:included|set\s+forth|contained)\s+in\s+(?:our|the|its)\s+(?:definitive\s+)?proxy|"
    r"(?:included|set\s+forth|contained)\s+in\s+(?:our|the|its)\s+(?:definitive\s+)?proxy\s+statement",
    re.IGNORECASE,
)


def extract_item(text_or_html: str, item: str) -> tuple[str, str]:
    """Return (section_text, status) for a 10-K item.

    Headings are only accepted at the start of a line, and the longest
    candidate section wins, so table-of-contents entries ("Item 13. Certain
    Relationships ... 89") are skipped in favour of the body section.

    Status values: ``ok``, ``short_section`` (only a short candidate such as a
    TOC line or a one-sentence cross-reference was found), ``start_not_found``.
    """
    if item not in ITEM_SPECS:
        raise ValueError(f"Unsupported item: {item}")
    end_items, min_words = ITEM_SPECS[item]
    text = html_to_text(text_or_html)
    return _extract_between_items(text, item, end_items, min_words)


def _extract_between_items(text: str, start_item: str, end_items: list[str], min_words: int) -> tuple[str, str]:
    start_matches = list(item_heading_pattern(start_item).finditer(text))
    if not start_matches:
        return "", "start_not_found"
    end_patterns = [item_heading_pattern(end_item) for end_item in end_items]
    end_patterns.append(re.compile(r"(?im)^[ \t]*part[ \t]+iv\b"))
    candidates: list[str] = []
    for match in start_matches:
        end = len(text)
        for pattern in end_patterns:
            next_match = pattern.search(text, match.end())
            if next_match:
                end = min(end, next_match.start())
        candidates.append(normalize_text(text[match.start():end]))
    best = max(candidates, key=word_count)
    if word_count(best) >= min_words:
        return best, "ok"
    return best, "short_section"


def item_heading_pattern(item: str) -> re.Pattern[str]:
    number = re.match(r"\d+", item).group(0)
    letter = item[len(number):]
    letter_part = rf"[ \t]*{letter}" if letter else ""
    # Line-anchored; the trailing lookahead stops "Item 1" matching "Item 13"/"Item 1A".
    return re.compile(rf"(?im)^[ \t]*item[ \t]*{number}{letter_part}(?![0-9A-Za-z])")


def is_incorporated_by_reference(section: str, max_words: int = 400) -> bool:
    """True when an item mainly points to the proxy statement instead of disclosing."""
    if not section:
        return False
    head = " ".join(section.split()[:max_words])
    return bool(INCORPORATED_BY_REFERENCE_RE.search(head)) and word_count(section) < max_words


# --------------------------------------------------------------------------
# Related-party note in the financial statements
# --------------------------------------------------------------------------

NOTE_HEADING_RE = re.compile(
    r"(?im)^[ \t]*(?:note[ \t]+)?(\d{1,2})[ \t]*[.:\-–—)]?[ \t]+([A-Z][^\n]{2,100})$"
)
RP_KEYWORD_RE = re.compile(r"related[ \t-]+part(?:y|ies)|related[ \t-]+person", re.IGNORECASE)


def extract_rp_note(text_or_html: str, min_words: int = 40) -> tuple[str, str]:
    """Extract the financial-statement note titled e.g. "26. RELATED PARTY TRANSACTIONS"."""
    text = html_to_text(text_or_html)
    headings = list(NOTE_HEADING_RE.finditer(text))
    candidates: list[tuple[bool, str]] = []
    for index, match in enumerate(headings):
        title = match.group(2)
        if not RP_KEYWORD_RE.search(title) or title.lower().startswith(("risk", "item")):
            continue
        number = int(match.group(1))
        end = len(text)
        for later in headings[index + 1:]:
            if int(later.group(1)) == number + 1:
                end = later.start()
                break
        candidates.append(("transaction" in title.lower(), normalize_text(text[match.start():end][:200_000])))
    if not candidates:
        return "", "start_not_found"
    # Prefer the "Related Party Transactions" note over e.g. "Investments - Related Parties".
    _, best = max(candidates, key=lambda c: (c[0], word_count(c[1])))
    return best, "ok" if word_count(best) >= min_words else "short_section"


# --------------------------------------------------------------------------
# Proxy statement (DEF 14A) related-party section
# --------------------------------------------------------------------------

PROXY_RPT_HEADING_RE = re.compile(
    r"(?im)^[^\n]{0,15}?(certain[ \t]+relationships[ \t]+and[ \t]+related[^\n]{0,80}|"
    r"related[ \t-]+(?:party|person|persons)[ \t]+transactions?[^\n]{0,60}|"
    r"transactions[ \t]+with[ \t]+related[ \t]+(?:parties|persons)[^\n]{0,60})$"
)
PROXY_TOP_HEADINGS = (
    "proposal", "stockholder proposals", "shareholder proposals", "proposals of stockholders",
    "proposals of shareholders", "other business", "other matters", "section 16(a)",
    "delinquent section 16", "audit committee report", "report of the audit committee",
    "executive compensation", "compensation discussion", "director compensation",
    "security ownership", "householding", "annual report", "independent registered",
    "principal accountant", "equity compensation plan", "where you can find", "appendix",
    "corporate governance", "board of directors", "executive officers", "code of ethics",
)
ENTITY_SUFFIX_RE = re.compile(r"\b(LLC|L\.L\.C\.|INC\.?|LTD\.?|CORP\.?|L\.P\.|LP|TRUST|PLC|N\.V\.)\b")


def _is_proxy_heading(line: str) -> bool:
    stripped = line.strip()
    if not (6 <= len(stripped) <= 120) or len(stripped.split()) < 2:
        return False
    lower = stripped.lower()
    if RP_KEYWORD_RE.search(stripped) or "certain relationships" in lower:
        return False
    if lower.startswith(PROXY_TOP_HEADINGS):
        return True
    letters = [c for c in stripped if c.isalpha()]
    if not letters or sum(c.isupper() for c in letters) / len(letters) < 0.85:
        return False
    # Upper-case party names ("PHILOU VENTURES, LLC") are sub-headings inside the section.
    return not ENTITY_SUFFIX_RE.search(stripped)


def extract_proxy_rpt_section(text_or_html: str, min_words: int = 40, max_words: int = 20_000) -> tuple[str, str]:
    """Extract the related-party section of a proxy statement."""
    text = html_to_text(text_or_html)
    candidates: list[str] = []
    for match in PROXY_RPT_HEADING_RE.finditer(text):
        end = len(text)
        position = match.end()
        for line_match in re.finditer(r"(?m)^[^\n]+$", text[position:]):
            if _is_proxy_heading(line_match.group(0)):
                end = position + line_match.start()
                break
        section = normalize_text(text[match.start():end])
        words = section.split()
        if len(words) > max_words:
            section = " ".join(words[:max_words])
        candidates.append(section)
    if not candidates:
        return "", "start_not_found"
    best = max(candidates, key=word_count)
    return best, "ok" if word_count(best) >= min_words else "short_section"


# --------------------------------------------------------------------------
# Item 9A internal-control flags
# --------------------------------------------------------------------------

_ICFR = r"internal\s+control\s+over\s+financial\s+reporting"
_DCP = r"disclosure\s+controls\s+and\s+procedures"
_NOT_EFFECTIVE = r"(?:were|was|are|is)\s+not\s+effective|(?:were|was|are|is)\s+ineffective"
ICFR_NOT_EFFECTIVE_RE = re.compile(rf"{_ICFR}[^.]{{0,250}}?(?:{_NOT_EFFECTIVE})|(?:{_NOT_EFFECTIVE})[^.]{{0,60}}?{_ICFR}|did\s+not\s+maintain\s+effective\s+{_ICFR}", re.IGNORECASE)
ICFR_EFFECTIVE_RE = re.compile(rf"{_ICFR}[^.]{{0,250}}?(?:was|is|were)\s+effective|maintained[^.]{{0,40}}effective\s+{_ICFR}", re.IGNORECASE)
DCP_NOT_EFFECTIVE_RE = re.compile(rf"{_DCP}[^.]{{0,250}}?(?:{_NOT_EFFECTIVE})", re.IGNORECASE)
MATERIAL_WEAKNESS_RE = re.compile(r"material\s+weakness(?:es)?", re.IGNORECASE)
# Auditor-report and definitional boilerplate that mentions material weaknesses without reporting one.
MW_BOILERPLATE_RE = re.compile(
    r"risk\s+that\s+a\s+material\s+weakness\s+exist[s]?|"
    r"a\s+material\s+weakness\s+is\s+a\s+deficiency[^.]*\.|"
    r"(?:no|not\s+identify\s+any|did\s+not\s+identify\s+any|absence\s+of\s+(?:any\s+)?)\s*material\s+weakness(?:es)?",
    re.IGNORECASE,
)
MW_IDENTIFIED_RE = re.compile(
    r"(?:identified|identify|disclosed|existence\s+of|following|remediat\w*|resulted\s+in|constitute[sd]?|due\s+to)[^.]{0,80}material\s+weakness|"
    r"material\s+weakness(?:es)?[^.]{0,80}(?:identified|existed|exists|remain|was\s+not\s+remediated|has\s+not\s+been\s+remediated)",
    re.IGNORECASE,
)
MW_REMEDIATED_RE = re.compile(r"material\s+weakness(?:es)?[^.]{0,60}(?:has|have)\s+been\s+remediated|remediat\w+\s+(?:of\s+)?the\s+material\s+weakness", re.IGNORECASE)
AUDITOR_ATTESTATION_RE = re.compile(r"attestation\s+report|report\s+of\s+independent\s+registered\s+public\s+accounting\s+firm", re.IGNORECASE)
ATTESTATION_EXEMPT_RE = re.compile(r"(?:not\s+(?:subject\s+to|required\s+to\s+(?:include|provide))|does\s+not\s+include)[^.]{0,80}attestation", re.IGNORECASE)


def icfr_flags(item9a: str) -> dict[str, object]:
    """Indicators from Item 9A. Values are blank when no Item 9A text is available."""
    if not item9a or word_count(item9a) < 20:
        return {
            "icfr_text_available": 0,
            "icfr_not_effective": "",
            "icfr_effective_stated": "",
            "dcp_not_effective": "",
            "material_weakness_mentions": "",
            "material_weakness_reported": "",
            "material_weakness_remediated": "",
            "auditor_attestation_mentioned": "",
            "auditor_attestation_exempt": "",
        }
    not_effective = bool(ICFR_NOT_EFFECTIVE_RE.search(item9a))
    substantive = MW_BOILERPLATE_RE.sub(" ", item9a)
    mw_mentions = len(MATERIAL_WEAKNESS_RE.findall(substantive))
    mw_identified = bool(MW_IDENTIFIED_RE.search(substantive))
    return {
        "icfr_text_available": 1,
        "icfr_not_effective": int(not_effective),
        "icfr_effective_stated": int(bool(ICFR_EFFECTIVE_RE.search(item9a)) and not not_effective),
        "dcp_not_effective": int(bool(DCP_NOT_EFFECTIVE_RE.search(item9a))),
        "material_weakness_mentions": mw_mentions,
        # 1 can mean a weakness disclosed during the year and remediated by year end;
        # icfr_not_effective is the year-end conclusion.
        "material_weakness_reported": int(not_effective or mw_identified),
        "material_weakness_remediated": int(bool(MW_REMEDIATED_RE.search(substantive))),
        "auditor_attestation_mentioned": int(bool(AUDITOR_ATTESTATION_RE.search(item9a))),
        "auditor_attestation_exempt": int(bool(ATTESTATION_EXEMPT_RE.search(item9a))),
    }
