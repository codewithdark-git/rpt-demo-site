"""Single entry point for building and publishing the SEC-RPT-Panel dataset (Colab-friendly).

Every parameter can be given as a flag or an environment variable, so in Colab:

    !pip install -q -r requirements.txt
    import os
    os.environ["HF_TOKEN"] = "hf_..."                       # write token (never commit it)
    os.environ["SEC_USER_AGENT"] = "Your Name you@uni.edu"  # SEC fair-access policy
    !python run_pipeline.py --cases-csv cases.csv --start-year 2005 --end-year 2024 \
        --repo-id codewithdark/SEC-RPT-Panel --upload --resume-from-hub

``--resume-from-hub`` first downloads what the Hub already holds for the
cases-file CIKs, so a restarted Colab session continues instead of redoing
finished filings; ``--upload`` pushes tables and raw texts when the run ends.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sec_rpt_dataset.config import PipelineConfig  # noqa: E402
from sec_rpt_dataset.hub import DEFAULT_REPO_ID  # noqa: E402
from sec_rpt_dataset.logging_utils import setup_logging  # noqa: E402
from sec_rpt_dataset.pipeline import run_all  # noqa: E402


def env(name: str, default):
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return type(default)(value) if default is not None and not isinstance(default, bool) else value


def main() -> None:
    p = argparse.ArgumentParser(description="Build the SEC-RPT-Panel dataset and publish it to the Hugging Face Hub")
    p.add_argument("--cases-csv", type=Path, default=env("CASES_CSV", None) and Path(os.environ["CASES_CSV"]),
                   help="verified case/peer file (default: $CASES_CSV); omit for the whole SEC ticker universe")
    p.add_argument("--output-dir", type=Path, default=Path(env("OUTPUT_DIR", "data")))
    p.add_argument("--start-year", type=int, default=int(env("START_YEAR", 2005)))
    p.add_argument("--end-year", type=int, default=int(env("END_YEAR", 2024)))
    p.add_argument("--aaer-start-year", type=int, default=int(env("AAER_START_YEAR", 0)) or None)
    p.add_argument("--assessment-window", type=int, default=int(env("ASSESSMENT_WINDOW", 5)))
    p.add_argument("--repo-id", default=env("HF_REPO_ID", DEFAULT_REPO_ID))
    p.add_argument("--upload", action="store_true", default=env("HF_UPLOAD", "0") in {"1", "true", "yes"})
    p.add_argument("--resume-from-hub", action="store_true", default=env("HF_RESUME", "0") in {"1", "true", "yes"})
    p.add_argument("--no-proxies", action="store_true")
    p.add_argument("--no-xbrl", action="store_true")
    p.add_argument("--no-aaer-documents", action="store_true")
    p.add_argument("--request-delay-seconds", type=float, default=float(env("SEC_DELAY", 0.2)))
    p.add_argument("--limit-companies", type=int, default=None, help="smoke test: first N companies only")
    p.add_argument("--limit-filings", type=int, default=None, help="smoke test: first N filings only")
    p.add_argument("--log-level", default=env("LOG_LEVEL", "INFO"))
    args = p.parse_args()

    if not os.environ.get("SEC_USER_AGENT"):
        p.error("set SEC_USER_AGENT='Your Name you@example.edu' (SEC requires a contact in automated requests)")
    if args.upload and not (os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")):
        p.error("--upload needs HF_TOKEN in the environment")

    config = PipelineConfig(
        output_dir=args.output_dir, start_year=args.start_year, end_year=args.end_year,
        aaer_start_year_override=args.aaer_start_year, assessment_window_years=args.assessment_window,
        cases_csv=args.cases_csv, include_proxies=not args.no_proxies, include_xbrl=not args.no_xbrl,
        download_aaer_documents=not args.no_aaer_documents, request_delay_seconds=args.request_delay_seconds,
        log_level=args.log_level, progress_interval=10, checkpoint_interval=25,
    )
    setup_logging(config.log_level)
    counts = run_all(config, limit_companies=args.limit_companies, limit_filings=args.limit_filings,
                     upload=args.upload, repo_id=args.repo_id, resume_from_hub=args.resume_from_hub)
    for key, value in counts.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
