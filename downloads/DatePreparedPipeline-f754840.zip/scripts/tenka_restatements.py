"""RESTATE from Form 10-K/A: amended annual reports that restate previously issued financial statements.

The design defines RESTATE as "1 if a restatement of prior accounts is announced in the year (Form 8-K; Form
10-K/A)". ``eightk_items.py`` covers the 8-K Item 4.02 half. This script covers the 10-K/A half from the EDGAR
submissions API (form list) plus the amendment's primary document: a 10-K/A counts only when its text says that
financial statements are restated (not a Part III-only amendment or an exhibit-only amendment).

    python scripts/tenka_restatements.py --cases-csv cases_core.csv --output data_core/tenka_restatements.csv

Output: one row per (cik, fiscal_year) with ``restatement_10ka`` (0/1), the number of 10-K/A filed that fiscal
year, the accession numbers and the sentence that carried the decision. Fiscal-year attribution follows
``eightk_items.py`` (filing date mapped with the company's fiscal-year-end month).
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import time
import urllib.request
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sec_rpt_dataset.company import cik10  # noqa: E402
from scripts.eightk_items import fiscal_year_of, get_json  # noqa: E402

UA = os.environ.get("SEC_USER_AGENT", "PhD research curam.rice@gmail.com")
BASE = "https://data.sec.gov/submissions/"
RESTATE = re.compile(
    r"\b(restat(?:e|ed|es|ement|ing)\s+(?:of\s+)?(?:our|its|the|previously|certain|consolidated|financial|prior)"
    r"|(?:previously\s+issued|prior\s+period)\s+(?:consolidated\s+)?financial\s+statements\s+(?:have\s+been|were|are\s+being|should\s+no\s+longer)"
    r"|should\s+no\s+longer\s+be\s+relied\s+upon|non-?reliance)\b", re.I)
PART_III_ONLY = re.compile(r"(?:sole|only)\s+purpose\s+of\s+this\s+amendment[^.]{0,200}part\s+iii|to\s+include\s+(?:the\s+)?(?:information\s+required\s+by\s+)?part\s+iii|part\s+iii\s+information", re.I)
EXHIBIT_ONLY = re.compile(r"(?:sole|only)\s+purpose\s+of\s+this\s+amendment[^.]{0,200}(?:exhibit|xbrl|interactive\s+data|certification|signature|typographical|cover\s+page)", re.I)
SENTENCE_END = re.compile(r"(?<=[.;])\s+(?=[A-Z(\"“])")


def fetch_text(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                raw = r.read()
            text = raw.decode("utf-8", "replace")
            text = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", text, flags=re.I | re.S)
            text = re.sub(r"<[^>]+>", " ", text)
            return html.unescape(re.sub(r"\s+", " ", text))
        except Exception:  # noqa: BLE001
            if attempt == 3:
                return ""
            time.sleep(2 * (attempt + 1))
    return ""


def classify(text: str) -> tuple[int, str, str]:
    """(restates financial statements?, reason, evidence sentence) from the first ~60k characters of the 10-K/A."""
    head = text[:60000]
    if not head:
        return 0, "no_text", ""
    expl = head[:15000]  # the explanatory note sits at the front
    if PART_III_ONLY.search(expl) and not RESTATE.search(expl):
        return 0, "part_iii_only", ""
    if EXHIBIT_ONLY.search(expl) and not RESTATE.search(expl):
        return 0, "exhibit_or_certification_only", ""
    m = RESTATE.search(head)
    if not m:
        return 0, "no_restatement_language", ""
    bounds = [b.end() for b in SENTENCE_END.finditer(head)]
    start = max([b for b in bounds if b <= m.start()], default=0)
    end = min([b for b in bounds if b > m.end()], default=min(len(head), m.end() + 300))
    return 1, "restatement_language", head[start:end][:400]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases-csv", required=True, nargs="+")
    ap.add_argument("--output", required=True)
    ap.add_argument("--start-year", type=int, default=2003)
    ap.add_argument("--delay", type=float, default=0.15)
    args = ap.parse_args()
    ciks: set[str] = set()
    for p in args.cases_csv:
        cases = pd.read_csv(p, dtype=str).fillna("")
        ciks |= {cik10(c) for c in cases["cik"] if c}
    ciks_sorted = sorted(ciks)
    out = Path(args.output)
    events_path = out.with_name(out.stem + "_events.csv")
    rows: list[dict] = []
    done: set[str] = set()
    if events_path.exists():  # resume: companies already fetched are kept
        prev = pd.read_csv(events_path, dtype={"cik": str}).fillna("")
        rows = prev.to_dict("records")
        done = set(prev["cik"].str.zfill(10))
    done_file = out.with_name(out.stem + "_done.txt")
    if done_file.exists():
        done |= set(done_file.read_text().split())
    for i, cik in enumerate(ciks_sorted, 1):
        if cik in done:
            continue
        try:
            d = get_json(f"{BASE}CIK{cik}.json")
        except Exception as exc:  # noqa: BLE001
            print(f"{cik}: submissions fetch failed ({exc}); retry on the next run", flush=True)
            time.sleep(5)
            continue
        fye = d.get("fiscalYearEnd") or ""
        fye_month = int(fye[:2]) if len(fye) == 4 and fye[:2].isdigit() else None
        batches = [d["filings"]["recent"]] + [get_json(BASE + e["name"]) for e in d["filings"].get("files", [])]
        for b in batches:
            docs = b.get("primaryDocument", [""] * len(b["form"]))
            descs = b.get("primaryDocDescription", [""] * len(b["form"]))
            for form, fdate, acc, doc, desc in zip(b["form"], b["filingDate"], b["accessionNumber"], docs, descs):
                if form not in ("10-K/A", "10-KT/A", "10-K405/A") or int(fdate[:4]) < args.start_year:
                    continue
                url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-', '')}/{doc}" if doc else ""
                text = fetch_text(url) if url else ""
                flag, reason, evidence = classify(text)
                rows.append({"cik": cik, "form": form, "filing_date": fdate, "accession_number": acc, "primary_document": doc,
                             "description": desc, "fiscal_year": fiscal_year_of(fdate, fye_month), "restatement_10ka": flag,
                             "reason": reason, "evidence": evidence})
                time.sleep(args.delay)
        time.sleep(args.delay)
        done.add(cik)
        out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(events_path, index=False)
        done_file.write_text("\n".join(sorted(done)))
        if i % 20 == 0:
            print(f"{i}/{len(ciks_sorted)} companies, {len(rows)} amendments so far", flush=True)
    ev = pd.DataFrame(rows)
    out.parent.mkdir(parents=True, exist_ok=True)
    ev.to_csv(events_path, index=False)
    if ev.empty:
        pd.DataFrame(columns=["cik", "fiscal_year", "n_10ka", "restatement_10ka", "accessions", "evidence"]).to_csv(out, index=False)
        print("no 10-K/A found")
        return
    agg = ev.groupby(["cik", "fiscal_year"]).agg(n_10ka=("accession_number", "size"), restatement_10ka=("restatement_10ka", "max"),
                                                 accessions=("accession_number", lambda s: ";".join(s)),
                                                 evidence=("evidence", lambda s: " | ".join(x for x in s if x)[:600])).reset_index()
    agg.to_csv(out, index=False)
    print(f"{out}: {len(ev)} amendments, {int(agg['restatement_10ka'].sum())} restating firm-years, "
          f"{ev['reason'].value_counts().to_dict()}")


if __name__ == "__main__":
    main()
