"""Build cases_gulfport.csv: the Gulfport Energy case (screened NEED_REVELATION_DATE on 2 Oct 2026) with its
rule-matched peers, so the sample decision can be taken on built data.

Revelation date (D2): 2018-11-01, Form 10-Q for Q3 2018, Item 4 / Item 5 — the company disclosed that in
September 2018 the Audit Committee was informed of the CEO's unauthorised use of chartered aircraft and personal
credit-card charges, not identified or disclosed in the proxy statements, and that the CEO stepped down on
29 October 2018 (accession 0001628280-18-013345). SEC settled order: Release 33-10930 / press release 2021-33,
24 February 2021 (undisclosed perquisites and related-person transactions, 2014-2018). D1 class: disclosure_only.
Window FY2013-2017: five 10-Ks on file.

    python scripts/make_gulfport_set.py --output cases_gulfport.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sec_rpt_dataset.peers import match_peers  # noqa: E402

CASE = {"case_id": "GULFPORT_ENERG", "cik": "0000874499", "sic": "1311", "revelation_date": "2018-11-01",
        "company_name": "Gulfport Energy", "d1_class": "disclosure_only", "confidence": "high"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="cases_gulfport.csv")
    args = ap.parse_args()
    cases = pd.DataFrame([CASE])
    universe_assets = pd.read_csv("scripts/universe_assets_fy.csv", dtype={"cik": str})
    universe_assets["cik"] = universe_assets["cik"].str.zfill(10)
    universe_sic = pd.read_csv("scripts/universe_ciks_by_sic.csv", dtype=str)
    universe_sic["cik"] = universe_sic["cik"].str.zfill(10)
    exclude = set()
    for f in ("cases_core.csv", "cases_sensitivity.csv"):
        exclude |= set(pd.read_csv(f, dtype=str)["cik"].str.zfill(10))
    aaer_path = Path("data_core/aaer_company_matches.csv")
    if aaer_path.exists():
        exclude |= set(pd.read_csv(aaer_path, dtype=str)["cik"].astype(str).str.zfill(10))
    peers = match_peers(cases, universe_assets, universe_sic, exclude_ciks=exclude, k=5, min_pool=8, window=5)
    rows = [{"case_id": CASE["case_id"], "cik": CASE["cik"], "ticker": "GPOR", "company_name": CASE["company_name"], "role": "case",
             "matched_case_id": "", "aaer_numbers": "Rel. 33-10930 (not on the AAER list)", "misconduct_start_fy": "2014", "misconduct_end_fy": "2018",
             "revelation_date": CASE["revelation_date"], "revelation_source": "10-Q Q3 2018 (0001628280-18-013345): Audit Committee informed Sept 2018 of undisclosed CEO aircraft use and personal charges; CEO stepped down 2018-10-29",
             "revelation_verified": "YES", "rpt_relevance": "Strong", "stratum": "disclosure_only", "d1_class": "disclosure_only",
             "confidence": "high", "cik_source": "edgar_verified"}]
    for _, p in peers.iterrows():
        rows.append({"case_id": "", "cik": p["cik"], "ticker": "", "company_name": "", "role": "peer", "matched_case_id": p["matched_case_id"],
                     "aaer_numbers": "", "misconduct_start_fy": "", "misconduct_end_fy": "", "revelation_date": "", "revelation_source": "",
                     "revelation_verified": "", "rpt_relevance": "", "stratum": "disclosure_only", "d1_class": "", "confidence": "",
                     "cik_source": f"rule_matched sic_{p['sic_level']} gap={float(p['ln_assets_gap']):.2f}"})
    out = pd.DataFrame(rows)
    out.to_csv(args.output, index=False)
    peers.to_csv("scripts/peers_matched_gulfport.csv", index=False)
    print(f"{args.output}: 1 case, {len(peers)} peers")
    print(peers.to_string())


if __name__ == "__main__":
    main()
