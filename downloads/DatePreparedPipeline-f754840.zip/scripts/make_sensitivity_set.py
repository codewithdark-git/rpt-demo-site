"""Build cases_sensitivity.csv: the cases that fail the design's four-report rule but have three annual
reports in the window (plus their rule-matched peers), as an external validation set for the trained model.

Matching follows rule D4 (same SIC-4, fallback SIC-3/SIC-2; nearest ln total assets in the fiscal year before
revelation; no AAER match). Where no XBRL asset value exists for the anchor year (windows before 2009) the
earliest available year up to three years later is used as the size anchor and the row says so.

    python scripts/make_sensitivity_set.py --output cases_sensitivity.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sec_rpt_dataset.peers import match_peers  # noqa: E402

MIN_REPORTS = 3


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="cases_sensitivity.csv")
    args = ap.parse_args()
    screen = pd.read_csv("scripts/phase_a_screen_v2.csv", dtype=str).fillna("")
    cand = screen[(screen["screen"] == "FAIL_4_REPORTS") & (pd.to_numeric(screen["tenk_in_window"], errors="coerce") >= MIN_REPORTS)].copy()
    cand = cand[cand["window"].str[:4].astype(int) >= 2005]  # same era rule as the core
    cand["case_id"] = cand["company"].str.upper().str.replace(r"[^A-Z0-9]+", "_", regex=True).str[:14].str.strip("_")
    cases = pd.DataFrame({"case_id": cand["case_id"], "cik": cand["cik"].str.zfill(10), "sic": cand["sic"], "revelation_date": cand["revelation_date"],
                          "company_name": cand["company"], "d1_class": cand["d1_class"], "confidence": cand["confidence"]})
    universe_assets = pd.read_csv("scripts/universe_assets_fy.csv", dtype={"cik": str})
    universe_assets["cik"] = universe_assets["cik"].str.zfill(10)
    universe_sic = pd.read_csv("scripts/universe_ciks_by_sic.csv", dtype=str)
    universe_sic["cik"] = universe_sic["cik"].str.zfill(10)
    core = pd.read_csv("cases_core.csv", dtype=str)
    exclude = set(core["cik"].str.zfill(10)) | set(cases["cik"])
    aaer = pd.read_csv("data_core/aaer_company_matches.csv", dtype=str) if Path("data_core/aaer_company_matches.csv").exists() else pd.DataFrame(columns=["cik"])
    exclude |= set(aaer["cik"].astype(str).str.zfill(10))
    peers_all = []
    for shift in (0, 1, 2, 3):
        pending = cases[~cases["case_id"].isin({p["matched_case_id"] for p in peers_all})] if peers_all else cases
        if pending.empty:
            break
        shifted = pending.copy()
        shifted["revelation_date"] = (pd.to_datetime(shifted["revelation_date"]) + pd.DateOffset(years=shift)).dt.strftime("%Y-%m-%d")
        try:
            got = match_peers(shifted, universe_assets, universe_sic, exclude_ciks=exclude, k=5, min_pool=8, window=5)
        except Exception as exc:  # noqa: BLE001
            print("matching failed at shift", shift, exc)
            continue
        if len(got):
            got["size_anchor_shift_years"] = shift
            peers_all += got.to_dict("records")
            exclude |= set(got["cik"])
    peers = pd.DataFrame(peers_all)
    rows = []
    for _, c in cases.iterrows():
        rows.append({"case_id": c["case_id"], "cik": c["cik"], "ticker": "", "company_name": c["company_name"], "role": "case", "matched_case_id": "",
                     "aaer_numbers": "", "misconduct_start_fy": "", "misconduct_end_fy": "", "revelation_date": c["revelation_date"],
                     "revelation_source": "phase_a_screen_v2", "revelation_verified": "NO", "rpt_relevance": "Strong", "stratum": "sensitivity_3_reports",
                     "d1_class": c["d1_class"], "confidence": c["confidence"], "cik_source": "edgar_verified"})
    for _, p in peers.iterrows():
        rows.append({"case_id": "", "cik": p["cik"], "ticker": "", "company_name": "", "role": "peer", "matched_case_id": p["matched_case_id"],
                     "aaer_numbers": "", "misconduct_start_fy": "", "misconduct_end_fy": "", "revelation_date": "", "revelation_source": "",
                     "revelation_verified": "", "rpt_relevance": "", "stratum": "sensitivity_3_reports", "d1_class": "", "confidence": "",
                     "cik_source": f"rule_matched sic_{p.get('sic_level', '')} gap={float(p.get('ln_assets_gap', np.nan)):.2f} anchor_shift={p.get('size_anchor_shift_years', 0)}"})
    out = pd.DataFrame(rows)
    out.to_csv(args.output, index=False)
    print(f"{args.output}: {int((out['role'] == 'case').sum())} cases, {int((out['role'] == 'peer').sum())} peers")
    print(peers.groupby("matched_case_id").size().to_string() if len(peers) else "no peers matched")


if __name__ == "__main__":
    main()
