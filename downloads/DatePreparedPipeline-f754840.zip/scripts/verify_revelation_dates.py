"""Evidence pass for the medium/low-confidence revelation dates (closure-plan item): for each such case, search
the firm's own EDGAR filings (full-text search, 2001+) for disclosures that would reveal the problem EARLIER than
the recorded date, and list the earliest hits with links for the supervisor to confirm.

Queries (each run separately, restricted to the firm's CIK and to the five years before the recorded date):
  non-reliance / restatement, SEC subpoena or investigation, audit-committee or special-committee investigation,
  auditor resignation or dismissal, going-concern doubt about related parties.

    python scripts/verify_revelation_dates.py --cases cases_core.csv --output scripts/revelation_verification.csv
"""
from __future__ import annotations

import argparse
import json
import os
import time
import urllib.parse
import urllib.request

import pandas as pd

UA = os.environ.get("SEC_USER_AGENT", "PhD research curam.rice@gmail.com")
FTS = "https://efts.sec.gov/LATEST/search-index?q={q}&ciks={cik}&startdt={start}&enddt={end}&forms={forms}"
QUERIES = {
    "non_reliance_restatement": '"non-reliance" OR "should no longer be relied upon" OR "restate" OR "restatement"',
    "sec_investigation": '"subpoena" OR "formal investigation" OR "SEC investigation" OR "Wells notice" OR "Division of Enforcement"',
    "committee_investigation": '"special committee" OR "audit committee investigation" OR "internal investigation" OR "independent investigation"',
    "auditor_resigned": '"resigned as" OR "dismissed" OR "declined to stand for re-election" OR "withdrew its report"',
    "related_party_concern": '"related party" AND ("investigation" OR "subpoena" OR "restatement" OR "misappropriat" OR "undisclosed")',
}
FORMS = "8-K,8-K/A,10-K,10-K/A,10-Q,10-Q/A,NT 10-K,NT 10-Q"


def fts(q: str, cik: str, start: str, end: str) -> list[dict]:
    url = FTS.format(q=urllib.parse.quote(q), cik=cik, start=start, end=end, forms=urllib.parse.quote(FORMS))
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                data = json.load(r)
            return data.get("hits", {}).get("hits", [])
        except Exception:  # noqa: BLE001
            time.sleep(2 + attempt * 2)
    return []


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="cases_core.csv")
    ap.add_argument("--output", default="scripts/revelation_verification.csv")
    ap.add_argument("--confidence", nargs="+", default=["medium", "low"])
    args = ap.parse_args()
    cases = pd.read_csv(args.cases, dtype=str).fillna("")
    cases = cases[(cases["role"] == "case") & cases["confidence"].isin(args.confidence)]
    rows = []
    for _, c in cases.iterrows():
        cik = str(c["cik"]).zfill(10)          # the full-text search wants the 10-digit CIK
        cik_int = str(int(c["cik"]))
        rec = pd.Timestamp(c["revelation_date"])
        start, end = (rec - pd.DateOffset(years=5)).strftime("%Y-%m-%d"), (rec - pd.Timedelta(days=1)).strftime("%Y-%m-%d")
        for name, q in QUERIES.items():
            hits = fts(q, cik, start, end)
            time.sleep(0.6)
            for h in hits[:40]:
                src = h.get("_source", {})
                fdate = src.get("file_date", "")
                adsh = (h.get("_id", "") or "").split(":")[0]
                rows.append({"case_id": c["case_id"], "company": c["company_name"], "recorded_revelation_date": c["revelation_date"], "confidence": c["confidence"],
                             "query": name, "hit_file_date": fdate, "form": src.get("form", ""), "accession": adsh,
                             "display_names": "; ".join(src.get("display_names", [])[:2]),
                             "url": f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{adsh.replace('-', '')}/" if adsh else ""})
        print(c["company_name"], "done", flush=True)
    out = pd.DataFrame(rows)
    if out.empty:
        print("no hits")
        return
    # Attach the passage around the first matching term of each hit so the supervisor can judge relevance
    # without opening the filing (filing index -> primary document -> text).
    import re
    import html as html_lib
    TERMS = re.compile(r"non-reliance|no longer be relied|restat|subpoena|investigation|wells notice|division of enforcement|special committee|resigned|dismissed|withdrew|declined to stand|related part", re.I)
    cache: dict[str, str] = {}

    def snippet(url: str) -> str:
        if not url:
            return ""
        if url in cache:
            return cache[url]
        text = ""
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=40) as r:
                index_html = r.read().decode("utf-8", "replace")
            docs = re.findall(r'href="(/Archives/edgar/data/[^"]+?\.(?:htm|html|txt))"', index_html)
            docs = [d for d in docs if "-index" not in d and "/xsl" not in d]
            docs = sorted(docs, key=lambda d: (not d.endswith(".txt"), d))  # the complete submission .txt holds every document
            if docs:
                req = urllib.request.Request("https://www.sec.gov" + docs[0], headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=60) as r:
                    raw = r.read(3_000_000).decode("utf-8", "replace")
                text = html_lib.unescape(re.sub(r"<[^>]+>", " ", raw))
                text = re.sub(r"\s+", " ", text)
        except Exception:  # noqa: BLE001
            text = ""
        m = TERMS.search(text) if text else None
        out_s = text[max(0, m.start() - 250): m.end() + 350] if m else ""
        cache[url] = out_s
        time.sleep(0.3)
        return out_s

    out["snippet"] = out["url"].map(snippet)
    out = out.sort_values(["case_id", "hit_file_date"])
    out.to_csv(args.output, index=False)
    summary = (out.groupby(["case_id", "company", "recorded_revelation_date", "confidence"])
               .agg(earliest_hit=("hit_file_date", "min"), n_hits=("accession", "nunique"),
                    queries_hit=("query", lambda s: ",".join(sorted(set(s))))).reset_index())
    summary["earlier_by_days"] = (pd.to_datetime(summary["recorded_revelation_date"]) - pd.to_datetime(summary["earliest_hit"])).dt.days
    summary.to_csv(args.output.replace(".csv", "_summary.csv"), index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
