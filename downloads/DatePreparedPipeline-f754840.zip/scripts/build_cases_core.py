"""Assemble cases_core.csv (builder schema) from the Phase A screen and the matched peers.

    python scripts/build_cases_core.py --output cases_core.csv

Inputs: scripts/phase_a_screen_v2.csv (screen, revelation dates, confidence),
scripts/candidates_v02.csv (AAER numbers, misconduct years, RPT element),
scripts/peers_matched_v1_check.csv (peers with verified 10-K coverage).
Extra columns beyond the builder schema (stratum, confidence, revelation_source)
are carried through for the thesis tables; the builder ignores them.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import pandas as pd

COLUMNS = ["case_id", "cik", "ticker", "company_name", "role", "matched_case_id", "aaer_numbers", "misconduct_start_fy",
           "misconduct_end_fy", "revelation_date", "revelation_source", "revelation_verified", "rpt_relevance",
           "stratum", "d1_class", "confidence", "cik_source"]


def case_id(name: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", name.upper()).strip("_")[:14]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, default=Path("cases_core.csv"))
    ap.add_argument("--include-disclosure-stratum", action="store_true", default=True)
    args = ap.parse_args()
    screen = pd.read_csv("scripts/phase_a_screen_v2.csv", dtype=str).fillna("")
    cand = pd.read_csv("scripts/candidates_v02.csv", dtype=str).fillna("")
    peers = pd.read_csv("scripts/peers_matched_v1_check.csv", dtype=str).fillna("") if Path("scripts/peers_matched_v1_check.csv").exists() else pd.DataFrame()
    pm = pd.read_csv("scripts/peers_matched_v1.csv", dtype=str).fillna("") if Path("scripts/peers_matched_v1.csv").exists() else pd.DataFrame()
    s = screen.merge(cand[["company", "misconduct_years", "rpt_element", "notes"]], on="company", how="left")
    s["case_id"] = s.company.map(case_id)
    keep = s.screen.eq("INCLUDE") | (s.screen.eq("STRATUM_DISCLOSURE_ONLY") if args.include_disclosure_stratum else False)
    rows = []
    for _, r in s[keep & (s.revelation_date != "")].iterrows():
        yrs = re.findall(r"\d{4}", r.misconduct_years)
        aaer = "|".join(sorted(set(re.findall(r"AAER-\d{4}", r.notes + " " + r.revelation_source))))
        rows.append({"case_id": r.case_id, "cik": r.cik.zfill(10), "ticker": "", "company_name": r.company, "role": "case",
                     "matched_case_id": "", "aaer_numbers": aaer, "misconduct_start_fy": yrs[0] if yrs else "", "misconduct_end_fy": yrs[-1] if yrs else "",
                     "revelation_date": r.revelation_date, "revelation_source": r.revelation_source,
                     "revelation_verified": "YES" if r.confidence == "high" else "NO", "rpt_relevance": r.d1_class,
                     "stratum": "disclosure_only" if r.screen == "STRATUM_DISCLOSURE_ONLY" else "core", "d1_class": r.d1_class,
                     "confidence": r.confidence, "cik_source": "edgar_verified"})
    case_ids = {r["case_id"] for r in rows}
    if len(peers):
        ok = peers[peers.ok.str.lower().eq("true") & peers.matched_case_id.isin(case_ids)]
        for _, p in ok.iterrows():
            lvl = pm.loc[pm.cik == p.cik, "sic_level"].iloc[0] if len(pm) and (pm.cik == p.cik).any() else ""
            rows.append({"case_id": "", "cik": p.cik.zfill(10), "ticker": "", "company_name": p["name"], "role": "peer",
                         "matched_case_id": p.matched_case_id, "aaer_numbers": "", "misconduct_start_fy": "", "misconduct_end_fy": "",
                         "revelation_date": "", "revelation_source": f"matched by rule D4 ({lvl})", "revelation_verified": "",
                         "rpt_relevance": "", "stratum": "", "d1_class": "", "confidence": "", "cik_source": "edgar_verified"})
    out = pd.DataFrame(rows, columns=COLUMNS)
    out.to_csv(args.output, index=False)
    n_case = (out.role == "case").sum()
    print(f"{args.output}: {n_case} cases ({(out.stratum == 'core').sum()} core, {(out.stratum == 'disclosure_only').sum()} disclosure-only), {(out.role == 'peer').sum()} peers")
    short = out[out.role == "case"].case_id[~out[out.role == "case"].case_id.isin(out.loc[out.role == "peer", "matched_case_id"])]
    if len(short):
        print("cases without peers:", list(short))


if __name__ == "__main__":
    main()
