"""Copy finished raw filings/proxies from a second builder's output into the primary one.

The primary builder skips a download when ``filing.txt`` (or ``proxy.txt``) already exists,
so feeding it the second worker's completed directories lets two local workers share one
SEC request budget without touching each other's tables. Only *complete* directories are
copied: a filing is complete when ``filing_metadata.csv`` exists (written last), a proxy
when ``proxy_rpt.txt`` exists.

    python scripts/sync_worker_b.py --src data_core_b --dst data_core --logs data_core_build.log data_core_b_build.log
"""
from __future__ import annotations

import argparse
import shutil
import time
from pathlib import Path


def complete_dirs(root: Path, marker: str):
    if not root.exists():
        return
    for m in root.rglob(marker):
        yield m.parent


def sync(src: Path, dst: Path) -> tuple[int, int]:
    copied_f = copied_p = 0
    for d in complete_dirs(src / "raw" / "filings", "filing_metadata.csv"):
        target = dst / "raw" / "filings" / d.relative_to(src / "raw" / "filings")
        if not (target / "filing.txt").exists():
            shutil.copytree(d, target, dirs_exist_ok=True)
            copied_f += 1
    for d in complete_dirs(src / "raw" / "proxies", "proxy_rpt.txt"):
        target = dst / "raw" / "proxies" / d.relative_to(src / "raw" / "proxies")
        if not (target / "proxy.txt").exists():
            shutil.copytree(d, target, dirs_exist_ok=True)
            copied_p += 1
    return copied_f, copied_p


def finished(log: Path) -> bool:
    return log.exists() and "BUILD EXIT" in log.read_text(encoding="utf-8", errors="replace")[-2000:]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", type=Path, required=True)
    ap.add_argument("--dst", type=Path, required=True)
    ap.add_argument("--logs", type=Path, nargs="+", required=True, help="builder logs; stop once all show BUILD EXIT")
    ap.add_argument("--interval", type=int, default=300)
    args = ap.parse_args()
    total_f = total_p = 0
    while True:
        f, p = sync(args.src, args.dst)
        total_f += f
        total_p += p
        print(time.strftime("%H:%M:%S"), f"copied filings={f} proxies={p} (total {total_f}/{total_p})", flush=True)
        if all(finished(l) for l in args.logs):
            print("all builders finished; final sync done", flush=True)
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
