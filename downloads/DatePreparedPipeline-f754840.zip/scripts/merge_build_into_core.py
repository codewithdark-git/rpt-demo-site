"""Merge a side build (e.g. data_gulf) into data_core after the researcher approves its case: append the side
build's table rows and copy its raw documents, and append the case rows to cases_core.csv.

    python scripts/merge_build_into_core.py --side data_gulf --cases cases_gulfport.csv
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd

TABLES = ["company_universe", "filing_manifest", "xbrl_financials", "nlp_scores", "extraction_manifest", "fraud_labels",
          "master_panel", "proxy_links", "proxy_manifest", "eightk_items", "eightk_items_events"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--core", default="data_core")
    ap.add_argument("--side", required=True)
    ap.add_argument("--cases", required=True, help="side cases file whose rows are appended to cases_core.csv")
    ap.add_argument("--core-cases", nargs="*", default=["cases_core.csv", "../PrivateResearch/cases_core.csv"])
    args = ap.parse_args()
    core, side = Path(args.core), Path(args.side)
    backup = core / "_backup_pre_merge"
    backup.mkdir(exist_ok=True)
    side_cases = pd.read_csv(args.cases, dtype=str).fillna("")
    ciks = set(side_cases["cik"].str.zfill(10))
    for t in TABLES:
        cp, sp = core / f"{t}.csv", side / f"{t}.csv"
        if not sp.exists():
            print(f"{t}: not in side build, skipped")
            continue
        c = pd.read_csv(cp, dtype=str, keep_default_na=False) if cp.exists() else pd.DataFrame()
        s = pd.read_csv(sp, dtype=str, keep_default_na=False)
        if "cik" in s.columns:
            s["cik"] = s["cik"].str.zfill(10)
            s = s[s["cik"].isin(ciks)]
        if cp.exists():
            shutil.copy2(cp, backup / cp.name)
        if "cik" in c.columns:
            c["cik"] = c["cik"].str.zfill(10)
            c = c[~c["cik"].isin(ciks)]  # replace any earlier rows for these firms
        merged = pd.concat([c, s], ignore_index=True, sort=False)
        cols = list(c.columns) + [x for x in s.columns if x not in c.columns] if len(c.columns) else list(s.columns)
        merged = merged[cols].fillna("")
        merged.to_csv(cp, index=False)
        print(f"{t}: +{len(s)} rows -> {len(merged)}")
    for sub in ("filings", "proxies", "xbrl"):
        src = side / "raw" / sub
        if not src.exists():
            continue
        for entry in src.iterdir():
            if any(entry.name.startswith(k) for k in ciks):
                dst = core / "raw" / sub / entry.name
                if dst.exists():
                    shutil.rmtree(dst) if dst.is_dir() else dst.unlink()
                shutil.copytree(entry, dst) if entry.is_dir() else shutil.copy2(entry, dst)
                print(f"raw/{sub}/{entry.name} copied")
    for cc in args.core_cases:
        p = Path(cc)
        if not p.exists():
            continue
        shutil.copy2(p, backup / (p.stem + "_" + p.parent.name + ".csv"))
        base = pd.read_csv(p, dtype=str).fillna("")
        base["cik"] = base["cik"].str.zfill(10)
        base = base[~base["cik"].isin(ciks)]
        out = pd.concat([base, side_cases[base.columns]], ignore_index=True)
        out.to_csv(p, index=False)
        print(f"{p}: {int((out['role']=='case').sum())} cases, {int((out['role']=='peer').sum())} peers")


if __name__ == "__main__":
    main()
