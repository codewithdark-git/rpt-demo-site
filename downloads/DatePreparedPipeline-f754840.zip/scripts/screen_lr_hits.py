"""Screen SEC litigation releases that mention related parties: issuer, CIK, 10-K history, snippets.

    python scripts/screen_lr_hits.py            # writes scripts/lr_candidates.csv and prints a review table

Inputs: scripts/lr_rpt_sweep.csv (+ _b.csv), cached texts in data_lr/raw/.
Excludes releases whose respondents are already candidates, and releases that
only name individuals / auditors / brokers (no issuer-like name).
"""
from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

import pandas as pd

UA = {"User-Agent": "PhD research curam.rice@gmail.com"}
ANNUAL = {"10-K", "10-K405", "10-KSB", "10-KSB40", "10-KT"}
ISSUER = re.compile(r"\b(Inc\.?|Corp\.?|Corporation|Co\.|Company|Ltd\.?|LLC|L\.P\.|LP|plc|Holdings?|Group|Bancorp|Trust|Technologies|Energy|Pharma\w*|International|Industries|Systems|Partners|Resources|Capital)\b", re.I)
NOISE = re.compile(r"\b(CPA|LLP|Esq|Advisors?|Advisers?|Securities|Fund|Investments?|Management|Asset|Wealth|Brokerage|Insurance|Bank of|Ponzi|offering fraud|unregistered|pump|microcap)\b", re.I)
RPT = re.compile(r"[^.]{0,230}(?:related[- ]part(?:y|ies)|related person|loans? to (?:the )?(?:ceo|chief executive|officers?|directors?)|undisclosed (?:transactions?|relationship|interest|loans?)|controlled by (?:the )?(?:ceo|chairman|chief executive|founder)|self-dealing)[^.]{0,230}\.", re.I)
PUBLIC = re.compile(r"\b(publicly[- ]traded|public company|common stock|Nasdaq|NYSE|OTC|annual report|Form 10-K|periodic reports|shareholders|issuer)\b", re.I)


def text_path(url: str) -> Path:
    return Path("data_lr/raw") / (re.sub(r"[^A-Za-z0-9]+", "_", url.split("/")[-1])[:80] + ".txt")


def lookup_cik(name: str):
    url = f"https://efts.sec.gov/LATEST/search-index?keysTyped={urllib.parse.quote(name)}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
            hits = json.load(r).get("hits", {}).get("hits", [])
        return (hits[0]["_id"].zfill(10), hits[0]["_source"].get("entity", "")) if hits else ("", "")
    except Exception:
        return ("", "")


def tenk_years(cik: str):
    try:
        with urllib.request.urlopen(urllib.request.Request(f"https://data.sec.gov/submissions/CIK{cik}.json", headers=UA), timeout=30) as r:
            d = json.load(r)
        fys = set()

        def add(rr):
            for f, rd, fd in zip(rr["form"], rr["reportDate"], rr["filingDate"]):
                if f in ANNUAL:
                    dt = rd or fd
                    y, m = int(dt[:4]), int(dt[5:7])
                    fys.add(y - 1 if m <= 5 else y)
        add(d["filings"]["recent"])
        for extra in d["filings"].get("files", []):
            with urllib.request.urlopen(urllib.request.Request("https://data.sec.gov/submissions/" + extra["name"], headers=UA), timeout=30) as r2:
                add(json.load(r2))
            time.sleep(0.12)
        return d["name"], d.get("sic", ""), sorted(fys)
    except Exception:
        return "", "", []


def main() -> None:
    parts = [pd.read_csv(p, dtype=str) for p in ("scripts/lr_rpt_sweep.csv", "scripts/lr_rpt_sweep_b.csv") if Path(p).exists()]
    sw = pd.concat(parts).drop_duplicates("url")
    sw["rp_hits"] = pd.to_numeric(sw.rp_hits, errors="coerce").fillna(0).astype(int)
    known = pd.read_csv("scripts/candidates_v02.csv", dtype=str).company.str.lower().str.split().str[0].tolist()
    sel = sw[(sw.rp_hits >= 2) & sw.respondents.str.contains(ISSUER) & ~sw.respondents.str.contains(NOISE)].copy()
    sel = sel[~sel.respondents.str.lower().apply(lambda s: any(k and k in s for k in known))]
    print("LRs mentioning related parties >=2 times with an issuer-like respondent:", len(sel))
    rows = []
    for _, r in sel.sort_values("rp_hits", ascending=False).iterrows():
        t = text_path(r.url).read_text(encoding="utf-8", errors="replace") if text_path(r.url).exists() else ""
        if not PUBLIC.search(t):
            continue
        snippets = [m.group(0).strip()[:300] for m in RPT.finditer(t)][:2]
        issuer = re.split(r",|;| and ", r.respondents)[0].strip()
        cik, ent = lookup_cik(issuer)
        time.sleep(0.25)
        name, sic, fys = tenk_years(cik) if cik else ("", "", [])
        time.sleep(0.2)
        rows.append({"date": r.date, "release_no": r.release_no, "respondents": r.respondents, "issuer_guess": issuer, "cik": cik, "edgar_name": name,
                     "sic": sic, "n_10k": len(fys), "first_fy": fys[0] if fys else "", "last_fy": fys[-1] if fys else "", "rp_hits": r.rp_hits,
                     "snippet_1": snippets[0] if snippets else "", "snippet_2": snippets[1] if len(snippets) > 1 else "", "url": r.url})
        print(f"{r.date} {r.release_no[:9]:9s} {issuer[:34]:34s} cik={cik or '-':10s} 10-Ks={len(fys):2d} {fys[0] if fys else ''}-{fys[-1] if fys else ''} rp={r.rp_hits}", flush=True)
    out = pd.DataFrame(rows)
    out.to_csv("scripts/lr_candidates.csv", index=False)
    print("written scripts/lr_candidates.csv:", len(out))


if __name__ == "__main__":
    main()
