"""Phase A2: provisional revelation dates (rule D2) and the re-screened candidate table.

D2: the revelation date is the earliest public document alleging or disclosing the
misconduct (8-K investigation / Item 4.01 / Item 4.02 / restatement, a published
short-seller or press report naming the misconduct, or failing those the SEC
order). confidence: high = dated SEC filing or order located; medium = well
documented public event whose URL still has to be attached; low = SEC action
date used as a placeholder. Rows with confidence != high must be verified before
the dates are used for labels.
"""
import pandas as pd

R = [
    ("Ault Alliance", "2023-04-14", "10-K FY2022 discloses SEC subpoena / special committee (FTS hit)", "medium", "check FY2021 10-K (filed 2022) for an earlier SEC-investigation disclosure"),
    ("Co-Diagnostics", "2023-07-05", "SEC order 33-11209 (AAER-4428); no earlier filing found", "low", "search 8-K/10-Q 2021-2023 for SEC inquiry disclosure"),
    ("ProPetro Holding", "2019-08-08", "8-K: delayed 10-Q, audit-committee review of related-party transactions and perquisites", "medium", "attach 8-K accession"),
    ("Gulfport Energy", "", "SEC order 2021 (not on AAER list); CEO perquisite review disclosed earlier?", "low", "find order number/date and any 2019-2020 8-K disclosure"),
    ("Skechers U.S.A.", "2024-03-07", "SEC settled order 34-99693; no prior public revelation", "high", ""),
    ("Eagle Bancorp", "2017-12-01", "Aurelius Value short report alleging undisclosed related-party loans; 8-K 2019-07-17 confirms investigations", "medium", "attach report URL; order AAER-4321 2022-08-16"),
    ("Ocwen Financial", "2014-08-18", "10-K/A restating FY2013 (Erbey recusal / Altisource); NY DFS letter 2014-08-04 public", "high", "AAER-3733 2016-01-20"),
    ("Valeant Pharmaceuticals", "2015-10-21", "Citron report on Philidor; 8-K ad hoc committee 2015-10-26", "medium", "attach URLs"),
    ("Manitex International", "2018-04-03", "10-K/A FY2016 with restatement and non-reliance (FTS); earlier 8-K likely Feb/Mar 2018", "high", "find the original Item 4.02 8-K"),
    ("American Electric Power", "2020-07-21", "HB6 scandal public (FirstEnergy arrests); AEP payments reported shortly after", "medium", "disclosure-only stratum; attach press URL"),
    ("Singularity Future Technology", "2023-03-06", "8-K/A Item 4.02 non-reliance: related-party loan receivable misaccounted", "high", "D1 to confirm from 2025 order"),
    ("China Natural Gas", "2010-08-20", "10-K/A disclosing undisclosed related-party loan; Nasdaq proceedings late 2010", "medium", "verify which filing first disclosed the loan"),
    ("Ener1", "2011-08-15", "8-K non-reliance / Think Holdings impairment; audit-committee investigation 8-K 2011-11-08", "medium", "attach accession"),
    ("Apple REIT Nine", "2011-05-27", "FINRA complaint against David Lerner Associates (valuation / related-party issues public)", "medium", "AAER-3535 2014-02-12"),
    ("China North East Petroleum", "2010-03-08", "8-K Item 4.02 non-reliance (restatement); CEO cash transfers surfaced mid-2010", "medium", "check 2010-05/06 8-Ks for the transfers"),
    ("Puda Coal", "2011-04-08", "Alfred Little research report: chairman transferred subsidiary to himself", "medium", "8-K auditor resignation / non-reliance 2011-07-18 confirms"),
    ("General Employment Enterprises", "2015-04-30", "SEC complaint (placeholder); misconduct 2009-2010", "low", "search 2011-2014 filings for SEC inquiry disclosure"),
    ("Home Loan Servicing Solutions", "2015-03-02", "Restatement / Deloitte matters announced; 10-K/A 2015-04-30 (FTS)", "medium", "AAER-3713 2015-10-05"),
    ("American Realty Capital Properties", "2014-10-29", "8-K: accounting irregularities, CFO and CAO resign", "high", ""),
    ("RINO International", "2010-11-10", "Muddy Waters report; 8-K non-reliance 2010-11-30 (FTS)", "high", ""),
    ("SAExploration Holdings", "2019-08-15", "8-K: audit-committee investigation and non-reliance", "medium", "attach accession; 10-K/A 2020-02-07 (FTS)"),
    ("Ideanomics (Seven Stars Cloud)", "2018-08-28", "10-K/A restating FY2017 (FTS restatement + related party)", "medium", "AAER-4512 2024-08-09; confirm the 10-K/A content"),
    ("RCI Hospitality Holdings", "2020-09-21", "SEC order 34-89935 (placeholder); SEC subpoena disclosed in 2019 filings?", "low", "disclosure-only stratum; search 2019 10-K/10-Q"),
    ("The Greenbrier Companies", "2023-03-02", "SEC settled order; no prior revelation", "high", "disclosure-only stratum"),
    ("Energy XXI", "2016-10-28", "10-K/A: audit / special committee investigation of CEO loans (FTS)", "medium", "disclosure-only stratum; check 2016-04 8-K (CEO departure)"),
    ("Maximus", "2023-09-11", "SEC order 34-98351; no prior revelation", "high", "disclosure-only stratum"),
    ("United Development Funding IV", "2015-12-10", "Anonymous (Hayman Capital) posts alleging Ponzi-like affiliate lending; FBI raid 2016-02-18", "medium", "LR-24185 2018-07-03"),
    ("FAT Brands", "2024-05-10", "SEC complaint LR-26001 (placeholder); DOJ/SEC investigation disclosed earlier", "low", "search 2021-2023 10-Q/10-K for investigation disclosure"),
    ("iFresh", "2022-05-31", "SEC complaint (placeholder)", "low", "search 2020-2021 filings"),
    ("Shift4 Payments", "2025-01-10", "SEC order 34-102146; no prior revelation", "high", "disclosure-only stratum"),
    ("Ammo Inc (Outdoor Holding)", "2024-07-29", "10-K FY2024 delayed; audit-committee investigation (FTS)", "medium", "D1 to confirm from LR-26446 / Order 33-11397"),
    ("MusclePharm", "2012-05-14", "8-K Item 4.02 non-reliance (FTS, 8-K/A 2012-05-25)", "high", "Press release 2015-179"),
    ("ChinaCast Education", "2012-04-02", "Board ousts CEO; CEO refuses to hand over seals; transfers revealed", "medium", "attach 8-K"),
    ("China Valves Technology", "2012-02-28", "8-K Item 4.02 non-reliance and investigation (FTS)", "high", "LR-23096 2014-09-29"),
    ("infoUSA / infoGROUP", "2008-08-22", "8-K: special committee investigation / auditor resignation (FTS); derivative suit public 2006", "medium", "consider the 2006 derivative complaint as first revelation"),
    ("Cemtrex", "2017-02-22", "Short report alleging hidden insider dealing and related-party transactions", "medium", "attach URL; press release 2021-132"),
    ("Quadrant 4 System", "2016-09-23", "10-K/A revising Item 13 related-party disclosure (FTS); CEO/CFO charged 2016-11", "medium", ""),
    ("Provectus Biopharmaceuticals", "2016-02-29", "CEO resigns amid audit-committee review of expense reimbursements", "medium", "attach 8-K"),
    ("Live Ventures", "2021-08-02", "SEC complaint LR-25155 (placeholder)", "low", "D1 to confirm"),
    ("BioElectronics Corp", "2016-10-27", "AAER-3819 (placeholder)", "low", "fails 4-report rule"),
    ("Northwest Biotherapeutics", "2019-10-10", "AAER-4099 (ICFR order)", "low", "D1: likely not RPT-central"),
    ("First Bancorp (NC)", "2015-06-01", "AAER-3660; no prior revelation", "high", "disclosure-only stratum"),
    ("HF Foods Group", "2020-03-23", "Hindenburg Research report alleging undisclosed related-party dealings", "high", "AAER-4506 2024-06-06"),
    ("Corporate Resource Services", "2015-02-10", "Disclosure of Tri-State unpaid payroll taxes / going concern", "medium", "D1: issuer not charged? confirm"),
    ("Longfin Corp", "2018-04-06", "SEC asset freeze / trading halt", "high", "fails 4-report rule"),
    ("American Equity Investment Life", "2010-03-03", "SEC complaint LR-21431 (company, CEO, CFO) on the 2006 proxy related-party disclosure; no earlier public revelation found", "high", "disclosure-only stratum"),
    ("TVI Corporation", "2008-06-30", "TVI disclosed a board investigation of former executives (2008); SEC complaint 2010-03-25", "low", "fails the 4-report rule either way"),
    ("Premier Holding Corp", "2017-12-04", "SEC complaint LR-24000 (placeholder); check 2016-2017 8-Ks", "low", "search filings for an SEC inquiry disclosure"),
    ("Proteonomix", "2015-02-19", "SEC complaint (placeholder)", "low", "fails the 4-report rule"),
    ("Electronic Game Card", "2010-02-19", "Trading halt / auditor resignation 2010", "medium", "fails the 4-report rule"),
    ("China Ruitai International", "2013-09-30", "AAER-3504 (placeholder)", "low", "10-K history to fetch"),
]


def main() -> None:
    rev = pd.DataFrame(R, columns=["company", "revelation_date", "revelation_source", "confidence", "verify"])
    s = pd.read_csv("scripts/phase_a_screen.csv", dtype=str).fillna("")
    # D1 class is maintained in candidates_v02.csv (updated as orders are read); it overrides the first screen.
    cand = pd.read_csv("scripts/candidates_v02.csv", dtype=str).fillna("")
    s = s.drop(columns=["d1_class"]).merge(cand[["company", "d1_class_prelim"]].rename(columns={"d1_class_prelim": "d1_class"}), on="company", how="left").fillna("")
    e = pd.read_csv("scripts/candidates_edgar_check.csv", dtype=str).fillna("")
    fy = dict(zip(e.company, e.fy_list))
    fy["Puda Coal"] = "2007,2008,2009,2010"
    fy["Ammo Inc (Outdoor Holding)"] = ",".join(str(y) for y in range(2008, 2026))
    fy["American Equity Investment Life"] = "1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025"
    fy["TVI Corporation"] = "2005,2006,2007"
    fy["Premier Holding Corp"] = "2009,2010,2011,2012,2013,2014,2015,2016,2017"
    fy["Proteonomix"] = "2009,2010,2011"
    fy["Electronic Game Card"] = "2008"
    fy["China Ruitai International"] = ""
    m = s.merge(rev, on="company", how="left")
    rows = []
    for _, r in m.iterrows():
        ry = int(r.revelation_date[:4]) if r.revelation_date else None
        fys = {int(x) for x in fy.get(r.company, "").split(",") if x}
        window = list(range(ry - 5, ry)) if ry else []
        avail = sorted(y for y in window if y in fys)
        if not ry:
            scr = "NEED_REVELATION_DATE"
        elif len(avail) < 4:
            scr = "FAIL_4_REPORTS"
        elif ry - 5 < 2005:
            scr = "PRE_2005_WINDOW"
        elif r.d1_class == "disclosure_only":
            scr = "STRATUM_DISCLOSURE_ONLY"
        elif r.d1_class in ("unclear",):
            scr = "CONFIRM_D1"
        elif r.d1_class in ("not_rpt", "controls_only"):
            scr = "EXCLUDE_D1"
        else:
            scr = "INCLUDE"
        rows.append({"company": r.company, "cik": r.cik, "sic": r.sic, "d1_class": r.d1_class, "revelation_date": r.revelation_date,
                     "confidence": r.confidence, "window": f"{window[0]}-{window[-1]}" if window else "", "tenk_in_window": len(avail),
                     "screen": scr, "revelation_source": r.revelation_source, "verify": r.verify})
    out = pd.DataFrame(rows)
    out.to_csv("scripts/phase_a_screen_v2.csv", index=False)
    pd.set_option("display.width", 200)
    pd.set_option("display.max_colwidth", 22)
    print(out[["company", "revelation_date", "confidence", "window", "tenk_in_window", "d1_class", "screen"]].to_string(index=False))
    print("\n", out.screen.value_counts().to_dict())
    print("confidence:", out.confidence.value_counts().to_dict())


if __name__ == "__main__":
    main()
