"""Build the pilot ``cases.csv`` (five AAER-anchored fraud cases + matched peers).

Peer CIKs are resolved from SEC's current ``company_tickers.json``; delisted
peers are taken from ``scripts/peer_cik_overrides.csv``. A row is never written
without a CIK. Revelation dates are provisional until ``revelation_verified``
is set to YES by hand.

Usage (from the repository root):
    python scripts/make_pilot_cases.py --output cases.csv
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sec_rpt_dataset.company import fetch_company_tickers  # noqa: E402
from sec_rpt_dataset.config import PipelineConfig  # noqa: E402
from sec_rpt_dataset.io_utils import cik10  # noqa: E402
from sec_rpt_dataset.pipeline import make_client  # noqa: E402

# case_id, cik, ticker, name, aaer_numbers, misconduct_start_fy, misconduct_end_fy,
# revelation_date (YYYY-MM-DD or blank), revelation_source, rpt_relevance
ANCHORS = [
    ("AULT", "0000896493", "AULT", "Ault Alliance, Inc. (now Hyperscale Data)", "AAER-4440", 2016, 2022,
     "2023-08-15", "SEC administrative order 33-11222 (AAER-4440). Check 10-K/8-K for an earlier subpoena or investigation disclosure.", "Strong"),
    ("PUMP", "0001680247", "PUMP", "ProPetro Holding Corp.", "AAER-4268", 2017, 2018,
     "2019-08-08", "8-K announcing delayed 10-Q and audit-committee review of related-party transactions and perquisites; SEC order 33-11008 of 2021-11-22 (AAER-4268). Verify exact 8-K date.", "Moderate to strong"),
    ("CODX", "0001692415", "CODX", "Co-Diagnostics, Inc.", "AAER-4428", 2018, 2020,
     "2023-07-05", "SEC order 33-11209 of 2023-07-05 (AAER-4428) used as the revelation date; replace if an earlier 8-K or 10-K disclosure exists.", "Strong"),
    ("GPOR", "0000874499", "GPOR", "Gulfport Energy Corp.", "", 2014, 2018,
     "", "SEC order 2021. Check FY2019 10-K / 2019-2020 8-Ks for the first disclosure of the CEO perquisite and related-party review.", "Moderate"),
    ("SKX", "0001065837", "SKX", "Skechers U.S.A., Inc.", "", 2019, 2022,
     "2024-03-07", "SEC settled order 34-99693 (press release 2024-33). No prior public revelation found.", "Strong"),
]

# Peers from PrivateResearch/companies.json; Adidas and Puma dropped (not 10-K filers),
# Skechers peers replaced with US footwear 10-K filers.
PEERS = {
    "AULT": ["ITI", "TACT", "KTCC", "ALOT", "PMTS"],
    "PUMP": ["LBRT", "NEX", "RES", "NINE", "PTEN"],
    "CODX": ["OSUR", "BDSX", "QTRX", "CEMI", "VIVO"],
    "GPOR": ["MTDR", "XEC", "PDCE", "SM", "CPE"],
    "SKX": ["CROX", "DECK", "SHOO", "WWW", "NKE"],
}

COLUMNS = [
    "case_id", "cik", "ticker", "company_name", "role", "matched_case_id", "aaer_numbers",
    "misconduct_start_fy", "misconduct_end_fy", "revelation_date", "revelation_source",
    "revelation_verified", "rpt_relevance", "cik_source",
]


def load_overrides(path: Path) -> dict[str, dict[str, str]]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8", newline="") as f:
        return {row["ticker"].upper(): row for row in csv.DictReader(f)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("cases.csv"))
    parser.add_argument("--overrides", type=Path, default=Path(__file__).with_name("peer_cik_overrides.csv"))
    parser.add_argument("--unresolved", type=Path, default=Path("cases_unresolved.csv"))
    args = parser.parse_args()

    # Overrides win: SEC's ticker file reuses tickers of delisted firms (e.g. VIVO).
    overrides = load_overrides(args.overrides)
    live = {row["ticker"].upper(): row for row in fetch_company_tickers(make_client(PipelineConfig()))}

    rows: list[dict[str, object]] = []
    unresolved: list[dict[str, str]] = []
    blocking: list[str] = []
    for case_id, cik, ticker, name, aaer, start, end, revelation, source, relevance in ANCHORS:
        rows.append({
            "case_id": case_id, "cik": cik10(cik), "ticker": ticker, "company_name": name, "role": "case",
            "matched_case_id": "", "aaer_numbers": aaer, "misconduct_start_fy": start, "misconduct_end_fy": end,
            "revelation_date": revelation, "revelation_source": source, "revelation_verified": "NO",
            "rpt_relevance": relevance, "cik_source": "hand_verified",
        })
        if not revelation:
            blocking.append(f"{case_id}: revelation_date is blank; labels for this case cannot be built")
        for peer in PEERS[case_id]:
            if peer in overrides:
                entry, cik_source = overrides[peer], "override"
                peer_cik, peer_name = entry["cik"], entry["company_name"]
            elif peer in live:
                peer_cik, peer_name, cik_source = live[peer]["cik"], live[peer]["name"], "company_tickers.json"
            else:
                unresolved.append({"ticker": peer, "matched_case_id": case_id, "reason": "not in company_tickers.json and no override"})
                continue
            rows.append({
                "case_id": "", "cik": cik10(peer_cik), "ticker": peer, "company_name": peer_name, "role": "peer",
                "matched_case_id": case_id, "aaer_numbers": "", "misconduct_start_fy": "", "misconduct_end_fy": "",
                "revelation_date": "", "revelation_source": "", "revelation_verified": "", "rpt_relevance": "",
                "cik_source": cik_source,
            })

    with args.output.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    with args.unresolved.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["ticker", "matched_case_id", "reason"])
        writer.writeheader()
        writer.writerows(unresolved)

    cases = sum(1 for r in rows if r["role"] == "case")
    print(f"Wrote {args.output}: {cases} cases, {len(rows) - cases} peers; {len(unresolved)} unresolved -> {args.unresolved}")
    for line in blocking:
        print("BLOCKING:", line)
    print("All revelation dates are provisional (revelation_verified=NO) until checked against the 8-K / press release.")
    return 1 if unresolved else 0


if __name__ == "__main__":
    raise SystemExit(main())
