"""Fetch the DEF 14A proxy statement for EVERY primary 10-K in a build (not only where Item 13 is incorporated
by reference), so governance variables can be coded for every firm-year.

For each primary filing the first proxy filed within PROXY_WINDOW_DAYS after the fiscal year end is taken.
Already-downloaded proxies are skipped. Writes <output_dir>/proxy_links.csv (cik, fiscal_year, accession_number,
proxy_accession_number, proxy_filing_date).

    python scripts/fetch_all_proxies.py --output-dir data_core
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sec_rpt_dataset.config import PipelineConfig  # noqa: E402
from sec_rpt_dataset.documents import candidate_proxies  # noqa: E402
from sec_rpt_dataset.http_client import SecHttpClient  # noqa: E402
from sec_rpt_dataset.io_utils import ensure_dir, read_text, safe_filename, write_text  # noqa: E402
from sec_rpt_dataset.parser import extract_proxy_rpt_section  # noqa: E402
from sec_rpt_dataset.parser import html_to_text  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", type=Path, default=Path("data_core"))
    ap.add_argument("--delay", type=float, default=0.2)
    args = ap.parse_args()
    ua = os.environ.get("SEC_USER_AGENT")
    if not ua:
        sys.exit("set SEC_USER_AGENT")
    cfg = PipelineConfig(output_dir=args.output_dir)
    client = SecHttpClient(user_agent=ua, delay_seconds=args.delay)
    filings = pd.read_csv(args.output_dir / "filing_manifest.csv", dtype=str).fillna("")
    proxies = pd.read_csv(args.output_dir / "proxy_manifest.csv", dtype=str).fillna("")
    filings = filings[filings["is_primary_filing"].astype(str).isin(["1", "1.0", "True"])] if "is_primary_filing" in filings else filings
    by_cik = {c: g.to_dict("records") for c, g in proxies.groupby("cik")}
    links, fetched, skipped, failed = [], 0, 0, 0
    for i, row in enumerate(filings.to_dict("records"), 1):
        cands = candidate_proxies(row, by_cik.get(row["cik"], []))
        if not cands:
            links.append({"cik": row["cik"], "fiscal_year": row["fiscal_year"], "accession_number": row["accession_number"], "proxy_accession_number": "", "proxy_filing_date": ""})
            continue
        proxy = cands[0]
        pdir = ensure_dir(cfg.raw_proxies_dir / safe_filename(str(proxy["cik"])) / safe_filename(str(proxy["accession_number"])))
        ppath = pdir / "proxy.txt"
        try:
            if not ppath.exists():
                write_text(ppath, html_to_text(client.get_text(str(proxy["document_url"]))))
                fetched += 1
            else:
                skipped += 1
            if not (pdir / "proxy_rpt.txt").exists():
                section, _ = extract_proxy_rpt_section(read_text(ppath))
                write_text(pdir / "proxy_rpt.txt", section)
            links.append({"cik": row["cik"], "fiscal_year": row["fiscal_year"], "accession_number": row["accession_number"],
                          "proxy_accession_number": proxy["accession_number"], "proxy_filing_date": proxy["filing_date"]})
        except Exception as exc:  # noqa: BLE001
            failed += 1
            links.append({"cik": row["cik"], "fiscal_year": row["fiscal_year"], "accession_number": row["accession_number"], "proxy_accession_number": "", "proxy_filing_date": f"failed: {exc}"[:80]})
        if i % 100 == 0:
            print(f"{i}/{len(filings)} filings | fetched {fetched} skipped {skipped} failed {failed}", flush=True)
            pd.DataFrame(links).to_csv(args.output_dir / "proxy_links_partial.csv", index=False)
    pd.DataFrame(links).to_csv(args.output_dir / "proxy_links.csv", index=False)
    print(f"done: {len(links)} filings | fetched {fetched} skipped {skipped} failed {failed} | linked {sum(1 for l in links if l['proxy_accession_number'])}")


if __name__ == "__main__":
    main()
