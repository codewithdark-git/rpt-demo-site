"""Finalize Phase A: fold the litigation-release leads into the screen, match their peers, build cases_core.csv.

    python scripts/finalize_phase_a.py
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import time
import urllib.request

import pandas as pd

sys.path.insert(0, ".")
from sec_rpt_dataset.peers import match_peers  # noqa: E402

UA = {"User-Agent": "PhD research curam.rice@gmail.com"}
ANNUAL = {"10-K", "10-K405", "10-KSB", "10-KSB40", "10-KT"}

NEW = [  # company, cik, edgar name, sic, fiscal years with an annual report
    ("American Equity Investment Life", "0001039828", "American National Group Inc. (fka American Equity Investment Life Holding)", "6311", list(range(1999, 2026))),
    ("TVI Corporation", "0000352079", "TVI CORP", "3812", [2005, 2006, 2007]),
    ("Premier Holding Corp", "0001030916", "PREMIER HOLDING CORP.", "4911", list(range(2009, 2018))),
    ("Proteonomix", "0001469559", "PROTEONOMIX, INC.", "2834", [2009, 2010, 2011]),
    ("Electronic Game Card", "0001083036", "ELECTRONIC GAME CARD INC", "3990", [2008]),
    ("China Ruitai International", "0000076348", "CHINA RUITAI INTERNATIONAL HOLDINGS CO., LTD.", "2860", []),
]
REVELATIONS = [
    ("American Equity Investment Life", "2010-03-03", "SEC complaint LR-21431 (company, CEO, CFO) on the 2006 proxy related-party disclosure; no earlier public revelation found", "high", "disclosure-only stratum"),
    ("TVI Corporation", "2008-06-30", "TVI disclosed a board investigation of former executives (2008); SEC complaint 2010-03-25", "low", "fails the 4-report rule either way"),
    ("Premier Holding Corp", "2017-12-04", "SEC complaint LR-24000 (placeholder); check 2016-2017 8-Ks", "low", "search filings for an SEC inquiry disclosure"),
    ("Proteonomix", "2015-02-19", "SEC complaint (placeholder)", "low", "fails the 4-report rule"),
    ("Electronic Game Card", "2010-02-19", "Trading halt / auditor resignation 2010", "medium", "fails the 4-report rule"),
    ("China Ruitai International", "2013-09-30", "AAER-3504 (placeholder)", "low", "10-K history to fetch"),
]


def fetch_years(cik: str):
    with urllib.request.urlopen(urllib.request.Request(f"https://data.sec.gov/submissions/CIK{cik}.json", headers=UA), timeout=30) as r:
        d = json.load(r)
    fys = set()

    def add(rr):
        for f, rd, fd in zip(rr["form"], rr["reportDate"], rr["filingDate"]):
            if f in ANNUAL:
                dt = rd or fd
                y, m = int(dt[:4]), int(dt[5:7])
                fys.add(y - 1 if m <= 5 else y)
    add(d["filings"]["recent"])
    for e in d["filings"].get("files", []):
        with urllib.request.urlopen(urllib.request.Request("https://data.sec.gov/submissions/" + e["name"], headers=UA), timeout=30) as r2:
            add(json.load(r2))
        time.sleep(0.12)
    return d["name"], d.get("sic", ""), sorted(fys)


def step_tables() -> None:
    e = pd.read_csv("scripts/candidates_edgar_check.csv", dtype=str).fillna("")
    s = pd.read_csv("scripts/phase_a_screen.csv", dtype=str).fillna("")
    c = pd.read_csv("scripts/candidates_v02.csv", dtype=str).fillna("")
    for name, cik, en, sic, fys in NEW:
        fy_list = ",".join(map(str, fys))
        if name not in set(e.company):
            e = pd.concat([e, pd.DataFrame([{"company": name, "cik": cik, "edgar_name": en, "sic": sic, "former_names": "", "n_10k": len(fys),
                                               "first_fy": fys[0] if fys else "", "last_fy": fys[-1] if fys else "", "fy_list": fy_list}])])
        if name not in set(s.company):
            d1 = c.loc[c.company == name, "d1_class_prelim"].iloc[0] if (c.company == name).any() else "unclear"
            s = pd.concat([s, pd.DataFrame([{"company": name, "cik": cik, "edgar_name": en, "sic": sic, "d1_class": d1}])]).fillna("")
    e.to_csv("scripts/candidates_edgar_check.csv", index=False)
    s.to_csv("scripts/phase_a_screen.csv", index=False)
    # extend the revelation list in the A2 script (idempotent)
    p = "scripts/phase_a2_revelation_dates.py"
    src = open(p, encoding="utf-8").read()
    for name, date, source, conf, verify in REVELATIONS:
        if f'("{name}",' in src:
            continue
        line = f'    ("{name}", "{date}", "{source}", "{conf}", "{verify}"),\n'
        src = src.replace("]\n\n\ndef main", line + "]\n\n\ndef main", 1)
    open(p, "w", encoding="utf-8").write(src)
    # the A2 script needs fy lists for the new names
    src = open(p, encoding="utf-8").read()
    if "American Equity Investment Life" not in src.split("def main")[1]:
        extra = "".join(f'    fy["{name}"] = "{",".join(map(str, fys))}"\n' for name, _, _, _, fys in NEW)
        src = src.replace('    fy["Ammo Inc (Outdoor Holding)"] = ",".join(str(y) for y in range(2008, 2026))\n',
                          '    fy["Ammo Inc (Outdoor Holding)"] = ",".join(str(y) for y in range(2008, 2026))\n' + extra, 1)
        open(p, "w", encoding="utf-8").write(src)
    subprocess.run([sys.executable, p], check=True)


def step_peers() -> None:
    s = pd.read_csv("scripts/phase_a_screen_v2.csv", dtype=str).fillna("")
    cases = s[s.company.isin(["American Equity Investment Life", "Premier Holding Corp"]) & s.screen.isin(["INCLUDE", "STRATUM_DISCLOSURE_ONLY"])].copy()
    if cases.empty:
        print("no new cases pass the screen")
        return
    cases["case_id"] = cases.company.str.upper().str.replace(r"[^A-Z0-9]+", "_", regex=True).str.strip("_").str[:14]
    ua = pd.read_csv("scripts/universe_assets_fy.csv", dtype={"cik": str})
    us = pd.read_csv("scripts/universe_ciks_by_sic.csv", dtype=str)
    # SIC 6311 (life insurance) is not yet in the universe: enumerate it and pull assets for 2009-2010 from the frames API
    if not (us.sic == "6311").any():
        rows, start = [], 0
        while True:
            url = f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&SIC=6311&type=10-K&dateb=&owner=include&count=100&start={start}&output=atom"
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
                x = r.read().decode("utf-8", "replace")
            ents = re.findall(r"<entry[^>]*>(.*?)</entry>", x, flags=re.S)
            n = 0
            for ent in ents:
                ck = re.search(r"<cik>(\d+)</cik>", ent)
                if ck:
                    rows.append({"sic": "6311", "cik": ck.group(1).zfill(10), "state": ""})
                    n += 1
            if n < 100:
                break
            start += 100
            time.sleep(0.25)
        us = pd.concat([us, pd.DataFrame(rows)]).drop_duplicates("cik")
        us.to_csv("scripts/universe_ciks_by_sic.csv", index=False)
        need = set(us[us.sic == "6311"].cik) | {"0001039828"}
        fr = []
        for cy in (2009, 2010):
            for q in (1, 2, 3, 4):
                try:
                    with urllib.request.urlopen(urllib.request.Request(f"https://data.sec.gov/api/xbrl/frames/us-gaap/Assets/USD/CY{cy}Q{q}I.json", headers=UA), timeout=90) as r:
                        d = json.load(r)
                except Exception:
                    continue
                for e in d.get("data", []):
                    ck = str(e["cik"]).zfill(10)
                    if ck in need:
                        fr.append({"cik": ck, "end": e["end"], "total_assets": e["val"], "accn": e["accn"], "entity": e.get("entityName", ""), "loc": "", "cal_year": int(e["end"][:4]), "sic": "6311", "state": ""})
                time.sleep(0.25)
        if fr:
            fr = pd.DataFrame(fr).sort_values(["cik", "cal_year", "end"]).drop_duplicates(["cik", "cal_year"], keep="last")
            ua = pd.concat([ua, fr])
            ua.to_csv("scripts/universe_assets_fy.csv", index=False)
    allc = pd.read_csv("scripts/candidates_edgar_check.csv", dtype=str)
    v1 = pd.read_csv("scripts/peers_matched_v1.csv", dtype=str)
    res = []
    for _, c in cases.iterrows():
        ry = int(c.revelation_date[:4])
        w = max(1, ry - max(ry - 5, 2011))  # XBRL-era coverage only; 10-K coverage verified below
        res.append(match_peers(pd.DataFrame([c]), ua, us, exclude_ciks=set(allc.cik) | set(v1.cik), k=5, window=w))
    res = pd.concat(res)
    if res.empty:
        print("no peers matched")
        return
    print(res.groupby("matched_case_id").agg(n=("cik", "size"), level=("sic_level", "first"), pool=("pool_size", "first"), gap=("ln_assets_gap", "mean")).round(2).to_string())
    rev = dict(zip(cases.case_id, cases.revelation_date.str[:4].astype(int)))
    chk = []
    for _, p in res.iterrows():
        try:
            name, sic, fys = fetch_years(p.cik)
            ry = rev[p.matched_case_id]
            have = len(set(range(ry - 5, ry)) & set(fys))
            chk.append({"cik": p.cik, "name": name, "sic": sic, "matched_case_id": p.matched_case_id, "tenk_in_window": have, "ok": have >= 4})
        except Exception as ex:
            chk.append({"cik": p.cik, "name": f"ERR {type(ex).__name__}", "sic": "", "matched_case_id": p.matched_case_id, "tenk_in_window": 0, "ok": False})
        time.sleep(0.15)
    chk = pd.DataFrame(chk)
    print(chk[["name", "matched_case_id", "tenk_in_window", "ok"]].to_string(index=False))
    pd.concat([pd.read_csv("scripts/peers_matched_v1_check.csv", dtype=str), chk.astype(str)]).to_csv("scripts/peers_matched_v1_check.csv", index=False)
    pd.concat([v1, res]).to_csv("scripts/peers_matched_v1.csv", index=False)


if __name__ == "__main__":
    step_tables()
    step_peers()
    subprocess.run([sys.executable, "scripts/build_cases_core.py", "--output", "cases_core.csv"], check=True)
