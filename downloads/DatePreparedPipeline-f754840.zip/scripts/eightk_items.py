"""8-K item flags per company and fiscal year from the EDGAR submissions API (no document download).

Item 4.01 = changes in registrant's certifying accountant (AUD_CHG), Item 4.02 = non-reliance on previously
issued financial statements (RESTATE). Fiscal year follows the Compustat rule used by the builder (FYE
January-May belongs to the previous year), applied to the 8-K's filing date so that an 8-K filed in the
fiscal year is attributed to that year.

    python scripts/eightk_items.py --cases-csv cases_core.csv --output data_core/eightk_items.csv
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.request
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sec_rpt_dataset.company import cik10  # noqa: E402

UA = os.environ.get("SEC_USER_AGENT", "PhD research curam.rice@gmail.com")
BASE = "https://data.sec.gov/submissions/"


def get_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip, deflate"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    import gzip
                    raw = gzip.decompress(raw)
                return json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            if attempt == 3:
                raise
            time.sleep(2 * (attempt + 1))
    return {}


def fiscal_year_of(date_str: str, fye_month: int | None) -> int:
    y, m = int(date_str[:4]), int(date_str[5:7])
    # Attribute the 8-K to the fiscal year in progress at its filing date, using the company's FYE month.
    if fye_month is None:
        return y
    fy_end_year = y if m <= fye_month else y + 1          # the fiscal year ending in fy_end_year
    return fy_end_year - 1 if fye_month <= 5 else fy_end_year


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases-csv", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--delay", type=float, default=0.15)
    args = ap.parse_args()
    cases = pd.read_csv(args.cases_csv, dtype=str).fillna("")
    ciks = sorted({cik10(c) for c in cases["cik"] if c})
    rows = []
    for i, cik in enumerate(ciks, 1):
        d = get_json(f"{BASE}CIK{cik}.json")
        fye = d.get("fiscalYearEnd") or ""
        fye_month = int(fye[:2]) if len(fye) == 4 and fye[:2].isdigit() else None
        batches = [d["filings"]["recent"]] + [get_json(BASE + e["name"]) for e in d["filings"].get("files", [])]
        for b in batches:
            for form, fdate, items, acc in zip(b["form"], b["filingDate"], b.get("items", [""] * len(b["form"])), b["accessionNumber"]):
                if not form.startswith("8-K"):
                    continue
                its = {x.strip() for x in str(items or "").split(",") if x.strip()}
                if its & {"4.01", "4.02"}:
                    rows.append({"cik": cik, "form": form, "filing_date": fdate, "accession_number": acc, "items": ";".join(sorted(its)),
                                 "fiscal_year": fiscal_year_of(fdate, fye_month), "item_401": int("4.01" in its), "item_402": int("4.02" in its)})
            time.sleep(args.delay)
        if i % 20 == 0:
            print(f"{i}/{len(ciks)} companies", flush=True)
    ev = pd.DataFrame(rows)
    out = (ev.groupby(["cik", "fiscal_year"]).agg(auditor_change_8k=("item_401", "max"), restatement_8k=("item_402", "max"),
                                                 n_8k_401_402=("accession_number", "size"), accessions=("accession_number", lambda s: "|".join(s))).reset_index()
           if not ev.empty else pd.DataFrame(columns=["cik", "fiscal_year", "auditor_change_8k", "restatement_8k", "n_8k_401_402", "accessions"]))
    # Every company-year in the panel should get an explicit 0, so write the events and let the consumer fill zeros.
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    ev.to_csv(str(Path(args.output)).replace(".csv", "_events.csv"), index=False)
    print(f"8-K 4.01/4.02 events: {len(ev)} across {out['cik'].nunique() if len(out) else 0} companies -> {args.output}")


if __name__ == "__main__":
    main()
