#!/usr/bin/env bash
# One command: install, build the SEC-RPT-Panel dataset from SEC EDGAR, and publish it to the Hugging Face Hub.
#
#   export HF_TOKEN=hf_...                                  # write token for the target org (never commit it)
#   export SEC_USER_AGENT="Your Name you@university.edu"    # required by SEC's fair-access policy
#   bash build_and_publish.sh                               # pilot defaults below
#   CASES=cases_core.csv START=2005 END=2024 bash build_and_publish.sh   # confirmatory sample
#
# Re-running resumes: files already on the Hub (and already on disk) are skipped.
set -Eeuo pipefail
cd "$(dirname "$0")"

CASES="${CASES:-cases.csv}"
START="${START:-2014}"
END="${END:-2024}"
REPO_ID="${REPO_ID:-codewithdark/SEC-RPT-Panel}"
OUTPUT_DIR="${OUTPUT_DIR:-data}"

: "${HF_TOKEN:?set HF_TOKEN to a Hugging Face write token}"
: "${SEC_USER_AGENT:?set SEC_USER_AGENT='Your Name you@example.edu'}"

python -m pip install -q -r requirements.txt
python -m unittest discover -s tests -q

python run_pipeline.py \
  --cases-csv "$CASES" \
  --output-dir "$OUTPUT_DIR" \
  --start-year "$START" --end-year "$END" --aaer-start-year "$START" \
  --repo-id "$REPO_ID" \
  --resume-from-hub --upload

echo
echo "Published: https://huggingface.co/datasets/$REPO_ID"
