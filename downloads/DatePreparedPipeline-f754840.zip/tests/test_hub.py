import json
import logging
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from sec_rpt_dataset import hub


def _make_output_dir(root: Path) -> Path:
    for name in ("company_universe", "filing_manifest", "master_panel"):
        (root / f"{name}.csv").write_text("cik\n0000896493\n", encoding="utf-8")
    (root / "master_panel.xlsx").write_bytes(b"xlsx")
    (root / "filing_manifest_partial.csv").write_text("x\n", encoding="utf-8")
    (root / "dataset_qa.json").write_text(json.dumps({"filings": 21, "companies": 3, "rpt_text_source": {"def14a": 14}}), encoding="utf-8")
    raw = root / "raw" / "filings" / "0000896493" / "2018" / "0001-18"
    raw.mkdir(parents=True)
    (raw / "rpt_disclosure.txt").write_text("text", encoding="utf-8")
    (root / "raw" / "aaer" / "2023").mkdir(parents=True)
    (root / "raw" / "aaer" / "2023" / "aaer_page_0.html").write_text("<html>", encoding="utf-8")
    (root / "raw" / "aaer" / "2023" / "AAER-4440.pdf").write_bytes(b"%PDF")
    return root


class TokenTests(unittest.TestCase):
    def test_explicit_then_env_then_none(self):
        with mock.patch.dict(os.environ, {"HF_TOKEN": "env-secret"}, clear=False):
            self.assertEqual(hub.resolve_token("explicit"), "explicit")
            self.assertEqual(hub.resolve_token(), "env-secret")

    def test_token_never_logged_during_upload(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(hub, "HfApi", create=True) as api_cls, \
                mock.patch("huggingface_hub.HfApi", api_cls), self.assertLogs(hub.LOGGER, level="DEBUG") as logs:
            _make_output_dir(Path(tmp))
            hub.upload_dataset(Path(tmp), "org/repo", version="2.0.0", token="hf_super_secret")
        self.assertFalse(any("hf_super_secret" in line for line in logs.output))


class CardTests(unittest.TestCase):
    def test_card_has_config_per_existing_table_and_label_semantics(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = _make_output_dir(Path(tmp))
            qa = json.loads((root / "dataset_qa.json").read_text())
            card = hub.build_dataset_card(root, "org/repo", "2.0.0", qa)
        self.assertIn("config_name: master_panel", card)
        self.assertIn("config_name: company_universe", card)
        self.assertNotIn("config_name: nlp_scores", card)  # not present on disk
        self.assertIn("fraud_aaer_label", card)
        self.assertIn("event_time", card)
        self.assertIn("| `filings` | 21 |", card)
        self.assertTrue(card.startswith("---\n"))


class PlanTests(unittest.TestCase):
    def test_plan_excludes_partials_html_and_xlsx_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = _make_output_dir(Path(tmp))
            plan = hub.plan_upload(root, hub.METADATA_PATTERNS, include_raw=True)
        self.assertIn("master_panel.csv", plan["metadata"])
        self.assertIn("dataset_qa.json", plan["metadata"])
        self.assertNotIn("filing_manifest_partial.csv", plan["metadata"])
        self.assertNotIn("master_panel.xlsx", plan["metadata"])
        self.assertIn("raw/filings/0000896493/2018/0001-18/rpt_disclosure.txt", plan["raw"])
        self.assertIn("raw/aaer/2023/AAER-4440.pdf", plan["raw"])
        self.assertNotIn("raw/aaer/2023/aaer_page_0.html", plan["raw"])

    def test_dry_run_makes_no_network_calls(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("huggingface_hub.HfApi") as api_cls:
            root = _make_output_dir(Path(tmp))
            summary = hub.upload_dataset(root, "org/repo", version="2.0.0", dry_run=True)
        api_cls.assert_not_called()
        self.assertEqual(summary["metadata_files"], 4)  # 3 csv + qa json
        self.assertEqual(summary["raw_files"], 2)
        self.assertFalse((root / "README.md").exists())


class UploadTests(unittest.TestCase):
    def test_upload_creates_repo_writes_card_and_commits_with_version(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("huggingface_hub.HfApi") as api_cls:
            root = _make_output_dir(Path(tmp))
            api = api_cls.return_value
            summary = hub.upload_dataset(root, "org/repo", version="2.0.0", token="t")
            api.create_repo.assert_called_once_with("org/repo", repo_type="dataset", exist_ok=True, private=False)
            self.assertTrue((root / "README.md").exists())
            api.upload_large_folder.assert_called_once()
            self.assertEqual(api.upload_large_folder.call_args.kwargs["allow_patterns"], ["raw/**"])
            folder_kwargs = api.upload_folder.call_args.kwargs
            self.assertIn("2.0.0", folder_kwargs["commit_message"])
            self.assertIn("*_partial.csv", folder_kwargs["ignore_patterns"])
            self.assertNotIn("*.xlsx", folder_kwargs["allow_patterns"])
            self.assertEqual(summary["url"], "https://huggingface.co/datasets/org/repo")

    def test_no_raw_skips_large_folder_upload(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("huggingface_hub.HfApi") as api_cls:
            root = _make_output_dir(Path(tmp))
            hub.upload_dataset(root, "org/repo", version="2.0.0", include_raw=False, include_xlsx=True)
            api = api_cls.return_value
            api.upload_large_folder.assert_not_called()
            self.assertIn("*.xlsx", api.upload_folder.call_args.kwargs["allow_patterns"])


class DownloadTests(unittest.TestCase):
    def test_cik_mode_builds_per_cik_patterns(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("huggingface_hub.snapshot_download") as snap:
            hub.download_dataset(Path(tmp), "org/repo", mode="ciks", ciks=["896493"], token="t")
            allow = snap.call_args.kwargs["allow_patterns"]
        self.assertIn("raw/filings/0000896493/**", allow)
        self.assertIn("raw/proxies/0000896493/**", allow)
        self.assertIn("raw/xbrl/CIK0000896493.json", allow)
        self.assertIn("*.csv", allow)

    def test_metadata_and_full_modes(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("huggingface_hub.snapshot_download") as snap:
            hub.download_dataset(Path(tmp), "org/repo", mode="metadata")
            self.assertEqual(snap.call_args.kwargs["allow_patterns"], list(hub.METADATA_PATTERNS))
            hub.download_dataset(Path(tmp), "org/repo", mode="full")
            self.assertIsNone(snap.call_args.kwargs["allow_patterns"])
        with self.assertRaises(ValueError):
            hub.download_dataset(Path(tmp), "org/repo", mode="ciks")


if __name__ == "__main__":
    unittest.main()
