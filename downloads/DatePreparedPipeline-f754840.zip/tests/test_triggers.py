import unittest

from sec_rpt_dataset.triggers import extract_trigger_values


class TriggerTests(unittest.TestCase):
    def test_extracts_urls_cik_and_ticker(self):
        data = {
            "company_name": "Example Corp",
            "ticker": "EXM",
            "url": "https://www.sec.gov/Archives/edgar/data/CIK0000123456/report.htm",
        }
        values = extract_trigger_values(data)
        self.assertIn("Example Corp", values["company_names"])
        self.assertIn("EXM", values["tickers"])
        self.assertTrue(values["urls"])


if __name__ == "__main__":
    unittest.main()

