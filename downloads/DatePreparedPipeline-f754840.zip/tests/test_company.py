import unittest

from sec_rpt_dataset.company import flatten_company_metadata


class CompanyMetadataTests(unittest.TestCase):
    def test_flatten_metadata_skips_none_in_list_fields(self):
        row = {"cik": "123", "ticker": "ABC", "name": "ABC Corp"}
        submission = {
            "cik": "123",
            "name": "ABC Corp",
            "tickers": ["ABC", None, ""],
            "exchanges": [None, "Nasdaq", ""],
            "formerNames": [{"name": None}, {"name": "Old ABC Inc."}],
        }

        flattened = flatten_company_metadata(row, submission)

        self.assertEqual(flattened["tickers"], "ABC")
        self.assertEqual(flattened["exchanges"], "Nasdaq")
        self.assertEqual(flattened["former_names"], "Old ABC Inc.")


if __name__ == "__main__":
    unittest.main()

