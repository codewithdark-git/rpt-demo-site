import unittest

from sec_rpt_dataset.nlp import score_text


class NLPTests(unittest.TestCase):
    def test_scores_vagueness_and_readability(self):
        scores = score_text("The company may possibly face uncertain risks. Profit improved.")
        self.assertEqual(scores["word_count"], 9)
        self.assertGreater(scores["vagueness_ratio"], 0)
        self.assertIn("fog_index", scores)
        self.assertIn("net_sentiment_ratio", scores)


if __name__ == "__main__":
    unittest.main()

