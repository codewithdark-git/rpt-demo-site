import unittest

from sec_rpt_dataset.parser import (
    extract_item,
    extract_proxy_rpt_section,
    extract_rp_note,
    icfr_flags,
    is_incorporated_by_reference,
    word_count,
)

FILLER = " ".join(["The company describes its operations, customers, suppliers and markets in detail."] * 30)
RPT_BODY = " ".join(["On March 9, 2017 we entered into a purchase agreement with Philou Ventures, our largest stockholder, managed by the spouse of our Chief Executive Officer."] * 5)

# A multi-line table of contents, as produced by html_to_text on real 10-Ks.
FILING = f"""
TABLE OF CONTENTS
Item 1.
Business
4
Item 1A.
Risk Factors
12
Item 9A.
Controls and Procedures
50
Item 13.
Certain Relationships and Related Transactions, and Director Independence
62
Item 14.
Principal Accountant Fees and Services
64
PART I
ITEM 1. BUSINESS
{FILLER}
See Item 13 for related transactions.
ITEM 1A. RISK FACTORS
Risks are many.
ITEM 9A. CONTROLS AND PROCEDURES
Based upon that evaluation, our principal executive officer concluded that our disclosure controls and procedures were not effective due to certain material weaknesses. Management concluded that our internal control over financial reporting was not effective. {FILLER}
ITEM 9B. OTHER INFORMATION
None.
ITEM 13. CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS, AND DIRECTOR INDEPENDENCE
{RPT_BODY}
ITEM 14. PRINCIPAL ACCOUNTANT FEES AND SERVICES
Fees are disclosed here.
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS
10. INVESTMENTS - RELATED PARTIES
{FILLER}
11. NOTES PAYABLE
Notes text.
26. RELATED PARTY TRANSACTIONS
{RPT_BODY}
27. SEGMENT INFORMATION
Segment text.
"""


class ItemExtractionTests(unittest.TestCase):
    def test_item13_skips_table_of_contents(self):
        section, status = extract_item(FILING, "13")
        self.assertEqual(status, "ok")
        self.assertIn("Philou Ventures", section)
        self.assertNotIn("Principal Accountant Fees", section)

    def test_item1_does_not_stop_at_inline_cross_reference(self):
        section, status = extract_item(FILING, "1")
        self.assertEqual(status, "ok")
        self.assertIn("See Item 13", section)
        self.assertNotIn("Risks are many", section)

    def test_item9a_extracted(self):
        section, status = extract_item(FILING, "9A")
        self.assertEqual(status, "ok")
        self.assertNotIn("OTHER INFORMATION", section)

    def test_toc_only_filing_is_short_section(self):
        toc_only = "Item 13.\nCertain Relationships and Related Transactions\n62\nItem 14.\nFees\n64"
        section, status = extract_item(toc_only, "13")
        self.assertEqual(status, "short_section")
        self.assertLess(word_count(section), 40)

    def test_incorporated_by_reference_detected(self):
        stub = ("ITEM 13. CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS, AND DIRECTOR INDEPENDENCE\n"
                "The information required by this item is incorporated by reference to the information "
                "contained under the captions Director Independence in our Proxy Statement.")
        self.assertTrue(is_incorporated_by_reference(stub))
        self.assertTrue(is_incorporated_by_reference(
            "Item 13: CERTAIN RELATIONSHIPS\nInformation appearing under the caption Related Person Transactions "
            "in the Company's 2021 Proxy Statement is incorporated herein by this reference."))
        self.assertFalse(is_incorporated_by_reference(extract_item(FILING, "13")[0]))


class RelatedPartyNoteTests(unittest.TestCase):
    def test_prefers_transactions_note_over_investments_note(self):
        note, status = extract_rp_note(FILING)
        self.assertEqual(status, "ok")
        self.assertTrue(note.startswith("26. RELATED PARTY TRANSACTIONS"))
        self.assertNotIn("Segment text", note)


class ProxySectionTests(unittest.TestCase):
    def test_section_ends_at_next_top_level_heading_not_party_name(self):
        proxy = f"""
CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS
45
PROPOSALS OF STOCKHOLDERS
47
CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS
{RPT_BODY}
PHILOU VENTURES, LLC
{RPT_BODY}
PROPOSALS OF STOCKHOLDERS FOR THE 2020 ANNUAL MEETING
Stockholders may submit proposals.
"""
        section, status = extract_proxy_rpt_section(proxy)
        self.assertEqual(status, "ok")
        self.assertIn("PHILOU VENTURES, LLC", section)
        self.assertNotIn("Stockholders may submit", section)


class IcfrFlagTests(unittest.TestCase):
    def test_not_effective_with_material_weakness(self):
        flags = icfr_flags(extract_item(FILING, "9A")[0])
        self.assertEqual(flags["icfr_not_effective"], 1)
        self.assertEqual(flags["dcp_not_effective"], 1)
        self.assertEqual(flags["material_weakness_reported"], 1)

    def test_auditor_boilerplate_is_not_a_reported_weakness(self):
        text = ("Management concluded that our internal control over financial reporting was effective. "
                "Our audit included assessing the risk that a material weakness exists. "
                "A material weakness is a deficiency, or a combination of deficiencies, in internal control. " + FILLER)
        flags = icfr_flags(text)
        self.assertEqual(flags["icfr_not_effective"], 0)
        self.assertEqual(flags["icfr_effective_stated"], 1)
        self.assertEqual(flags["material_weakness_reported"], 0)
        self.assertEqual(flags["material_weakness_mentions"], 0)

    def test_remediated_weakness_is_flagged_separately(self):
        text = ("We previously disclosed a material weakness in internal control over financial reporting. "
                "We concluded that the material weakness has been remediated as of July 3, 2021. "
                "Management concluded that our internal control over financial reporting was effective. " + FILLER)
        flags = icfr_flags(text)
        self.assertEqual(flags["icfr_not_effective"], 0)
        self.assertEqual(flags["material_weakness_reported"], 1)
        self.assertEqual(flags["material_weakness_remediated"], 1)

    def test_missing_text_gives_blank_flags(self):
        flags = icfr_flags("")
        self.assertEqual(flags["icfr_text_available"], 0)
        self.assertEqual(flags["icfr_not_effective"], "")


if __name__ == "__main__":
    unittest.main()
