import tempfile
import unittest
from pathlib import Path

from sec_rpt_dataset.aaer import build_fraud_labels, match_aaer_company, parse_aaer_listing
from sec_rpt_dataset.config import PipelineConfig


def listing_row(date: str, respondents: str, numbers: str, pdf: str) -> str:
    return f"""
<tr class="pr-list-page-row">
  <td headers="view-field-publish-date-table-column"><time datetime="{date}T13:00:00Z" class="datetime">x</time></td>
  <td><div class='release-view__respondents'><a href='{pdf}'>{respondents}</a></div>
  <div class="view-table_subfield view-table_subfield_release_number">
    <span class="view-table_subfield_label">Release No.</span>
    <span class="view-table_subfield_value">{numbers}</span>
  </div></td>
</tr>"""


PAGE = (
    "<table>"
    + listing_row("2023-08-21", "Michael J. Senken", "34-98186, AAER-4442", "https://www.sec.gov/files/litigation/apdocuments/34-98186.pdf")
    + listing_row("2023-08-15", "Ault Alliance, et al.", "33-11222, 34-98131, AAER-4440", "/files/litigation/admin/2023/33-11222.pdf")
    + listing_row("2024-12-31", "Accell Audit &amp; Compliance, PA", "34-102060, AAER-4554, AAER-4553", "/x.pdf")
    + listing_row("2024-12-27", "Christopher Hiestand, CPA", "34-102047, AAER-4552", "/y.pdf")
    + "</table>"
)
BASE = "https://www.sec.gov/enforcement-litigation/accounting-auditing-enforcement-releases"


class ListingParserTests(unittest.TestCase):
    def setUp(self):
        self.rows = parse_aaer_listing(PAGE, BASE, 2023)

    def test_each_row_keeps_its_own_date_and_release_number(self):
        ault = next(r for r in self.rows if r["aaer_no"] == "AAER-4440")
        self.assertEqual(ault["release_date"], "2023-08-15")
        self.assertEqual(ault["release_no"], "33-11222|34-98131")
        self.assertEqual(ault["respondents"], "Ault Alliance, et al.")
        self.assertEqual(ault["document_url"], "https://www.sec.gov/files/litigation/admin/2023/33-11222.pdf")

    def test_row_with_two_aaer_numbers_gives_two_rows(self):
        numbers = sorted(r["aaer_no"] for r in self.rows if r["respondents"].startswith("Accell"))
        self.assertEqual(numbers, ["AAER-4553", "AAER-4554"])


class MatchingTests(unittest.TestCase):
    def setUp(self):
        self.rows = parse_aaer_listing(PAGE, BASE, 2023)

    def test_cpa_credential_does_not_match_ticker_cpa(self):
        copa = {"name": "Copa Holdings, S.A.", "ticker": "CPA", "tickers": "CPA", "former_names": ""}
        self.assertFalse(any(match_aaer_company(r, copa)[0] for r in self.rows))

    def test_former_name_matches_renamed_issuer(self):
        hyperscale = {"name": "Hyperscale Data, Inc.", "former_names": "Ault Alliance, Inc.|DPW Holdings, Inc."}
        matched = [r["aaer_no"] for r in self.rows if match_aaer_company(r, hyperscale)[0]]
        self.assertEqual(matched, ["AAER-4440"])

    def test_individual_name_inside_company_name_does_not_match(self):
        company = {"name": "Senken Industries Corp", "former_names": ""}
        self.assertFalse(any(match_aaer_company(r, company)[0] for r in self.rows))


class LabelTests(unittest.TestCase):
    def test_cases_file_labels_assessment_window_before_revelation(self):
        cases = [
            {"cik": "0000896493", "case_id": "AULT", "role": "case", "misconduct_start_fy": "2016",
             "misconduct_end_fy": "2022", "revelation_date": "2023-08-15", "rpt_relevance": "Strong"},
            {"cik": "0000000001", "case_id": "", "role": "peer", "matched_case_id": "AULT"},
        ]
        companies = [{"cik": "0000896493", "name": "Hyperscale Data, Inc."}, {"cik": "0000000001", "name": "Peer Co"}]
        with tempfile.TemporaryDirectory() as tmp:
            config = PipelineConfig(output_dir=Path(tmp), start_year=2016, end_year=2023, checkpoint_interval=0)
            labels = build_fraud_labels(config, companies, [], cases=cases)
        ault = {r["fiscal_year"]: r for r in labels if r["cik"] == "0000896493"}
        peer = {r["fiscal_year"]: r for r in labels if r["cik"] == "0000000001"}
        self.assertEqual([y for y, r in ault.items() if r["fraud_aaer_label"] == 1], [2018, 2019, 2020, 2021, 2022])
        self.assertEqual(ault[2023]["event_time"], 0)
        self.assertEqual(ault[2017]["fraud_aaer_label"], 0)
        self.assertTrue(all(r["fraud_aaer_label"] == 0 for r in peer.values()))
        self.assertEqual(peer[2020]["event_time"], -3)
        self.assertEqual(peer[2020]["case_id"], "AULT")

    def test_missing_revelation_date_gives_unknown_label_not_zero(self):
        cases = [
            {"cik": "0000874499", "case_id": "GPOR", "role": "case", "misconduct_start_fy": "2014",
             "misconduct_end_fy": "2018", "revelation_date": ""},
            {"cik": "0000000002", "role": "peer", "matched_case_id": "GPOR"},
        ]
        companies = [{"cik": "0000874499", "name": "Gulfport"}, {"cik": "0000000002", "name": "Peer"}]
        with tempfile.TemporaryDirectory() as tmp:
            config = PipelineConfig(output_dir=Path(tmp), start_year=2016, end_year=2018, checkpoint_interval=0)
            labels = build_fraud_labels(config, companies, [], cases=cases)
        self.assertTrue(all(r["fraud_aaer_label"] == "" for r in labels))
        self.assertTrue(all(r["label_source"] == "cases_file_missing_revelation_date" for r in labels))
        self.assertEqual(labels[0]["misconduct_period"], 1)


if __name__ == "__main__":
    unittest.main()
