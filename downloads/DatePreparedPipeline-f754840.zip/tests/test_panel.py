import unittest

from sec_rpt_dataset.company import dedupe_by_cik
from sec_rpt_dataset.documents import candidate_proxies
from sec_rpt_dataset.filings import fiscal_year, flag_duplicate_fiscal_years
from sec_rpt_dataset.financials import extract_annual_values
from sec_rpt_dataset.nlp import score_text


class FiscalYearTests(unittest.TestCase):
    def test_compustat_convention(self):
        self.assertEqual(fiscal_year({"reportDate": "2024-05-31"}), 2023)
        self.assertEqual(fiscal_year({"reportDate": "2024-06-30"}), 2024)
        self.assertEqual(fiscal_year({"reportDate": "2018-12-31"}), 2018)

    def test_falls_back_to_filing_date_minus_one(self):
        self.assertEqual(fiscal_year({"reportDate": "", "filingDate": "2019-04-16"}), 2018)

    def test_first_original_filing_is_primary(self):
        rows = [
            {"cik": "1", "year": 2019, "form": "10-K/A", "filing_date": "2020-06-01"},
            {"cik": "1", "year": 2019, "form": "10-K", "filing_date": "2020-05-29"},
        ]
        flagged = {r["form"]: r["is_primary_filing"] for r in flag_duplicate_fiscal_years(rows)}
        self.assertEqual(flagged, {"10-K": 1, "10-K/A": 0})


class UniverseTests(unittest.TestCase):
    def test_one_row_per_cik(self):
        rows = [{"cik": "896493", "ticker": "GPUS"}, {"cik": "0000896493", "ticker": "GPUS-PD"}, {"cik": "1750", "ticker": "AIR"}]
        deduped = dedupe_by_cik(rows)
        self.assertEqual(len(deduped), 2)
        self.assertEqual(deduped[0]["all_tickers"], "GPUS|GPUS-PD")


class ProxyWindowTests(unittest.TestCase):
    def test_only_proxies_filed_after_year_end_within_window(self):
        filing = {"report_date": "2018-12-31"}
        proxies = [
            {"filing_date": "2018-06-01", "document_url": "a"},
            {"filing_date": "2019-01-30", "document_url": "b"},
            {"filing_date": "2019-06-07", "document_url": "c"},
            {"filing_date": "2020-11-13", "document_url": "d"},
        ]
        self.assertEqual([p["document_url"] for p in candidate_proxies(filing, proxies)], ["b", "c"])


class XbrlTests(unittest.TestCase):
    def test_first_reported_value_wins_and_quarters_are_ignored(self):
        facts = {"facts": {"us-gaap": {
            "NetIncomeLoss": {"units": {"USD": [
                {"start": "2018-01-01", "end": "2018-12-31", "val": -32, "form": "10-K", "filed": "2019-04-16", "accn": "orig"},
                {"start": "2018-01-01", "end": "2018-12-31", "val": -40, "form": "10-K", "filed": "2020-05-29", "accn": "restated"},
                {"start": "2018-10-01", "end": "2018-12-31", "val": -9, "form": "10-K", "filed": "2019-04-16", "accn": "q4"},
            ]}},
            "Assets": {"units": {"USD": [{"end": "2018-12-31", "val": 49, "form": "10-K", "filed": "2019-04-16", "accn": "orig"}]}},
        }}}
        rows = extract_annual_values(facts, "0000896493", 2018, 2018)
        self.assertEqual(rows[0]["net_income"], -32)
        self.assertEqual(rows[0]["net_income_accession"], "orig")
        self.assertEqual(rows[0]["total_assets"], 49)


class NlpMissingTextTests(unittest.TestCase):
    def test_short_text_is_missing_not_zero(self):
        scores = score_text("Item 13. Certain Relationships", prefix="item13", min_words=40)
        self.assertEqual(scores["item13_text_available"], 0)
        self.assertEqual(scores["item13_fog_index"], "")


if __name__ == "__main__":
    unittest.main()
