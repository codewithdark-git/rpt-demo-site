# SEC EDGAR RPT / AAER Research Dataset Pipeline

This codebase builds a company-year dataset for accounting PhD research using
official SEC EDGAR company submissions, 10-K filings, and SEC Accounting and
Auditing Enforcement Releases (AAERs).

The pipeline stores data as CSV, Excel workbooks, and raw text files. It does
not use SQL.

## Data Sources

- Company universe: `https://www.sec.gov/files/company_tickers.json`
- Company submissions: `https://data.sec.gov/submissions/CIK##########.json`
- Filing documents: `https://www.sec.gov/Archives/edgar/data/...`
- AAER labels: `https://www.sec.gov/enforcement-litigation/accounting-auditing-enforcement-releases`

## Quick Start

Set a research contact User-Agent before downloading from SEC:

```powershell
$env:SEC_USER_AGENT="Your Name your.email@university.edu"
```

Run the offline tests:

```powershell
python -m unittest discover -s tests
```

Create the company universe file and Excel workbook:

```powershell
python -m sec_rpt_dataset.cli companies --output-dir data --display-limit 25
```

Run a small smoke test against SEC for two companies and one year:

```powershell
python -m sec_rpt_dataset.cli run-sample --output-dir data --start-year 2023 --end-year 2023 --limit-companies 2
```

Run the full research pipeline:

```powershell
python -m sec_rpt_dataset.cli run-all --output-dir data --start-year 2000 --end-year 2026
```

Long runs print terminal progress by default and write partial CSV checkpoints
such as `company_universe_partial.csv`, `filing_manifest_partial.csv`, and
`extraction_manifest_partial.csv` while the job is still running. This is useful
for Colab and remote terminals where a full SEC universe run can take many hours.

Tune progress output if needed:

```powershell
python -m sec_rpt_dataset.cli run-all --output-dir data --start-year 2000 --end-year 2026 --progress-interval 25 --checkpoint-interval 25
```

Use `--quiet` to suppress progress logs, or `--log-level DEBUG` for more detail.

## One-command run (local or Google Colab)

```bash
export HF_TOKEN=hf_...  SEC_USER_AGENT="Your Name you@university.edu"
bash build_and_publish.sh                                   # pilot (cases.csv, FY2014-2024)
CASES=cases_core.csv START=2005 END=2024 bash build_and_publish.sh   # confirmatory sample
```

`build_and_publish.sh` installs, runs the tests, builds every phase and uploads. Equivalent Python call:

```python
# Colab cell
!git clone https://github.com/codewithdark-git/DatePreparedPipeline.git && cd DatePreparedPipeline && pip install -q -r requirements.txt
import os
os.environ["SEC_USER_AGENT"] = "Your Name you@university.edu"   # required by SEC
os.environ["HF_TOKEN"] = "hf_..."                               # write token; never commit it
!cd DatePreparedPipeline && python run_pipeline.py --cases-csv cases.csv \
    --start-year 2014 --end-year 2024 --aaer-start-year 2014 \
    --repo-id codewithdark/SEC-RPT-Panel --resume-from-hub --upload
```

`run_pipeline.py` runs every phase (universe → manifests → 10-K/DEF 14A
download and extraction → XBRL → AAER → labels → master panel → QA) and, with
`--upload`, pushes the result to the Hub. `--resume-from-hub` makes a restarted
Colab session continue where the last one stopped. All flags can also be set
as environment variables (`CASES_CSV`, `START_YEAR`, `END_YEAR`, `HF_REPO_ID`,
`HF_UPLOAD=1`, `HF_RESUME=1`).

## Thesis Panel Mode (v2, recommended)

Build the dataset from a hand-verified case/peer file instead of the current
SEC ticker list. The ticker list contains only *currently listed* firms, so
delisted fraud firms (Enron, Puda Coal, Iteris, Skechers after going private, ...)
would otherwise be silently missing.

```powershell
python -m sec_rpt_dataset.cli run-all --output-dir data --start-year 2005 --end-year 2024 `
  --cases-csv cases.csv --aaer-start-year 2005
```

`cases.csv` columns (one row per firm; see `cases.example.csv`):

| column | meaning |
|---|---|
| `case_id` | identifier of the fraud case (blank for peers) |
| `cik` | SEC CIK (required) |
| `ticker`, `company_name` | informational |
| `role` | `case` or `peer` |
| `matched_case_id` | for peers: the `case_id` they are matched to |
| `aaer_numbers` | verified AAER number(s), pipe-separated |
| `misconduct_start_fy`, `misconduct_end_fy` | misconduct period from the SEC order |
| `revelation_date` | first public revelation (8-K, press release, restatement), `YYYY-MM-DD` |
| `rpt_relevance` | Strong / Moderate / Weak (your inclusion rule) |

Labels written to `fraud_labels.csv` (keyed on `cik`, `fiscal_year`):

- `fraud_aaer_label`: 1 for a case firm's fiscal years inside the assessment
  window (`--assessment-window`, default 5 years before the revelation year);
  0 for peers and for years outside the window.
- `event_time`: fiscal year minus revelation year (peers inherit their case's).
- `misconduct_period`: 1 inside the misconduct period (case firms).
- `aaer_release_in_year` / `aaer_numbers`: *unverified* automatic name matches
  of AAERs released in that year. Review `aaer_company_matches.csv`.

Without `--cases-csv`, `fraud_aaer_label` falls back to the unverified
enforcement-year match and `label_source` says so. Do not use that for analysis.

### Pilot cases file

`python scripts/make_pilot_cases.py --output cases.csv` writes the five pilot
anchors (Ault Alliance, ProPetro, Co-Diagnostics, Gulfport, Skechers) and their
peers. Delisted peers are resolved through `scripts/peer_cik_overrides.csv`
because SEC's `company_tickers.json` only lists current registrants and reuses
tickers (VIVO now belongs to VivoPower, not Meridian Bioscience). Every
`revelation_date` is provisional until you set `revelation_verified` to `YES`.

### Peer matching

Pilot peers are the hand-picked industry competitors from the research design.
For the confirmatory sample use the rule: same 4-digit SIC (fall back to 3-digit),
closest `ln(total_assets)` in the fiscal year before the revelation year, and a
10-K on file for every window year. Document any manual substitution in
`cases.csv`.

### Publishing and resuming (Hugging Face Hub)

```powershell
$env:HF_TOKEN = "hf_..."          # write token for the target org; never committed
python -m sec_rpt_dataset.cli upload --output-dir data --dry-run      # list what would go up
python -m sec_rpt_dataset.cli upload --output-dir data                # publish tables + raw/
python -m sec_rpt_dataset.cli run-all ... --cases-csv cases.csv --resume-from-hub --upload
python -m sec_rpt_dataset.cli download --output-dir data --mode metadata
python -m sec_rpt_dataset.cli download --output-dir data --mode ciks --cases-csv cases.csv
```

Default repo: `codewithdark/SEC-RPT-Panel` (`--repo-id` to change). Uploads
skip files the Hub already has and downloads skip unchanged local files, so a
run can be stopped and resumed. `*_partial.csv` checkpoints and AAER listing
HTML are never uploaded; Excel copies only with `--include-xlsx`. A dataset
card (`README.md`) with one config per table and the `dataset_qa.json`
coverage summary is generated at upload time.

### What v2 extracts per 10-K

| file | content |
|---|---|
| `item1.txt` | Item 1 Business (specificity baseline) |
| `item9a.txt` | Item 9A Controls and Procedures; flags in `extraction_manifest.csv` (`icfr_not_effective`, `material_weakness_reported`, ...) |
| `item13.txt` | Item 13 **body** (table-of-contents lines are skipped) |
| `rp_note.txt` | financial-statement note "Related Party Transactions" |
| `rpt_disclosure.txt` | Item 13 body if substantive, otherwise the related-party section of the matching DEF 14A (`rpt_text_source` = `10k_item13` / `def14a` / `none`) |

Texts under `--min-text-words` (default 40) are treated as **missing**: NLP
scores are blank and `*_text_available` = 0, never 0.0 scores.

`xbrl_financials.csv` holds annual XBRL values *as first reported* (FY2009+).
Related-party amounts tagged on a dimension are not in SEC company facts;
hand-collect them from `rp_note.txt`.

`fiscal_year` follows the Compustat convention (FYE January-May belongs to the
previous year). `is_primary_filing` = 1 marks the first original 10-K per
company-year. `dataset_qa.json` summarises coverage; publish it with the dataset.

## Output Layout

```text
data/
  company_universe.csv
  company_universe.xlsx
  filing_manifest.csv
  filing_manifest.xlsx
  proxy_manifest.csv
  aaer_manifest.csv
  aaer_manifest.xlsx
  aaer_company_matches.csv
  xbrl_financials.csv
  dataset_qa.json
  fraud_labels.csv
  fraud_labels.xlsx
  nlp_scores.csv
  nlp_scores.xlsx
  master_panel.csv
  master_panel.xlsx
  raw/
    filings/<CIK>/<YEAR>/<ACCESSION>/
      filing.txt
      item1.txt
      item9a.txt
      item13.txt
      rp_note.txt
      rpt_disclosure.txt
      filing_metadata.csv
    proxies/<CIK>/<ACCESSION>/
      proxy.txt
      proxy_rpt.txt
    xbrl/CIK##########.json
    aaer/<YEAR>/
      aaer_page_<N>.html
      <AAER_NO>.pdf
      <AAER_NO>.txt
```

## Notes

- SEC automated access must comply with SEC fair-access policies. The downloader
  uses a User-Agent, retries, and request pacing.
- Raw 10-K filing text and extracted Item 1 / Item 13 text are stored as `.txt`
  files to keep CSV/Excel outputs usable.
- A full 2000-2026 run across the SEC company universe is large. Phase 1 fetches
  company submission metadata before the final `company_universe.csv/xlsx` files
  are written, but partial checkpoint CSVs are created during the phase.
- AAER matching is deterministic and source-backed, but company names in AAER
  releases are not always CIK-tagged. Review `fraud_labels.csv` for match
  evidence before using final labels in publication analyses.
- To restrict the universe to an external trigger-card JSON, pass
  `--trigger-card-json path\to\trigger_cards.json` or
  `--trigger-card-url https://.../trigger_cards.json`.
