"""Generate the public static demo site (GitHub Pages) from the research outputs.

One script, one output folder. Everything on the site is read from the same files the thesis tables come from
(outputs/full_all, its design_tests_v2/<design> battery, the coded CSVs in data/, the EDGAR build in
SEC-EDGAR-Downloader/data_core), so the site can be regenerated after any re-run. Only public SEC filing excerpts and
the coder's evidence sentences are shipped.

    python scripts/export_site.py --out ../rpt-demo-site --design main31
    python scripts/export_site.py --out ../rpt-demo-site --limit 3 --skip-zip --skip-docs   # smoke test
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from rpt_panel import data_access as da  # noqa: E402
from rpt_panel import run as R  # noqa: E402
from rpt_panel.config import load_config  # noqa: E402
from rpt_panel.predict import load_model  # noqa: E402
from rpt_panel.text_features import _word_count, related_party_text  # noqa: E402
from design_tests_v2 import CHARACTERISTICS, attribution, characteristic_values, rank_scores  # noqa: E402
from core.config import Config  # noqa: E402
from nlp.readability import ReadabilityAnalyser  # noqa: E402
from nlp.sfl_analyser import SFLAnalyser  # noqa: E402
from nlp.vagueness_scorer import VaguenessScorer  # noqa: E402

SITE_SRC = ROOT / "scripts" / "site"
DOWNLOADER = ROOT.parent / "SEC-EDGAR-Downloader"
REPOS = [
    {"name": "TrainingPipeline", "path": ROOT, "url": "https://github.com/codewithdark-git/TrainingPipeline", "branch": "rpt-panel-v2",
     "what": "Panel construction, the coders (related-party amounts, governance, audit opinion), the design battery, the exploratory models, explainability, the document generators and this site's exporter (package rpt_panel, scripts/).",
     "exclude": [":(exclude)data", ":(exclude)*.docx", ":(exclude)*.log", ":(exclude)tests/fixtures", ":(exclude)legacy"]},
    {"name": "DatePreparedPipeline", "path": DOWNLOADER, "url": "https://github.com/codewithdark-git/DatePreparedPipeline", "branch": "fix/thesis-panel-v2",
     "what": "The EDGAR downloader and extractor (package sec_rpt_dataset), the Phase A case discovery and screening scripts, peer matching, 8-K item and 10-K/A fetchers.",
     "exclude": [":(exclude)*.log"]},
]
CHAR_LABEL = {
    "RP_LEND": ("Loans, advances, notes and receivables due from related parties ÷ total assets", "largest lending amount in the related-party text ÷ XBRL total assets (clipped at 1)"),
    "RP_PAY": ("Loans, notes and amounts due to related parties ÷ total assets", "largest payable amount ÷ XBRL total assets (clipped at 1)"),
    "RP_SALES": ("Revenue from related parties ÷ total revenue", "largest sales amount ÷ XBRL revenue (clipped at 1)"),
    "RP_PURCH": ("Purchases, fees, rent and services paid to related parties ÷ total assets", "largest purchase amount ÷ XBRL total assets (clipped at 1)"),
    "RP_INCOMP": ("Incompleteness of the disclosure", "(4 − items stated) ÷ 4; items: counterparty named, amount stated, terms stated, purpose stated"),
    "RP_VAGUE": ("Vagueness of the related-party text", "(uncertainty + weak-modal words) ÷ total words"),
    "BRD_NONIND": ("Share of non-independent directors", "1 − (independent directors ÷ board size), from the proxy statement"),
    "DUAL": ("CEO duality", "1 if the chief executive also chairs the board"),
}
FEATURE_META = {
    "earnings_cash_divergence": ("L1_financial", "(net income − operating cash flow) ÷ total assets, bounded ±1", "XBRL"),
    "accruals": ("L1_financial", "(net income − operating cash flow) ÷ lagged total assets, bounded ±1", "XBRL"),
    "icfr_not_effective": ("L2_monitoring", "1 if Item 9A says internal control over financial reporting was not effective", "10-K Item 9A"),
    "material_weakness_reported": ("L2_monitoring", "1 if a material weakness is reported", "10-K Item 9A"),
    "mw_count": ("L2_monitoring", "number of material weaknesses described", "10-K Item 9A"),
    "mw_persistence_2yr": ("L2_monitoring", "1 if a material weakness was reported in this and the previous year", "10-K Item 9A"),
    "big4": ("L2_monitoring", "1 if the signing auditor is Deloitte, EY, KPMG or PwC", "10-K audit report"),
    "ceo_duality": ("L2_monitoring", "1 if the CEO chairs the board", "DEF 14A"),
    "ac_indep": ("L2_monitoring", "1 if every audit-committee member is stated independent", "DEF 14A"),
    "auditor_change": ("L2_monitoring", "1 if the signing auditor differs from the previous year", "10-K audit report"),
    "going_concern_opinion": ("L2_monitoring", "1 if the audit report raises substantial doubt about going concern", "10-K audit report"),
    "restatement_8k": ("L2_monitoring", "1 if an 8-K Item 4.02 was filed in the fiscal year", "submissions API"),
    "auditor_change_8k": ("L2_monitoring", "1 if an 8-K Item 4.01 was filed in the fiscal year", "submissions API"),
    "rp_incomp": ("L3_disclosure", "(4 − disclosure items stated) ÷ 4", "related-party text"),
    "rpt_vagueness": ("L3_disclosure", "uncertainty and weak-modal words ÷ words", "related-party text"),
    "rpt_relabeling": ("L3_disclosure", "euphemistic / reframing terms ÷ words", "related-party text"),
    "rpt_indeterminate_ratio": ("L3_disclosure", "indeterminate quantifiers ('certain', 'various') ÷ words", "related-party text"),
    "rpt_transparency": ("L3_disclosure", "share of sentences stating counterparty, amount and term together", "related-party text"),
    "rpt_agency_masking": ("L3_disclosure", "share of clauses with the agent removed (agentless passives, nominalisations, existentials)", "related-party text"),
    "rpt_passive_ratio": ("L3_disclosure", "passive clauses ÷ clauses", "related-party text"),
    "rpt_fog": ("L3_disclosure", "Gunning Fog index 0.4 × (words per sentence + 100 × share of 3-syllable words)", "related-party text"),
    "d_rpt_vagueness": ("L3_disclosure", "year-on-year change in vagueness", "related-party text, consecutive years"),
    "d_rpt_fog": ("L3_disclosure", "year-on-year change in Fog", "related-party text, consecutive years"),
    "rpt_boilerplate_sim": ("L3_disclosure", "TF-IDF cosine similarity with the previous year's related-party text", "related-party text, consecutive years"),
    "spec_gap_vagueness": ("L3_disclosure", "vagueness of the related-party text minus vagueness of Item 1", "10-K Item 1 and related-party text"),
    "ln_assets": ("controls", "natural log of total assets", "XBRL"),
    "leverage": ("controls", "total liabilities ÷ total assets, bounded [0, 3]", "XBRL"),
    "roa": ("controls", "net income ÷ total assets, bounded ±1", "XBRL"),
    "listing_age": ("controls", "years since the first annual report on EDGAR", "filing manifest"),
    "rpt_vagueness_z": ("L4_peer_relative", "leave-one-out z-score of vagueness within the set-year", "related-party text, set-year peers"),
    "rpt_agency_masking_z": ("L4_peer_relative", "leave-one-out z-score of agency masking within the set-year", "related-party text, set-year peers"),
    "rpt_fog_z": ("L4_peer_relative", "leave-one-out z-score of Fog within the set-year", "related-party text, set-year peers"),
    "earnings_cash_divergence_z": ("L4_peer_relative", "leave-one-out z-score of earnings–cash divergence within the set-year", "XBRL, set-year peers"),
    "accruals_z": ("L4_peer_relative", "leave-one-out z-score of accruals within the set-year", "XBRL, set-year peers"),
    "rpt_peer_text_distance": ("L4_peer_relative", "1 − cosine(TF-IDF of the firm's related-party text, centroid of its set-year peers)", "related-party text, set-year peers"),
    "text_risk": ("text", "stacked TF-IDF logistic-regression probability on the related-party text (nested folds)", "related-party text"),
}
XBRL_KEYS = ["total_assets", "total_liabilities", "revenue", "net_income", "operating_cash_flow", "stockholders_equity"]


# --------------------------------------------------------------------------- helpers
def nan_to_none(o):
    if isinstance(o, dict):
        return {k: nan_to_none(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [nan_to_none(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating, float)):
        return None if (o is None or np.isnan(o) or np.isinf(o)) else float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if o is pd.NA or o is pd.NaT:
        return None
    return o


def write_json(path: Path, obj) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    s = json.dumps(nan_to_none(obj), allow_nan=False, separators=(",", ":"), ensure_ascii=False)
    path.write_text(s, encoding="utf-8")
    return len(s.encode("utf-8"))


def edgar_url(cik: str, accession: str, doc: str = "") -> str:
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{str(accession).replace('-', '')}/{doc or ''}"


def edgar_index_url(cik: str, accession: str) -> str:
    return f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{str(accession).replace('-', '')}/{accession}-index.htm"


def excerpt(text: str, cap: int) -> dict:
    text = (text or "").strip()
    words = _word_count(text)
    if not text:
        return {"status": "not on file", "words": 0, "chars_total": 0, "excerpt": "", "truncated": False}
    status = "used" if words >= 40 else f"too short ({words} words; treated as missing)"
    return {"status": status, "words": words, "chars_total": len(text), "excerpt": text[:cap], "truncated": len(text) > cap}


def sval(v) -> str:
    """string or '' for NaN/NA/None"""
    if v is None or v is pd.NA:
        return ""
    try:
        if isinstance(v, float) and np.isnan(v):
            return ""
    except TypeError:
        pass
    t = str(v)
    return "" if t in ("nan", "<NA>", "None") else t


def fnum(v):
    try:
        f = float(v)
        return None if np.isnan(f) else f
    except (TypeError, ValueError):
        return None


def sha7(repo: Path) -> str:
    try:
        return subprocess.check_output(["git", "-C", str(repo), "rev-parse", "--short=7", "HEAD"], text=True).strip()
    except Exception:  # noqa: BLE001
        return "unknown"


def fmt_p(p) -> str:
    return "" if pd.isna(p) else ("< 0.001" if p < 0.001 else f"= {p:.3f}")


# --------------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT.parent / "rpt-demo-site"))
    ap.add_argument("--config", default="rpt_panel.full_all.json")
    ap.add_argument("--design", default="main31")
    ap.add_argument("--limit", type=int, default=None, help="export only the first N firms (smoke test)")
    ap.add_argument("--skip-zip", action="store_true")
    ap.add_argument("--skip-docs", action="store_true")
    ap.add_argument("--cap", type=int, default=3000)
    args = ap.parse_args()
    out = Path(args.out).resolve()
    cfg = load_config(str(ROOT / args.config))
    RUN = cfg.output_dir if cfg.output_dir.is_absolute() else ROOT / cfg.output_dir
    DT = RUN / "design_tests_v2" / args.design
    EDGAR = (ROOT / cfg.local_dir).resolve()
    print("run", RUN, "design", DT, "edgar", EDGAR, "->", out)

    # ---- inputs
    X = R._load_features(cfg)
    train = R._training(cfg, X).reset_index(drop=True)
    panel_texts = pd.read_csv(RUN / "panel_texts.csv", dtype={"cik": str, "rpt_text": str}, keep_default_na=False)
    panel_texts["cik"] = panel_texts["cik"].str.zfill(10)
    text_of = {(c, int(y)): t for c, y, t in zip(panel_texts["cik"], panel_texts["fiscal_year"], panel_texts["rpt_text"])}
    scores_rec = pd.read_csv(DT / "scores_by_firm_year.csv", dtype={"cik": str})
    a1 = pd.read_csv(DT / "a1_attribution_by_firm_year.csv", dtype={"cik": str})
    h13 = pd.read_csv(DT / "h1_h3_layer_tests.csv")
    h5 = pd.read_csv(DT / "h5_model_ab.csv").iloc[0]
    h4r = pd.read_csv(DT / "h4_design_rule.csv")
    a3 = pd.read_csv(DT / "a3_layers_in_flagged_fraud_firm_years.csv")
    lead = pd.read_csv(DT / "lead_time_by_case.csv")
    rules = pd.read_csv(DT / "scoring_rules.csv")
    m1 = pd.read_csv(DT / "m1_coverage_by_group.csv")
    expl = pd.read_csv(DT / "exploratory_fitted_score.csv").iloc[0].to_dict() if (DT / "exploratory_fitted_score.csv").exists() else {}
    summ_line = (DT / "summary.md").read_text(encoding="utf-8").splitlines()[2]
    m = re.search(r"Analysed firm-years: (\d+) \((\d+) fraud firm-years\) in (\d+) matched sets: (\d+) RPT-fraud cases.*?and (\d+) matched firms", summ_line)
    sample = {"window_firm_years": int(m.group(1)), "window_fraud_firm_years": int(m.group(2)), "sets": int(m.group(3)), "cases": int(m.group(4)), "peers": int(m.group(5))}
    assert len(train) == sample["window_firm_years"], (len(train), sample)
    psum = json.loads((RUN / "panel_summary.json").read_text(encoding="utf-8"))
    spec = json.loads((RUN / "model_spec.json").read_text(encoding="utf-8"))
    model = load_model(RUN / "models" / "rpt_panel_logit.pkl")
    oof = pd.read_csv(RUN / "oof_scores.csv", dtype={"cik": str})
    oof["cik"] = oof["cik"].str.zfill(10)
    oofw = oof.pivot_table(index=["cik", "fiscal_year"], columns="model", values="score", aggfunc="first")
    shap_l = pd.read_csv(RUN / "oof_shap_logit.csv", dtype={"cik": str})
    shap_l["cik"] = shap_l["cik"].str.zfill(10)
    shap_l = shap_l.set_index(["cik", "fiscal_year"])
    trace = pd.read_csv(RUN / "explainability" / "traceability.csv", dtype={"cik": str}, keep_default_na=False)
    trace["cik"] = trace["cik"].str.zfill(10)
    trace["fiscal_year"] = trace["fiscal_year"].astype(int)
    trace_g = {k: g.sort_values("rank") for k, g in trace.groupby(["cik", "fiscal_year"])}
    t5 = json.loads((RUN / "stress_tests" / "t5_clean_fpr.json").read_text())
    trace_sum = json.loads((RUN / "explainability" / "traceability_summary.json").read_text())
    oof_metrics = pd.read_csv(RUN / "tables" / "oof_metrics.csv")
    cases = pd.read_csv(ROOT / "cases_core.csv", dtype=str).fillna("")
    cases["cik"] = cases["cik"].str.zfill(10)
    case_by_id = cases[cases["role"] == "case"].set_index("case_id")

    def coded(name):
        d = pd.read_csv(ROOT / "data" / name, dtype={"cik": str}, keep_default_na=False)
        d["cik"] = d["cik"].str.zfill(10)
        d["fiscal_year"] = pd.to_numeric(d["fiscal_year"], errors="coerce").astype(int)
        return d.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])
    rp_coded, gov, aud, tenka = coded("rp_note_coded.csv"), coded("governance_manual.csv"), coded("audit_opinions.csv"), coded("tenka_restatements.csv")
    tenka_ev = pd.read_csv(ROOT / "data" / "tenka_restatements_events.csv", dtype={"cik": str}, keep_default_na=False)
    tenka_ev["cik"] = tenka_ev["cik"].str.zfill(10)
    master = da.load_master_panel(EDGAR)
    master = master[master["is_primary_filing"].astype(str).isin(["1", "1.0", "True"])].copy()
    master["fiscal_year"] = master["fiscal_year"].astype(int)
    master_i = master.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"], drop=False)
    manifest = da.load_table(EDGAR, "filing_manifest")
    manifest["fiscal_year"] = pd.to_numeric(manifest["fiscal_year"], errors="coerce")
    universe = da.load_table(EDGAR, "company_universe").drop_duplicates("cik").set_index("cik")
    proxy_links = da.load_table(EDGAR, "proxy_links")
    proxy_links["fiscal_year"] = pd.to_numeric(proxy_links["fiscal_year"], errors="coerce")
    proxy_i = proxy_links.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])
    proxy_man = da.load_table(EDGAR, "proxy_manifest")
    proxy_doc = dict(zip(proxy_man["accession_number"], proxy_man["primary_document"]))
    proxy_date = dict(zip(proxy_man["accession_number"], proxy_man["filing_date"]))
    eightk = da.load_table(EDGAR, "eightk_items")
    eightk["fiscal_year"] = pd.to_numeric(eightk["fiscal_year"], errors="coerce")
    eightk_i = eightk.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])
    eightk_ev = da.load_table(EDGAR, "eightk_items_events")
    eightk_date = dict(zip(eightk_ev["accession_number"], eightk_ev["filing_date"]))

    # ---- design recompute (the numbers the browser must reproduce)
    values = characteristic_values(train)
    scores, ranks = rank_scores(values)
    attr = attribution(scores, ranks)
    key = list(zip(train["cik"], train["fiscal_year"].astype(int)))
    rec = scores_rec.copy()
    rec["cik"] = rec["cik"].str.zfill(10)
    rec_i = rec.set_index(["cik", "fiscal_year"])
    a1i = a1.assign(cik=a1["cik"].str.zfill(10)).set_index(["cik", "fiscal_year"])
    recorded_ai = np.array([rec_i.loc[k, "AI_SCORE"] for k in key], dtype=float)
    assert np.allclose(scores["AI_SCORE"].values, recorded_ai, equal_nan=True, atol=1e-9), "recomputed AI_SCORE differs from the recorded battery"
    peers_ai = scores.loc[train["fraud_aaer_label"] == 0, "AI_SCORE"]
    thr5 = float(peers_ai.quantile(1 - cfg.target_fpr))
    assert round(thr5, 2) == round(float(h5["ai_threshold_5pct_far"]), 2), (thr5, h5["ai_threshold_5pct_far"])
    flags_re = (scores["AI_SCORE"] >= thr5).fillna(False).values
    flags_rec = np.array([bool(a1i.loc[k, "AI_FLAG_5"]) for k in key])
    assert (flags_re == flags_rec).all(), "AI flags differ from the recorded battery"

    # ---- fitted logit inputs and the exporter's reference probability
    feats = list(model["features"])
    X36 = train.reindex(columns=[f for f in feats if f != "text_risk"]).copy()
    texts = pd.Series([text_of.get(k, "") for k in key], index=train.index)
    X36["text_risk"] = model["text_model"].predict_proba(texts).values
    X36 = X36[feats]
    prob_full = model["pipeline"].predict_proba(X36)[:, 1]
    imp, sc, clf = (model["pipeline"].named_steps[n] for n in ("impute", "scale", "clf"))
    tm = model["text_model"]
    top_terms = tm.top_terms(40)
    risk_terms = top_terms.loc[top_terms["direction"] == "risk", "term"].tolist()
    prot_terms = top_terms.loc[top_terms["direction"] == "protective", "term"].tolist()

    # ---- lexicon analysers (the same objects the tracer uses)
    nlp_cfg = Config()
    vag, sfl, rd = VaguenessScorer(nlp_cfg), SFLAnalyser(nlp_cfg), ReadabilityAnalyser(nlp_cfg)

    # ---- output skeleton
    if out.exists():
        for child in out.iterdir():
            if child.name == ".git":
                continue
            shutil.rmtree(child) if child.is_dir() else child.unlink()
    for d in ("data/companies", "assets/img/thesis", "assets/img/docs", "assets/img/waterfall", "docs", "downloads/models", "tools"):
        (out / d).mkdir(parents=True, exist_ok=True)
    shutil.copytree(SITE_SRC / "assets", out / "assets", dirs_exist_ok=True)
    (out / ".nojekyll").write_text("")

    build = {"generated_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), "panel_dataset_version": psum.get("dataset_version", ""),
             "training_pipeline_sha": sha7(ROOT), "data_pipeline_sha": sha7(DOWNLOADER), "run_dir": str(RUN.relative_to(ROOT)).replace("\\", "/"), "design_dir": f"design_tests_v2/{args.design}"}

    # ---- global.json
    chars = []
    for code, (col, layer, higher) in CHARACTERISTICS.items():
        v = values[code].dropna().sort_values()
        chars.append({"code": code, "layer": layer, "panel_column": col, "higher_is_risk": higher, "label": CHAR_LABEL[code][0], "formula": CHAR_LABEL[code][1],
                      "n_ranked": int(len(v)), "sorted_values": [float(x) for x in v.values]})
    feature_meta = {f: {"group": FEATURE_META.get(f, ("", "", ""))[0], "formula": FEATURE_META.get(f, ("", "", ""))[1], "source": FEATURE_META.get(f, ("", "", ""))[2]} for f in feats}
    G = {
        "build": build,
        "sample": {**sample, "firms": int(train["cik"].nunique()), "firm_years_all": int(len(X)), "strata": train.drop_duplicates("cluster_id")["stratum"].value_counts().to_dict(),
                   "window": cfg.window, "fy_min": int(X["fiscal_year"].min()), "fy_max": int(X["fiscal_year"].max()),
                   "rpt_text_source_window": train["rpt_source"].value_counts().to_dict()},
        "characteristics": chars,
        "layers": {"L1": "financial (conflict of interest)", "L2": "disclosure (information asymmetry)", "L3": "governance (weak monitoring)"},
        "design_rules": rules.to_dict("records"),
        "ai_flag": {"thr_5pct_far": thr5, "far_at_5pct": float((peers_ai >= thr5).mean()), "thr_equal_far": float(h5["ai_threshold_equal_far"]), "trad_rule": str(h5["trad_rule_equal_far"]),
                    "trad_far": float(h5["trad_far"]), "method": "0.95 quantile (linear interpolation) of the matched firm-years' AI_SCORE"},
        "traditional": {"ICFR_MW": "material weakness reported (10-K Item 9A)", "AUD_OPIN": "modified or going-concern audit opinion", "AUD_CHG": "8-K Item 4.01 in the fiscal year", "RESTATE": "8-K Item 4.02 or a restating 10-K/A"},
        "logit": {"features": feats, "groups": spec["feature_groups"], "dropped_features": spec.get("dropped_features", []),
                  "imputer_median": [float(x) for x in imp.statistics_], "scaler_mean": [float(x) for x in sc.mean_], "scaler_scale": [float(x) for x in sc.scale_],
                  "coef": [float(x) for x in clf.coef_[0]], "intercept": float(clf.intercept_[0]), "threshold": float(model["threshold"]),
                  "threshold_note": f"fixed for the ensemble alert at a clean-firm false-positive rate of at most 5 % (T5: {t5['false_positives']} of {t5['n_clean_firm_years']} matched firm-years)",
                  "trained_on": {"rows": int(oofw.shape[0]), "sets": int(oof.merge(train[['cik', 'fiscal_year', 'cluster_id']], on=['cik', 'fiscal_year'])['cluster_id'].nunique()), "note": "the matched sets available when the model was fitted; the Gulfport set was added afterwards"},
                  "sklearn_version": model.get("sklearn_version", ""), "trained_at": str(model.get("trained_at", "")), "feature_meta": feature_meta},
        "text_model": {"terms": top_terms.to_dict("records")},
        "metrics": {"oof": oof_metrics.to_dict("records"), "t5": t5, "traceability": trace_sum},
        "design_results": {"h1_h3": h13.to_dict("records"), "h4_rule": h4r.to_dict("records"), "h5": h5.to_dict(), "a3": a3.to_dict("records"), "lead_time": lead.to_dict("records"),
                           "m1": m1.to_dict("records"), "exploratory_fitted": expl},
        "labels": {"design_primary": "The design tests (H1–H5, P1, A1–A3) on the rank-averaged AI risk score are the primary results.",
                   "fitted_exploratory": "The fitted 36-input model contains the traditional signals and is exploratory; it does not test H5.",
                   "identification_not_prediction": "All results are associations within matched sets that identify fraud already under way, not predictions."},
    }
    g_bytes = write_json(out / "data" / "global.json", G)

    # ---- per-company JSON
    firms = train.drop_duplicates("cik")[["cik", "company_name", "cluster_id", "case_role", "stratum", "sic"]].reset_index(drop=True)
    if args.limit:
        firms = firms.head(args.limit)
    series = {}
    for cik_, g in train.sort_values("fiscal_year").groupby("cik"):
        ks = list(zip(g["cik"], g["fiscal_year"].astype(int)))
        series[cik_] = {"event_time": [int(e) for e in g["event_time"]], "fiscal_year": [int(y) for y in g["fiscal_year"]],
                        "ai_score": [fnum(rec_i.loc[k, "AI_SCORE"]) for k in ks], "trad_index": [fnum(rec_i.loc[k, "TRAD_INDEX"]) for k in ks],
                        "logit_oof": [fnum(oofw.loc[k, "logit"]) if k in oofw.index else None for k in ks],
                        "ensemble_oof": [fnum(oofw.loc[k, "ensemble"]) if k in oofw.index else None for k in ks]}
    names = dict(zip(train["cik"], train["company_name"]))
    roles = dict(zip(train["cik"], train["case_role"]))
    cluster_firms = {c: [{"cik": k, "name": names[k], "role": roles[k]} for k in sorted(g["cik"].unique(), key=lambda k: (roles[k] != "case", names[k]))] for c, g in train.groupby("cluster_id")}
    oof_clusters = set(oof.merge(train[["cik", "fiscal_year", "cluster_id"]], on=["cik", "fiscal_year"])["cluster_id"].unique())
    waterfalls = {}
    for c in cluster_firms:
        wf = {k: f"assets/img/waterfall/fig_waterfall_{c}_{k}.png" for k in ("logit", "rf", "xgb") if (RUN / "figures" / f"fig_waterfall_{c}_{k}.png").exists()}
        for k, rel in wf.items():
            shutil.copy2(RUN / "figures" / Path(rel).name, out / rel)
        waterfalls[c] = wf or None
    train_i = train.set_index(["cik", "fiscal_year"])
    manifest_by_cik = {c: g.sort_values("fiscal_year") for c, g in manifest[manifest["is_primary_filing"].astype(str).isin(["1", "1.0", "True"])].groupby("cik")}
    sizes = {}
    index_sets = {}
    for _, f in firms.iterrows():
        cik_ = f["cik"]
        c = f["cluster_id"]
        case = case_by_id.loc[c] if c in case_by_id.index else None
        rows = train[train["cik"] == cik_].sort_values("fiscal_year")
        u = universe.loc[cik_] if cik_ in universe.index else {}
        years = []
        ens_series = series[cik_]["ensemble_oof"]
        best_i = int(np.nanargmax([v if v is not None else np.nan for v in ens_series])) if any(v is not None for v in ens_series) else -1
        for j, (_, r) in enumerate(rows.iterrows()):
            fy = int(r["fiscal_year"])
            k = (cik_, fy)
            mrow = master_i.loc[k] if k in master_i.index else None
            if isinstance(mrow, pd.DataFrame):
                mrow = mrow.iloc[0]
            # filings
            tenk = None
            if mrow is not None:
                tenk = {"accession": sval(mrow["accession_number"]), "form": sval(mrow.get("form")) or "10-K", "filing_date": sval(mrow.get("filing_date")), "report_date": sval(mrow.get("report_date")),
                        "url": edgar_url(cik_, mrow["accession_number"], sval(mrow.get("primary_document"))), "index_url": edgar_index_url(cik_, mrow["accession_number"])}
            pacc = ""
            if mrow is not None and sval(mrow.get("extract_proxy_accession_number")):
                pacc = sval(mrow["extract_proxy_accession_number"])
            elif k in proxy_i.index and sval(proxy_i.loc[k, "proxy_accession_number"]):
                pacc = sval(proxy_i.loc[k, "proxy_accession_number"])
            def14a = {"accession": pacc, "filing_date": proxy_date.get(pacc, ""), "url": edgar_url(cik_, pacc, proxy_doc.get(pacc, ""))} if pacc else None
            ek = eightk_i.loc[k] if k in eightk_i.index else None
            ek_acc = [a for a in str(ek["accessions"]).split(";") if a] if ek is not None else []
            tk_rows = tenka_ev[(tenka_ev["cik"] == cik_) & (pd.to_numeric(tenka_ev["fiscal_year"], errors="coerce") == fy)]
            filings = {"tenk": tenk, "def14a": def14a,
                       "eightk": [{"accession": a, "filing_date": eightk_date.get(a, ""), "url": edgar_index_url(cik_, a)} for a in ek_acc],
                       "tenka": [{"accession": t["accession_number"], "filing_date": t["filing_date"], "url": edgar_url(cik_, t["accession_number"], t["primary_document"])} for _, t in tk_rows.iterrows()]}
            # sections
            sections = {}
            if mrow is not None:
                for name in ("rpt_disclosure", "rp_note", "item13", "item9a"):
                    sections[name] = excerpt(da.read_section(EDGAR, mrow, name), args.cap)
                ppath = EDGAR / "raw" / "proxies" / cik_ / pacc / "proxy_rpt.txt" if pacc else None
                sections["proxy_rpt"] = excerpt(ppath.read_text(encoding="utf-8", errors="replace") if ppath and ppath.exists() else "", args.cap)
                rpt_text, _src = related_party_text(EDGAR, mrow, cfg.min_text_words)
            else:
                rpt_text = text_of.get(k, "")
            # coded
            rpc = rp_coded.loc[k].to_dict() if k in rp_coded.index else {}
            gv = gov.loc[k].to_dict() if k in gov.index else {}
            au = aud.loc[k].to_dict() if k in aud.index else {}
            tk = tenka.loc[k].to_dict() if k in tenka.index else {}
            coded_block = {
                "rp_note": {**{code: {"amount": fnum(rpc.get(code)), "evidence": str(rpc.get(f"{code}_evidence", ""))} for code in ("RP_LEND", "RP_PAY", "RP_SALES", "RP_PURCH")},
                            **{kk: fnum(rpc.get(kk)) for kk in ("counterparty_named", "amount_stated", "terms_stated", "purpose_stated", "rp_incomp", "no_transactions_stated", "n_amounts")},
                            "text_source": str(rpc.get("text_source", "")), "text_words": fnum(rpc.get("text_words"))},
                "governance": {**{kk: fnum(gv.get(kk)) for kk in ("big4", "going_concern_opinion", "ceo_duality", "board_indep", "ac_indep", "auditor_change")},
                               **{kk: str(gv.get(kk, "")) for kk in ("auditor_name", "auditor_evidence", "going_concern_evidence", "ceo_duality_evidence", "board_indep_evidence", "ac_indep_evidence", "proxy_accession")}},
                "audit_opinion": {"modified_opinion": fnum(au.get("modified_opinion")), "audit_opinion_modified_or_gc": fnum(au.get("audit_opinion_modified_or_gc")),
                                  "modified_opinion_evidence": str(au.get("modified_opinion_evidence", "")), "audit_report_found": fnum(au.get("audit_report_found"))},
                "restatement_10ka": {"n_10ka": fnum(tk.get("n_10ka")), "restatement_10ka": fnum(tk.get("restatement_10ka")), "accessions": str(tk.get("accessions", "")), "evidence": str(tk.get("evidence", ""))},
                "eightk": {"auditor_change_8k": fnum(r.get("auditor_change_8k")), "restatement_8k": fnum(r.get("restatement_8k")), "accessions": ";".join(ek_acc)},
                "icfr": {kk: fnum(r.get(kk)) for kk in ("icfr_text_available", "icfr_not_effective", "material_weakness_reported", "material_weakness_remediated", "mw_count", "mw_persistence_2yr", "auditor_attestation_exempt")},
            }
            xbrl = {}
            if mrow is not None:
                for kk in XBRL_KEYS:
                    xbrl[kk] = {"value": fnum(mrow.get(f"xbrl_{kk}")), "tag": sval(mrow.get(f"xbrl_{kk}_tag")), "accession": sval(mrow.get(f"xbrl_{kk}_accession"))}
            # lexicon detail
            lex = {}
            if rpt_text and _word_count(rpt_text) >= cfg.min_text_words:
                v = vag.score(rpt_text)
                s_ = sfl.analyse(rpt_text)
                rdd = rd.analyse(rpt_text)
                lex = {"vagueness": {"score": fnum(v.get("vagueness_score")), "relabeling": fnum(v.get("categorical_relabeling")), "indeterminate_ratio": fnum(v.get("indeterminate_ratio")),
                                     "transparency": fnum(v.get("transparency_score")), "high_risk_terms": [t for t, _ in v.get("high_risk_terms", [])][:20], "transparency_terms": list(v.get("transparency_terms_found", []))[:20]},
                       "sfl": {"agency_masking": fnum(s_.get("agency_masking_score")), "passive_ratio": fnum(s_.get("passive_voice_ratio")),
                               "masking_examples": [{"type": i.get("type"), "example": (i.get("examples") or [""])[0]} for i in s_.get("masking_instances", [])[:5]]},
                       "fog": fnum(rdd.get("fog_index")), "words": int(_word_count(rpt_text))}
            idx = rows.index[j]
            characteristics = {code: {"value": fnum(values.loc[idx, code]), "rank_recorded": fnum(ranks.loc[idx, code])} for code in CHARACTERISTICS}
            dr = rec_i.loc[k]
            a1r = a1i.loc[k]
            design_recorded = {**{kk: fnum(dr[kk]) for kk in ("L1_SCORE", "L2_SCORE", "L3_SCORE", "AI_SCORE", "TRAD_INDEX", "ICFR_MW", "AUD_OPIN", "AUD_CHG", "RESTATE")},
                               "AI_FLAG_5": bool(a1r["AI_FLAG_5"]), "shares": {kk: fnum(a1r[kk]) for kk in a1r.index if str(kk).startswith("share_")},
                               "largest_layer": None if pd.isna(a1r["largest_layer"]) else str(a1r["largest_layer"]), "named_evidence": str(a1r["named_evidence"])}
            features = {fcol: fnum(X36.loc[idx, fcol]) for fcol in feats}
            low = (rpt_text or "").lower()
            oofk = oofw.loc[k].to_dict() if k in oofw.index else None
            if oofk:
                oofk = {kk: fnum(vv) for kk, vv in oofk.items()}
                oofk["alert_fired"] = bool(oofk.get("ensemble") is not None and oofk["ensemble"] >= float(model["threshold"]))
            years.append({
                "fiscal_year": fy, "event_time": int(r["event_time"]), "label": int(r["fraud_aaer_label"]), "in_oof": oofk is not None, "is_waterfall_year": j == best_i,
                "filings": filings, "sections": sections, "rpt_text_source": str(r.get("rpt_source", "")),
                "coded": coded_block, "xbrl": xbrl, "lexicon": lex, "characteristics": characteristics, "design_recorded": design_recorded,
                "features": features, "logit_recorded": {"prob_full_fit": float(prob_full[idx])},
                "oof": oofk, "shap_logit": {fcol: fnum(shap_l.loc[k, fcol]) for fcol in feats if fcol in shap_l.columns} if k in shap_l.index else None,
                "traceability": [{"rank": int(t["rank"]), "feature": t["feature"], "shap": fnum(t["shap"]), "traceable": int(float(t["traceable"] or 0)), "evidence": t["evidence"], "locator": t["locator"]} for _, t in trace_g[k].iterrows()] if k in trace_g else None,
                "text_terms": {"risk_hits": [t for t in risk_terms if t in low][:12], "protective_hits": [t for t in prot_terms if t in low][:12]},
            })
        case_block = None
        if case is not None and f["case_role"] == "case":
            case_block = {"d1_class": case["d1_class"], "revelation_date": case["revelation_date"], "revelation_source": case["revelation_source"], "confidence": case["confidence"],
                          "aaer_numbers": case["aaer_numbers"], "misconduct_fy": [case["misconduct_start_fy"], case["misconduct_end_fy"]]}
        matched_case = None if case is None else {"case_name": case["company_name"], "case_cik": case["cik"], "revelation_date": case["revelation_date"], "d1_class": case["d1_class"]}
        fm = manifest_by_cik.get(cik_, pd.DataFrame())
        filings_all = [{"fiscal_year": int(x["fiscal_year"]), "form": x["form"], "accession": x["accession_number"], "filing_date": sval(x["filing_date"]), "url": edgar_url(cik_, x["accession_number"], sval(x["primary_document"]))}
                       for _, x in fm.iterrows() if pd.notna(x["fiscal_year"])]
        company = {"cik": cik_, "name": f["company_name"], "edgar_name": str(u.get("name", f["company_name"])) if len(u) else f["company_name"], "ticker": str(u.get("ticker", "")) if len(u) else "",
                   "sic": str(f["sic"]), "sic_description": str(u.get("sic_description", "")) if len(u) else "", "cluster_id": c, "role": f["case_role"], "stratum": f["stratum"],
                   "case": case_block, "matched_case": matched_case, "oof_available": c in oof_clusters,
                   "set": {"cluster_id": c, "case_name": case["company_name"] if case is not None else c, "firms": cluster_firms[c], "series": {ff["cik"]: series[ff["cik"]] for ff in cluster_firms[c]}},
                   "filings_all": filings_all, "years": years, "waterfalls": waterfalls.get(c) if f["case_role"] == "case" else None}
        sizes[cik_] = write_json(out / "data" / "companies" / f"{cik_}.json", company)
        # index entry
        ent = index_sets.setdefault(c, {"cluster_id": c, "case_name": case["company_name"] if case is not None else c, "case_cik": case["cik"] if case is not None else "",
                                        "stratum": f["stratum"], "d1_class": case["d1_class"] if case is not None else "", "revelation_date": case["revelation_date"] if case is not None else "",
                                        "window_fy": [int(rows["fiscal_year"].min()), int(rows["fiscal_year"].max())], "oof_available": c in oof_clusters, "firms": []})
        ent["firms"].append({"cik": cik_, "name": f["company_name"], "role": f["case_role"], "sic": str(f["sic"]), "window_years": int(len(rows)),
                             "ai_flag_any": bool(any(y["design_recorded"]["AI_FLAG_5"] for y in years)),
                             "ai_max": max([y["design_recorded"]["AI_SCORE"] for y in years if y["design_recorded"]["AI_SCORE"] is not None] or [None]) if any(y["design_recorded"]["AI_SCORE"] is not None for y in years) else None,
                             "oof_max": max([y["oof"]["ensemble"] for y in years if y["oof"] and y["oof"]["ensemble"] is not None] or [None]) if any(y["oof"] for y in years) else None,
                             "oof_available": c in oof_clusters})
    sets_sorted = sorted(index_sets.values(), key=lambda s: s["case_name"].lower())
    for s_ in sets_sorted:
        s_["firms"].sort(key=lambda f: (f["role"] != "case", f["name"].lower()))
    write_json(out / "data" / "index.json", {"sets": sets_sorted, "firms_by_cik": {f["cik"]: s_["cluster_id"] for s_ in sets_sorted for f in s_["firms"]}})
    print(f"companies: {len(sizes)} files, largest {max(sizes.values())/1024:.0f} KB, total {sum(sizes.values())/1e6:.1f} MB; global {g_bytes/1024:.0f} KB")
    assert max(sizes.values()) < 400_000, "a company file exceeds 400 KB"

    # ---- results.json, CSV tables and the Excel workbook (the charts' data)
    tables_dir = out / "downloads" / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    LAYER_NAME = {"L1_SCORE": "financial", "L2_SCORE": "disclosure", "L3_SCORE": "governance"}
    h13r = h13.copy()
    h13r["layer_name"] = h13r["layer_score"].map(LAYER_NAME)
    variants = pd.read_csv(DT / "h1_h3_variants.csv")
    variants = variants[variants["n_firm_years"] > 0].copy()
    variants["layer_code"] = variants["layer_score"].map(lambda x: x[:2] if x.endswith("_SCORE") else {"RP_LEND": "L1", "RP_PAY": "L1", "RP_SALES": "L1", "RP_PURCH": "L1", "RP_INCOMP": "L2", "RP_VAGUE": "L2", "BRD_NONIND": "L3", "DUAL": "L3"}.get(x, "L2"))
    variants = variants[variants["odds_ratio_per_sd"] < 1e6]
    h4 = pd.read_csv(DT / "h4_by_year.csv")
    lead_r = lead.copy()
    lead_r["case_name"] = lead_r["case"].map(lambda c: case_by_id.loc[c, "company_name"] if c in case_by_id.index else c)
    lead_r["first_year"] = lead_r["earliest_window_year_separated_from_matched_firms"]
    p1 = pd.read_csv(DT / "p1_rpt_types_by_form.csv")
    p1_rows = [{"form_group": r["form_group"], "n": int(r["lending_count"]), "lending": r["lending_sum"] / r["lending_count"], "sales": r["sales_sum"] / r["sales_count"], "purchases": r["purchases_sum"] / r["purchases_count"]} for _, r in p1.iterrows()]
    a1s = pd.read_csv(DT / "a1_attribution_summary.csv", index_col=0)
    a1_rows = [{"code": i.replace("share_", ""), "all": float(r["mean_share_all_firm_years"]), "fraud": float(r["mean_share_fraud_firm_years"]), "flagged": float(r["mean_share_flagged_fraud_firm_years"])} for i, r in a1s.iterrows() if not i.replace("share_", "") in ("L1", "L2", "L3")]
    power = pd.read_csv(DT / "power_simulation.csv") if (DT / "power_simulation.csv").exists() else pd.DataFrame(columns=["matched_sets", "odds_ratio_per_sd", "power"])
    sample_runs = [("core21", "21 misstatement/misappropriation cases"), ("all30", "30 cases (before Gulfport)"), ("main31", "31 cases (main sample)"), ("all36_threereport", "36 cases (+ five three-report cases)"), ("main31_rankall", "31 cases, ranks over all years")]
    samples, sample_rows = [], []
    for key_, name_ in sample_runs:
        d_ = RUN / "design_tests_v2" / key_
        if not (d_ / "h1_h3_layer_tests.csv").exists():
            continue
        hh = pd.read_csv(d_ / "h1_h3_layer_tests.csv").set_index("hypothesis")
        h5_ = pd.read_csv(d_ / "h5_model_ab.csv").iloc[0]
        ent = {"name": name_, "sets": int(h5_["n_matched_sets"])}
        for hyp in ("H1", "H2", "H3"):
            ent[hyp] = {"or": float(hh.loc[hyp, "odds_ratio_per_sd"]), "lo": float(hh.loc[hyp, "or_ci_low"]), "hi": float(hh.loc[hyp, "or_ci_high"]), "p": float(hh.loc[hyp, "p_unadjusted"]), "pc": float(hh.loc[hyp, "p_firm_cluster"])}
            sample_rows.append({"sample": name_, "sets": ent["sets"], "hypothesis": hyp, **ent[hyp]})
        ent["h5"] = {"A": float(h5_["loso_auc_model_A"]), "B": float(h5_["loso_auc_model_B"]), "trad": float(h5_["auc_trad_index_alone"])}
        samples.append(ent)
    oof_core = pd.read_csv(ROOT / "outputs" / "full" / "tables" / "oof_metrics.csv")
    per_case = pd.read_csv(ROOT / "docs" / "run3_results" / "per_case_detection.csv")
    ext = json.loads((ROOT / "outputs" / "sens" / "external_validation.json").read_text())
    # screening
    screen = pd.read_csv(DOWNLOADER / "scripts" / "phase_a_screen_v2.csv", dtype=str).fillna("")
    sc = screen["screen"].str.replace(r" \(.*\)", "", regex=True)
    funnel_rows = [
        {"label": "Candidates recorded", "n": 58, "note": "workbook, AAER sweep, litigation-release sweep, EDGAR full-text search", "color": "all"},
        {"label": "Screened against the enforcement record", "n": int(len(screen)), "note": "order or complaint read for every candidate", "color": "all"},
        {"label": "Excluded by D1 (no RPT element)", "n": int((sc == "EXCLUDE_D1").sum()), "note": "", "color": "out"},
        {"label": "Window before 2005 (no Item 9A)", "n": int((sc == "PRE_2005_WINDOW").sum()) + 12, "note": "one from the screen, twelve from the AAER sweep", "color": "out"},
        {"label": "Fewer than four annual reports (D3)", "n": int((sc == "FAIL_4_REPORTS").sum()), "note": "ten of them form the external validation set", "color": "out"},
        {"label": "Misstatement / misappropriation cases", "n": int((sc == "INCLUDE").sum()), "note": "", "color": "case"},
        {"label": "Disclosure-only cases", "n": int((sc == "STRATUM_DISCLOSURE_ONLY").sum()), "note": "including Gulfport Energy, dated and approved 10 Oct 2026", "color": "disc"},
        {"label": "Matched firms (D4)", "n": int(sample["peers"]), "note": "five per case where the industry pool allows", "color": "all"},
    ]
    sources = [{"source": "Client workbook (2 Oct 2026)", "n": 39}, {"source": "AAER full text 2005–2024 (2,383 releases)", "n": 9}, {"source": "Litigation releases 2010–2025 (5,086)", "n": 2}, {"source": "EDGAR full-text search of issuers' filings", "n": 8}]
    conf = train.drop_duplicates("cluster_id")[["cluster_id"]].merge(cases[cases["role"] == "case"][["case_id", "confidence"]], left_on="cluster_id", right_on="case_id")["confidence"].value_counts()
    confidence = [{"level": lv, "n": int(conf.get(lv, 0))} for lv in ("high", "medium", "low")]
    case_rows = [{"name": r["company_name"], "cik": r["cik"], "year": int(str(r["revelation_date"])[:4]), "revelation_date": r["revelation_date"], "stratum": r["stratum"], "d1_class": r["d1_class"], "confidence": r["confidence"]} for _, r in cases[cases["role"] == "case"].iterrows()]
    match_frames = [pd.read_csv(DOWNLOADER / "scripts" / f, dtype=str) for f in ("peers_matched_v1.csv", "peers_matched_v2_relaxed.csv", "peers_matched_puda.csv", "peers_matched_gulfport.csv") if (DOWNLOADER / "scripts" / f).exists()]
    match = pd.concat(match_frames, ignore_index=True).drop_duplicates(["cik", "matched_case_id"], keep="last")
    match["cik"] = match["cik"].str.zfill(10)
    match = match[match["cik"].isin(set(train["cik"]))]
    match["ln_assets_gap"] = pd.to_numeric(match["ln_assets_gap"], errors="coerce")
    sic_counts = match["sic_level"].value_counts()
    sic_levels = [{"label": lab, "n": int(sic_counts.get(k, 0))} for k, lab in (("sic4", "same four-digit industry"), ("sic3", "same three-digit industry"), ("sic2", "same two-digit industry"))]
    results = {
        "sample": sample, "thr5": thr5,
        "ai_scores": {"fraud": [float(v) for v in scores.loc[train["fraud_aaer_label"] == 1, "AI_SCORE"].dropna()], "matched": [float(v) for v in scores.loc[train["fraud_aaer_label"] == 0, "AI_SCORE"].dropna()]},
        "m1": m1.to_dict("records"), "m3": {"labels": ["Financial", "Disclosure", "Governance"], "values": pd.read_csv(DT / "m3_layer_correlations.csv", index_col=0).values.tolist()},
        "h1_h3": h13r.to_dict("records"), "h2_variants": variants.to_dict("records"), "h4": h4.to_dict("records"),
        "h4_rule_met": [str(x) for x, v in zip(h4r["layer_score"], h4r["design_rule_met_before_final_year"]) if v],
        "h5": h5.to_dict(), "timing": pd.read_csv(DT / "h5_timing_by_case.csv").to_dict("records"), "lead": lead_r.to_dict("records"),
        "p1": p1_rows, "a1": a1_rows, "power": power.to_dict("records"), "samples": samples,
        "exploratory": {"oof": oof_core.to_dict("records"), "per_case": per_case.to_dict("records"), "external": ext},
        "screening": {"funnel": funnel_rows, "sources": sources, "confidence": confidence, "cases": case_rows,
                      "match": {"gaps": [float(v) for v in match["ln_assets_gap"].dropna()], "sic_levels": sic_levels}},
    }
    write_json(out / "data" / "results.json", results)
    sheets = {"H1_H3": h13r, "H2_variants": variants, "H4_by_year": h4, "H5": pd.DataFrame([h5]), "H5_timing": pd.read_csv(DT / "h5_timing_by_case.csv"), "lead_time": lead_r,
              "M1_coverage": m1, "M3_correlations": pd.read_csv(DT / "m3_layer_correlations.csv"), "P1": p1, "A1_shares": a1s.reset_index(), "A2_stability": pd.read_csv(DT / "a2_stability_summary.csv"),
              "A3": a3, "power": power, "sample_comparison": pd.DataFrame(sample_rows), "scoring_rules": rules, "scores_by_firm_year": scores_rec,
              "exploratory_oof": oof_core, "exploratory_per_case": per_case, "external_validation": pd.DataFrame([ext]),
              "screening_funnel": pd.DataFrame(funnel_rows), "cases": pd.DataFrame(case_rows), "peer_matches": match}
    with pd.ExcelWriter(out / "downloads" / "results_tables.xlsx", engine="openpyxl") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=name[:31], index=False)
    for name, df in sheets.items():
        df.to_csv(tables_dir / f"{ {'H1_H3': 'h1_h3_layer_tests', 'H2_variants': 'h1_h3_variants', 'H4_by_year': 'h4_by_year', 'H5': 'h5_model_ab', 'M1_coverage': 'm1_coverage_by_group', 'M3_correlations': 'm3_layer_correlations', 'P1': 'p1_rpt_types_by_form', 'A1_shares': 'a1_attribution_summary', 'power': 'power_simulation', 'exploratory_oof': 'oof_metrics'}.get(name, name) }.csv", index=False)
    print("results.json, Excel workbook and", len(sheets), "CSV tables written")

    # ---- documents and pages
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    env = Environment(loader=FileSystemLoader(str(SITE_SRC / "templates")), autoescape=select_autoescape(["html"]))
    ctx_base = {"build": build}

    def page(template: str, name: str, **ctx):
        (out / name).write_text(env.get_template(template).render(**ctx_base, **ctx), encoding="utf-8")

    for img in (ROOT / "docs" / "thesis_figures").glob("*.png"):
        shutil.copy2(img, out / "assets" / "img" / "thesis" / img.name)
    if not args.skip_docs:
        import markdown
        docs_dir = ROOT / "docs"

        def render_md(md_text: str, title: str, name: str, docx: Path | None, intro: str = ""):
            def fix_img(mm):
                alt, src = mm.group(1), mm.group(2)
                p = (docs_dir / src).resolve()
                if not p.exists():
                    alt2 = ROOT / "outputs" / "full_all" / Path(src).relative_to("../outputs/full") if src.startswith("../outputs/full/") else None
                    if alt2 and alt2.exists():
                        p = alt2
                    else:
                        print("  missing image", src)
                        return f"*[figure not available: {alt}]*"
                shutil.copy2(p, out / "assets" / "img" / "docs" / p.name)
                return f"![{alt}](assets/img/docs/{p.name})"
            md_text = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", fix_img, md_text)
            mdp = markdown.Markdown(extensions=["tables", "fenced_code", "toc", "attr_list", "sane_lists"], extension_configs={"toc": {"toc_depth": "1-3"}})
            body = mdp.convert(md_text)
            if docx and docx.exists():
                shutil.copy2(docx, out / "docs" / docx.name)
            page("doc.html", name, title=title, body=body, toc=mdp.toc, docx=f"docs/{docx.name}" if docx and docx.exists() else None, intro=intro)

        thesis = (docs_dir / "THESIS_Methodology_and_Results.md").read_text(encoding="utf-8")
        cut = thesis.index("# Chapter 4")
        render_md(thesis[:cut], "Methodology chapter", "methodology-chapter.html", docs_dir / "THESIS_Methodology_and_Results.docx",
                  "Chapter 3 of the thesis in full. The <a href=\"methodology.html\">methodology page</a> gives the same content as a diagram with short notes.")
        render_md(thesis[cut:], "Results chapter", "results-chapter.html", docs_dir / "THESIS_Methodology_and_Results.docx",
                  "Chapter 4 of the thesis in full, with every table. The <a href=\"results.html\">results page</a> shows the same findings as charts.")
        render_md((docs_dir / "CLIENT_RESPONSE_to_Review_2026-10-10.md").read_text(encoding="utf-8"), "Review response", "review-response.html", docs_dir / "CLIENT_RESPONSE_to_Review_2026-10-10.docx")
        render_md((docs_dir / "THESIS_Companies_Used_in_the_Research.md").read_text(encoding="utf-8"), "Companies", "companies.html", docs_dir / "THESIS_Companies_Used_in_the_Research.docx",
                  "Every case and matched firm with its enforcement record, revelation date and matching details. The <a href=\"screening.html\">sample page</a> summarises this in charts; use the contents list or search the page.")
        if (docs_dir / "REPORT_Candidate_Screen_2026-10-08.md").exists():
            render_md((docs_dir / "REPORT_Candidate_Screen_2026-10-08.md").read_text(encoding="utf-8"), "Candidate screening report", "screening-report.html", docs_dir / "REPORT_Candidate_Screen_2026-10-08.docx")

    # home: honest verdicts from the battery
    hh = h13.set_index("hypothesis")

    def verdict(hyp, name):
        r = hh.loc[hyp]
        d = "as predicted" if r["coef_per_sd"] > 0 else "in the opposite direction"
        s1 = "supported" if r["supported_design_rule"] else "not supported"
        s2 = "supported" if r["supported_firm_cluster"] else "not supported"
        return (f"{name}: odds ratio {r['odds_ratio_per_sd']:.2f} per standard deviation [{r['or_ci_low']:.2f}, {r['or_ci_high']:.2f}], {d}; "
                f"p {fmt_p(r['p_unadjusted'])} (Holm {fmt_p(r['p_holm'])}) with model-based errors, p {fmt_p(r['p_firm_cluster'])} with the firm-clustered errors the design asks for; "
                f"{int(r['n_firm_years'])} firm-years of {int(r['n_firms'])} firms in {int(r['n_matched_sets'])} sets. {s1} with model-based errors; {s2} with firm-clustered errors.")
    met = [str(x) for x, v in zip(h4r["layer_score"], h4r["design_rule_met_before_final_year"]) if v]
    Rtxt = {"h1": verdict("H1", "Fraud firms have higher related-party financial exposure") + " The subset that states an amount is selected on the outcome: fraud firms state amounts about three times as often.",
            "h2": verdict("H2", "Fraud firms' RPT disclosures are less complete and vaguer") + " Part of the reversal is the coding convention for texts that state 'no transactions'.",
            "h3": verdict("H3", "Fraud firms have weaker governance") + " The layer is carried by CEO duality.",
            "h4h5": (f"H4 (differences in earlier years): the design rule is met for {', '.join(met) if met else 'no layer'} with the conditional logit as the primary test. "
                     f"H5 (the layers add to audit and internal-control signals): not supported for the design's AI risk score — Model B's out-of-set AUC {float(h5['loso_auc_model_B']):.2f} against Model A {float(h5['loso_auc_model_A']):.2f} and the traditional index alone {float(h5['auc_trad_index_alone']):.2f}; "
                     f"at an equal false-alarm rate the AI rule flags {int(h5['cases_flagged_ai_equal_far'])} of {int(h5['cases'])} cases, the traditional rule {int(h5['cases_flagged_trad_equal_far'])}.")}
    CH = [{"layer": c["layer"], "code": c["code"], "formula": c["formula"], "source": {"L1": "related-party text amount ÷ XBRL total", "L2": "related-party text (Item 13, DEF 14A section, note)", "L3": "proxy statement (DEF 14A)"}[c["layer"]]} for c in chars]
    page("home.html", "index.html", title="Home", S=G["sample"], R=Rtxt)
    page("results.html", "results.html", title="Results", S=G["sample"], EXT=ext)
    page("screening.html", "screening.html", title="Sample", S=G["sample"])
    page("methodology.html", "methodology.html", title="Methodology", S=G["sample"], CH=CH)
    page("run.html", "run.html", title="Run the model")
    page("404.html", "404.html", title="Not found")

    # code page, zips, models
    repos_ctx = []
    for rp in REPOS:
        sha = sha7(rp["path"])
        zname = f"{rp['name']}-{sha}.zip"
        zpath = out / "downloads" / zname
        if not args.skip_zip:
            subprocess.check_call(["git", "-C", str(rp["path"]), "archive", "--format=zip", "-o", str(zpath), "HEAD", "--", "."] + rp["exclude"])
        repos_ctx.append({**rp, "sha": sha, "zip": f"downloads/{zname}", "zip_mb": f"{zpath.stat().st_size/1e6:.1f}" if zpath.exists() else "—"})
    tree = []
    for rp in REPOS:
        files = subprocess.check_output(["git", "-C", str(rp["path"]), "ls-files"], text=True).splitlines()
        tree.append(f"== {rp['name']} ({rp['url']}, {rp['branch']} @ {sha7(rp['path'])}; {len(files)} tracked files)\n" + "\n".join(files))
    (out / "downloads" / "FILE_TREE.txt").write_text("\n\n".join(tree), encoding="utf-8")
    models_ctx = []
    for pk in sorted((RUN / "models").glob("*.pkl")):
        shutil.copy2(pk, out / "downloads" / "models" / pk.name)
        models_ctx.append({"name": pk.name, "path": f"downloads/models/{pk.name}", "kb": f"{pk.stat().st_size/1024:.0f}"})
    page("code.html", "code.html", title="Code and data", repos=repos_ctx, models=models_ctx, cap=args.cap, logit=G["logit"])

    # README, verify tool, manifest, safety grep
    (out / "README.md").write_text(
        "# RPT fraud-risk study — public demo site\n\nStatic site generated by `scripts/export_site.py` in the TrainingPipeline repository from the research outputs "
        f"(run `{build['run_dir']}`, battery `{build['design_dir']}`, {build['generated_at']}). Nothing here is hand-edited; regenerate after any re-run.\n\n"
        "The 'Run the model' page loads JSON with fetch(), which browsers block for file:// addresses: open the GitHub Pages URL or serve the folder locally "
        "(`python -m http.server 8080`). `node tools/verify.mjs` re-runs the browser computation and reports the largest difference from the recorded numbers.\n\n"
        "Only public SEC filing excerpts and the coder's evidence sentences are included. Design tests are the primary results; the fitted score is exploratory; "
        "every result is an association that identifies fraud already under way, not a prediction.\n", encoding="utf-8")
    (out / "tools" / "verify.mjs").write_text(VERIFY_MJS, encoding="utf-8")
    total = sum(p.stat().st_size for p in out.rglob("*") if p.is_file() and ".git" not in p.parts)
    write_json(out / "data" / "manifest.json", {"generated_at": build["generated_at"], "companies": len(sizes), "bytes_total": total, "bytes_companies": sum(sizes.values()), "bytes_global": g_bytes})
    bad = []
    for p in list(out.rglob("*.json")) + list(out.rglob("*.html")):
        t = p.read_text(encoding="utf-8", errors="replace")
        if re.search(r"hf_[A-Za-z0-9]{20,}|HF_TOKEN|D:\\\\alpha|D:/alpha", t):
            bad.append(p.name)
    assert not bad, f"private strings found in {bad}"
    print(f"site written to {out}: {total/1e6:.1f} MB")


VERIFY_MJS = r"""// node tools/verify.mjs  (run from the site root): recompute every firm-year with assets/js/compute.js and compare.
import { readFileSync, readdirSync } from "node:fs";
import { designScore, logit, aiFlag } from "../assets/js/compute.js";
const G = JSON.parse(readFileSync("data/global.json", "utf8"));
let n = 0, maxAI = 0, maxP = 0, flagMismatch = 0, layerMax = 0;
for (const f of readdirSync("data/companies")) {
  const co = JSON.parse(readFileSync("data/companies/" + f, "utf8"));
  for (const y of co.years) {
    const values = {}; for (const c of G.characteristics) values[c.code] = y.characteristics[c.code].value;
    const ds = designScore(G.characteristics, values);
    const rec = y.design_recorded;
    if ((ds.AI_SCORE === null) !== (rec.AI_SCORE === null)) maxAI = 1; else if (ds.AI_SCORE !== null) maxAI = Math.max(maxAI, Math.abs(ds.AI_SCORE - rec.AI_SCORE));
    for (const L of ["L1", "L2", "L3"]) { const a = ds.layer[L], b = rec[L + "_SCORE"]; if ((a === null) !== (b === null)) layerMax = 1; else if (a !== null) layerMax = Math.max(layerMax, Math.abs(a - b)); }
    if (aiFlag(ds.AI_SCORE, G.ai_flag.thr_5pct_far) !== rec.AI_FLAG_5) flagMismatch++;
    const lg = logit(G.logit, y.features);
    maxP = Math.max(maxP, Math.abs(lg.prob - y.logit_recorded.prob_full_fit));
    n++;
  }
}
console.log(`firm-years ${n}; max |ΔAI_SCORE| ${maxAI.toExponential(2)}; max |Δlayer| ${layerMax.toExponential(2)}; flag mismatches ${flagMismatch}; max |Δlogit prob| ${maxP.toExponential(2)}`);
process.exit(maxAI < 1e-9 && layerMax < 1e-9 && flagMismatch === 0 && maxP < 1e-7 ? 0 : 1);
"""


if __name__ == "__main__":
    main()
