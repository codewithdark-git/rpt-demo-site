"""Independent check of the exported site data against the research outputs.

Recomputes, from the exported JSON alone, the design ranks / layer scores / AI_SCORE / flag and the fitted logit
probability for a sample of firm-years, and compares them with scores_by_firm_year.csv, the pickled pipeline's
predict_proba and the deployment path rpt_panel.predict.predict (with the rpt_text). Also checks that the OOF
values equal oof_scores.csv and that every EDGAR document URL matches filing_manifest.document_url.

    python scripts/check_site_export.py --site ../rpt-demo-site --n 12
"""
from __future__ import annotations

import argparse
import bisect
import json
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rpt_panel.predict import load_model, predict  # noqa: E402


def rank_pct(sorted_vals, v):
    if v is None:
        return None
    lo = bisect.bisect_left(sorted_vals, v)
    hi = bisect.bisect_right(sorted_vals, v)
    return (lo + 1 + hi) / (2 * len(sorted_vals))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", default=str(ROOT.parent / "rpt-demo-site"))
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--design", default="main31")
    args = ap.parse_args()
    site = Path(args.site)
    G = json.loads((site / "data" / "global.json").read_text(encoding="utf-8"))
    files = sorted((site / "data" / "companies").glob("*.json"))
    rng = random.Random(args.seed)
    pick = {"0000874499", "0000896493"} | {f.stem for f in rng.sample(files, min(args.n, len(files)))}
    rec = pd.read_csv(ROOT / "outputs" / "full_all" / "design_tests_v2" / args.design / "scores_by_firm_year.csv", dtype={"cik": str})
    rec["cik"] = rec["cik"].str.zfill(10)
    rec = rec.set_index(["cik", "fiscal_year"])
    oof = pd.read_csv(ROOT / "outputs" / "full_all" / "oof_scores.csv", dtype={"cik": str})
    oof["cik"] = oof["cik"].str.zfill(10)
    oof = oof.pivot_table(index=["cik", "fiscal_year"], columns="model", values="score", aggfunc="first")
    manifest = pd.read_csv(ROOT.parent / "SEC-EDGAR-Downloader" / "data_core" / "filing_manifest.csv", dtype=str, keep_default_na=False)
    url_of = dict(zip(manifest["accession_number"], manifest["document_url"]))
    texts = pd.read_csv(ROOT / "outputs" / "full_all" / "panel_texts.csv", dtype={"cik": str, "rpt_text": str}, keep_default_na=False)
    texts["cik"] = texts["cik"].str.zfill(10)
    text_of = {(c, int(y)): t for c, y, t in zip(texts["cik"], texts["fiscal_year"], texts["rpt_text"])}
    model = load_model(ROOT / "outputs" / "full_all" / "models" / "rpt_panel_logit.pkl")
    sorted_vals = {c["code"]: c["sorted_values"] for c in G["characteristics"]}
    L = G["logit"]
    worst = {"rank": 0.0, "ai": 0.0, "prob_pipeline": 0.0, "prob_predict": 0.0, "oof": 0.0}
    n_rows, bad_urls, flag_mismatch = 0, [], 0
    for cik in sorted(pick):
        co = json.loads((site / "data" / "companies" / f"{cik}.json").read_text(encoding="utf-8"))
        for y in co["years"]:
            k = (cik, y["fiscal_year"])
            n_rows += 1
            # ranks and AI score from the exported sorted arrays
            layer = {}
            for Lk in ("L1", "L2", "L3"):
                rs = []
                for c in G["characteristics"]:
                    if c["layer"] != Lk:
                        continue
                    r = rank_pct(sorted_vals[c["code"]], y["characteristics"][c["code"]]["value"])
                    if r is not None:
                        rs.append(r)
                        worst["rank"] = max(worst["rank"], abs(r - y["characteristics"][c["code"]]["rank_recorded"]))
                layer[Lk] = float(np.mean(rs)) if rs else None
            present = [v for v in layer.values() if v is not None]
            ai = 10 * float(np.mean(present)) if present else None
            rec_ai = rec.loc[k, "AI_SCORE"]
            if ai is None:
                assert pd.isna(rec_ai), (k, rec_ai)
            else:
                worst["ai"] = max(worst["ai"], abs(ai - float(rec_ai)))
            if (ai is not None and ai >= G["ai_flag"]["thr_5pct_far"]) != bool(y["design_recorded"]["AI_FLAG_5"]):
                flag_mismatch += 1
            # logit from the exported parameters
            z = []
            for i, f in enumerate(L["features"]):
                raw = y["features"][f]
                imputed = L["imputer_median"][i] if raw is None else raw
                z.append((imputed - L["scaler_mean"][i]) / L["scaler_scale"][i])
            lin = L["intercept"] + float(np.dot(L["coef"], z))
            prob = 1 / (1 + np.exp(-lin))
            X = pd.DataFrame([{f: (np.nan if y["features"][f] is None else y["features"][f]) for f in L["features"]}])
            p_pipe = float(model["pipeline"].predict_proba(X)[:, 1][0])
            worst["prob_pipeline"] = max(worst["prob_pipeline"], abs(prob - p_pipe), abs(p_pipe - y["logit_recorded"]["prob_full_fit"]))
            # deployment path with the raw text (text_risk recomputed by the text model)
            Xd = X.drop(columns=["text_risk"]).assign(rpt_text=text_of.get(k, ""))
            p_dep = float(predict(model, Xd, force=True)["risk_score"].iloc[0])
            if not np.isnan(p_dep):
                worst["prob_predict"] = max(worst["prob_predict"], abs(p_dep - y["logit_recorded"]["prob_full_fit"]))
            # OOF equality
            if y["oof"]:
                for m_ in ("logit", "rf", "xgb", "ensemble"):
                    worst["oof"] = max(worst["oof"], abs(y["oof"][m_] - float(oof.loc[k, m_])))
            # EDGAR URL
            tk = y["filings"]["tenk"]
            if tk and url_of.get(tk["accession"]) and url_of[tk["accession"]] != tk["url"]:
                bad_urls.append((k, tk["url"], url_of[tk["accession"]]))
    print(f"checked {n_rows} firm-years of {len(pick)} firms")
    for k_, v in worst.items():
        print(f"  max |delta| {k_}: {v:.2e}")
    print(f"  flag mismatches: {flag_mismatch}; EDGAR URL mismatches: {len(bad_urls)}")
    for b in bad_urls[:5]:
        print("   ", b)
    ok = worst["rank"] < 1e-9 and worst["ai"] < 1e-9 and worst["prob_pipeline"] < 1e-7 and worst["oof"] < 1e-12 and flag_mismatch == 0 and not bad_urls
    print("OK" if ok else "FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
