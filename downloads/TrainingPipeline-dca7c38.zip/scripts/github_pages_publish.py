"""Create the public site repository and enable GitHub Pages through the REST API, using the token stored in the
Git credential manager. The token is read with `git credential fill`, kept in memory and never printed or written.

    python scripts/github_pages_publish.py --owner codewithdark-git --repo rpt-demo-site create
    python scripts/github_pages_publish.py --owner codewithdark-git --repo rpt-demo-site pages
    python scripts/github_pages_publish.py --owner codewithdark-git --repo rpt-demo-site status
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import urllib.error
import urllib.request

API = "https://api.github.com"


def token() -> str:
    out = subprocess.run(["git", "credential", "fill"], input="protocol=https\nhost=github.com\n\n", text=True, capture_output=True, check=True).stdout
    for line in out.splitlines():
        if line.startswith("password="):
            return line[len("password="):]
    raise SystemExit("no GitHub credential stored for https://github.com (run `git credential approve` or sign in with Git Credential Manager first)")


def call(method: str, path: str, tok: str, body: dict | None = None) -> tuple[int, dict | str]:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + path, data=data, method=method,
                                 headers={"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
                                          "User-Agent": "rpt-demo-site-publisher", **({"Content-Type": "application/json"} if data else {})})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read().decode()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            return e.code, json.loads(raw)
        except json.JSONDecodeError:
            return e.code, raw


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["create", "pages", "status"])
    ap.add_argument("--owner", required=True)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--description", default="Related-party transactions and corporate fraud risk: public demo of a matched case-control study of SEC enforcement cases")
    args = ap.parse_args()
    tok = token()
    if args.action == "create":
        st, body = call("POST", "/user/repos", tok, {"name": args.repo, "private": False, "has_issues": False, "has_wiki": False, "has_projects": False,
                                                    "description": args.description, "auto_init": False})
        if st == 201:
            print("created", body.get("html_url"))
        elif st == 422:
            print("repository already exists (or name invalid):", body.get("errors", body.get("message")))
        else:
            print(f"could not create the repository (HTTP {st}): {body if isinstance(body, str) else body.get('message')}")
            print("Create it in the GitHub UI instead: New repository -> name", args.repo, "-> Public -> Create, then push.")
            sys.exit(1)
    elif args.action == "pages":
        st, body = call("POST", f"/repos/{args.owner}/{args.repo}/pages", tok, {"source": {"branch": "main", "path": "/"}})
        if st == 409:
            st, body = call("PUT", f"/repos/{args.owner}/{args.repo}/pages", tok, {"source": {"branch": "main", "path": "/"}})
        if st not in (201, 204, 200):
            print(f"could not enable Pages (HTTP {st}): {body if isinstance(body, str) else body.get('message')}")
            print("Enable it in the GitHub UI: Settings -> Pages -> Build and deployment: Deploy from a branch -> main, / (root).")
            sys.exit(1)
        for _ in range(30):
            st, body = call("GET", f"/repos/{args.owner}/{args.repo}/pages", tok)
            if st == 200 and body.get("status") == "built":
                print("Pages built:", body.get("html_url"))
                return
            time.sleep(10)
        print("Pages enabled; build still in progress:", body.get("html_url") if isinstance(body, dict) else body)
    else:
        st, body = call("GET", f"/repos/{args.owner}/{args.repo}/pages", tok)
        print(st, body if isinstance(body, str) else {k: body.get(k) for k in ("html_url", "status", "source", "public")})


if __name__ == "__main__":
    main()
