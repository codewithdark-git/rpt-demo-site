"""Entry point for the RPT fraud-risk research pipeline.

    python main.py all --config rpt_panel.json          # download -> build -> model -> stress -> mediate -> explain -> report
    python main.py build --config rpt_panel.json        # any single step
    python main.py infer --model-path outputs/panel/models/rpt_panel_logit.pkl --data my_firm_years.csv

This is a thin wrapper around ``python -m rpt_panel.run``. The pre-2026 pipeline
lives in ``legacy/`` and is not runnable; see legacy/README.md for why.
"""
from rpt_panel.run import main

if __name__ == "__main__":
    main()
