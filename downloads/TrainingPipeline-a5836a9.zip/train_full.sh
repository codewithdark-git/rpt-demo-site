#!/usr/bin/env bash
# One command: install, test, download the published SEC-RPT-Panel dataset and run every stage
# (panel -> features -> leave-one-cluster-out models -> stress tests T1-T5 -> mediation and
# clustered logit -> explainability -> figures/tables) with the full-performance configuration.
#
#   export HF_TOKEN=hf_...            # only needed if the dataset repo is private
#   cp /path/to/cases.csv .           # the same verified cases file the dataset was built with
#   bash train_full.sh                # uses rpt_panel.full.json
#   CONFIG=rpt_panel.pilot.json bash train_full.sh --skip-download
#
# Results land in outputs/full (or the config's output_dir). Nothing is tuned on held-out
# clusters: every reported score is out-of-fold and the alert threshold is fixed by the
# clean-firm false-positive target.
set -Eeuo pipefail
cd "$(dirname "$0")"

CONFIG="${CONFIG:-rpt_panel.full.json}"

python -m pip install -q -r requirements.txt
python -m unittest discover -s tests/rpt_panel -t . -q

python main.py all --config "$CONFIG" "$@"

OUT=$(python -c "import json,sys; print(json.load(open('$CONFIG')).get('output_dir','outputs/panel'))")
echo
echo "Done. Key outputs:"
echo "  $OUT/panel_summary.json            sample, text coverage"
echo "  $OUT/tables/oof_metrics.*          H1 out-of-fold AUC with cluster-bootstrap CIs"
echo "  $OUT/stress_tests/stress_summary.* T1-T5"
echo "  $OUT/tables/mediation.*            P4 bootstrap mediation"
echo "  $OUT/tables/logit_*                primary inference"
echo "  $OUT/explainability/               stability, traceability, SHAP"
echo "  $OUT/figures/                      ROC, calibration, event-time scores, waterfalls, z-heatmap, drift"
