"""
Configuration management for the forensic RPT research system.
Supports JSON config files and programmatic override.
"""

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional, Dict, Any


@dataclass
class NLPConfig:
    """NLP analysis parameters."""
    enable_advanced_nlp: bool = False
    vagueness_keywords: List[str] = field(default_factory=lambda: [
        "consulting", "professional fees", "administrative services",
        "management fees", "advisory services", "service fees",
        "general services", "business development", "strategic services",
        "other services", "miscellaneous", "various services",
    ])
    passive_voice_markers: List[str] = field(default_factory=lambda: [
        "was agreed", "was determined", "was established", "was provided",
        "were paid", "was recorded", "was considered", "was entered",
        "was made", "were made", "has been", "have been",
        "was reached", "was completed", "was executed",
    ])
    agency_masking_patterns: List[str] = field(default_factory=lambda: [
        r"an agreement was",
        r"it was determined",
        r"the company entered",
        r"a payment was",
        r"fees were paid",
        r"services were provided",
        r"the transaction was",
    ])
    fog_index_threshold: float = 12.0          # Above this = complex/obfuscating
    boilerplate_similarity_threshold: float = 0.85  # Above = copy-paste (no new info)
    vagueness_score_threshold: float = 0.40    # Above = flagged for review
    agency_masking_threshold: float = 0.40     # SFL agency-masking flag
    min_rpt_section_words: int = 50            # Minimum words for valid RPT section


@dataclass
class FinancialConfig:
    """Financial ratio thresholds."""
    rpt_revenue_ratio_threshold: float = 0.10  # 10% flags as material
    rpt_assets_ratio_threshold: float = 0.05
    icfr_weakness_years_threshold: int = 2     # Consecutive years = systemic
    icfr_periods_per_year: int = 4             # Quarterly periods per year
    material_weakness_score_max: int = 10
    restatement_flag: bool = True


@dataclass
class MLConfig:
    """Machine learning model parameters."""
    test_size: float = 0.30
    random_state: int = 42
    cv_folds: int = 5
    fraud_label_col: str = "is_fraud"
    feature_importance_top_n: int = 15
    # XGBoost params (used when library available)
    xgb_n_estimators: int = 300
    xgb_max_depth: int = 5
    xgb_learning_rate: float = 0.05


@dataclass
class SICConfig:
    """Industry / peer matching parameters."""
    target_sic: str = ""
    sic_description: str = ""
    peer_asset_min_usd: float = 4e8    # $400M
    peer_asset_max_usd: float = 8e8    # $800M
    num_peers: int = 5


@dataclass
class DatasetConfig:
    """Dataset source configuration."""
    source_type: str = "local"  # "local" or "huggingface"
    hf_dataset_id: str = "alphatechlogics/SEC-EDGAR-Download"
    hf_cache_dir: str = "./data/hf_cache"
    hf_auth_token: Optional[str] = None
    hf_download_mode: str = "targeted"  # "targeted" metadata + needed filings, or "snapshot"
    hf_max_rows: Optional[int] = None  # Limit firm-years selected from Hugging Face metadata
    hf_sample_strategy: str = "fraud-balanced"  # "fraud-balanced" or "first"
    use_local_companies_json: bool = True


@dataclass
class Config:
    """Master configuration object."""
    # Study identifiers. Deliberately empty: the sample is defined by the cases file
    # of the dataset builder, never by defaults in code.
    target_cik: str = ""
    target_name: str = ""
    aaer_number: str = ""
    analysis_years: List[int] = field(default_factory=list)

    # Sub-configs
    nlp: NLPConfig = field(default_factory=NLPConfig)
    financial: FinancialConfig = field(default_factory=FinancialConfig)
    ml: MLConfig = field(default_factory=MLConfig)
    sic: SICConfig = field(default_factory=SICConfig)
    dataset: DatasetConfig = field(default_factory=DatasetConfig)

    # I/O
    output_dir: Path = field(default_factory=lambda: Path("outputs"))
    data_dir: Path = field(default_factory=lambda: Path("data"))
    cache_dir: Path = field(default_factory=lambda: Path("data/cache"))

    # Peers come from the cases file (matched by SIC and size), not from code.
    peer_ciks: List[str] = field(default_factory=list)

    # EDGAR API settings
    edgar_base_url: str = "https://data.sec.gov"
    edgar_submissions_url: str = "https://data.sec.gov/submissions"
    edgar_user_agent: str = "PhD Forensic Research forensic.research@university.edu"
    edgar_rate_limit_seconds: float = 0.15
    # Real-data policy: never fall back to stub or hand-typed data.
    strict_real_data: bool = True
    skip_missing_years: bool = True

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["output_dir"] = str(self.output_dir)
        d["data_dir"] = str(self.data_dir)
        d["cache_dir"] = str(self.cache_dir)
        return d

    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str) -> "Config":
        p = Path(path)
        if not p.exists():
            cfg = cls()
            p.parent.mkdir(parents=True, exist_ok=True)
            cfg.save(str(p))
            cfg.config_path = str(p)
            return cfg
        with open(p) as f:
            data = json.load(f)
        cfg = cls()
        nested_configs = {
            "nlp": cfg.nlp,
            "financial": cfg.financial,
            "ml": cfg.ml,
            "sic": cfg.sic,
            "dataset": cfg.dataset,
        }
        for k, v in data.items():
            if k in nested_configs and isinstance(v, dict):
                target = nested_configs[k]
                for nk, nv in v.items():
                    if hasattr(target, nk):
                        setattr(target, nk, nv)
            elif hasattr(cfg, k) and k not in nested_configs:
                setattr(cfg, k, v)
        cfg.config_path = str(p)
        return cfg
