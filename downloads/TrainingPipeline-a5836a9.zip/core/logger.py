"""Logging configuration for the research system."""

import logging
import sys
import warnings
from pathlib import Path
from typing import Optional


def setup_logging(level: str = "INFO", log_file: Optional[Path] = None) -> logging.Logger:
    """
    Configure root logger with console + optional file handler.
    Returns the root logger for use in main.
    """
    fmt = "%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    handlers = [logging.StreamHandler(sys.stdout)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, mode="a", encoding="utf-8"))

    logging.basicConfig(
        level=numeric_level,
        format=fmt,
        datefmt=datefmt,
        handlers=handlers,
        force=True,
    )

    # Silence noisy third-party libs
    for noisy in ("urllib3", "requests", "httpx", "huggingface_hub", "matplotlib", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    warnings.filterwarnings(
        "ignore",
        message=".*sklearn.utils.parallel.delayed.*",
        category=UserWarning,
    )

    return logging.getLogger("forensic_rpt")
