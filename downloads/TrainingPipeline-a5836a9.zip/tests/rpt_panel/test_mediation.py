import unittest

import numpy as np
import pandas as pd

from rpt_panel import inference_stats
from rpt_panel.mediation import bootstrap_mediation


def simulate(n_firms=60, years=5, a=0.8, b=1.2, direct=0.3, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for f in range(n_firms):
        for t in range(years):
            x = rng.normal()
            m = a * x + rng.normal()
            logit = -1.0 + direct * x + b * m
            y = rng.random() < 1 / (1 + np.exp(-logit))
            rows.append({"cik": f"{f:010d}", "cluster_id": f"C{f % 10}", "x": x, "m": m, "y": int(y), "fraud_aaer_label": int(y)})
    return pd.DataFrame(rows)


class MediationTests(unittest.TestCase):
    def test_bootstrap_se_is_not_the_legacy_fifteen_percent_rule(self):
        df = simulate()
        res = bootstrap_mediation(df, "x", "m", y="y", n_boot=200, seed=1)
        self.assertGreater(res.indirect, 0)
        self.assertGreater(res.se_boot, 0)
        self.assertNotAlmostEqual(res.se_boot, 0.15 * abs(res.indirect), places=3)
        self.assertLess(res.ci_low, res.indirect)
        self.assertGreater(res.ci_high, res.indirect)
        self.assertGreater(res.ci_low, 0)          # true indirect effect is positive
        self.assertGreaterEqual(res.n_boot_ok, 150)

    def test_null_mediator_path_gives_interval_covering_zero(self):
        df = simulate(a=0.0, seed=3)
        res = bootstrap_mediation(df, "x", "m", y="y", n_boot=200, seed=2)
        self.assertLessEqual(res.ci_low, 0)
        self.assertGreaterEqual(res.ci_high, 0)

    def test_requires_both_classes(self):
        df = simulate()
        df["y"] = 0
        with self.assertRaises(ValueError):
            bootstrap_mediation(df, "x", "m", y="y", n_boot=10)


class ClusteredLogitTests(unittest.TestCase):
    def test_clustered_logit_recovers_signal_with_cluster_count(self):
        df = simulate()
        out = inference_stats.clustered_logit(df, ["x", "m"], y="y", cluster="cik")
        self.assertEqual(set(out["term"]), {"const", "x", "m"})
        self.assertEqual(int(out["n_clusters"].iloc[0]), 60)
        m_row = out[out["term"] == "m"].iloc[0]
        self.assertGreater(m_row["coef"], 0)
        self.assertLess(m_row["p"], 0.01)

    def test_conditional_logit_runs_within_clusters(self):
        df = simulate()
        out = inference_stats.conditional_logit(df, ["x", "m"], y="y", group="cluster_id")
        self.assertIn("m", set(out["term"]))
        self.assertGreater(out.loc[out["term"] == "m", "coef"].iloc[0], 0)


if __name__ == "__main__":
    unittest.main()
