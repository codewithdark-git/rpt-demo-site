"""Rule-based governance coder: known-answer checks on short filing / proxy passages."""
import math
import unittest

from rpt_panel import governance_coder as gc


class AuditorTests(unittest.TestCase):
    REPORT = (
        "Table of Contents ... Report of Independent Registered Public Accounting Firm ... 45\n"
        "REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM\n"
        "To the shareholders and the Board of Directors of Example Corp\n"
        "We have audited the accompanying consolidated balance sheets ... These conditions raise substantial doubt "
        "about the Company's ability to continue as a going concern. ...\n"
        "/s/ Marcum LLP\nNew York, NY\nMarch 1, 2019\n"
    )

    def test_auditor_signature_and_big4(self):
        name, _ = gc.auditor(self.REPORT)
        self.assertEqual(name, "Marcum")
        name, _ = gc.auditor(self.REPORT.replace("Marcum LLP", "Deloitte & Touche LLP"))
        self.assertEqual(name, "Deloitte & Touche")
        self.assertIn(name, set(gc.BIG4.values()))

    def test_officer_signatures_are_not_auditors(self):
        text = "REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM ... /s/ John Doe, Chief Executive Officer LLC"
        self.assertEqual(gc.auditor(text)[0], "")

    def test_going_concern_only_inside_audit_report(self):
        flag, _ = gc.going_concern(self.REPORT)
        self.assertEqual(flag, 1.0)
        clean = self.REPORT.replace("These conditions raise substantial doubt about the Company's ability to continue as a going concern.", "")
        self.assertEqual(gc.going_concern(clean)[0], 0.0)
        risk_factor_only = "Risk factors: our auditors may raise substantial doubt about our ability to continue as a going concern."
        self.assertTrue(math.isnan(gc.going_concern(risk_factor_only)[0]))


class ProxyTests(unittest.TestCase):
    def test_ceo_duality_positive(self):
        self.assertEqual(gc.ceo_duality("Robert Greenberg has served as our Chairman of the Board and Chief Executive Officer since 1993.")[0], 1.0)

    def test_ceo_duality_negative_and_conditional(self):
        text = ("Our Guidelines allow our Board to determine whether to separate or combine the roles of the Chairman and "
                "Chief Executive Officer. Currently, Mr. Devine serves as our Company's independent Chairman of the Board.")
        self.assertEqual(gc.ceo_duality(text)[0], 0.0)
        self.assertEqual(gc.ceo_duality("The Company separates the roles of Chairman and Chief Executive Officer.")[0], 0.0)

    def test_titles_at_other_companies_do_not_count(self):
        text = ("Dr. Lechleiter is Chairman of the Board, President, and Chief Executive Officer of Eli Lilly and Company. "
                "He is Chairman, President and Chief Executive Officer of Lilly.")
        self.assertTrue(math.isnan(gc.ceo_duality(text)[0]))
        self.assertTrue(math.isnan(gc.ceo_duality("")[0]))

    def test_board_independence_counts(self):
        self.assertAlmostEqual(gc.board_indep("Six of our seven directors are independent under NASDAQ rules.")[0], 6 / 7)
        names = ("The Board of Directors currently consists of eight members. The Board has determined that each of "
                 "Messrs. Smith, Jones and Brown, Ms. Lee and Dr. Wu is independent.")
        self.assertAlmostEqual(gc.board_indep(names)[0], 5 / 8)
        all_but = "Our Board consists of seven directors. The Board has determined that all of our directors, other than Mr. Smith, are independent."
        self.assertAlmostEqual(gc.board_indep(all_but)[0], 6 / 7)
        self.assertTrue(math.isnan(gc.board_indep("A majority of our directors are independent.")[0]))

    def test_audit_committee_independence(self):
        self.assertEqual(gc.ac_indep("Each member of the Audit Committee is independent under NYSE rules.")[0], 1.0)
        self.assertEqual(gc.ac_indep("The audit committee is composed entirely of independent directors.")[0], 1.0)
        self.assertTrue(math.isnan(gc.ac_indep("The audit committee met four times.")[0]))


if __name__ == "__main__":
    unittest.main()
