import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from rpt_panel import modelling, predict
from rpt_panel.config import PanelConfig
from tests.rpt_panel.synthetic import make_panel

FEATURES = ["x1", "x2", "m", "noise_only", "ln_assets"]


class PredictTests(unittest.TestCase):
    def setUp(self):
        self.df = make_panel()
        self.cfg = PanelConfig(n_boot=20)
        pipe, _ = modelling.fit_final(self.df, FEATURES, "logit", self.cfg)
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "m.pkl"
        modelling.save_model(pipe, FEATURES, {"g": FEATURES}, threshold=0.6, cfg=self.cfg, dataset_version="2.0.0", path=self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_round_trip_and_threshold(self):
        model = predict.load_model(self.path)
        out = predict.predict(model, self.df, dataset_version="2.0.0")
        self.assertEqual(len(out), len(self.df))
        self.assertTrue(((out["risk_score"] >= 0.6) == (out["flagged"] == 1)).all())

    def test_missing_column_is_imputed_with_training_median_not_zero(self):
        model = predict.load_model(self.path)
        full = predict.predict(model, self.df, dataset_version="2.0.0")["risk_score"]
        shifted = self.df.copy()
        shifted["ln_assets"] = shifted["ln_assets"] + 50     # training median ~18
        shifted_scores = predict.predict(model, shifted, dataset_version="2.0.0")["risk_score"]
        dropped = predict.predict(model, self.df.drop(columns=["ln_assets"]), dataset_version="2.0.0")["risk_score"]
        self.assertFalse(np.allclose(shifted_scores, full))
        median_filled = self.df.copy()
        median_filled["ln_assets"] = self.df["ln_assets"].median()
        self.assertTrue(np.allclose(dropped, predict.predict(model, median_filled, dataset_version="2.0.0")["risk_score"], atol=1e-6))

    def test_dataset_version_mismatch_is_refused(self):
        model = predict.load_model(self.path)
        with self.assertRaises(ValueError):
            predict.predict(model, self.df, dataset_version="9.9.9")
        predict.predict(model, self.df, dataset_version="9.9.9", force=True)


if __name__ == "__main__":
    unittest.main()
