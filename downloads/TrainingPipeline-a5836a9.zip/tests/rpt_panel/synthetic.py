"""Synthetic case-control panel used by the rpt_panel tests (no real firm data)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_panel(n_clusters: int = 6, peers_per_case: int = 4, years=range(2015, 2020), effect: float = 1.5, seed: int = 0) -> pd.DataFrame:
    """Each cluster has one case firm (label 1 in the window) and ``peers_per_case`` peers (label 0).

    ``x1`` carries a real signal (shifted for cases), ``x2`` is noise, ``m`` is a
    mediator driven by ``x1`` and ``noise_only`` is pure noise.
    """
    rng = np.random.default_rng(seed)
    rows = []
    rev_year = max(years) + 1
    for c in range(n_clusters):
        cluster = f"C{c}"
        for firm in range(peers_per_case + 1):
            is_case = int(firm == 0)
            cik = f"{c:04d}{firm:06d}"
            for y in years:
                x1 = rng.normal(effect if is_case else 0.0, 1.0)
                m = 0.8 * x1 + rng.normal(0, 1)
                rows.append({
                    "cik": cik, "ticker": f"T{c}{firm}", "fiscal_year": y, "cluster_id": cluster,
                    "case_role": "case" if is_case else "peer", "is_case": is_case,
                    "fraud_aaer_label": is_case, "event_time": y - rev_year,
                    "report_date": f"{y}-12-31", "x1": x1, "x2": rng.normal(), "m": m,
                    "noise_only": rng.normal(), "ln_assets": rng.normal(18, 1),
                })
    return pd.DataFrame(rows)
