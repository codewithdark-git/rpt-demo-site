import unittest

import numpy as np
import pandas as pd

from rpt_panel import modelling, stress_tests
from rpt_panel.config import PanelConfig
from tests.rpt_panel.synthetic import make_panel

FEATURES = ["x1", "x2", "m", "noise_only", "ln_assets"]


class GroupedSplitTests(unittest.TestCase):
    def setUp(self):
        self.df = make_panel()
        self.cfg = PanelConfig(n_boot=50, seed=1)

    def test_no_firm_or_cluster_in_both_train_and_test(self):
        for train_idx, test_idx in modelling.splits(self.df["cluster_id"]):
            self.assertFalse(set(self.df.iloc[train_idx]["cik"]) & set(self.df.iloc[test_idx]["cik"]))
            self.assertFalse(set(self.df.iloc[train_idx]["cluster_id"]) & set(self.df.iloc[test_idx]["cluster_id"]))

    def test_oof_scores_cover_every_row_exactly_once(self):
        res = modelling.fit_oof(self.df, FEATURES, "logit", self.cfg)
        self.assertEqual(int(res.scores.notna().sum()), len(self.df))
        self.assertEqual(len(res.folds), self.df["cluster_id"].nunique())  # leave-one-cluster-out

    def test_signal_feature_is_detected_and_noise_is_not(self):
        res = modelling.fit_oof(self.df, FEATURES, "rf", self.cfg)
        ev = modelling.evaluate(self.df, res, self.cfg)
        self.assertGreater(ev["oof_auc"], 0.75)
        self.assertLess(ev["oof_auc_ci_low"], ev["oof_auc"])
        importance = res.shap_values.abs().mean()
        self.assertGreater(importance["x1"], importance["noise_only"])

    def test_pure_noise_gives_chance_level_auc(self):
        res = modelling.fit_oof(self.df, ["x2", "noise_only"], "logit", self.cfg)
        ev = modelling.evaluate(self.df, res, self.cfg)
        self.assertLess(ev["oof_auc"], 0.7)

    def test_imputer_is_fitted_inside_the_fold(self):
        df = self.df.copy()
        df.loc[df["cluster_id"] == "C0", "x2"] = np.nan        # all missing in one cluster
        df.loc[df["cluster_id"] == "C1", "x2"] = 100.0          # extreme values in another
        res = modelling.fit_oof(df, FEATURES, "logit", self.cfg)
        fold_c1_out = [i for i, (_, te) in enumerate(res.folds) if set(df.iloc[te]["cluster_id"]) == {"C1"}][0]
        median_without_c1 = res.estimators[fold_c1_out].named_steps["impute"].statistics_[FEATURES.index("x2")]
        self.assertLess(abs(median_without_c1), 5)              # the 100s never entered this fold's imputer

    def test_xgb_pipeline_runs(self):
        res = modelling.fit_oof(self.df, FEATURES, "xgb", self.cfg)
        self.assertEqual(int(res.scores.notna().sum()), len(self.df))


def synthetic_texts(df: pd.DataFrame, seed: int = 0) -> pd.Series:
    """Case texts carry a marker vocabulary; everything else is shared boilerplate."""
    rng = np.random.default_rng(seed)
    base = "the company entered into agreements with related parties during the year pursuant to the policy approved by the audit committee"
    marker = "consulting fees were paid to an entity controlled by the chief executive officer under an oral agreement"
    out = []
    for _, r in df.iterrows():
        words = (base + " ").split() * 4
        if r["is_case"] == 1 and rng.random() < 0.8:
            words += marker.split() * 2
        rng.shuffle(words)
        out.append(" ".join(words))
    return pd.Series(out, index=df.index)


class TextStackingTests(unittest.TestCase):
    def setUp(self):
        self.df = make_panel(effect=0.3)   # weak numeric signal so the text has room to help
        self.cfg = PanelConfig(n_boot=30, seed=3)
        self.texts = synthetic_texts(self.df)

    def test_stacked_text_feature_is_out_of_fold_and_informative(self):
        res = modelling.fit_oof(self.df, ["x2", "noise_only"], "logit", self.cfg, texts=self.texts)
        self.assertIn("text_risk", res.features)
        self.assertEqual(int(res.text_oof.notna().sum()), len(self.df))
        ev = modelling.evaluate(self.df, res, self.cfg)
        base = modelling.evaluate(self.df, modelling.fit_oof(self.df, ["x2", "noise_only"], "logit", self.cfg), self.cfg)
        self.assertGreater(ev["oof_auc"], base["oof_auc"] + 0.1)

    def test_text_model_without_signal_does_not_inflate_auc(self):
        rng = np.random.default_rng(1)
        shuffled = pd.Series(rng.permutation(self.texts.values), index=self.texts.index)   # texts decoupled from labels
        res = modelling.fit_oof(self.df, ["x2", "noise_only"], "logit", self.cfg, texts=shuffled)
        self.assertLess(modelling.evaluate(self.df, res, self.cfg)["oof_auc"], 0.7)

    def test_peer_text_distance_flags_the_odd_text_out(self):
        from rpt_panel.text_model import peer_text_distance
        d = peer_text_distance(self.texts, self.df)
        cases, peers = d[self.df["is_case"] == 1].dropna(), d[self.df["is_case"] == 0].dropna()
        self.assertGreater(cases.mean(), peers.mean())
        self.assertTrue(((d.dropna() >= 0) & (d.dropna() <= 1)).all())


class PeerZTests(unittest.TestCase):
    def test_loo_baseline_uses_no_role_information(self):
        from rpt_panel.financial_features import peer_relative_z
        df = make_panel(n_clusters=2, peers_per_case=3, years=[2019])
        df["case_role_shuffled"] = df["case_role"]
        z1 = peer_relative_z(df, ["x1"], baseline="loo_all")
        df["case_role"] = "peer"      # roles removed entirely
        z2 = peer_relative_z(df, ["x1"], baseline="loo_all")
        np.testing.assert_allclose(z1["x1_z"].values, z2["x1_z"].values, equal_nan=True)
        # hand check for one row: mean/sd of the other three firms in the cluster-year
        g = df[df["cluster_id"] == "C0"]
        others = g["x1"].iloc[1:]
        expected = (g["x1"].iloc[0] - others.mean()) / others.std(ddof=1)
        self.assertAlmostEqual(z1.loc[g.index[0], "x1_z"] if g.index[0] in z1.index else z1["x1_z"].iloc[0], expected, places=9)

    def test_zero_variance_gives_nan_not_inf(self):
        from rpt_panel.financial_features import peer_relative_z
        df = make_panel(n_clusters=1, peers_per_case=3, years=[2019])
        df["x1"] = 1.0
        z = peer_relative_z(df, ["x1"], baseline="loo_all")
        self.assertTrue(z["x1_z"].isna().all())


class ThresholdAndStressTests(unittest.TestCase):
    def setUp(self):
        self.df = make_panel()
        self.cfg = PanelConfig(n_boot=30, seed=2)
        self.res = modelling.fit_oof(self.df, FEATURES, "logit", self.cfg)

    def test_threshold_meets_target_fpr(self):
        thr = stress_tests.choose_threshold(self.res.scores, self.df["fraud_aaer_label"], 0.05)
        t5 = stress_tests.t5_clean_fpr(self.res.scores, self.df["fraud_aaer_label"], thr, 0.05)
        self.assertTrue(t5["pass"])
        self.assertLessEqual(t5["fpr"], 0.05)

    def test_lead_time_uses_revelation_date(self):
        cases = pd.DataFrame({"case_id": [f"C{i}" for i in range(6)], "role": "case", "revelation_date": "2020-06-30"})
        thr = stress_tests.choose_threshold(self.res.scores, self.df["fraud_aaer_label"], 0.05)
        t3 = stress_tests.t3_lead_time(self.df, self.res.scores, thr, cases)
        self.assertEqual(len(t3), 6)
        flagged = t3[t3["flagged_years"] > 0]
        self.assertTrue((flagged["lead_time_months"] >= 6).all())   # FYE Dec-2019 at the latest -> >= 6 months

    def test_holm_is_monotone_and_bounded(self):
        adj = stress_tests.holm({"a": 0.01, "b": 0.04, "c": 0.5})
        self.assertAlmostEqual(adj["a"], 0.03)
        self.assertLessEqual(adj["b"], adj["c"])
        self.assertLessEqual(max(adj.values()), 1.0)

    def test_ablation_reports_delta_vs_full(self):
        groups = {"L1_financial": ["x1"], "L2_monitoring": ["x2"], "L3_disclosure": ["m"], "controls": ["ln_assets"]}
        tab = modelling.ablation(self.df, groups, "logit", self.cfg)
        self.assertIn("drop_L3_disclosure", set(tab["spec"]))
        self.assertAlmostEqual(float(tab.loc[tab["spec"] == "full", "delta_auc_vs_full"].iloc[0]), 0.0)


if __name__ == "__main__":
    unittest.main()
