"""T4 Fisher test must reject when case firms show MORE persistent material weaknesses than peers."""
import unittest

import numpy as np
import pandas as pd

from rpt_panel import stress_tests as st


class T4DirectionTests(unittest.TestCase):
    def _panel(self, case_rate, peer_rate, n=200, seed=0):
        rng = np.random.default_rng(seed)
        case = pd.DataFrame({"case_role": "case", "cik": [f"c{i}" for i in range(n)], "fiscal_year": 2010,
                             "mw_persistence_2yr": rng.binomial(1, case_rate, n).astype(float)})
        peer = pd.DataFrame({"case_role": "peer", "cik": [f"p{i}" for i in range(n)], "fiscal_year": 2010,
                             "mw_persistence_2yr": rng.binomial(1, peer_rate, n).astype(float)})
        df = pd.concat([case, peer], ignore_index=True)
        for c in ("d_rpt_vagueness", "d_rpt_agency", "d_rpt_fog"):
            df[c] = rng.normal(size=len(df))
        return df

    def test_more_persistent_cases_give_small_p(self):
        out = st.t4_mw_persistence(self._panel(0.4, 0.1))
        p = float(out.loc[out["metric"] == "persistence_rate_case_vs_peer", "p_value"].iloc[0])
        self.assertLess(p, 0.001)

    def test_less_persistent_cases_give_large_p(self):
        out = st.t4_mw_persistence(self._panel(0.1, 0.4))
        p = float(out.loc[out["metric"] == "persistence_rate_case_vs_peer", "p_value"].iloc[0])
        self.assertGreater(p, 0.5)


if __name__ == "__main__":
    unittest.main()
