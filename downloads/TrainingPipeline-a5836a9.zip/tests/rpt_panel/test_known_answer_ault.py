"""Known-answer tests on a real filing: Ault Alliance (CIK 0000896493) FY2018 10-K and 2019 proxy.

The fixture texts were derived once from the raw SEC documents with the dataset
builder's parser (see tests/fixtures/make_ault_fixture.py) and are frozen.
"""
import json
import re
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from rpt_panel import financial_features as ff
from rpt_panel.config import PanelConfig
from rpt_panel.text_features import SectionScorer

FIX = Path(__file__).resolve().parents[1] / "fixtures" / "ault_fy2018"


@unittest.skipUnless((FIX / "expected.json").exists(), "fixture not generated")
class AultKnownAnswerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.expected = json.loads((FIX / "expected.json").read_text(encoding="utf-8"))
        cls.rpt = (FIX / "rpt_disclosure.txt").read_text(encoding="utf-8")
        cls.item1 = (FIX / "item1.txt").read_text(encoding="utf-8")
        cls.scorer = SectionScorer(PanelConfig())

    def test_item13_is_the_body_not_the_table_of_contents(self):
        self.assertEqual(self.expected["statuses"]["item13"], "ok")
        self.assertFalse(self.expected["item13_incorporated_by_reference"])
        self.assertGreater(self.expected["words"]["item13"], 300)
        self.assertIn("Philou Ventures", self.rpt)
        self.assertNotIn("Principal Accountant Fees", self.rpt)

    def test_related_party_note_and_proxy_section_found(self):
        self.assertEqual(self.expected["statuses"]["rp_note"], "ok")
        self.assertEqual(self.expected["statuses"]["proxy_rpt"], "ok")
        self.assertGreater(self.expected["words"]["proxy_rpt"], 300)

    def test_icfr_not_effective_in_fy2018(self):
        icfr = self.expected["icfr"]
        self.assertEqual(icfr["icfr_not_effective"], 1)
        self.assertEqual(icfr["material_weakness_reported"], 1)
        self.assertEqual(icfr["icfr_effective_stated"], 0)

    def test_text_scores_exist_and_are_name_invariant(self):
        base = self.scorer.score(self.rpt)
        self.assertFalse(np.isnan(base["vagueness"]))
        self.assertFalse(np.isnan(base["agency_masking"]))
        self.assertGreater(base["fog"], 10)
        anonymised = re.sub(r"\b(Ault|Horne|Milton|Todd|Philou|Kristine)\b", "Xperson", self.rpt)
        anon = self.scorer.score(anonymised)
        for key in ("vagueness", "agency_masking", "passive_ratio", "relabeling"):
            self.assertAlmostEqual(base[key], anon[key], places=9, msg=key)

    def test_item1_scores_as_baseline(self):
        s = self.scorer.score(self.item1)
        self.assertFalse(np.isnan(s["vagueness"]))
        self.assertGreater(s["words"], 1000)

    def test_layer1_matches_xbrl_as_first_reported(self):
        x17, x18 = self.expected["xbrl_2017"], self.expected["xbrl_2018"]
        df = pd.DataFrame([
            {"cik": "0000896493", "fiscal_year": 2017, **{f"xbrl_{k}": v for k, v in x17.items() if k not in ("cik", "fiscal_year")}},
            {"cik": "0000896493", "fiscal_year": 2018, **{f"xbrl_{k}": v for k, v in x18.items() if k not in ("cik", "fiscal_year")}},
        ])
        l1 = ff.layer1(df).set_index("fiscal_year")
        ecd = (x18["net_income"] - x18["operating_cash_flow"]) / x18["total_assets"]
        self.assertAlmostEqual(l1.loc[2018, "earnings_cash_divergence"], ecd, places=9)
        self.assertAlmostEqual(l1.loc[2018, "accruals"], (x18["net_income"] - x18["operating_cash_flow"]) / x17["total_assets"], places=9)
        self.assertTrue(np.isnan(l1.loc[2017, "accruals"]))            # no lag year
        self.assertEqual(x18["net_income"], -32233881)                 # as first reported, not the restated figure
        ctrl = ff.controls(df).set_index("fiscal_year")
        self.assertAlmostEqual(ctrl.loc[2018, "roa"], x18["net_income"] / x18["total_assets"], places=9)


if __name__ == "__main__":
    unittest.main()
