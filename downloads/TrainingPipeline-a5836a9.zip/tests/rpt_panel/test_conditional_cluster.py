"""Firm-clustered sandwich for the conditional logit: the per-observation scores x_i (y_i - pi_i) must sum to the
model score (zero at the MLE), and the clustered standard errors must be positive and of the same order as the
model-based ones when there is no within-firm correlation."""
from __future__ import annotations

import numpy as np
import pandas as pd

from rpt_panel import inference_stats as inf


def _panel(seed: int = 3, firm_effect: float = 0.0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for s in range(25):
        for f in range(6):
            u = rng.normal(0, firm_effect)
            for t in range(5):
                y = int(f == 0)
                rows.append({"cluster_id": s, "cik": f"{s}_{f}", inf.LABEL: y, "x": 0.8 * y + u + rng.normal(),
                             "leverage": rng.normal(), "roa": rng.normal()})
    return pd.DataFrame(rows)


def test_conditional_probabilities_sum_to_number_of_cases():
    xb = np.array([0.1, -0.3, 1.2, 0.0, 0.5])
    for m in (1, 2, 3):
        assert abs(inf._conditional_probabilities(xb, m).sum() - m) < 1e-9


def test_cluster_se_present_and_positive():
    inf.MIN_COVERAGE = 0
    t = inf.conditional_logit(_panel(), ["x", "leverage", "roa"])
    r = t[t["term"] == "x"].iloc[0]
    assert r["coef"] > 0
    assert r["se_cluster"] > 0 and np.isfinite(r["p_cluster"])
    assert 0.3 < r["se_cluster"] / r["se"] < 3.0
    assert r["n_firms"] == 150


def test_cluster_se_grows_with_firm_effect():
    inf.MIN_COVERAGE = 0
    t0 = inf.conditional_logit(_panel(firm_effect=0.0), ["x"])
    t1 = inf.conditional_logit(_panel(firm_effect=2.0), ["x"])
    ratio0 = t0["se_cluster"].iloc[0] / t0["se"].iloc[0]
    ratio1 = t1["se_cluster"].iloc[0] / t1["se"].iloc[0]
    assert ratio1 > ratio0
