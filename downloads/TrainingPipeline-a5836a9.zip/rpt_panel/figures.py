"""Publication figures. All labels come from the data; no firm names or industry codes are hardcoded."""
from __future__ import annotations

from pathlib import Path
from typing import Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import roc_curve  # noqa: E402

plt.rcParams.update({"figure.dpi": 150, "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def plot_oof_roc(y: pd.Series, scores_by_model: Dict[str, pd.Series], metrics: pd.DataFrame, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(4.5, 4.5))
    for model, s in scores_by_model.items():
        mask = s.notna()
        if y[mask].nunique() < 2:
            continue
        fpr, tpr, _ = roc_curve(y[mask], s[mask])
        row = metrics[metrics["model"] == model]
        auc = float(row["oof_auc"].iloc[0]) if len(row) else np.nan
        ax.plot(fpr, tpr, label=f"{model} (OOF AUC {auc:.2f})")
    ax.plot([0, 1], [0, 1], ls="--", c="grey", lw=0.8)
    ax.set_xlabel("False-positive rate (peer firm-years)")
    ax.set_ylabel("True-positive rate (case firm-years)")
    ax.set_title("Leave-one-cluster-out ROC")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_z_heatmap(X: pd.DataFrame, z_cols: list[str], path: Path) -> None:
    """Case firms' peer-relative z-scores by fiscal year (one panel per case)."""
    cases = X[X["case_role"] == "case"].sort_values(["cluster_id", "fiscal_year"])
    z_cols = [c for c in z_cols if c in cases.columns and cases[c].notna().any()]  # drop items no case reported
    if cases.empty or not z_cols:
        return
    clusters = list(cases["cluster_id"].unique())
    fig, axes = plt.subplots(1, len(clusters), figsize=(2.2 * len(clusters) + 1, 0.4 * len(z_cols) + 1.5), squeeze=False)
    vmax = np.nanmax(np.abs(cases[z_cols].values)) if cases[z_cols].notna().any().any() else 1
    vmax = min(max(vmax, 1), 6)
    for ax, cl in zip(axes[0], clusters):
        sub = cases[cases["cluster_id"] == cl]
        mat = sub[z_cols].T.values.astype(float)
        im = ax.imshow(mat, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
        ax.set_xticks(range(len(sub)))
        ax.set_xticklabels(sub["fiscal_year"].astype(int), rotation=90)
        ax.set_yticks(range(len(z_cols)))
        ax.set_yticklabels([c.replace("_z", "") for c in z_cols] if ax is axes[0][0] else [])
        ax.set_title(str(sub["ticker"].iloc[0]), fontsize=8)
    fig.colorbar(im, ax=axes[0].tolist(), shrink=0.8, label="z vs matched peers (clipped)")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def plot_shap_summary(attribution: pd.DataFrame, path: Path, top_n: int = 12) -> None:
    if attribution.empty:
        return
    pivot = attribution.pivot_table(index="feature", columns="model", values="mean_abs_shap", aggfunc="mean")
    pivot = pivot.loc[pivot.mean(axis=1).sort_values(ascending=False).index[:top_n]]
    fig, ax = plt.subplots(figsize=(5.5, 0.35 * len(pivot) + 1))
    pivot.iloc[::-1].plot.barh(ax=ax, width=0.8)
    ax.set_xlabel("mean |SHAP| (out-of-fold)")
    ax.set_ylabel("")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_lead_time(t3: pd.DataFrame, path: Path) -> None:
    if t3.empty:
        return
    fig, ax = plt.subplots(figsize=(5, 0.5 * len(t3) + 1))
    y = np.arange(len(t3))
    vals = t3["lead_time_months"].fillna(0).values
    ax.barh(y, vals, color=["tab:blue" if f > 0 else "lightgrey" for f in t3["flagged_years"]])
    ax.set_yticks(y)
    ax.set_yticklabels(t3["ticker"])
    ax.set_xlabel("months from first out-of-fold alert to first public revelation (grey = never flagged)")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_case_waterfall(shap_row: pd.Series, score: float, title: str, path: Path, top_n: int = 10) -> None:
    """Local explanation of one firm-year: the top-n out-of-fold SHAP contributions to its risk score."""
    vals = shap_row.dropna()
    if vals.empty:
        return
    top = vals.reindex(vals.abs().sort_values(ascending=False).index[:top_n])[::-1]
    fig, ax = plt.subplots(figsize=(5.5, 0.35 * len(top) + 1.2))
    ax.barh(range(len(top)), top.values, color=["tab:red" if v > 0 else "tab:blue" for v in top.values])
    ax.set_yticks(range(len(top)))
    ax.set_yticklabels(top.index)
    ax.axvline(0, c="black", lw=0.8)
    ax.set_xlabel("SHAP contribution to risk score (log-odds units for logit)")
    ax.set_title(f"{title}: OOF risk score {score:.2f}", fontsize=9)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_oof_scores_by_event_time(X: pd.DataFrame, scores_by_model: Dict[str, pd.Series], threshold: float, path: Path) -> None:
    """Out-of-fold risk scores of each case firm against event time, with the peer distribution and alert threshold."""
    models = list(scores_by_model)
    fig, axes = plt.subplots(1, len(models), figsize=(3.6 * len(models), 3.2), squeeze=False, sharey=True)
    for ax, model in zip(axes[0], models):
        s = scores_by_model[model]
        peers = X[X["case_role"] == "peer"]
        ax.scatter(peers["event_time"] + np.random.default_rng(0).uniform(-0.15, 0.15, len(peers)), s.reindex(peers.index), s=8, c="lightgrey", label="peers")
        for cik, firm in X[X["case_role"] == "case"].groupby("cik"):
            firm = firm.sort_values("event_time")
            tick = firm["ticker"].iloc[0] if "ticker" in firm else None
            label = tick if isinstance(tick, str) and tick.strip() else str(firm["cluster_id"].iloc[0])
            ax.plot(firm["event_time"], s.reindex(firm.index), marker="o", ms=4, lw=1, label=label)
        if model == models[0]:
            ax.axhline(threshold, ls="--", c="black", lw=0.8, label=f"alert threshold {threshold:.2f}")
        ax.set_title(model, fontsize=9)
        ax.set_xlabel("years to revelation")
    axes[0][0].set_ylabel("out-of-fold risk score")
    axes[0][-1].legend(frameon=False, fontsize=7, loc="upper left")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_calibration(y: pd.Series, scores: pd.Series, threshold: float, path: Path, n_bins: int = 5) -> None:
    """Reliability curve of the alert score plus the score distributions by class."""
    mask = scores.notna()
    y, s = y[mask].astype(int), scores[mask]
    if y.nunique() < 2:
        return
    fig, axes = plt.subplots(1, 2, figsize=(7.5, 3.3))
    bins = np.quantile(s, np.linspace(0, 1, n_bins + 1))
    bins[0], bins[-1] = -0.001, 1.001
    cut = pd.cut(s, np.unique(bins), include_lowest=True)
    grp = pd.DataFrame({"y": y, "s": s}).groupby(cut, observed=True)
    axes[0].plot(grp["s"].mean(), grp["y"].mean(), marker="o")
    axes[0].plot([0, 1], [0, 1], ls="--", c="grey", lw=0.8)
    axes[0].set_xlabel("mean alert score in bin")
    axes[0].set_ylabel("observed share of case firm-years")
    axes[0].set_title("Reliability (quantile bins)", fontsize=9)
    axes[1].hist(s[y == 0], bins=20, range=(0, 1), alpha=0.6, label="peer firm-years", color="tab:blue")
    axes[1].hist(s[y == 1], bins=20, range=(0, 1), alpha=0.6, label="case firm-years", color="tab:red")
    axes[1].axvline(threshold, ls="--", c="black", lw=0.8, label=f"threshold {threshold:.2f}")
    axes[1].set_xlabel("out-of-fold alert score")
    axes[1].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_drift(X: pd.DataFrame, path: Path, cols=("rpt_vagueness", "rpt_agency_masking", "rpt_fog")) -> None:
    present = [c for c in cols if c in X.columns]
    if not present or "event_time" not in X.columns:
        return
    fig, axes = plt.subplots(1, len(present), figsize=(3.5 * len(present), 3), squeeze=False)
    for ax, col in zip(axes[0], present):
        for role, color in (("case", "tab:red"), ("peer", "tab:blue")):
            g = X[X["case_role"] == role].groupby("event_time")[col]
            m, se = g.mean(), g.std(ddof=1) / np.sqrt(g.count().clip(lower=1))
            ax.errorbar(m.index, m.values, yerr=se.values, label=role, color=color, marker="o", ms=3, capsize=2, lw=1)
        ax.axvline(0, ls="--", c="grey", lw=0.8)
        ax.set_title(col.replace("rpt_", "RPT "), fontsize=9)
        ax.set_xlabel("years to revelation")
    axes[0][0].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)
