"""Firm-year panel selection: one row per primary 10-K, case/peer clusters, training window."""
from __future__ import annotations

import pandas as pd

from .config import PanelConfig
from .data_access import ANNUAL_FORMS

KEY = ["cik", "fiscal_year"]


def select_primary_filings(master: pd.DataFrame, cfg: PanelConfig) -> pd.DataFrame:
    """Keep the first original annual report per (cik, fiscal_year) inside the year range."""
    df = master.copy()
    df = df[df["form"].isin(ANNUAL_FORMS)]
    df = df[df["is_primary_filing"].fillna(0).astype(int) == 1]
    df = df[df["fiscal_year"].between(cfg.start_year, cfg.end_year)]
    df["fiscal_year"] = df["fiscal_year"].astype(int)
    duplicates = df.duplicated(KEY, keep=False)
    if duplicates.any():
        raise ValueError(f"master_panel has {int(duplicates.sum())} duplicate primary (cik, fiscal_year) rows")
    return df.sort_values(KEY).reset_index(drop=True)


def attach_cluster(df: pd.DataFrame) -> pd.DataFrame:
    """cluster_id = the case a firm belongs to (its own case_id, or the matched case for a peer).

    Rows without a cluster (firms not in the cases file) are dropped.
    ``fraud_aaer_label`` becomes float with NaN where the builder left it unknown.
    """
    out = df.copy()
    role = out.get("case_role", pd.Series("", index=out.index)).fillna("").astype(str)
    case_id = out.get("case_id", pd.Series("", index=out.index)).fillna("").astype(str)
    matched = out.get("matched_case_id", pd.Series("", index=out.index)).fillna("").astype(str)
    out["case_role"] = role
    out["cluster_id"] = case_id.where(role == "case", matched)
    out = out[out["cluster_id"] != ""].copy()
    out["is_case"] = (out["case_role"] == "case").astype(int)
    out["fraud_aaer_label"] = pd.to_numeric(out["fraud_aaer_label"], errors="coerce")
    out["event_time"] = pd.to_numeric(out["event_time"], errors="coerce")
    return out.reset_index(drop=True)


def training_mask(df: pd.DataFrame, cfg: PanelConfig) -> pd.Series:
    """Rows used to fit and score models: the pre-revelation window of every cluster.

    Both cases and their peers are restricted to event_time in [-window, -1], so the
    comparison is aligned in event time; post-revelation years never enter training.
    Rows whose label is unknown (missing revelation date) are excluded.
    """
    return (
        df["fraud_aaer_label"].notna()
        & df["event_time"].notna()
        & df["event_time"].between(-cfg.window, -1)
    )


def panel_summary(df: pd.DataFrame, cfg: PanelConfig) -> dict:
    train = df[training_mask(df, cfg)]
    return {
        "firm_years": int(len(df)),
        "firms": int(df["cik"].nunique()),
        "clusters": int(df["cluster_id"].nunique()),
        "cases": int(df.loc[df["is_case"] == 1, "cik"].nunique()),
        "training_firm_years": int(len(train)),
        "training_positive": int(train["fraud_aaer_label"].sum()),
        "fiscal_years": sorted(int(y) for y in df["fiscal_year"].unique()),
        "unknown_label_rows": int(df["fraud_aaer_label"].isna().sum()),
    }
