"""Rule-based coding of Layer-2 governance variables from the raw 10-K and DEF 14A texts.

Produces the same columns as the hand-collected ``governance_manual.csv`` so the two
sources are interchangeable in ``governance_features.layer2``:

    big4                 1 if the audit report is signed by Deloitte, EY, KPMG or PwC
    auditor_change       1 if the signing auditor differs from the previous fiscal year's
    going_concern_opinion 1 if the audit report raises substantial doubt about going concern
    ceo_duality          1 if the CEO also chairs the board (proxy statement), 0 if the roles are
                         stated to be separate, NaN when the proxy says neither
    board_indep          share of directors the board has determined independent ("six of our
                         eight directors are independent"); NaN when no such count is stated
    ac_indep             1 when the proxy states every audit-committee member is independent

Every value is traceable: ``*_evidence`` columns keep the matched passage. Reliability
is checked against a 10 % hand-coded sample (closure plan M2); until then these are
*rule-based* codes and the thesis must say so.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)

BIG4 = {
    "deloitte": "Deloitte & Touche",
    "ernst & young": "Ernst & Young",
    "ernst and young": "Ernst & Young",
    "kpmg": "KPMG",
    "pricewaterhousecoopers": "PricewaterhouseCoopers",
    "pricewaterhouse coopers": "PricewaterhouseCoopers",
}
KNOWN_FIRMS = [
    "Deloitte & Touche", "Ernst & Young", "KPMG", "PricewaterhouseCoopers", "Grant Thornton", "BDO USA", "BDO Seidman",
    "RSM US", "McGladrey", "Marcum", "Moss Adams", "Crowe", "Baker Tilly", "CohnReznick", "EisnerAmper", "Friedman",
    "MaloneBailey", "WithumSmith", "Withum", "BF Borgers", "Cherry Bekaert", "Plante & Moran", "Plante Moran", "Dixon Hughes",
    "Mayer Hoffman", "Squar Milner", "Haskell & White", "Weinberg", "Marcum Bernstein", "Kabani", "Sherb", "MSPC",
    "Frazer Frost", "Moore Stephens", "UHY", "Hein & Associates", "Whitley Penn", "Weaver", "Rosenberg Rich Baker Berman",
    "RBSM", "Turner, Stone", "Sadler, Gibb", "Haynie", "Anton & Chia", "GBH CPAs", "Paritz", "Liggett & Webb", "D. Brooks",
    "Boyle CPA", "Fruci", "M&K CPAS", "Pinnacle", "Salberg", "Daszkal Bolton", "Hall & Company", "Burr Pilger Mayer",
    "SingerLewak", "Armanino", "Macias Gini", "Wipfli", "Schneider Downs", "Elliott Davis", "Dixon Hughes Goodman", "FORVIS",
    "BKD", "LBMC", "HoganTaylor", "Carr, Riggs & Ingram", "Yount, Hyde & Barbour", "Crowe Horwath", "Ernst & Young LLP",
]
AUDIT_REPORT_HEAD = re.compile(r"report\s+of\s+independent\s+registered\s+public\s+accounting\s+firm", re.I)
SIGNATURE = re.compile(r"/s/\s*([A-Z][A-Za-z&.,'\- ]{2,70}?(?:LLP|LLC|L\.L\.P\.|P\.C\.|PC|CPAs|CPA|Ltd\.?|Inc\.?|PLLC|S\.C\.|Co\.))", re.M)
GOING_CONCERN = re.compile(
    r"(raise[sd]?|exists?)\s+substantial\s+doubt\s+(?:about|as\s+to|regarding)\s+(?:the\s+company'?s?|its|our|their|the\s+partnership'?s?|[A-Z][\w.,& ]{0,40}?'?s?)\s+ability\s+to\s+continue\s+as\s+a\s+going\s+concern",
    re.I,
)
NUMBER_WORDS = {w: i for i, w in enumerate(
    ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
     "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"])}
NUM = r"(\d{1,2}|" + "|".join(NUMBER_WORDS) + r")"
BOARD_INDEP = re.compile(
    NUM + r"\s+(?:\(\d+\)\s+)?of\s+(?:the|our|its)\s+(?:company'?s\s+)?(?:current\s+|incumbent\s+)?" + NUM +
    r"\s+(?:current\s+|incumbent\s+|sitting\s+)?(?:directors|board\s+members|members\s+of\s+(?:the|our)\s+board(?:\s+of\s+directors)?)"
    r"[^.;]{0,80}?\b(?:is|are|were|was|qualif(?:y|ies)\s+as|to\s+be|as)\s+(?:an\s+)?[\"“]?independent", re.I)
DUALITY_POS = [
    re.compile(r"serv(?:es|ed|ing)\s+as\s+(?:both\s+)?(?:our\s+|the\s+)?(?:executive\s+)?chair(?:man|person|woman)?\s+(?:of\s+the\s+board\s+)?and\s+(?:as\s+)?(?:our\s+|the\s+)?(?:president\s+and\s+)?chief\s+executive\s+officer", re.I),
    re.compile(r"(?:combin(?:e|ed|es|ing)|consolidat(?:e|ed|es))\s+the\s+(?:roles|positions|offices)\s+of\s+(?:the\s+)?(?:chair(?:man|person)?(?:\s+of\s+the\s+board)?)\s+and\s+(?:the\s+)?(?:chief\s+executive\s+officer|ceo)", re.I),
    re.compile(r"(?:roles|positions|offices)\s+of\s+(?:the\s+)?chair(?:man|person)?(?:\s+of\s+the\s+board)?\s+and\s+(?:the\s+)?(?:chief\s+executive\s+officer|ceo)\s+(?:are|is|be|remain|have\s+been)\s+(?:currently\s+)?(?:held\s+by\s+(?:the\s+same|one)\s+(?:person|individual)|combined)", re.I),
    re.compile(r"\b(?:chairman|chair)\s*(?:of\s+the\s+board)?,?\s*(?:president\s+and\s+|president,\s+)?(?:and\s+)?chief\s+executive\s+officer\b", re.I),  # title use, counted
]
DUALITY_NEG = [
    re.compile(r"separat(?:e|es|ed|ing|ion\s+of)\s+(?:the\s+)?(?:roles|positions|offices|functions)\s+of\s+(?:the\s+)?(?:chair(?:man|person)?(?:\s+of\s+the\s+board)?|board\s+chair)\s+and\s+(?:the\s+)?(?:chief\s+executive\s+officer|ceo|president)", re.I),
    re.compile(r"(?:roles|positions|offices)\s+of\s+(?:the\s+)?chair(?:man|person)?(?:\s+of\s+the\s+board)?\s+and\s+(?:the\s+)?(?:chief\s+executive\s+officer|ceo)\s+(?:are|be|remain|have\s+been)\s+(?:currently\s+)?(?:separate|held\s+by\s+(?:two\s+)?(?:different|separate)\s+(?:persons|individuals|people))", re.I),
    re.compile(r"(?:independent|non-executive)\s+chair(?:man|person|woman)?\s+of\s+the\s+board", re.I),
    re.compile(r"chair(?:man|person)?\s+of\s+the\s+board\s+is\s+an?\s+independent\s+director", re.I),
]
OTHER_COMPANY = re.compile(r"\s+(?:of|at|for)\s+(?!the\s+Company\b|our\b|the\s+Board\b|[A-Z][A-Za-z]*\s+(?:Inc|Corp|Corporation|Company|Holdings|Ltd|Group|LLC)\b(?=[^.]{0,20}\(the\s+[\"“]?Company))[A-Z]")
BOARD_SIZE = re.compile(r"board(?:\s+of\s+directors)?\s+(?:currently\s+|presently\s+|now\s+)?(?:consists?\s+of|is\s+comprised\s+of|comprises|is\s+composed\s+of|has|includes)\s+(?:a\s+total\s+of\s+)?" + NUM + r"\s+(?:\(\d+\)\s+)?(?:members|directors|persons|individuals)", re.I)
ALL_BUT = re.compile(r"(?:all|each)\s+of\s+(?:our|the|its)\s+(?:current\s+)?directors(?:\s+and\s+(?:director\s+)?nominees)?,?\s+(?:other\s+than|except(?:\s+for)?|with\s+the\s+exception\s+of)\s+((?:(?:Mr|Ms|Mrs|Dr|Messrs)\.?\s*[A-Z][\w'\-]+(?:,?\s+(?:and\s+)?(?:Mr|Ms|Mrs|Dr)\.?\s*[A-Z][\w'\-]+)*|our\s+(?:chief\s+executive\s+officer|ceo|chairman|president|founder)(?:\s+and\s+\w+(?:\s+\w+)?)?))[^.;]{0,60}?\b(?:is|are|qualif(?:y|ies)\s+as)\s+(?:an\s+)?[\"“]?independent", re.I)
CONDITIONAL = re.compile(r"(?:whether\s+to|whether\s+or\s+not\s+to|separate\s+or|combine\s+or|or\s+to|may|might|could|should|to\s+determine|flexibility\s+to|decision\s+to|right\s+to|option\s+to|if\s+it|periodically)\s*$", re.I)
ROLE_TALK = re.compile(r"(?:roles?|positions?|offices?|functions?|titles?)\s+of\s+(?:the\s+|our\s+)?$|(?:the|our)\s+$", re.I)
NAME = r"(?:(?:Messrs|Mr|Ms|Mrs|Dr|Mses)\.?\s*)?[A-Z][\w'\-]+(?:\s+[A-Z]\.)?(?:\s+(?:de\s+|van\s+|von\s+)?[A-Z][\w'\-]+(?:,\s*(?:Jr|Sr|II|III|IV)\.?)?)?"
SEP = r"(?:,\s*(?:and\s+)?|\s+and\s+|;\s*)"
NAME_LIST = re.compile(
    r"(?i:(?:board|directors)\s+(?:of\s+directors\s+)?has\s+(?:affirmatively\s+)?determined\s+that\s+(?:each\s+of\s+|all\s+of\s+)?(?:the\s+following\s+(?:directors|nominees|individuals)[^:]{0,80}:\s*)?)"
    r"(" + NAME + r"(?:" + SEP + NAME + r")*)"
    r"(?i:\s+(?:is|are|each\s+is|qualif(?:y|ies)\s+as|(?:is|are)\s+each)\s+(?:an\s+)?[\"“]?independent)")
NEG_INDEP_CONTEXT = re.compile(r"not\s+(?:an\s+)?independent|non-?independent", re.I)
AC_INDEP = re.compile(
    r"(?:each|all|every)\s+(?:of\s+the\s+)?(?:current\s+)?members?\s+of\s+(?:the|our)\s+audit\s+(?:and\s+finance\s+|and\s+risk\s+)?committee\s+"
    r"(?:is|are|meets?|satisf(?:y|ies)|qualif(?:y|ies)\s+as)\s+(?:an\s+)?(?:[\"“]?independent|the\s+independence)", re.I)
AC_INDEP_ALT = re.compile(
    r"audit\s+(?:and\s+finance\s+|and\s+risk\s+)?committee[^.;]{0,120}?(?:is\s+)?(?:composed|comprised|consists?|made\s+up)\s+(?:entirely|solely|exclusively|wholly)\s+of\s+(?:[\"“]?independent|non-employee,?\s+independent|directors\s+who\s+are\s+independent)"
    r"|all\s+(?:of\s+)?(?:the\s+|our\s+)?(?:current\s+)?members\s+of\s+(?:the|our)\s+audit\s+committee\s+(?:are|were|meet|satisfy|qualify\s+as)\s+(?:[\"“]?independent|the\s+independence)"
    r"|each\s+(?:director|member)\s+(?:who\s+)?serv(?:es|ing)\s+on\s+(?:the|our)\s+audit\s+committee\s+(?:is|qualifies\s+as|meets)\s+(?:an\s+)?(?:[\"“]?independent|the\s+independence)"
    r"|audit\s+committee[^.;]{0,80}?(?:all|each)\s+of\s+whom\s+(?:is|are|the\s+board\s+has\s+determined\s+(?:is|are|to\s+be))\s+(?:an\s+)?[\"“]?independent", re.I)
AC_NOT_INDEP = re.compile(r"(?:is|are)\s+not\s+(?:an\s+)?independent[^.]{0,80}audit\s+committee|audit\s+committee[^.]{0,120}(?:is|are)\s+not\s+(?:an\s+)?independent", re.I)


def _num(token: str) -> Optional[int]:
    token = token.lower()
    if token.isdigit():
        return int(token)
    return NUMBER_WORDS.get(token)


def _snippet(text: str, m: re.Match, pad: int = 80) -> str:
    return re.sub(r"\s+", " ", text[max(0, m.start() - pad): m.end() + pad]).strip()


def audit_report_window(text: str) -> str:
    """Text from the first audit-report heading to the signature that follows it (or 15k chars)."""
    heads = list(AUDIT_REPORT_HEAD.finditer(text))
    if not heads:
        return ""
    # Prefer the heading that is followed by a signature (the TOC entry has none nearby).
    for h in heads:
        chunk = text[h.start(): h.start() + 15000]
        sig = SIGNATURE.search(chunk)
        if sig:
            return chunk[: sig.end()]
    return text[heads[-1].start(): heads[-1].start() + 15000]


def auditor(text: str) -> tuple[str, str]:
    """(normalised auditor name, evidence) from the audit report signature; '' when not found."""
    window = audit_report_window(text)
    candidates = [window] if window else []
    candidates.append(text)
    for chunk in candidates:
        for sig in SIGNATURE.finditer(chunk):
            name = re.sub(r"\s+", " ", sig.group(1)).strip(" ,.")
            low = name.lower()
            if any(k in low for k in ("chief", "officer", "director", "president", "secretary", "treasurer", "attorney")):
                continue
            for key, canon in BIG4.items():
                if key in low:
                    return canon, _snippet(chunk, sig, 40)
            for firm in KNOWN_FIRMS:
                if firm.lower() in low:
                    return firm, _snippet(chunk, sig, 40)
            if re.search(r"LLP|LLC|P\.C\.|CPA", name):
                return name, _snippet(chunk, sig, 40)
    if window:  # unsigned text copy: look for a known firm name inside the report
        low = window.lower()
        for key, canon in BIG4.items():
            if key in low:
                return canon, "name inside audit report (no /s/ signature)"
        for firm in KNOWN_FIRMS:
            if firm.lower() in low:
                return firm, "name inside audit report (no /s/ signature)"
    return "", ""


MODIFIED_OPINION = re.compile(
    r"\b(qualified\s+opinion|except\s+for\s+the\s+(?:effects?|matters?)|adverse\s+opinion|disclaimer\s+of\s+opinion|"
    r"(?:do|did)\s+not\s+express\s+an\s+opinion|(?:we\s+)?were\s+(?:not\s+able|unable)\s+to\s+(?:obtain|form)\s+(?:sufficient|an\s+opinion)|"
    r"do\s+not\s+present\s+fairly|not\s+presented\s+fairly)\b", re.I)
INTERNAL_CONTROL_NEAR = re.compile(r"internal\s+control|control\s+over\s+financial\s+reporting|attestation", re.I)
# Not a modified opinion: the paragraph on another auditor's prior-year statements ("we were not engaged to audit ...
# and accordingly do not express an opinion or any other form of assurance"), and the boilerplate negation
# ("did not contain an adverse opinion or disclaimer of opinion and were not qualified").
NOT_MODIFIED_CONTEXT = re.compile(
    r"any\s+other\s+form\s+of\s+assurance|any\s+other\s+assurance|other\s+than\s+with\s+respect\s+to|were\s+not\s+engaged\s+to|"
    r"other\s+auditors?|predecessor|did\s+not\s+contain\s+an\s+adverse|not\s+qualified\s+or\s+modified|retrospective|revision\s+adjustments", re.I)


def modified_opinion(text: str) -> tuple[float, str]:
    """1 if the audit report on the financial statements is qualified, adverse or a disclaimer (the design's
    'modified' opinion). An adverse opinion on internal control over financial reporting is excluded: it is the
    ICFR signal, not the opinion on the accounts. Going-concern language is coded separately."""
    window = audit_report_window(text)
    if not window:
        return np.nan, ""
    for m in MODIFIED_OPINION.finditer(window):
        around = window[max(0, m.start() - 250): m.end() + 250]
        if INTERNAL_CONTROL_NEAR.search(around) or NOT_MODIFIED_CONTEXT.search(around):
            continue
        return 1.0, _snippet(window, m)
    return 0.0, ""


def going_concern(text: str) -> tuple[float, str]:
    window = audit_report_window(text)
    m = GOING_CONCERN.search(window) if window else None
    if m:
        return 1.0, _snippet(window, m)
    if window:
        return 0.0, ""
    return np.nan, ""


def ceo_duality(proxy: str) -> tuple[float, str]:
    if not proxy:
        return np.nan, ""
    pos_hits = [m for p in DUALITY_POS[:3] for m in p.finditer(proxy) if not CONDITIONAL.search(proxy[max(0, m.start() - 60): m.start()])]
    title_hits = [m for m in DUALITY_POS[3].finditer(proxy)
                  if not OTHER_COMPANY.match(proxy, m.end()) and not ROLE_TALK.search(proxy[max(0, m.start() - 30): m.start()])]
    neg_hits = [m for p in DUALITY_NEG for m in p.finditer(proxy) if not CONDITIONAL.search(proxy[max(0, m.start() - 60): m.start()])]
    pos = len(pos_hits) + (1 if len(title_hits) >= 2 else 0)
    neg = len(neg_hits)
    if pos and pos > neg:
        m = pos_hits[0] if pos_hits else title_hits[0]
        return 1.0, _snippet(proxy, m)
    if neg and neg >= pos:
        return 0.0, _snippet(proxy, neg_hits[0])
    return np.nan, ""


def board_indep(proxy: str) -> tuple[float, str]:
    if not proxy:
        return np.nan, ""
    best = None
    for m in BOARD_INDEP.finditer(proxy):
        n, d = _num(m.group(1)), _num(m.group(2))
        if n is None or d is None or d == 0 or n > d or d < 3 or d > 20:
            continue
        ratio = n / d
        if best is None or ratio > best[0]:
            best = (ratio, _snippet(proxy, m))
    if best:
        return best
    size = None
    for m in BOARD_SIZE.finditer(proxy):
        d = _num(m.group(1))
        if d and 3 <= d <= 20:
            size = d
            break
    if size:
        for m in NAME_LIST.finditer(proxy):
            if NEG_INDEP_CONTEXT.search(proxy[m.end() - 30: m.end() + 20]):
                continue
            n = len([x for x in re.split(SEP, m.group(1)) if x.strip()])
            if 1 <= n <= size:
                return n / size, _snippet(proxy, m)
    m = ALL_BUT.search(proxy)
    if m and size:
        names = m.group(1)
        excepted = max(1, len(re.findall(r"(?:Mr|Ms|Mrs|Dr)\.?\s*[A-Z]", names)) or (1 + names.lower().count(" and ")))
        if excepted < size:
            return (size - excepted) / size, _snippet(proxy, m)
    return np.nan, ""


def ac_indep(proxy: str) -> tuple[float, str]:
    if not proxy:
        return np.nan, ""
    if AC_NOT_INDEP.search(proxy):
        return 0.0, _snippet(proxy, AC_NOT_INDEP.search(proxy))
    m = AC_INDEP.search(proxy) or AC_INDEP_ALT.search(proxy)
    if m:
        return 1.0, _snippet(proxy, m)
    return np.nan, ""


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def _proxy_links(local_dir: Path) -> dict:
    """(cik, fiscal_year) -> proxy accession from scripts/fetch_all_proxies.py, when that file exists."""
    path = Path(local_dir) / "proxy_links.csv"
    if not path.exists():
        return {}
    links = pd.read_csv(path, dtype=str, keep_default_na=False)
    links["cik"] = links["cik"].str.zfill(10)
    return {(c, int(float(y))): a for c, y, a in zip(links["cik"], links["fiscal_year"], links["proxy_accession_number"]) if a}


def code_panel(local_dir: Path, panel: pd.DataFrame) -> pd.DataFrame:
    """One row per (cik, fiscal_year) of ``panel`` (primary filings; needs accession_number, year,
    extract_proxy_accession_number). A proxy linked by ``proxy_links.csv`` (every-year fetch) is used when the
    builder itself did not fetch one."""
    local_dir = Path(local_dir)
    links = _proxy_links(local_dir)
    rows = []
    for _, r in panel.sort_values(["cik", "fiscal_year"]).iterrows():
        cik = str(r["cik"]).zfill(10)
        year = str(int(float(r.get("year", r["fiscal_year"]))))
        filing = _read(local_dir / "raw" / "filings" / cik / year / str(r["accession_number"]) / "filing.txt")
        proxy_acc = str(r.get("extract_proxy_accession_number", "") or "")
        if not proxy_acc or proxy_acc == "nan":
            proxy_acc = links.get((cik, int(r["fiscal_year"])), "")
        proxy = _read(local_dir / "raw" / "proxies" / cik / proxy_acc / "proxy.txt") if proxy_acc and proxy_acc != "nan" else ""
        name, aud_ev = auditor(filing)
        gc, gc_ev = going_concern(filing)
        dual, dual_ev = ceo_duality(proxy)
        bi, bi_ev = board_indep(proxy)
        ac, ac_ev = ac_indep(proxy)
        rows.append({
            "cik": cik, "fiscal_year": int(r["fiscal_year"]),
            "auditor_name": name, "big4": (1.0 if name in set(BIG4.values()) else (0.0 if name else np.nan)),
            "auditor_evidence": aud_ev,
            "going_concern_opinion": gc, "going_concern_evidence": gc_ev,
            "ceo_duality": dual, "ceo_duality_evidence": dual_ev,
            "board_indep": bi, "board_indep_evidence": bi_ev,
            "ac_indep": ac, "ac_indep_evidence": ac_ev,
            "proxy_accession": proxy_acc if proxy else "",
            "source": "rule_based",
        })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    prev = out.groupby("cik")["auditor_name"].shift(1)
    prev_year = out.groupby("cik")["fiscal_year"].shift(1)
    consecutive = (out["fiscal_year"] - prev_year) == 1
    known = (out["auditor_name"] != "") & prev.fillna("").ne("") & consecutive
    out["auditor_change"] = np.where(known, (out["auditor_name"] != prev).astype(float), np.nan)
    return out


def coverage(table: pd.DataFrame) -> dict:
    cols = ["big4", "auditor_change", "going_concern_opinion", "ceo_duality", "board_indep", "ac_indep"]
    return {c: float(table[c].notna().mean()) for c in cols if c in table}
