"""Layer 3 (concealment) features from related-party text, with Item 1 as the specificity baseline.

Scores reuse the validated lexicon modules in ``nlp/`` (Li-style vagueness
composite, Halliday SFL agency masking, Gunning Fog). Text below the minimum
length yields NaN, never 0. Drift features use only earlier years.
"""
from __future__ import annotations

import logging
import re
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from core.config import Config
from nlp.readability import ReadabilityAnalyser
from nlp.sfl_analyser import SFLAnalyser
from nlp.vagueness_scorer import VaguenessScorer

from .config import PanelConfig
from .data_access import read_section

LOGGER = logging.getLogger(__name__)
KEY = ["cik", "fiscal_year"]
SECTION_COLUMNS = (
    "vagueness", "relabeling", "indeterminate_ratio", "transparency", "red_flag_ratio",
    "agency_masking", "passive_ratio", "relational_ratio", "named_role_mentions",
    "fog", "avg_sentence_len", "words",
)


def _word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z][A-Za-z'-]*", text))


class SectionScorer:
    def __init__(self, cfg: PanelConfig):
        nlp_cfg = Config()
        self.vagueness = VaguenessScorer(nlp_cfg)
        self.sfl = SFLAnalyser(nlp_cfg)
        self.readability = ReadabilityAnalyser(nlp_cfg)
        self.min_words = cfg.min_text_words

    def score(self, text: str) -> Dict[str, float]:
        words = _word_count(text)
        if words < self.min_words:
            return {col: np.nan for col in SECTION_COLUMNS} | {"words": words}
        v = self.vagueness.score(text)
        s = self.sfl.analyse(text)
        r = self.readability.analyse(text)
        return {
            "vagueness": v["vagueness_score"],
            "relabeling": v["categorical_relabeling"],
            "indeterminate_ratio": v["indeterminate_ratio"],
            "transparency": v["transparency_score"],
            "red_flag_ratio": v["red_flag_keyword_ratio"],
            "agency_masking": s["agency_masking_score"],
            "passive_ratio": s["passive_voice_ratio"],
            "relational_ratio": s["relational_process_ratio"],
            "named_role_mentions": s["named_executive_mentions"],
            "fog": r.get("fog_index", np.nan),
            "avg_sentence_len": r.get("avg_sentence_length", np.nan),
            "words": words,
        }


def related_party_text(local_dir, row: pd.Series, min_words: int) -> Tuple[str, str]:
    """(text, source). Item 13 body or proxy section, plus the RP note when it exists."""
    rpt = read_section(local_dir, row, "rpt_disclosure")
    source = str(row.get("rpt_text_source") or row.get("extract_rpt_text_source") or "none")
    note = read_section(local_dir, row, "rp_note")
    if _word_count(rpt) < min_words:
        rpt, source = "", "none"
    if _word_count(note) >= min_words:
        rpt = (rpt + "\n\n" + note).strip()
        source = source if source != "none" else "rp_note"
    return rpt, source


def score_sections(df: pd.DataFrame, cfg: PanelConfig) -> Tuple[pd.DataFrame, Dict[tuple, str]]:
    """Per firm-year scores for the related-party text (``rpt_*``) and Item 1 (``item1_*``).

    Returns the score frame (keyed on cik, fiscal_year) and the RPT texts, which
    ``drift_features`` needs for year-on-year boilerplate similarity.
    """
    scorer = SectionScorer(cfg)
    rows = []
    texts: Dict[tuple, str] = {}
    for _, row in df.iterrows():
        rpt_text, source = related_party_text(cfg.local_dir, row, cfg.min_text_words)
        item1_text = read_section(cfg.local_dir, row, "item1")
        key = (row["cik"], int(row["fiscal_year"]))
        texts[key] = rpt_text
        record = {"cik": row["cik"], "fiscal_year": int(row["fiscal_year"]), "rpt_source": source}
        record.update({f"rpt_{k}": v for k, v in scorer.score(rpt_text).items()})
        record.update({f"item1_{k}": v for k, v in scorer.score(item1_text).items()})
        rows.append(record)
    out = pd.DataFrame(rows)
    out["rpt_text_available"] = out["rpt_vagueness"].notna().astype(int)
    out["item1_text_available"] = out["item1_vagueness"].notna().astype(int)
    # Specificity gap used by T1: vagueness engineered into the RPT section vs. firm-wide style.
    out["spec_gap_vagueness"] = out["rpt_vagueness"] - out["item1_vagueness"]
    out["spec_gap_agency"] = out["rpt_agency_masking"] - out["item1_agency_masking"]
    LOGGER.info("Scored %s firm-years; RPT text available for %s", len(out), int(out["rpt_text_available"].sum()))
    return out, texts


def drift_features(scores: pd.DataFrame, texts: Dict[tuple, str], cfg: PanelConfig) -> pd.DataFrame:
    """Lag-only year-on-year changes. A value at year t uses only year t-1 of the same firm."""
    scorer = VaguenessScorer(Config())
    df = scores.sort_values(KEY).copy()
    prev = df.groupby("cik")[["fiscal_year", "rpt_vagueness", "rpt_fog", "rpt_agency_masking", "rpt_words"]].shift(1)
    consecutive = (df["fiscal_year"] - prev["fiscal_year"]) == 1
    df["d_rpt_vagueness"] = (df["rpt_vagueness"] - prev["rpt_vagueness"]).where(consecutive)
    df["d_rpt_fog"] = (df["rpt_fog"] - prev["rpt_fog"]).where(consecutive)
    df["d_rpt_agency"] = (df["rpt_agency_masking"] - prev["rpt_agency_masking"]).where(consecutive)
    df["d_rpt_words_pct"] = ((df["rpt_words"] - prev["rpt_words"]) / prev["rpt_words"].replace(0, np.nan)).where(consecutive)
    sims = []
    for (cik, fy), ok in zip(zip(df["cik"], df["fiscal_year"]), consecutive):
        cur, before = texts.get((cik, fy), ""), texts.get((cik, fy - 1), "")
        sims.append(scorer.score_boilerplate(cur, before) if ok and cur and before else np.nan)
    df["rpt_boilerplate_sim"] = sims
    return df[KEY + ["d_rpt_vagueness", "d_rpt_fog", "d_rpt_agency", "d_rpt_words_pct", "rpt_boilerplate_sim"]]
