"""Leak-free firm-year modelling of RPT fraud risk on the SEC-RPT-Panel dataset.

Pipeline: download -> panel -> features -> leave-one-cluster-out modelling ->
stress tests T1-T5 -> bootstrap mediation -> clustered logit -> explainability
-> reporting. Every number the thesis reports comes from this package.
"""

__version__ = "2.0.0"
