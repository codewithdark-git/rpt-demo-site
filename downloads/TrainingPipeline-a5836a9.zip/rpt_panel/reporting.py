"""CSV and LaTeX tables for the thesis. Captions are built from the data; nothing is hardcoded."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable

import numpy as np
import pandas as pd


def _tex_escape(value: object) -> str:
    text = "" if value is None or (isinstance(value, float) and np.isnan(value)) else str(value)
    for a, b in (("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"), ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"), ("}", r"\}")):
        text = text.replace(a, b)
    return text


def _fmt(value: object, digits: int) -> str:
    if isinstance(value, (float, np.floating)):
        return "" if np.isnan(value) else f"{value:.{digits}f}"
    if isinstance(value, (bool, np.bool_)):
        return "yes" if value else "no"
    return _tex_escape(value)


def to_latex(df: pd.DataFrame, caption: str, label: str, digits: int = 3, columns: Iterable[str] | None = None) -> str:
    cols = list(columns) if columns else list(df.columns)
    align = "l" + "r" * (len(cols) - 1)
    lines = [
        r"\begin{table}[htbp]", r"\centering", r"\small",
        f"\\caption{{{_tex_escape(caption)}}}", f"\\label{{{label}}}",
        f"\\begin{{tabular}}{{{align}}}", r"\toprule",
        " & ".join(_tex_escape(c).replace(r"\_", " ") for c in cols) + r" \\", r"\midrule",
    ]
    for _, row in df[cols].iterrows():
        lines.append(" & ".join(_fmt(row[c], digits) for c in cols) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    return "\n".join(lines)


def write_table(df: pd.DataFrame, out_dir: Path, name: str, caption: str, digits: int = 3, columns: Iterable[str] | None = None) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / f"{name}.csv", index=False)
    (out_dir / f"{name}.tex").write_text(to_latex(df, caption, f"tab:{name}", digits, columns), encoding="utf-8")


def write_json(data: Dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=_json_default), encoding="utf-8")


def _json_default(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if np.isnan(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, Path):
        return str(value)
    return str(value)


def descriptives(X: pd.DataFrame, features: Iterable[str]) -> pd.DataFrame:
    """Mean/SD/N by case vs peer for each feature over the training window (thesis descriptive table)."""
    rows = []
    for f in features:
        if f not in X.columns:
            continue
        for role in ("case", "peer"):
            s = X.loc[X["case_role"] == role, f].dropna()
            rows.append({"feature": f, "group": role, "n": int(len(s)), "mean": s.mean() if len(s) else np.nan,
                         "sd": s.std(ddof=1) if len(s) > 1 else np.nan, "median": s.median() if len(s) else np.nan})
    return pd.DataFrame(rows)


def coverage(X: pd.DataFrame, features: Iterable[str]) -> pd.DataFrame:
    """Share of firm-years with a non-missing value per feature, by group — the boundary-condition table."""
    rows = []
    for f in features:
        if f not in X.columns:
            continue
        rows.append({"feature": f,
                     "available_all": float(X[f].notna().mean()),
                     "available_cases": float(X.loc[X["case_role"] == "case", f].notna().mean()) if (X["case_role"] == "case").any() else np.nan,
                     "available_peers": float(X.loc[X["case_role"] == "peer", f].notna().mean()) if (X["case_role"] == "peer").any() else np.nan})
    return pd.DataFrame(rows)


def panel_caption(X: pd.DataFrame, cfg) -> str:
    n_cases = X.loc[X["case_role"] == "case", "cik"].nunique()
    n_peers = X.loc[X["case_role"] == "peer", "cik"].nunique()
    years = f"FY{int(X['fiscal_year'].min())}–FY{int(X['fiscal_year'].max())}"
    return f"{n_cases} case firms and {n_peers} matched peers, {len(X)} firm-years, {years}; window of {cfg.window} pre-revelation years"
