"""Assemble the modelling matrix and define the three layers used by the thesis."""
from __future__ import annotations

from typing import Iterable, List

import pandas as pd

KEY = ["cik", "fiscal_year"]

FEATURE_GROUPS = {
    "L1_financial": [
        "rpt_to_revenue", "rp_receivables_to_assets", "rp_sales_ratio", "abnormal_rp_sales",
        "rp_lend_to_assets", "rp_pay_to_assets", "rp_sales_to_revenue", "rp_purch_to_assets",
        "earnings_cash_divergence", "accruals",
    ],
    "L2_monitoring": [
        "icfr_not_effective", "material_weakness_reported", "mw_count", "mw_persistence_2yr",
        "restatement_proxy", "big4", "ceo_duality", "board_indep", "ac_indep", "auditor_change", "going_concern_opinion",
        "restatement_8k", "auditor_change_8k",
    ],
    "L3_disclosure": [
        "rp_incomp",
        "rpt_vagueness", "rpt_relabeling", "rpt_indeterminate_ratio", "rpt_transparency",
        "rpt_agency_masking", "rpt_passive_ratio", "rpt_fog",
        "d_rpt_vagueness", "d_rpt_fog", "rpt_boilerplate_sim", "spec_gap_vagueness",
    ],
    "controls": ["ln_assets", "leverage", "roa", "listing_age"],
    # Peer-relative deviations (leave-one-out within cluster-year; label-free) and the
    # lexicon-free peer textual anomaly. This is the "RPT anomaly as a multidimensional,
    # peer-relative construct" contribution operationalised as model inputs.
    "L4_peer_relative": [
        "rpt_vagueness_z", "rpt_agency_masking_z", "rpt_fog_z", "earnings_cash_divergence_z", "accruals_z",
        "rp_receivables_to_assets_z", "rpt_to_revenue_z", "rpt_peer_text_distance",
    ],
}
ID_COLUMNS = ["cik", "fiscal_year", "ticker", "company_name", "cluster_id", "case_role", "is_case",
              "fraud_aaer_label", "event_time", "misconduct_period", "rpt_source", "rpt_text_available",
              "accession_number", "report_date", "filing_date", "sic", "stratum"]


def feature_list(groups: Iterable[str] = FEATURE_GROUPS.keys()) -> List[str]:
    out: List[str] = []
    for g in groups:
        out += FEATURE_GROUPS[g]
    return out


def assemble(panel: pd.DataFrame, *parts: pd.DataFrame) -> pd.DataFrame:
    """Start from the panel's identifier columns and left-join feature frames on (cik, fiscal_year)."""
    df = panel[[c for c in ID_COLUMNS if c in panel.columns]].copy()
    df["fiscal_year"] = df["fiscal_year"].astype(int)
    return join(df, *parts)


def join(df: pd.DataFrame, *parts: pd.DataFrame) -> pd.DataFrame:
    """Left-join further feature frames onto an existing feature matrix (all columns kept)."""
    for part in parts:
        part = part.copy()
        part["fiscal_year"] = part["fiscal_year"].astype(int)
        overlap = [c for c in part.columns if c in df.columns and c not in KEY]
        df = df.merge(part.drop(columns=overlap), on=KEY, how="left", validate="one_to_one")
    return df


def drop_all_missing(df: pd.DataFrame, features: List[str], min_share: float = 0.2) -> List[str]:
    """Features with fewer than ``min_share`` non-missing values are reported and excluded."""
    keep, dropped = [], []
    for f in features:
        if f in df.columns and df[f].notna().mean() >= min_share:
            keep.append(f)
        else:
            dropped.append(f)
    return keep, dropped
