"""Leak-free discrimination models (H1) with out-of-fold scores and attributions.

Rules enforced here, because the legacy code broke every one of them:
* folds are grouped by case cluster (a fraud firm and its matched peers are
  always in the same fold), so no firm appears in both train and test;
* imputation and scaling are fitted inside each training fold;
* every score, SHAP value and importance reported is out-of-fold;
* the final model is refit on all training rows only for deployment and is
  saved together with its feature list, threshold and dataset version.
"""
from __future__ import annotations

import logging
import pickle
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .config import PanelConfig

LOGGER = logging.getLogger(__name__)
LABEL = "fraud_aaer_label"
GROUP = "cluster_id"
MAX_LOGO_GROUPS = 10


@dataclass
class OOFResult:
    model: str
    features: List[str]
    scores: pd.Series                      # out-of-fold P(case); index = df index
    shap_values: Optional[pd.DataFrame]    # out-of-fold SHAP per row x feature (same index)
    fold_metrics: List[dict] = field(default_factory=list)
    folds: List[Tuple[np.ndarray, np.ndarray]] = field(default_factory=list)
    estimators: List[Pipeline] = field(default_factory=list)
    text_oof: Optional[pd.Series] = None        # out-of-fold TF-IDF text risk (stacked feature), if used


def make_pipeline(model: str, seed: int, n_pos: int | None = None, n_neg: int | None = None) -> Pipeline:
    if model == "logit":
        clf = LogisticRegression(C=1.0, class_weight="balanced", max_iter=5000)
    elif model == "rf":
        clf = RandomForestClassifier(
            n_estimators=500, max_depth=4, min_samples_leaf=3, class_weight="balanced_subsample",
            random_state=seed, n_jobs=-1,
        )
    elif model == "xgb":
        from xgboost import XGBClassifier

        spw = (n_neg / n_pos) if n_pos and n_neg else 1.0
        clf = XGBClassifier(
            n_estimators=300, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8,
            min_child_weight=3, reg_lambda=1.0, scale_pos_weight=spw, eval_metric="logloss",
            random_state=seed, n_jobs=1, verbosity=0,
        )
    else:
        raise ValueError(f"unknown model {model!r}")
    return Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler()), ("clf", clf)])


def splits(groups: pd.Series, max_logo: int = MAX_LOGO_GROUPS) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Leave-one-cluster-out up to ``max_logo`` clusters; GroupKFold(5) otherwise."""
    n_groups = groups.nunique()
    X_dummy = np.zeros((len(groups), 1))
    if n_groups <= max_logo:
        return list(LeaveOneGroupOut().split(X_dummy, groups=groups))
    return list(GroupKFold(n_splits=5).split(X_dummy, groups=groups))


def _oof_shap(pipe: Pipeline, model: str, X_train: pd.DataFrame, X_test: pd.DataFrame) -> Optional[np.ndarray]:
    try:
        import shap
    except ImportError:
        return None
    pre = Pipeline(pipe.steps[:-1])
    clf = pipe.named_steps["clf"]
    Z_train, Z_test = pre.transform(X_train), pre.transform(X_test)
    try:
        if model == "logit":
            masker = shap.maskers.Independent(Z_train, max_samples=len(Z_train))
            explainer = shap.LinearExplainer(clf, masker)
            values = explainer.shap_values(Z_test)
        else:
            explainer = shap.TreeExplainer(clf)
            values = explainer.shap_values(Z_test)
            if isinstance(values, list):          # sklearn RF returns one array per class
                values = values[1]
            elif values.ndim == 3:
                values = values[:, :, 1]
    except Exception as exc:  # SHAP failures must not break the modelling run
        LOGGER.warning("SHAP failed for %s: %s", model, exc)
        return None
    return np.asarray(values)


TEXT_STACK = "text_risk"


def fit_oof(df: pd.DataFrame, features: Sequence[str], model: str, cfg: PanelConfig,
            texts: Optional[pd.Series] = None) -> OOFResult:
    """Fit one model class with grouped out-of-fold prediction. ``df`` must be the training rows only.

    With ``texts`` (RPT text per row) a lexicon-free TF-IDF risk score is stacked
    as an extra feature using nested grouped folds (see ``text_model``), so the
    stacked column for a training row never comes from a model that saw that row.
    """
    features = list(features)
    use_text = texts is not None and getattr(cfg, "stack_text", True)
    used = features + ([TEXT_STACK] if use_text else [])
    X, y, groups = df[features], df[LABEL].astype(int), df[GROUP]
    scores = pd.Series(np.nan, index=df.index, dtype=float)
    shap_rows = pd.DataFrame(np.nan, index=df.index, columns=used, dtype=float)
    result = OOFResult(model=model, features=used, scores=scores, shap_values=shap_rows)
    result.text_oof = pd.Series(np.nan, index=df.index, dtype=float)
    shap_ok = True
    for fold, (train_idx, test_idx) in enumerate(splits(groups, getattr(cfg, "max_logo_groups", MAX_LOGO_GROUPS))):
        tr, te = df.index[train_idx], df.index[test_idx]
        assert not set(df.loc[tr, "cik"]) & set(df.loc[te, "cik"]), "firm leaked across folds"
        y_tr = y.loc[tr]
        if y_tr.nunique() < 2:
            LOGGER.warning("%s fold %s skipped: training fold has one class", model, fold)
            continue
        X_tr, X_te = X.loc[tr].copy(), X.loc[te].copy()
        if use_text:
            from .text_model import nested_text_risk

            inner, outer = nested_text_risk(texts, y, groups, tr, te, cfg.seed + fold, firms=df["cik"])
            X_tr[TEXT_STACK], X_te[TEXT_STACK] = inner.values, outer.values
            result.text_oof.loc[te] = outer.values
        pipe = make_pipeline(model, cfg.seed + fold, n_pos=int(y_tr.sum()), n_neg=int((y_tr == 0).sum()))
        pipe.fit(X_tr, y_tr)
        p = pipe.predict_proba(X_te)[:, 1]
        scores.loc[te] = p
        values = _oof_shap(pipe, model, X_tr, X_te)
        if values is None:
            shap_ok = False
        else:
            shap_rows.loc[te, used] = values
        y_te = y.loc[te]
        result.fold_metrics.append({
            "fold": fold, "held_out_cluster": "|".join(sorted(groups.loc[te].unique())),
            "n_test": int(len(te)), "n_pos_test": int(y_te.sum()),
            "auc": roc_auc_score(y_te, p) if y_te.nunique() == 2 else np.nan,
            "mean_score_pos": float(p[y_te.values == 1].mean()) if y_te.sum() else np.nan,
            "mean_score_neg": float(p[y_te.values == 0].mean()) if (y_te == 0).sum() else np.nan,
        })
        result.folds.append((train_idx, test_idx))
        result.estimators.append(pipe)
    if not shap_ok:
        result.shap_values = None
    return result


def cluster_bootstrap_auc(y: pd.Series, scores: pd.Series, groups: pd.Series, n_boot: int, seed: int) -> Tuple[float, float, float]:
    """Point AUC and percentile CI from resampling clusters with replacement."""
    mask = scores.notna()
    y, scores, groups = y[mask], scores[mask], groups[mask]
    if y.nunique() < 2:
        return np.nan, np.nan, np.nan
    point = roc_auc_score(y, scores)
    rng = np.random.default_rng(seed)
    clusters = groups.unique()
    by_cluster = {g: np.where(groups.values == g)[0] for g in clusters}
    aucs = []
    for _ in range(n_boot):
        idx = np.concatenate([by_cluster[g] for g in rng.choice(clusters, size=len(clusters), replace=True)])
        yy = y.values[idx]
        if len(np.unique(yy)) < 2:
            continue
        aucs.append(roc_auc_score(yy, scores.values[idx]))
    if len(aucs) < 10:
        return point, np.nan, np.nan
    return point, float(np.percentile(aucs, 2.5)), float(np.percentile(aucs, 97.5))


def evaluate(df: pd.DataFrame, result: OOFResult, cfg: PanelConfig) -> dict:
    y, s, g = df[LABEL].astype(int), result.scores, df[GROUP]
    auc, lo, hi = cluster_bootstrap_auc(y, s, g, cfg.n_boot, cfg.seed)
    mask = s.notna()
    return {
        "model": result.model,
        "n_features": len(result.features),
        "n_rows": int(mask.sum()),
        "n_pos": int(y[mask].sum()),
        "n_clusters": int(g.nunique()),
        "oof_auc": auc,
        "oof_auc_ci_low": lo,
        "oof_auc_ci_high": hi,
        "oof_pr_auc": average_precision_score(y[mask], s[mask]) if y[mask].nunique() == 2 else np.nan,
        "prevalence": float(y[mask].mean()),
        "fold_auc_mean": float(np.nanmean([m["auc"] for m in result.fold_metrics])) if result.fold_metrics else np.nan,
        "folds": len(result.fold_metrics),
    }


def ablation(df: pd.DataFrame, feature_groups: Dict[str, List[str]], model: str, cfg: PanelConfig,
             texts: Optional[pd.Series] = None) -> pd.DataFrame:
    """OOF AUC for the full set and with each layer removed (H2 / T2 uses the L3 row).

    The stacked text score counts as part of the disclosure layer: it is removed
    together with L3 and in the dedicated ``drop_text_stack`` row.
    """
    available = {g: [f for f in fs if f in df.columns and df[f].notna().any()] for g, fs in feature_groups.items()}
    all_feats = [f for fs in available.values() for f in fs]
    configs: Dict[str, Tuple[List[str], Optional[pd.Series]]] = {"full": (all_feats, texts)}
    for g in available:
        if g == "controls":
            continue
        rest = [f for h, fs in available.items() if h != g for f in fs]
        configs[f"drop_{g}"] = (rest, None if g == "L3_disclosure" else texts)
    if texts is not None:
        configs["drop_text_stack"] = (all_feats, None)
    configs["controls_only"] = (available.get("controls", []), None)
    rows = []
    for name, (feats, t) in configs.items():
        if len(feats) == 0:
            continue
        res = fit_oof(df, feats, model, cfg, texts=t)
        ev = evaluate(df, res, cfg)
        rows.append({"spec": name, "model": model, "n_features": len(res.features), **{k: v for k, v in ev.items() if k.startswith("oof_")}})
    out = pd.DataFrame(rows)
    if "full" in set(out["spec"]):
        full = float(out.loc[out["spec"] == "full", "oof_auc"].iloc[0])
        out["delta_auc_vs_full"] = out["oof_auc"] - full
    return out


def mean_ensemble(scores_by_model: Dict[str, pd.Series]) -> pd.Series:
    """Pre-specified alert score: the mean out-of-fold probability across model classes.

    Probabilities (not ranks) are averaged so the same rule applies at inference
    and the alert threshold transfers unchanged.
    """
    return pd.concat(scores_by_model.values(), axis=1).mean(axis=1, skipna=True)


def fit_final(df: pd.DataFrame, features: Sequence[str], model: str, cfg: PanelConfig,
              texts: Optional[pd.Series] = None):
    """Refit on all training rows for deployment. Returns (pipeline, text_model or None)."""
    y = df[LABEL].astype(int)
    X = df[list(features)].copy()
    text_model = None
    if texts is not None and getattr(cfg, "stack_text", True):
        from .text_model import TextRiskModel, nested_text_risk

        # Training rows get inner-fold scores (as in fit_oof); the saved text model is fitted on everything.
        inner, _ = nested_text_risk(texts, y, df[GROUP], df.index, df.index[:0], cfg.seed, firms=df["cik"])
        X[TEXT_STACK] = inner.values
        text_model = TextRiskModel(cfg.seed).fit(texts.loc[df.index], y, df["cik"])
    pipe = make_pipeline(model, cfg.seed, n_pos=int(y.sum()), n_neg=int((y == 0).sum()))
    pipe.fit(X, y)
    return pipe, text_model


def save_model(pipe, features: Sequence[str], feature_groups: Dict[str, List[str]], threshold: float,
               cfg: PanelConfig, dataset_version: str, path: Path, metrics: dict | None = None,
               text_model=None, ensemble_members: Dict[str, Pipeline] | None = None) -> Path:
    import sklearn

    payload = {
        "pipeline": pipe,
        "ensemble_members": ensemble_members,   # {model: pipeline} when the alert model is the mean ensemble
        "text_model": text_model,               # TextRiskModel producing the stacked `text_risk` column
        "features": list(features),
        "feature_groups": feature_groups,
        "threshold": float(threshold),
        "dataset_version": dataset_version,
        "sklearn_version": sklearn.__version__,
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "config": {k: (str(v) if isinstance(v, Path) else v) for k, v in cfg.__dict__.items() if k != "hf_token"},
        "metrics": metrics or {},
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        pickle.dump(payload, f)
    return path
