"""Read the SEC-RPT-Panel dataset (tables + raw texts) from a local mirror of the Hub repo."""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Iterable

import pandas as pd

from .config import PanelConfig

LOGGER = logging.getLogger(__name__)
METADATA_PATTERNS = ["*.csv", "*.json", "README.md"]
ANNUAL_FORMS = {"10-K", "10-K405", "10-KSB", "10-KSB40", "10-KT"}


def _cik10(value: object) -> str:
    return "".join(ch for ch in str(value) if ch.isdigit()).zfill(10)


def cik_patterns(ciks: Iterable[str]) -> list[str]:
    out: list[str] = []
    for cik in ciks:
        c = _cik10(cik)
        out += [f"raw/filings/{c}/**", f"raw/proxies/{c}/**", f"raw/xbrl/CIK{c}.json"]
    return out


def download(cfg: PanelConfig, mode: str = "metadata", ciks: Iterable[str] | None = None) -> Path:
    """Mirror the dataset into ``cfg.local_dir``. Unchanged files are skipped, so this is resumable."""
    from huggingface_hub import snapshot_download

    if mode == "metadata":
        allow: list[str] | None = list(METADATA_PATTERNS)
    elif mode == "full":
        allow = None
    elif mode == "ciks":
        ciks = list(ciks or [])
        if not ciks:
            raise ValueError("mode='ciks' needs CIKs (pass them or set cases_csv)")
        allow = list(METADATA_PATTERNS) + cik_patterns(ciks)
    else:
        raise ValueError(f"unknown download mode {mode!r}")
    cfg.local_dir.mkdir(parents=True, exist_ok=True)
    token = cfg.hf_token or os.environ.get("HF_TOKEN")
    LOGGER.info("Downloading %s (%s) -> %s", cfg.repo_id, mode, cfg.local_dir)
    snapshot_download(
        repo_id=cfg.repo_id, repo_type="dataset", local_dir=str(cfg.local_dir),
        allow_patterns=allow, token=token, revision=cfg.dataset_revision,
    )
    return cfg.local_dir


def ciks_from_cases(cases_csv: Path) -> list[str]:
    cases = pd.read_csv(cases_csv, dtype=str).fillna("")
    return [_cik10(c) for c in cases["cik"] if c]


def load_table(local_dir: Path, name: str) -> pd.DataFrame:
    path = Path(local_dir) / f"{name}.csv"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found; run `download` first")
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    if "cik" in df.columns:
        df["cik"] = df["cik"].map(_cik10)
    return df


def load_master_panel(local_dir: Path) -> pd.DataFrame:
    """master_panel.csv with numeric columns coerced; blanks become NaN."""
    df = load_table(local_dir, "master_panel")
    df = df.replace({"": pd.NA})
    numeric_prefixes = ("xbrl_", "item1_", "item13_", "rpt_disclosure_", "rp_note_", "extract_icfr_", "extract_material_", "extract_dcp_", "extract_auditor_", "extract_item13_incorporated")
    numeric_exact = {"fiscal_year", "year", "is_primary_filing", "fraud_aaer_label", "event_time", "misconduct_period", "in_assessment_window", "aaer_release_in_year", "ever_aaer_matched", "size", "is_xbrl", "is_inline_xbrl", "extract_item1_words", "extract_item9a_words", "extract_item13_words", "extract_rp_note_words", "extract_rpt_disclosure_words"}
    for col in df.columns:
        if col in numeric_exact or col.startswith(numeric_prefixes):
            if col.endswith(("_tag", "_accession", "_status", "_source", "_path", "_error")):
                continue
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def section_path(local_dir: Path, row: pd.Series | dict, name: str) -> Path:
    """Rebuild raw/filings/<cik>/<fy>/<accession>/<name>.txt from the row's own columns.

    The builder's absolute ``*_path`` columns are machine-specific and never used.
    """
    cik = _cik10(row["cik"])
    year = str(int(float(row.get("year", row.get("fiscal_year")))))
    accession = str(row["accession_number"])
    return Path(local_dir) / "raw" / "filings" / cik / year / accession / f"{name}.txt"


def read_section(local_dir: Path, row: pd.Series | dict, name: str) -> str:
    path = section_path(local_dir, row, name)
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def read_cases(cfg: PanelConfig, local_dir: Path | None = None) -> pd.DataFrame | None:
    """The verified cases file, if configured (revelation dates etc.)."""
    if cfg.cases_csv and Path(cfg.cases_csv).exists():
        cases = pd.read_csv(cfg.cases_csv, dtype=str).fillna("")
        cases["cik"] = cases["cik"].map(_cik10)
        return cases
    return None
