"""Rule-based coding of the design's related-party characteristics from the related-party text.

For each firm-year the related-party note (``rp_note.txt``) is read; when it is missing, the Item 13 body or
the proxy's related-party section (``rpt_disclosure.txt``) is used. Money amounts are located and classified by
the words around them:

    RP_LEND   loans, advances, notes or receivables due FROM related parties        (out of the firm)
    RP_PAY    loans, notes, payables or amounts due TO related parties               (into the firm)
    RP_SALES  sales / revenue from related parties                                   (into the firm)
    RP_PURCH  purchases, fees, rent, services or compensation paid TO related parties (out of the firm)

The largest amount found per category is kept (USD) together with its passage, and the four disclosure items of
RP_INCOMP are flagged: counterparty named, amount stated, terms stated, business purpose stated.

These are rule-based codes with evidence, to be checked against human coding on a 10 % sample (M2) before they
are relied upon. Nothing is imputed: a note with no amount gives NaN amounts and ``amount_stated = 0``.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

MONEY = re.compile(
    r"\$\s?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?\s*(million|billion|thousand|mm|m\b|b\b|k\b)?"
    r"|(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?\s*(million|billion|thousand)\s+(?:dollars|usd)", re.I)
UNIT = {"million": 1e6, "mm": 1e6, "m": 1e6, "billion": 1e9, "b": 1e9, "thousand": 1e3, "k": 1e3}
IN_THOUSANDS = re.compile(r"\(?in\s+thousands\)?", re.I)
IN_MILLIONS = re.compile(r"\(?in\s+millions\)?", re.I)

CATEGORIES = {
    "RP_LEND": re.compile(r"\b(loan(?:s|ed)?\s+to|advanc(?:e|es|ed)\s+to|note[s]?\s+receivable|receivable[s]?\s+from|due\s+from|amounts?\s+owed\s+(?:to\s+the\s+company|by)|lent\s+to|extended\s+(?:a\s+)?(?:loan|credit)|credit\s+facility\s+(?:to|for)|borrowed\s+from\s+the\s+company|owed\s+to\s+the\s+company|promissory\s+note[s]?\s+(?:issued\s+by|from))\b", re.I),
    "RP_PAY": re.compile(r"\b(loan(?:s|ed)?\s+from|borrow(?:ed|ings?)\s+from|note[s]?\s+payable\s+to|payable[s]?\s+to|due\s+to\s+(?:related|affiliate|officer|director|shareholder|stockholder|the\s+ceo|the\s+chairman|mr\.|ms\.)|amounts?\s+owed\s+to|advanc(?:e|es|ed)\s+(?:from|by)|indebted\s+to|promissory\s+note[s]?\s+(?:issued\s+to|in\s+favou?r\s+of)|line\s+of\s+credit\s+from)\b", re.I),
    "RP_SALES": re.compile(r"\b(sales?\s+to|revenue[s]?\s+from|sold\s+(?:products|goods|services|inventory)?\s*to|net\s+sales\s+to|billed\s+to|fees?\s+(?:earned|received)\s+from|income\s+from\s+(?:services\s+)?(?:provided\s+)?to|licens(?:e|ing)\s+(?:fees|revenue)\s+from)\b", re.I),
    "RP_PURCH": re.compile(r"\b(purchas(?:e|es|ed)\s+from|paid\s+to|payments?\s+to|fees?\s+(?:paid\s+)?to|rent(?:al)?\s+(?:paid\s+|expense\s+|payments?\s+)?to|lease[d]?\s+(?:from|office\s+space\s+from)|services\s+(?:provided|rendered)\s+by|consulting\s+(?:fees|agreement)\s+with|compensation\s+(?:paid\s+)?to|expenses?\s+(?:paid\s+|reimbursed\s+)?to|management\s+fees?\s+(?:paid\s+)?to|royalt(?:y|ies)\s+(?:paid\s+)?to|cost\s+of\s+(?:goods|services)\s+(?:purchased\s+)?from|acquired\s+from)\b", re.I),
}
COUNTERPARTY = re.compile(r"\b(Mr\.|Ms\.|Mrs\.|Dr\.|director|officer|chief\s+executive|chairman|president|shareholder|stockholder|affiliate|subsidiary|family|spouse|brother|son|daughter|father|mother|entity\s+(?:owned|controlled)|owned\s+by|controlled\s+by)\b|\b[A-Z][A-Za-z&.'-]+(?:\s+[A-Z][A-Za-z&.'-]+){1,4},?\s+(?:Inc|LLC|L\.L\.C|Ltd|LP|L\.P|Corp|Corporation|Company|Co|Holdings|Partners|Trust|Group)\b", re.I)
TERMS = re.compile(r"\b(interest\s+(?:rate|at|of)|\d+(?:\.\d+)?\s?%|per\s+annum|matur(?:e|es|ity|ing)|due\s+(?:on|in|date)|term\s+of|repay(?:able|ment)|monthly\s+(?:payments?|rent)|annual\s+(?:rent|fee)|payable\s+(?:in|on|quarterly|monthly)|unsecured|secured\s+by|collateral|prime\s+rate|libor|sofr|expir(?:es|ing|ation)|renew)\b", re.I)
PURPOSE = re.compile(r"\b(purpose|in\s+connection\s+with|to\s+fund|to\s+finance|working\s+capital|in\s+exchange\s+for|in\s+consideration|for\s+(?:the\s+)?(?:use|provision|rental|lease)\s+of|office\s+space|consulting\s+services|management\s+services|administrative\s+services|legal\s+services|to\s+support|operating\s+expenses|acquisition\s+of|to\s+acquire|in\s+order\s+to|for\s+services\s+(?:rendered|provided)|as\s+compensation|for\s+use\s+of)\b", re.I)
SENTENCE_END = re.compile(r"(?<=[.;:])\s+(?=[A-Z(\"\u201c])|\n{2,}")
THRESHOLD_BOILERPLATE = re.compile(
    r"(?:exceed(?:s|ed|ing)?|in\s+excess\s+of|greater\s+than|more\s+than|threshold|lesser\s+of|one\s+percent)\b[^.]{0,80}\$\s?120,000"
    r"|\$\s?120,000[^.]{0,120}(?:threshold|exceed|lesser\s+of|one\s+percent)|item\s+404", re.I)
EXHIBIT_LINE = re.compile(r"incorporated\s+by\s+reference\s+to\s+exhibit|^\s*\d{1,2}\.\d{1,2}\s+[A-Z]|exhibit\s+\d{1,2}\.\d{1,2}", re.I)
TO_THE_COMPANY = re.compile(r"\b(?:to|for)\s+(?:the\s+company|us|the\s+registrant|the\s+partnership|the\s+fund|the\s+trust|the\s+bank)\b|\bbilled\s+to\s+us\b|\bowed\s+by\s+(?:the\s+company|us)\b", re.I)
FROM_THE_COMPANY = re.compile(r"\b(?:by|from)\s+(?:the\s+company|us|the\s+registrant|the\s+partnership|the\s+fund|the\s+trust|the\s+bank)\b|\bowed\s+to\s+(?:the\s+company|us)\b", re.I)
NEGATION = re.compile(r"\b(no\s+(?:related\s+party\s+)?transactions?|none|not\s+(?:any|applicable)|there\s+were\s+no|did\s+not\s+(?:have|enter|engage))\b", re.I)


def _amount(m: re.Match, default_scale: float) -> Optional[float]:
    whole = m.group(1) or m.group(4)
    frac = m.group(2) or m.group(5)
    unit = (m.group(3) or m.group(6) or "").lower()
    if whole is None:
        return None
    try:
        value = float(whole.replace(",", "") + (f".{frac}" if frac else ""))
    except ValueError:
        return None
    if unit:
        value *= UNIT.get(unit, 1.0)
    elif value < 1000 and default_scale == 1.0:
        return None  # "$5" style fragments without a unit are not amounts
    else:
        value *= default_scale
    return value


def code_text(text: str, window: int = 220) -> dict:
    out = {"RP_LEND": np.nan, "RP_PAY": np.nan, "RP_SALES": np.nan, "RP_PURCH": np.nan,
           "RP_LEND_evidence": "", "RP_PAY_evidence": "", "RP_SALES_evidence": "", "RP_PURCH_evidence": "",
           "n_amounts": 0, "counterparty_named": 0, "amount_stated": 0, "terms_stated": 0, "purpose_stated": 0, "rp_incomp": np.nan,
           "no_transactions_stated": 0}
    if not text or len(text.split()) < 20:
        return out
    scale = 1e3 if IN_THOUSANDS.search(text[:600]) else (1e6 if IN_MILLIONS.search(text[:600]) else 1.0)
    out["counterparty_named"] = int(bool(COUNTERPARTY.search(text)))
    out["terms_stated"] = int(bool(TERMS.search(text)))
    out["purpose_stated"] = int(bool(PURPOSE.search(text)))
    out["no_transactions_stated"] = int(bool(NEGATION.search(text[:800])))
    best: dict[str, tuple[float, str]] = {}
    n = 0
    bounds = [m.end() for m in SENTENCE_END.finditer(text)]
    for m in MONEY.finditer(text):
        value = _amount(m, scale)
        if value is None or value <= 0:
            continue
        # Context = the sentence holding the amount (bounded by the previous and next sentence end).
        start = max([b for b in bounds if b <= m.start()], default=0)
        end = min([b for b in bounds if b > m.end()], default=len(text))
        sent = text[start:end]
        if THRESHOLD_BOILERPLATE.search(sent):
            continue  # the Item 404 "$120,000" materiality threshold is not a transaction
        if EXHIBIT_LINE.search(sent):
            continue  # exhibit index entries ("incorporated by reference to Exhibit 10.2") are not transactions
        n += 1
        ctx = re.sub(r"\s+", " ", sent).strip()
        inward = bool(TO_THE_COMPANY.search(sent))     # "... loan to the Company", "billed to us": money flows INTO the firm
        outward = bool(FROM_THE_COMPANY.search(sent))  # "... advanced by the Company": money flows OUT of the firm
        for cat, pat in CATEGORIES.items():
            if not pat.search(sent):
                continue
            if cat in ("RP_LEND", "RP_PURCH") and inward and not outward:
                cat = "RP_PAY" if cat == "RP_LEND" else "RP_SALES"
            elif cat in ("RP_PAY", "RP_SALES") and outward and not inward:
                cat = "RP_LEND" if cat == "RP_PAY" else "RP_PURCH"
            if cat not in best or value > best[cat][0]:
                best[cat] = (value, ctx[:300])
    out["n_amounts"] = n
    out["amount_stated"] = int(n > 0)
    for cat, (value, ev) in best.items():
        out[cat] = value
        out[f"{cat}_evidence"] = ev
    items = out["counterparty_named"] + out["amount_stated"] + out["terms_stated"] + out["purpose_stated"]
    out["rp_incomp"] = (4 - items) / 4
    return out


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def code_panel(local_dir: Path, panel: pd.DataFrame, min_words: int = 40) -> pd.DataFrame:
    """One row per (cik, fiscal_year) from the panel's primary filings."""
    local_dir = Path(local_dir)
    rows = []
    for _, r in panel.iterrows():
        cik = str(r["cik"]).zfill(10)
        year = str(int(float(r.get("year", r["fiscal_year"]))))
        base = local_dir / "raw" / "filings" / cik / year / str(r["accession_number"])
        note, disc = _read(base / "rp_note.txt"), _read(base / "rpt_disclosure.txt")
        text, source = (note, "rp_note") if len(note.split()) >= min_words else ((disc, "rpt_disclosure") if len(disc.split()) >= min_words else ("", "none"))
        # The note and the Item 13 / proxy section complement each other: amounts live in the note, the four
        # disclosure items often in the governance section, so both are scanned when both exist.
        combined = (note + "\n\n" + disc) if (note and disc) else text
        coded = code_text(combined) if combined else code_text("")
        coded.update({"cik": cik, "fiscal_year": int(r["fiscal_year"]), "text_source": source, "text_words": len(combined.split())})
        rows.append(coded)
    return pd.DataFrame(rows)


def coverage(table: pd.DataFrame) -> dict:
    cols = ["RP_LEND", "RP_PAY", "RP_SALES", "RP_PURCH", "rp_incomp"]
    return {c: float(table[c].notna().mean()) for c in cols if c in table}
