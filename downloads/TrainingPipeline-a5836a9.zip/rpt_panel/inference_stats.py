"""Primary inference: logit with firm-clustered standard errors and conditional (within-cluster) logit.

Per the revision plan the ML models are secondary; these regressions carry the
hypothesis tests for H1 and the layer-level associations.
"""
from __future__ import annotations

import warnings
from typing import Sequence

import numpy as np
import pandas as pd
import statsmodels.api as sm

LABEL = "fraud_aaer_label"


MIN_COVERAGE = 0.5      # a regressor must be observed in at least half the training rows (complete-case design)
WINSOR = (0.01, 0.99)   # ratio variables are winsorised at these quantiles before standardising


def winsorise(s: pd.Series, lo: float = WINSOR[0], hi: float = WINSOR[1]) -> pd.Series:
    """Clip a continuous variable at its empirical quantiles (binary flags are left alone)."""
    vals = s.dropna()
    if vals.nunique() <= 2:
        return s
    return s.clip(lower=vals.quantile(lo), upper=vals.quantile(hi))


def _prepare(df: pd.DataFrame, features: Sequence[str], y: str, extra: Sequence[str]) -> pd.DataFrame:
    cols = [f for f in features if f in df.columns and df[f].notna().mean() >= MIN_COVERAGE and df[f].std(skipna=True) > 0]
    df = df.copy()
    for c in cols:
        df[c] = winsorise(df[c])
    data = df[cols + [y, *extra]].dropna().copy()
    # A predictor can become constant once complete cases are taken (e.g. a flag that is 1 whenever
    # it is observed); standardising it would give inf/NaN, so drop it and re-take complete cases.
    for _ in range(3):
        constant = [c for c in cols if data[c].std(ddof=1) == 0 or not np.isfinite(data[c].std(ddof=1))]
        if not constant:
            break
        cols = [c for c in cols if c not in constant]
        data = df[cols + [y, *extra]].dropna().copy()
    for c in cols:
        data[c] = (data[c] - data[c].mean()) / data[c].std(ddof=1)
    data[y] = data[y].astype(int)
    data.attrs["features"] = cols
    return data


def _tidy(params, bse, pvalues, conf, n, n_clusters, extra: dict) -> pd.DataFrame:
    out = pd.DataFrame({
        "term": params.index, "coef": params.values, "se": bse.values,
        "z": (params / bse).values, "p": pvalues.values,
        "ci_low": conf.iloc[:, 0].values, "ci_high": conf.iloc[:, 1].values,
    })
    out["odds_ratio"] = np.exp(out["coef"])
    out["n"] = n
    out["n_clusters"] = n_clusters
    for k, v in extra.items():
        out[k] = v
    return out


def clustered_logit(df: pd.DataFrame, features: Sequence[str], y: str = LABEL, cluster: str = "cik") -> pd.DataFrame:
    """Pooled logit, standardised predictors, sandwich SEs clustered by firm. Complete cases only."""
    data = _prepare(df, features, y, [cluster])
    cols = data.attrs["features"]
    if data[y].nunique() < 2 or not cols:
        return pd.DataFrame()
    X = sm.add_constant(data[cols], has_constant="add")
    groups = pd.factorize(data[cluster])[0]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            try:
                res = sm.Logit(data[y], X).fit(disp=0, maxiter=200, method="newton", cov_type="cluster", cov_kwds={"groups": groups})
            except Exception:
                res = sm.Logit(data[y], X).fit(disp=0, maxiter=500, method="bfgs", cov_type="cluster", cov_kwds={"groups": groups})
            converged, method = bool(res.mle_retvals.get("converged", True)), "logit_cluster_se"
            if not np.isfinite(res.params).all() or res.params.abs().max() > 25:
                raise RuntimeError("separation")
            tidy = _tidy(res.params, res.bse, res.pvalues, res.conf_int(), len(data), int(data[cluster].nunique()),
                         {"method": method, "converged": converged, "pseudo_r2": float(res.prsquared)})
        except Exception:
            # (Quasi-)separation with few positives: report a ridge-penalised logit and say so.
            res = sm.Logit(data[y], X).fit_regularized(alpha=1.0, L1_wt=0.0, disp=0, maxiter=1000)
            params = pd.Series(np.asarray(res.params).ravel(), index=X.columns)
            nan = pd.Series(np.nan, index=X.columns)
            tidy = _tidy(params, nan, nan, pd.DataFrame({0: nan, 1: nan}), len(data), int(data[cluster].nunique()),
                         {"method": "ridge_logit_no_se (separation)", "converged": True, "pseudo_r2": np.nan})
    return tidy


def _conditional_probabilities(xb: np.ndarray, m: int) -> np.ndarray:
    """P(y_i = 1 | sum y = m) in one stratum of a conditional logit, via elementary symmetric polynomials.

    With w_i = exp(x_i b), the stratum likelihood denominator is e_m(w) (the sum over all subsets of size m of
    the product of w), and P(y_i = 1 | sum y = m) = w_i e_{m-1}(w without i) / e_m(w). Computed in log space for
    stability. n and m are small (a matched set has at most about 30 firm-years, 5 of them case years).
    """
    w = np.exp(xb - xb.max())
    n = len(w)

    def esp(vals: np.ndarray, k: int) -> float:
        e = np.zeros(k + 1)
        e[0] = 1.0
        for v in vals:
            e[1:] = e[1:] + v * e[:-1]
        return float(e[k])

    total = esp(w, m)
    out = np.empty(n)
    for i in range(n):
        out[i] = w[i] * esp(np.delete(w, i), m - 1) / total if total > 0 else m / n
    return out


def conditional_logit(df: pd.DataFrame, features: Sequence[str], y: str = LABEL, group: str = "cluster_id",
                      cluster: str | None = "cik") -> pd.DataFrame:
    """Fixed-effects (conditional) logit within case clusters: each case is compared only with its own peers.

    Standard errors: the model-based ones (``se``, ``p``, ``ci_*``) and, when ``cluster`` is given and present
    in ``df``, sandwich standard errors clustered by that column (``se_cluster``, ``p_cluster``,
    ``ci_low_cluster``, ``ci_high_cluster``). The per-observation score of a conditional logit is
    x_i (y_i - pi_i) with pi_i = P(y_i = 1 | stratum total); firm clusters are nested in the strata, so the
    firm-clustered sandwich is well defined. The design asks for firm-clustered standard errors.
    """
    from statsmodels.discrete.conditional_models import ConditionalLogit

    extra = [group] + ([cluster] if cluster and cluster in df.columns and cluster != group else [])
    data = _prepare(df, features, y, extra)
    cols = data.attrs["features"]
    informative = data.groupby(group)[y].transform("nunique") == 2
    data = data[informative]
    cols = [c for c in cols if data[c].std(ddof=1) > 0]  # a flag can be constant within the informative clusters
    if data.empty or data[y].nunique() < 2 or not cols:
        return pd.DataFrame()
    groups = pd.factorize(data[group])[0]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            model = ConditionalLogit(data[y].values, data[cols].values, groups=groups)
            res = model.fit(disp=0, maxiter=500)
        except Exception as exc:
            return pd.DataFrame([{"term": "model", "method": f"conditional_logit failed: {exc}", "n": len(data)}])
    params = pd.Series(res.params, index=cols)
    bse = pd.Series(res.bse, index=cols)
    pvals = pd.Series(res.pvalues, index=cols)
    conf = pd.DataFrame(res.conf_int(), index=cols)
    tidy = _tidy(params, bse, pvals, conf, len(data), int(data[group].nunique()), {"method": "conditional_logit", "converged": True, "pseudo_r2": np.nan})
    tidy["n_firms"] = int(data[cluster].nunique()) if cluster and cluster in data.columns else np.nan
    if cluster and cluster in data.columns:
        try:
            X = data[cols].values.astype(float)
            yv = data[y].values.astype(int)
            xb = X @ res.params
            score = np.zeros_like(X)
            for g in np.unique(groups):
                idx = np.where(groups == g)[0]
                pi = _conditional_probabilities(xb[idx], int(yv[idx].sum()))
                score[idx] = X[idx] * (yv[idx] - pi)[:, None]
            cl = pd.factorize(data[cluster])[0]
            S = np.zeros((len(cols), len(cols)))
            for c in np.unique(cl):
                s = score[cl == c].sum(axis=0)
                S += np.outer(s, s)
            H = -np.asarray(model.hessian(res.params))
            Hinv = np.linalg.pinv(H)
            G = len(np.unique(cl))
            V = Hinv @ S @ Hinv * (G / (G - 1)) if G > 1 else Hinv @ S @ Hinv
            se_c = np.sqrt(np.clip(np.diag(V), 0, None))
            from scipy import stats as _st
            z = params.values / se_c
            tidy["se_cluster"] = se_c
            tidy["p_cluster"] = 2 * (1 - _st.norm.cdf(np.abs(z)))
            tidy["ci_low_cluster"] = params.values - 1.959964 * se_c
            tidy["ci_high_cluster"] = params.values + 1.959964 * se_c
            tidy["cluster_var"] = cluster
        except Exception:  # noqa: BLE001
            pass
    return tidy
