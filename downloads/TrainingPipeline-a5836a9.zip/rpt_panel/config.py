from __future__ import annotations

import json
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Optional, Tuple


@dataclass(frozen=True)
class PanelConfig:
    """All run parameters. No firm, SIC or CIK is ever a default here."""

    repo_id: str = "codewithdark/SEC-RPT-Panel"
    local_dir: Path = Path("data/hf_cache")
    output_dir: Path = Path("outputs/panel")
    start_year: int = 2014
    end_year: int = 2024
    min_text_words: int = 40
    window: int = 5                 # pre-revelation years used as the case window
    target_fpr: float = 0.05        # clean-firm false-positive rate that fixes the alert threshold (T5)
    n_boot: int = 1000              # cluster-bootstrap resamples (mediation, CIs, stability)
    seed: int = 42
    models: Tuple[str, ...] = ("logit", "rf", "xgb")
    alert_model: str = "ensemble"   # score used for the alert threshold, T3 and T5: a model name or "ensemble" (mean probability)
    stack_text: bool = True         # stack a nested TF-IDF text-risk score as a feature
    peer_baseline: str = "loo_all"  # baseline for *_z features: "loo_all" (label-free) or "peers"
    case_strata: Optional[Tuple[str, ...]] = None  # case strata (cases_csv `stratum`) whose clusters enter training; None = all
    max_logo_groups: int = 10       # leave-one-cluster-out up to this many clusters, GroupKFold(5) beyond
    cases_csv: Optional[Path] = None             # restrict the panel to these CIKs when downloading
    governance_manual_csv: Optional[Path] = None  # hand-collected DEF 14A governance variables
    rp_note_coded_csv: Optional[Path] = None      # coded related-party amounts / disclosure items (rule-based or hand); built if missing
    eightk_items_csv: Optional[Path] = None       # 8-K Item 4.01/4.02 flags per cik-fiscal_year (from the submissions API)
    dataset_revision: Optional[str] = None        # Hub revision to pin
    hf_token: Optional[str] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        for name in ("local_dir", "output_dir", "cases_csv", "governance_manual_csv", "rp_note_coded_csv", "eightk_items_csv"):
            value = getattr(self, name)
            if value is not None and not isinstance(value, Path):
                object.__setattr__(self, name, Path(value))
        if isinstance(self.models, list):
            object.__setattr__(self, "models", tuple(self.models))
        if isinstance(self.case_strata, list):
            object.__setattr__(self, "case_strata", tuple(self.case_strata))


def load_config(path: Path | str | None) -> PanelConfig:
    if path is None:
        return PanelConfig()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    known = {f.name for f in fields(PanelConfig)}
    unknown = set(data) - known
    if unknown:
        raise ValueError(f"Unknown config keys: {sorted(unknown)}")
    return PanelConfig(**data)
