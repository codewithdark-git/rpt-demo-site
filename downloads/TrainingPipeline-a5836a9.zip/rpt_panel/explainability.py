"""RO4: explainability as a measured property — attribution stability and traceability."""
from __future__ import annotations

import re
from pathlib import Path
from itertools import combinations
from typing import Dict, List

import numpy as np
import pandas as pd
from scipy import stats

from core.config import Config
from nlp.sfl_analyser import SFLAnalyser
from nlp.vagueness_scorer import VaguenessScorer

from .config import PanelConfig
from .features import FEATURE_GROUPS
from .modelling import OOFResult
from .text_features import related_party_text


def mean_abs_shap(result: OOFResult) -> pd.Series:
    if result.shap_values is None:
        return pd.Series(dtype=float)
    return result.shap_values.abs().mean().sort_values(ascending=False)


def attribution_table(results: Dict[str, OOFResult]) -> pd.DataFrame:
    frames = []
    for name, res in results.items():
        s = mean_abs_shap(res)
        if s.empty:
            continue
        frames.append(pd.DataFrame({"model": name, "feature": s.index, "mean_abs_shap": s.values, "rank": np.arange(1, len(s) + 1)}))
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["model", "feature", "mean_abs_shap", "rank"])


def attribution_stability(results: Dict[str, OOFResult], cfg: PanelConfig, n_resamples: int | None = None) -> pd.DataFrame:
    """Spearman rank correlation of feature-importance rankings (a) across model classes and
    (b) across cluster-bootstrap resamples of the out-of-fold rows within each model."""
    n_resamples = n_resamples or min(cfg.n_boot, 200)
    rows = []
    rankings = {name: mean_abs_shap(res) for name, res in results.items() if res.shap_values is not None}
    for a, b in combinations(rankings, 2):
        common = rankings[a].index.intersection(rankings[b].index)
        if len(common) >= 3:
            rho = stats.spearmanr(rankings[a][common], rankings[b][common]).statistic
            rows.append({"comparison": "across_models", "a": a, "b": b, "n_features": len(common), "spearman_rho": rho})
    rng = np.random.default_rng(cfg.seed)
    for name, res in results.items():
        if res.shap_values is None:
            continue
        sv = res.shap_values.dropna(how="all")
        full = sv.abs().mean()
        rhos = []
        for _ in range(n_resamples):
            idx = rng.choice(sv.index, size=len(sv), replace=True)
            boot = sv.loc[idx].abs().mean()
            rhos.append(stats.spearmanr(full, boot).statistic)
        rows.append({"comparison": "bootstrap_within_model", "a": name, "b": name, "n_features": int(len(full)),
                     "spearman_rho": float(np.nanmean(rhos)), "rho_ci_low": float(np.nanpercentile(rhos, 2.5)),
                     "rho_ci_high": float(np.nanpercentile(rhos, 97.5)), "n_resamples": n_resamples})
    return pd.DataFrame(rows)


# Traceability ------------------------------------------------------------

L3 = set(FEATURE_GROUPS["L3_disclosure"])
L2 = set(FEATURE_GROUPS["L2_monitoring"])
L1 = set(FEATURE_GROUPS["L1_financial"]) | set(FEATURE_GROUPS["controls"])
XBRL_SOURCE = {
    "rpt_to_revenue": "rp_transaction_amount", "rp_receivables_to_assets": "due_from_related_parties_current",
    "rp_sales_ratio": "rp_revenue", "abnormal_rp_sales": "rp_revenue", "earnings_cash_divergence": "net_income",
    "accruals": "net_income", "ln_assets": "total_assets", "leverage": "total_liabilities", "roa": "net_income",
}


RP_CODED_EVIDENCE = {"rp_lend_to_assets": "RP_LEND_evidence", "rp_pay_to_assets": "RP_PAY_evidence",
                     "rp_sales_to_revenue": "RP_SALES_evidence", "rp_purch_to_assets": "RP_PURCH_evidence"}
GOVERNANCE_EVIDENCE = {
    "big4": ("auditor_evidence", "10-K audit report signature"),
    "auditor_change": ("auditor_evidence", "10-K audit report signature (vs prior year)"),
    "going_concern_opinion": ("going_concern_evidence", "10-K audit report"),
    "ceo_duality": ("ceo_duality_evidence", "DEF 14A (rule-based coder)"),
    "board_indep": ("board_indep_evidence", "DEF 14A (rule-based coder)"),
    "ac_indep": ("ac_indep_evidence", "DEF 14A (rule-based coder)"),
}


class Tracer:
    """Locate the filing evidence behind a feature attribution for one firm-year."""

    def __init__(self, cfg: PanelConfig, master: pd.DataFrame, text_model=None):
        self.cfg = cfg
        nlp_cfg = Config()
        self.vag = VaguenessScorer(nlp_cfg)
        self.sfl = SFLAnalyser(nlp_cfg)
        m = master.copy()
        if "is_primary_filing" in m.columns:  # one row per firm-year: amendments/duplicates would return a frame
            m = m[pd.to_numeric(m["is_primary_filing"], errors="coerce").fillna(0).astype(int) == 1]
        m["fiscal_year"] = pd.to_numeric(m["fiscal_year"], errors="coerce").astype("Int64")
        self.master = m.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])
        self.text_model = text_model
        # Evidence passages written by the rule-based governance coder (governance_manual.csv).
        self.governance = None
        gov = getattr(cfg, "governance_manual_csv", None)
        if gov is not None and Path(gov).exists():
            g = pd.read_csv(gov, dtype={"cik": str}, keep_default_na=False)
            g["cik"] = g["cik"].str.zfill(10)
            g["fiscal_year"] = pd.to_numeric(g["fiscal_year"], errors="coerce").astype("Int64")
            self.governance = g.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])
        self.rp_coded = None
        rpc = getattr(cfg, "rp_note_coded_csv", None)
        if rpc is not None and Path(rpc).exists():
            r = pd.read_csv(rpc, dtype={"cik": str}, keep_default_na=False)
            r["cik"] = r["cik"].str.zfill(10)
            r["fiscal_year"] = pd.to_numeric(r["fiscal_year"], errors="coerce").astype("Int64")
            self.rp_coded = r.drop_duplicates(["cik", "fiscal_year"]).set_index(["cik", "fiscal_year"])

    def locate(self, row: pd.Series, feature: str) -> dict:
        key = (row["cik"], int(row["fiscal_year"]))
        m = self.master.loc[key] if key in self.master.index else None
        if isinstance(m, pd.DataFrame):
            m = m.iloc[0]
        if feature.endswith("_z"):
            base = self.locate(row, feature[:-2])
            return {**base, "locator": (base["locator"] + " vs cluster-year peers").strip()}
        if feature in ("text_risk", "rpt_peer_text_distance"):
            text, source = related_party_text(self.cfg.local_dir, row, self.cfg.min_text_words)
            if not text:
                return {"traceable": 0, "evidence": "", "locator": ""}
            if feature == "text_risk" and self.text_model is not None and getattr(self.text_model, "fitted", False):
                terms = self.text_model.top_terms(40)
                low = text.lower()
                hits = [t for t in terms.loc[terms["direction"] == "risk", "term"] if t in low][:6]
                return {"traceable": int(bool(hits)), "evidence": ", ".join(hits), "locator": f"{source}:tfidf_terms"}
            return {"traceable": 1, "evidence": "RPT text vs cluster-year peer centroid", "locator": f"{source}:peer_centroid"}
        if feature in L3:
            text, source = related_party_text(self.cfg.local_dir, row, self.cfg.min_text_words)
            if not text:
                return {"traceable": 0, "evidence": "", "locator": ""}
            if "agency" in feature or "passive" in feature:
                inst = self.sfl.analyse(text)["masking_instances"]
                ex = "; ".join(f"{i['type']}: {i['examples'][0]}" for i in inst[:3] if i.get("examples"))
                return {"traceable": int(bool(inst)), "evidence": ex, "locator": f"{source}:masking_patterns"}
            v = self.vag.score(text)
            terms = [t for t, _ in v["high_risk_terms"]] + v["transparency_terms_found"]
            hedges = [w for w in re.findall(r"[a-z']+", text.lower()) if w in self.vag.INDETERMINATE_WORDS][:5]
            evidence = ", ".join(terms[:5] or hedges)
            return {"traceable": int(bool(terms or hedges)), "evidence": evidence, "locator": f"{source}:lexicon"}
        if feature in RP_CODED_EVIDENCE or feature == "rp_incomp":
            r = self.rp_coded.loc[key] if self.rp_coded is not None and key in self.rp_coded.index else None
            if isinstance(r, pd.DataFrame):
                r = r.iloc[0]
            if r is None:
                return {"traceable": 0, "evidence": "", "locator": ""}
            if feature == "rp_incomp":
                items = {k: int(float(r.get(k, 0) or 0)) for k in ("counterparty_named", "amount_stated", "terms_stated", "purpose_stated")}
                return {"traceable": 1, "evidence": "; ".join(f"{k}={v}" for k, v in items.items()), "locator": f"{r.get('text_source', '')}:disclosure_items"}
            ev = str(r.get(RP_CODED_EVIDENCE[feature], ""))
            return {"traceable": int(bool(ev.strip())), "evidence": ev[:160], "locator": f"{r.get('text_source', '')}:amount_passage" if ev.strip() else ""}
        if feature in GOVERNANCE_EVIDENCE:
            col, locator = GOVERNANCE_EVIDENCE[feature]
            g = self.governance.loc[key] if self.governance is not None and key in self.governance.index else None
            if isinstance(g, pd.DataFrame):
                g = g.iloc[0]
            ev = str(g.get(col, "")) if g is not None else ""
            return {"traceable": int(bool(ev.strip())), "evidence": ev[:160], "locator": locator if ev.strip() else ""}
        if feature in L2:
            available = m is not None and bool(pd.to_numeric(m.get("extract_icfr_text_available"), errors="coerce") == 1)
            return {"traceable": int(bool(available)), "evidence": "Item 9A text", "locator": "10-K Item 9A"} if feature != "restatement_proxy" \
                else {"traceable": int(pd.notna(row.get(feature))), "evidence": "10-K/A on file", "locator": "filing_manifest"}
        if feature == "listing_age":
            # Years since the firm's first annual report in the EDGAR filing manifest.
            return {"traceable": 1, "evidence": f"{row.get('listing_age')} years since first 10-K on EDGAR", "locator": "filing_manifest:first_annual_report"}
        if feature in L1:
            var = XBRL_SOURCE.get(feature, "")
            tag = m.get(f"xbrl_{var}_tag") if m is not None else None
            acc = m.get(f"xbrl_{var}_accession") if m is not None else None
            ok = isinstance(tag, str) and tag != ""
            return {"traceable": int(ok), "evidence": f"us-gaap:{tag}" if ok else "", "locator": f"XBRL {acc}" if ok else ""}
        return {"traceable": 0, "evidence": "", "locator": ""}


def traceability(result: OOFResult, X: pd.DataFrame, master: pd.DataFrame, cfg: PanelConfig, top_k: int = 3,
                 text_model=None) -> pd.DataFrame:
    """For each scored firm-year, the top-k |SHAP| features and whether each maps to a located passage/tag.

    The summary share (``attrs['share_traceable']``) is the operational measure of
    'supports forensic investigation' (RO4).
    """
    if result.shap_values is None:
        return pd.DataFrame()
    tracer = Tracer(cfg, master, text_model=text_model)
    rows: List[dict] = []
    sv = result.shap_values.dropna(how="all")
    for idx, values in sv.iterrows():
        row = X.loc[idx]
        top = values.abs().sort_values(ascending=False).head(top_k)
        for rank, (feature, _) in enumerate(top.items(), start=1):
            loc = tracer.locate(row, feature)
            rows.append({"cik": row["cik"], "ticker": row.get("ticker", ""), "fiscal_year": int(row["fiscal_year"]),
                         "case_role": row["case_role"], "rank": rank, "feature": feature, "shap": float(values[feature]), **loc})
    out = pd.DataFrame(rows)
    if len(out):
        out.attrs["share_traceable"] = float(out["traceable"].mean())
        out.attrs["share_traceable_cases"] = float(out.loc[out["case_role"] == "case", "traceable"].mean()) if (out["case_role"] == "case").any() else np.nan
    return out
