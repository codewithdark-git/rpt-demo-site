"""Pre-registered forensic stress tests T1-T5 (Thesis_Revision_Plan, section 9.3).

All tests consume out-of-fold scores; nothing here refits a model on its own
test rows. p-values across the five tests are Holm-corrected in ``summary``.
"""
from __future__ import annotations

from datetime import date
from typing import Dict, Optional

import numpy as np
import pandas as pd
from scipy import stats

from .config import PanelConfig

LABEL = "fraud_aaer_label"


def choose_threshold(scores: pd.Series, y: pd.Series, target_fpr: float) -> float:
    """Smallest alert threshold whose false-positive rate on clean firm-years is <= target_fpr."""
    clean = scores[(y == 0) & scores.notna()].sort_values().values
    if len(clean) == 0:
        return 0.5
    k = int(np.ceil((1 - target_fpr) * len(clean)))
    k = min(max(k, 0), len(clean) - 1)
    thr = float(clean[k])
    # make the inequality strict enough that FPR is really <= target
    while thr <= 1 and (clean >= thr).mean() > target_fpr:
        thr = float(np.nextafter(thr, 1.0))
    return thr


def holm(pvals: Dict[str, float]) -> Dict[str, float]:
    items = [(k, v) for k, v in pvals.items() if v is not None and not np.isnan(v)]
    items.sort(key=lambda kv: kv[1])
    m = len(items)
    adjusted, running = {}, 0.0
    for i, (k, p) in enumerate(items):
        running = max(running, min(1.0, (m - i) * p))
        adjusted[k] = running
    for k in pvals:
        adjusted.setdefault(k, np.nan)
    return adjusted


# T1 ----------------------------------------------------------------------

def t1_specificity(X: pd.DataFrame) -> pd.DataFrame:
    """Is vagueness/masking concentrated in related-party text rather than firm-wide style?

    Paired (RPT section minus Item 1 of the same filing) within cases and within
    peers (Wilcoxon signed-rank), then the case-vs-peer difference of the gap
    (Mann-Whitney). H4 predicts a positive gap for cases and a larger gap than peers.
    """
    rows = []
    for metric, gap_col in (("vagueness", "spec_gap_vagueness"), ("agency_masking", "spec_gap_agency")):
        for role in ("case", "peer"):
            gap = X.loc[X["case_role"] == role, gap_col].dropna()
            p = stats.wilcoxon(gap, alternative="greater").pvalue if len(gap) >= 5 and (gap != 0).any() else np.nan
            rows.append({"test": "T1", "metric": metric, "group": role, "n": int(len(gap)), "mean_gap": gap.mean() if len(gap) else np.nan,
                         "median_gap": gap.median() if len(gap) else np.nan, "p_value": p, "statistic": "wilcoxon_greater"})
        case_gap = X.loc[X["case_role"] == "case", gap_col].dropna()
        peer_gap = X.loc[X["case_role"] == "peer", gap_col].dropna()
        p = stats.mannwhitneyu(case_gap, peer_gap, alternative="greater").pvalue if len(case_gap) >= 3 and len(peer_gap) >= 3 else np.nan
        rows.append({"test": "T1", "metric": metric, "group": "case_minus_peer", "n": int(len(case_gap) + len(peer_gap)),
                     "mean_gap": case_gap.mean() - peer_gap.mean() if len(case_gap) and len(peer_gap) else np.nan,
                     "median_gap": np.nan, "p_value": p, "statistic": "mannwhitney_greater"})
    return pd.DataFrame(rows)


# T3 ----------------------------------------------------------------------

def _to_date(value) -> Optional[date]:
    text = str(value or "")
    try:
        return date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (ValueError, IndexError):
        return None


def t3_lead_time(X: pd.DataFrame, scores: pd.Series, threshold: float, cases: pd.DataFrame | None) -> pd.DataFrame:
    """Months between the fiscal-year end of the first out-of-fold alert and the first public revelation.

    Computed per case firm over its pre-revelation window only, so an alert can
    never be dated after the revelation it is supposed to anticipate.
    """
    rev_by_case: Dict[str, Optional[date]] = {}
    if cases is not None:
        for _, c in cases[cases["role"] == "case"].iterrows():
            rev_by_case[c["case_id"]] = _to_date(c.get("revelation_date"))
    rows = []
    for cik, firm in X[X["case_role"] == "case"].groupby("cik"):
        firm = firm.sort_values("fiscal_year")
        s = scores.reindex(firm.index)
        flagged = firm[(s >= threshold).values & s.notna().values]
        revelation = rev_by_case.get(str(firm["cluster_id"].iloc[0]))
        first_flag_year = int(flagged["fiscal_year"].iloc[0]) if len(flagged) else None
        first_fye = _to_date(flagged["report_date"].iloc[0]) if len(flagged) else None
        lead_months = ((revelation.year - first_fye.year) * 12 + revelation.month - first_fye.month) if (first_fye and revelation) else np.nan
        rows.append({
            "test": "T3", "cik": cik, "ticker": firm["ticker"].iloc[0], "cluster_id": firm["cluster_id"].iloc[0],
            "window_years": int(len(firm)), "scored_years": int(s.notna().sum()), "flagged_years": int(len(flagged)),
            "first_flag_fiscal_year": first_flag_year, "revelation_date": revelation.isoformat() if revelation else "",
            "lead_time_months": lead_months, "max_oof_score": float(s.max()) if s.notna().any() else np.nan,
        })
    out = pd.DataFrame(rows)
    if len(out):
        out.attrs["share_cases_flagged"] = float((out["flagged_years"] > 0).mean())
        out.attrs["median_lead_months"] = float(out["lead_time_months"].median())
    return out


# T4 ----------------------------------------------------------------------

def t4_mw_persistence(X: pd.DataFrame) -> pd.DataFrame:
    """Does persistent ICFR weakness precede escalation of the disclosure signals and separate cases from peers?"""
    rows = []
    df = X.sort_values(["cik", "fiscal_year"]).copy()
    for col in ("d_rpt_vagueness", "d_rpt_agency", "d_rpt_fog"):
        nxt = df.groupby("cik")[col].shift(-1)
        pair = pd.DataFrame({"mw": df["mw_persistence_2yr"], "esc": nxt}).dropna()
        if len(pair) >= 8 and pair["mw"].nunique() == 2:
            u = stats.mannwhitneyu(pair.loc[pair["mw"] == 1, "esc"], pair.loc[pair["mw"] == 0, "esc"], alternative="greater")
            p = u.pvalue
        else:
            p = np.nan
        rows.append({"test": "T4", "metric": f"next_year_{col}", "n": int(len(pair)),
                     "mean_with_persistence": pair.loc[pair["mw"] == 1, "esc"].mean() if len(pair) else np.nan,
                     "mean_without": pair.loc[pair["mw"] == 0, "esc"].mean() if len(pair) else np.nan,
                     "p_value": p, "statistic": "mannwhitney_greater"})
    # Columns ordered (persistent, not persistent) so that alternative="greater" tests
    # odds(case persistent) > odds(peer persistent), the direction stated in the design.
    tab = pd.crosstab(X["case_role"], X["mw_persistence_2yr"].fillna(-1)).reindex(index=["case", "peer"], columns=[1.0, 0.0], fill_value=0)
    p = stats.fisher_exact(tab.values, alternative="greater").pvalue if tab.values.sum() else np.nan
    rows.append({"test": "T4", "metric": "persistence_rate_case_vs_peer", "n": int(tab.values.sum()),
                 "mean_with_persistence": tab.loc["case", 1.0] / max(tab.loc["case"].sum(), 1),
                 "mean_without": tab.loc["peer", 1.0] / max(tab.loc["peer"].sum(), 1), "p_value": p, "statistic": "fisher_greater"})
    return pd.DataFrame(rows)


# T5 ----------------------------------------------------------------------

def t5_clean_fpr(scores: pd.Series, y: pd.Series, threshold: float, target_fpr: float) -> dict:
    clean = scores[(y == 0) & scores.notna()]
    fpr = float((clean >= threshold).mean()) if len(clean) else np.nan
    return {"test": "T5", "threshold": threshold, "n_clean_firm_years": int(len(clean)),
            "false_positives": int((clean >= threshold).sum()), "fpr": fpr, "target_fpr": target_fpr,
            "pass": bool(fpr <= target_fpr) if not np.isnan(fpr) else False}


def summary(t1: pd.DataFrame, t2: pd.DataFrame, t3: pd.DataFrame, t4: pd.DataFrame, t5: dict) -> pd.DataFrame:
    """One row per test with the headline statistic and Holm-adjusted p where a p exists."""
    pv = {}
    r = t1[(t1["metric"] == "vagueness") & (t1["group"] == "case_minus_peer")]
    pv["T1_specificity"] = float(r["p_value"].iloc[0]) if len(r) else np.nan
    r = t4[t4["metric"] == "persistence_rate_case_vs_peer"]
    pv["T4_mw_persistence"] = float(r["p_value"].iloc[0]) if len(r) else np.nan
    adj = holm(pv)
    rows = [
        {"test": "T1 specificity (H4)", "headline": r"case-minus-peer gap in RPT vs Item 1 vagueness", "value": pv["T1_specificity"], "p_holm": adj["T1_specificity"]},
        {"test": "T2 ablation (H2)", "headline": "AUC change when the disclosure layer is removed",
         "value": float(t2.loc[t2["spec"] == "drop_L3_disclosure", "delta_auc_vs_full"].iloc[0]) if "drop_L3_disclosure" in set(t2.get("spec", [])) else np.nan, "p_holm": np.nan},
        {"test": "T3 lead time (H3)", "headline": "median months from first OOF alert to revelation", "value": t3.attrs.get("median_lead_months", np.nan), "p_holm": np.nan},
        {"test": "T4 MW persistence", "headline": "case vs peer persistence rate (Fisher p)", "value": pv["T4_mw_persistence"], "p_holm": adj["T4_mw_persistence"]},
        {"test": "T5 clean-firm FPR", "headline": f"FPR at threshold {t5['threshold']:.3f}", "value": t5["fpr"], "p_holm": np.nan},
    ]
    return pd.DataFrame(rows)
