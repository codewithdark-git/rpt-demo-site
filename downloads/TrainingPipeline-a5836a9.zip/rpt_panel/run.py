"""Command line for the rpt_panel pipeline.

    python -m rpt_panel.run all --config rpt_panel.json
    python -m rpt_panel.run download|build|model|stress|mediate|explain|report|infer [--config ...]

Each step reads the previous step's CSV outputs from ``cfg.output_dir`` so steps can be re-run alone.
"""
from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

from . import data_access as da
from . import explainability as ex
from . import features as fe
from . import figures as fg
from . import financial_features as ff
from . import governance_coder as gc
from . import governance_features as gf
from . import inference_stats as inf
from . import mediation as med
from . import modelling as md
from . import panel as pn
from . import predict as pr
from . import reporting as rp
from . import rp_note_coder as rc
from . import stress_tests as st
from . import text_features as tf
from . import text_model as tm
from .config import PanelConfig, load_config

LOGGER = logging.getLogger("rpt_panel")
Z_COLS = ["rpt_vagueness", "rpt_agency_masking", "rpt_fog", "earnings_cash_divergence", "accruals", "rp_receivables_to_assets", "rpt_to_revenue", "rp_lend_to_assets", "rp_purch_to_assets", "rp_incomp"]


# ---------------------------------------------------------------- helpers

def _out(cfg: PanelConfig, *parts: str) -> Path:
    """Output path; the parent (or the directory itself when no suffix) is created."""
    path = cfg.output_dir.joinpath(*parts)
    (path if not path.suffix else path.parent).mkdir(parents=True, exist_ok=True)
    return path


def _dataset_version(cfg: PanelConfig) -> str:
    qa = cfg.local_dir / "dataset_qa.json"
    if qa.exists():
        return str(json.loads(qa.read_text(encoding="utf-8")).get("dataset_version", "unknown"))
    return "unknown"


def _load_features(cfg: PanelConfig) -> pd.DataFrame:
    X = pd.read_csv(_out(cfg, "panel_features.csv"), dtype={"cik": str, "accession_number": str})
    X["cik"] = X["cik"].str.zfill(10)
    return X


def _training(cfg: PanelConfig, X: pd.DataFrame) -> pd.DataFrame:
    mask = pn.training_mask(X, cfg)
    if cfg.case_strata and "stratum" in X.columns:
        mask &= X["stratum"].fillna("core").isin(cfg.case_strata)
    return X[mask].copy()


def _attach_stratum(cfg: PanelConfig, panel: pd.DataFrame) -> pd.DataFrame:
    """cluster_id -> `stratum` of the case firm in the cases file (default 'core')."""
    cases = da.read_cases(cfg)
    out = panel.copy()
    if cases is not None and "stratum" in cases.columns and "case_id" in cases.columns:
        c = cases[cases.get("role", "case").astype(str).str.lower() == "case"]
        lookup = dict(zip(c["case_id"], c["stratum"].replace("", "core")))
        out["stratum"] = out["cluster_id"].map(lookup).fillna("core")
    else:
        out["stratum"] = "core"
    return out


def _feature_set(cfg: PanelConfig, X: pd.DataFrame) -> tuple[List[str], Dict[str, List[str]], List[str]]:
    train = _training(cfg, X)
    keep, dropped = fe.drop_all_missing(train, fe.feature_list())
    groups = {g: [f for f in fs if f in keep] for g, fs in fe.FEATURE_GROUPS.items()}
    return keep, groups, dropped


def _primary_model(cfg: PanelConfig) -> str:
    # Pre-specified: the first model in the config, never the best-scoring one.
    return cfg.models[0]


def _load_texts(cfg: PanelConfig, X: pd.DataFrame) -> pd.Series | None:
    path = _out(cfg, "panel_texts.csv")
    if not path.exists() or not cfg.stack_text:
        return None
    t = pd.read_csv(path, dtype={"cik": str, "rpt_text": str}, keep_default_na=False)
    t["cik"] = t["cik"].str.zfill(10)
    merged = X[["cik", "fiscal_year"]].merge(t, on=["cik", "fiscal_year"], how="left")
    return pd.Series(merged["rpt_text"].fillna("").values, index=X.index)


def _oof_scores(cfg: PanelConfig) -> pd.DataFrame:
    return pd.read_csv(_out(cfg, "oof_scores.csv"), dtype={"cik": str})


def _scores_for(cfg: PanelConfig, X: pd.DataFrame, model: str) -> pd.Series:
    oof = _oof_scores(cfg)
    oof = oof[oof["model"] == model]
    merged = X[["cik", "fiscal_year"]].merge(oof, on=["cik", "fiscal_year"], how="left")
    return pd.Series(merged["score"].values, index=X.index)


def _load_oof_result(cfg: PanelConfig, X: pd.DataFrame, model: str, features: List[str]) -> md.OOFResult:
    scores = _scores_for(cfg, X, model)
    shap_path = _out(cfg, f"oof_shap_{model}.csv")
    shap_df = None
    if shap_path.exists():
        s = pd.read_csv(shap_path, dtype={"cik": str})
        merged = X[["cik", "fiscal_year"]].merge(s, on=["cik", "fiscal_year"], how="left")
        cols = [c for c in s.columns if c not in ("cik", "fiscal_year")]
        shap_df = pd.DataFrame(merged[cols].values, index=X.index, columns=cols)
        shap_df = shap_df.dropna(how="all")
    return md.OOFResult(model=model, features=features, scores=scores, shap_values=shap_df)


# ---------------------------------------------------------------- steps

def step_download(cfg: PanelConfig) -> None:
    ciks = da.ciks_from_cases(cfg.cases_csv) if cfg.cases_csv else None
    da.download(cfg, mode="ciks" if ciks else "full", ciks=ciks)


def _rp_coded_features(cfg: PanelConfig, panel: pd.DataFrame) -> pd.DataFrame:
    """Design characteristics 1-5 from the coded related-party text, scaled by XBRL totals."""
    key = pd.DataFrame({"cik": panel["cik"], "fiscal_year": panel["fiscal_year"].astype(int)})
    path = cfg.rp_note_coded_csv
    if path is None:
        return key
    if not Path(path).exists():
        LOGGER.info("No %s: coding related-party amounts and disclosure items from the texts (rule-based)", path)
        coded = rc.code_panel(cfg.local_dir, panel)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        coded.to_csv(path, index=False)
        rp.write_json(rc.coverage(coded), _out(cfg, "rp_note_coder_coverage.json"))
    coded = pd.read_csv(path, dtype={"cik": str}, keep_default_na=False)
    coded["cik"] = coded["cik"].str.zfill(10)
    coded["fiscal_year"] = pd.to_numeric(coded["fiscal_year"], errors="coerce").astype("Int64")
    for c in ("RP_LEND", "RP_PAY", "RP_SALES", "RP_PURCH", "rp_incomp"):
        coded[c] = pd.to_numeric(coded[c], errors="coerce")
    fin = pd.DataFrame({"cik": panel["cik"], "fiscal_year": panel["fiscal_year"].astype(int),
                        "assets": pd.to_numeric(panel.get("xbrl_total_assets"), errors="coerce").values,
                        "revenue": pd.to_numeric(panel.get("xbrl_revenue"), errors="coerce").values})
    m = fin.merge(coded, on=["cik", "fiscal_year"], how="left")
    assets = m["assets"].where(m["assets"].abs() > 0)
    revenue = m["revenue"].where(m["revenue"].abs() > 0)
    out = pd.DataFrame({"cik": m["cik"], "fiscal_year": m["fiscal_year"],
                        "rp_lend_to_assets": (m["RP_LEND"] / assets).clip(upper=1),
                        "rp_pay_to_assets": (m["RP_PAY"] / assets).clip(upper=1),
                        "rp_sales_to_revenue": (m["RP_SALES"] / revenue).clip(upper=1),
                        "rp_purch_to_assets": (m["RP_PURCH"] / assets).clip(upper=1),
                        "rp_incomp": m["rp_incomp"]})
    return out


def _eightk_features(cfg: PanelConfig, panel: pd.DataFrame) -> pd.DataFrame:
    """RESTATE (Item 4.02) and AUD_CHG (Item 4.01) from the 8-K items file; 0 where the firm-year has no such 8-K."""
    key = pd.DataFrame({"cik": panel["cik"], "fiscal_year": panel["fiscal_year"].astype(int)})
    path = cfg.eightk_items_csv
    if path is None or not Path(path).exists():
        return key
    ek = pd.read_csv(path, dtype={"cik": str})
    ek["cik"] = ek["cik"].str.zfill(10)
    ek["fiscal_year"] = pd.to_numeric(ek["fiscal_year"], errors="coerce").astype("Int64")
    m = key.merge(ek[["cik", "fiscal_year", "restatement_8k", "auditor_change_8k"]], on=["cik", "fiscal_year"], how="left")
    m["restatement_8k"] = m["restatement_8k"].fillna(0).astype(float)
    m["auditor_change_8k"] = m["auditor_change_8k"].fillna(0).astype(float)
    return m


def step_build(cfg: PanelConfig) -> pd.DataFrame:
    master = da.load_master_panel(cfg.local_dir)
    manifest = da.load_table(cfg.local_dir, "filing_manifest")
    panel = _attach_stratum(cfg, pn.attach_cluster(pn.select_primary_filings(master, cfg)))
    if panel.empty:
        raise SystemExit("No firm-years with a case cluster: build the dataset with --cases-csv")
    scores, texts = tf.score_sections(panel, cfg)
    drift = tf.drift_features(scores, texts, cfg)
    l1, ctrl = ff.layer1(panel), ff.controls(panel, manifest)
    gov_csv = cfg.governance_manual_csv
    if gov_csv is not None and not Path(gov_csv).exists():
        LOGGER.info("No %s: coding governance variables from the raw 10-K/DEF 14A texts (rule-based)", gov_csv)
        coded = gc.code_panel(cfg.local_dir, panel)
        Path(gov_csv).parent.mkdir(parents=True, exist_ok=True)
        coded.to_csv(gov_csv, index=False)
        rp.write_json(gc.coverage(coded), _out(cfg, "governance_coder_coverage.json"))
    l2 = gf.layer2(panel, manifest, gov_csv)
    X = fe.assemble(panel, scores, drift, l1, ctrl, l2)
    X = fe.join(X, _rp_coded_features(cfg, panel))
    X = fe.join(X, _eightk_features(cfg, panel))
    z_cols = [c for c in Z_COLS if c in X.columns and X[c].notna().any()]
    X = fe.join(X, ff.peer_relative_z(X, z_cols, baseline=cfg.peer_baseline))
    # Lexicon-free peer textual anomaly + the texts themselves (for the stacked text model).
    text_series = pd.Series([texts.get((c, int(y)), "") for c, y in zip(X["cik"], X["fiscal_year"])], index=X.index)
    X["rpt_peer_text_distance"] = tm.peer_text_distance(text_series, X).values
    pd.DataFrame({"cik": X["cik"], "fiscal_year": X["fiscal_year"], "rpt_text": text_series}).to_csv(_out(cfg, "panel_texts.csv"), index=False)
    X.to_csv(_out(cfg, "panel_features.csv"), index=False)
    summary = pn.panel_summary(X, cfg)
    summary["dataset_version"] = _dataset_version(cfg)
    summary["rpt_text_source"] = X["rpt_source"].value_counts().to_dict()
    summary["clusters_by_stratum"] = X.drop_duplicates("cluster_id")["stratum"].value_counts().to_dict()
    summary["case_strata_trained"] = list(cfg.case_strata) if cfg.case_strata else "all"
    rp.write_json(summary, _out(cfg, "panel_summary.json"))
    train = _training(cfg, X)
    rp.write_table(rp.coverage(train, fe.feature_list()), _out(cfg, "tables"), "feature_coverage",
                   "Share of training firm-years with a non-missing value, by feature and group")
    rp.write_table(rp.descriptives(train, fe.feature_list()), _out(cfg, "tables"), "descriptives",
                   f"Descriptive statistics over the training window: {rp.panel_caption(train, cfg)}")
    LOGGER.info("Panel built: %s", summary)
    return X


def step_model(cfg: PanelConfig) -> None:
    X = _load_features(cfg)
    train = _training(cfg, X)
    features, groups, dropped = _feature_set(cfg, X)
    if train["fraud_aaer_label"].nunique() < 2 or train["cluster_id"].nunique() < 2:
        raise SystemExit("Training window needs >=2 clusters and both classes")
    LOGGER.info("Training rows=%s positives=%s clusters=%s features=%s (dropped for missingness: %s)",
                len(train), int(train["fraud_aaer_label"].sum()), train["cluster_id"].nunique(), len(features), dropped)
    texts = _load_texts(cfg, train)
    metrics, folds, oof_rows, scores_by_model, used_features = [], [], [], {}, features
    for model in cfg.models:
        res = md.fit_oof(train, features, model, cfg, texts=texts)
        used_features = res.features
        ev = md.evaluate(train, res, cfg)
        metrics.append(ev)
        folds += [{"model": model, **m} for m in res.fold_metrics]
        scores_by_model[model] = res.scores
        oof_rows.append(pd.DataFrame({"cik": train["cik"], "fiscal_year": train["fiscal_year"], "model": model, "score": res.scores.values}))
        if res.shap_values is not None:
            shap_df = res.shap_values.copy()
            shap_df.insert(0, "fiscal_year", train["fiscal_year"].values)
            shap_df.insert(0, "cik", train["cik"].values)
            shap_df.to_csv(_out(cfg, f"oof_shap_{model}.csv"), index=False)
        LOGGER.info("%s: OOF AUC %.3f [%.3f, %.3f]", model, ev["oof_auc"], ev["oof_auc_ci_low"], ev["oof_auc_ci_high"])
        if res.text_oof is not None and res.text_oof.notna().any() and model == cfg.models[0]:
            text_only = md.OOFResult(model="text_tfidf_only", features=["text_risk"], scores=res.text_oof, shap_values=None)
            ev_t = md.evaluate(train, text_only, cfg)
            metrics.append(ev_t)
            oof_rows.append(pd.DataFrame({"cik": train["cik"], "fiscal_year": train["fiscal_year"], "model": "text_tfidf_only", "score": res.text_oof.values}))
            LOGGER.info("text_tfidf_only: OOF AUC %.3f", ev_t["oof_auc"])
    if cfg.alert_model == "ensemble":
        ens = md.mean_ensemble(scores_by_model)
        ev = md.evaluate(train, md.OOFResult(model="ensemble", features=used_features, scores=ens, shap_values=None), cfg)
        metrics.append(ev)
        scores_by_model["ensemble"] = ens
        oof_rows.append(pd.DataFrame({"cik": train["cik"], "fiscal_year": train["fiscal_year"], "model": "ensemble", "score": ens.values}))
        LOGGER.info("ensemble: OOF AUC %.3f [%.3f, %.3f]", ev["oof_auc"], ev["oof_auc_ci_low"], ev["oof_auc_ci_high"])
    pd.concat(oof_rows).to_csv(_out(cfg, "oof_scores.csv"), index=False)
    if "stratum" in train.columns and train["stratum"].nunique() > 1:
        by_stratum = []
        for stratum, sub in train.groupby("stratum"):
            for name, s in scores_by_model.items():
                res_s = md.OOFResult(model=name, features=used_features, scores=s.reindex(sub.index), shap_values=None)
                by_stratum.append({"stratum": stratum, **md.evaluate(sub, res_s, cfg)})
        rp.write_table(pd.DataFrame(by_stratum), _out(cfg, "tables"), "oof_metrics_by_stratum",
                       "Out-of-fold discrimination within each case stratum (same OOF scores; clusters of that stratum only)")
    pd.DataFrame(folds).to_csv(_out(cfg, "fold_metrics.csv"), index=False)
    rp.write_table(pd.DataFrame(metrics), _out(cfg, "tables"), "oof_metrics",
                   f"Out-of-fold discrimination (leave-one-cluster-out): {rp.panel_caption(train, cfg)}")
    primary = _primary_model(cfg)
    alert = cfg.alert_model if cfg.alert_model in scores_by_model else primary
    threshold = st.choose_threshold(scores_by_model[alert], train["fraud_aaer_label"], cfg.target_fpr)
    final_members, text_model = {}, None
    for model in cfg.models:
        pipe, text_model = md.fit_final(train, features, model, cfg, texts=texts)
        final_members[model] = pipe
        md.save_model(pipe, used_features, groups, threshold, cfg, _dataset_version(cfg), _out(cfg, "models", f"rpt_panel_{model}.pkl"),
                      metrics=next(m for m in metrics if m["model"] == model), text_model=text_model)
    if alert == "ensemble":
        md.save_model(None, used_features, groups, threshold, cfg, _dataset_version(cfg), _out(cfg, "models", "rpt_panel_ensemble.pkl"),
                      metrics=next(m for m in metrics if m["model"] == "ensemble"), text_model=text_model, ensemble_members=final_members)
    if text_model is not None and text_model.fitted:
        rp.write_table(text_model.top_terms(), _out(cfg, "tables"), "text_model_terms",
                       "Lexicon-free text model: TF-IDF terms with the largest positive (risk) and negative (protective) logit coefficients", digits=3)
    rp.write_json({"primary_model": primary, "alert_model": alert, "threshold": threshold, "target_fpr": cfg.target_fpr,
                   "features": used_features, "feature_groups": groups, "dropped_features": dropped,
                   "stack_text": bool(texts is not None), "peer_baseline": cfg.peer_baseline}, _out(cfg, "model_spec.json"))


def step_stress(cfg: PanelConfig) -> None:
    X = _load_features(cfg)
    train = _training(cfg, X)
    spec = json.loads(_out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    primary, threshold = spec["primary_model"], float(spec["threshold"])
    alert = spec.get("alert_model", primary)
    scores = _scores_for(cfg, train, alert)
    cases = da.read_cases(cfg)
    out = _out(cfg, "stress_tests")
    texts = _load_texts(cfg, train) if spec.get("stack_text") else None
    t1 = st.t1_specificity(train)
    # Ablation for every model class; the summary row uses the pre-specified primary.
    t2_all = pd.concat([md.ablation(train, dict(spec["feature_groups"]), m, cfg, texts=texts) for m in cfg.models], ignore_index=True)
    t2 = t2_all[t2_all["model"] == primary].reset_index(drop=True)
    t3 = st.t3_lead_time(train, scores, threshold, cases)
    t4 = st.t4_mw_persistence(train)
    t5 = st.t5_clean_fpr(scores, train["fraud_aaer_label"], threshold, cfg.target_fpr)
    rp.write_table(t1, out, "t1_specificity", "T1 specificity: vagueness/masking in related-party text minus Item 1 of the same filing")
    rp.write_table(t2_all, out, "t2_ablation", "T2 ablation: out-of-fold AUC with each layer removed, by model class")
    rp.write_table(t3, out, "t3_lead_time", f"T3 lead time: first out-of-fold alert of the {alert} score (threshold {threshold:.3f}) to first public revelation", digits=1)
    rp.write_table(t4, out, "t4_mw_persistence", "T4 material-weakness persistence and subsequent escalation of disclosure signals")
    rp.write_json(t5, out / "t5_clean_fpr.json")
    rp.write_table(st.summary(t1, t2, t3, t4, t5), out, "stress_summary", "Summary of the five forensic stress tests (Holm-adjusted p where applicable)")
    fg.plot_lead_time(t3, out / "fig_lead_time.png")
    LOGGER.info("Stress tests written to %s", out)


def step_mediate(cfg: PanelConfig) -> None:
    X = _load_features(cfg)
    train = _training(cfg, X)
    table = med.run_mediation_suite(train, cfg.n_boot, cfg.seed)
    rp.write_table(table, _out(cfg, "tables"), "mediation",
                   f"P4 cluster-bootstrap mediation ({cfg.n_boot} resamples; firms resampled): indirect effects through V and A", digits=4)
    spec = json.loads(_out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    for name, fn in (("logit_clustered", inf.clustered_logit), ("logit_conditional", inf.conditional_logit)):
        for layer, feats in spec["feature_groups"].items():
            if not feats or layer == "controls":
                continue
            tab = fn(train, feats + spec["feature_groups"].get("controls", []))
            if not tab.empty:
                tab.insert(0, "layer", layer)
                rp.write_table(tab, _out(cfg, "tables"), f"{name}_{layer}", f"{name.replace('_', ' ')}: {layer} indicators (standardised) with controls", digits=3)
    LOGGER.info("Mediation and regression tables written")


def step_explain(cfg: PanelConfig) -> None:
    X = _load_features(cfg)
    train = _training(cfg, X)
    spec = json.loads(_out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    results = {m: _load_oof_result(cfg, train, m, spec["features"]) for m in cfg.models}
    results = {m: r for m, r in results.items() if r.shap_values is not None}
    out = _out(cfg, "explainability")
    attribution = ex.attribution_table(results)
    rp.write_table(attribution, out, "attribution", "Mean absolute out-of-fold SHAP by feature and model", digits=4)
    rp.write_table(ex.attribution_stability(results, cfg), out, "stability", "Attribution stability: Spearman rank correlation of importance rankings across models and bootstrap resamples")
    master = da.load_master_panel(cfg.local_dir)
    primary = spec["primary_model"]
    if primary in results:
        text_model = pr.load_model(_out(cfg, "models", f"rpt_panel_{primary}.pkl")).get("text_model")
        trace = ex.traceability(results[primary], train, master, cfg, text_model=text_model)
        rp.write_table(trace, out, "traceability", f"Traceability of top-3 attributions ({primary}) to a located filing passage or XBRL tag", digits=3)
        rp.write_json({"share_traceable": trace.attrs.get("share_traceable"), "share_traceable_cases": trace.attrs.get("share_traceable_cases")}, out / "traceability_summary.json")
    fg.plot_shap_summary(attribution, out / "fig_shap_summary.png")


def step_report(cfg: PanelConfig) -> None:
    X = _load_features(cfg)
    train = _training(cfg, X)
    metrics = pd.read_csv(_out(cfg, "tables", "oof_metrics.csv"))
    scores = {m: _scores_for(cfg, train, m) for m in metrics["model"]}
    figs = _out(cfg, "figures")
    fg.plot_oof_roc(train["fraud_aaer_label"], scores, metrics, figs / "fig_oof_roc.png")
    fg.plot_z_heatmap(X, [c for c in X.columns if c.endswith("_z")], figs / "fig_z_heatmap.png")
    fg.plot_drift(X, figs / "fig_drift.png")
    z_cols = [c for c in X.columns if c.endswith("_z")]
    rp.write_table(X.loc[X["case_role"] == "case", ["ticker", "fiscal_year", "event_time"] + z_cols], _out(cfg, "tables"), "z_scores",
                   "Peer-relative z-scores of case firms (NaN where fewer than two peers reported the item)", digits=2)
    # Local explanations: one waterfall per case firm for its highest-scoring pre-revelation year, per model.
    spec = json.loads(_out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    for model in cfg.models:
        res = _load_oof_result(cfg, train, model, spec["features"])
        if res.shap_values is None:
            continue
        for cik, firm in train[train["case_role"] == "case"].groupby("cik"):
            s = res.scores.reindex(firm.index).dropna()
            if s.empty:
                continue
            idx = s.idxmax()
            row = train.loc[idx]
            ticker = row.get("ticker")
            label = ticker if isinstance(ticker, str) and ticker.strip() else str(row["cluster_id"])
            fg.plot_case_waterfall(res.shap_values.loc[idx], float(s.loc[idx]), f"{label} FY{int(row['fiscal_year'])} ({model})",
                                   figs / f"fig_waterfall_{label}_{model}.png")
    alert = spec.get("alert_model", spec["primary_model"])
    shown = list(cfg.models) + (["ensemble"] if alert == "ensemble" else [])
    fg.plot_oof_scores_by_event_time(train, {m: _scores_for(cfg, train, m) for m in shown}, float(spec["threshold"]), figs / "fig_scores_event_time.png")
    fg.plot_calibration(train["fraud_aaer_label"], _scores_for(cfg, train, alert), float(spec["threshold"]), figs / "fig_calibration.png")
    LOGGER.info("Figures written to %s", figs)


def step_infer(cfg: PanelConfig, model_path: Path | None, data_path: Path | None) -> None:
    if model_path is None:  # score with this run's own primary model
        spec = json.loads(_out(cfg, "model_spec.json").read_text(encoding="utf-8"))
        model_path = _out(cfg, "models", f"rpt_panel_{spec['primary_model']}.pkl")
    model = pr.load_model(model_path)  # an external model (e.g. the core run's) carries its own threshold and features
    X = pd.read_csv(data_path, dtype={"cik": str}) if data_path else _load_features(cfg)
    preds = pr.predict(model, X, dataset_version=_dataset_version(cfg))
    preds.to_csv(_out(cfg, "predictions.csv"), index=False)
    LOGGER.info("Predictions written: %s rows, %s flagged", len(preds), int(preds["flagged"].sum()))


STEPS = {"download": step_download, "build": step_build, "model": step_model, "stress": step_stress,
         "mediate": step_mediate, "explain": step_explain, "report": step_report}


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description="rpt_panel: leak-free RPT fraud-risk panel modelling")
    parser.add_argument("step", choices=list(STEPS) + ["infer", "all"])
    parser.add_argument("--config", type=Path, default=None, help="JSON with PanelConfig fields")
    parser.add_argument("--skip-download", action="store_true", help="with 'all': use the existing local mirror")
    parser.add_argument("--model-path", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=None, help="infer: CSV of firm-years with the training feature columns")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args(argv)
    logging.basicConfig(level=args.log_level, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    cfg = load_config(args.config)
    if args.step == "infer":
        step_infer(cfg, args.model_path, args.data)
        return
    if args.step == "all":
        for name, fn in STEPS.items():
            if name == "download" and args.skip_download:
                continue
            LOGGER.info("==== %s ====", name)
            fn(cfg)
        return
    STEPS[args.step](cfg)


if __name__ == "__main__":
    main()
