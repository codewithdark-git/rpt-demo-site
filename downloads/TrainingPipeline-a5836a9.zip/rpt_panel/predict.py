"""Score new firm-years with a saved pipeline, reproducing the training feature path exactly."""
from __future__ import annotations

import logging
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)


def load_model(path: Path) -> dict:
    # Pickle is required to round-trip fitted sklearn/xgboost pipelines. Only load
    # models produced by this project's own `modelling.save_model` (trusted, local).
    with Path(path).open("rb") as f:
        payload = pickle.load(f)
    for key in ("pipeline", "features", "threshold", "dataset_version"):
        if key not in payload:
            raise ValueError(f"model file {path} lacks '{key}'")
    return payload


def predict(model: dict, X: pd.DataFrame, dataset_version: str | None = None, force: bool = False) -> pd.DataFrame:
    """Missing feature columns become NaN and are imputed with the *training* medians inside the pipeline.

    The alert flag uses the threshold chosen at training (clean-firm FPR target),
    never a default 0.5. A dataset-version mismatch is refused unless ``force``.
    """
    if dataset_version and dataset_version != model["dataset_version"] and not force:
        raise ValueError(f"model trained on dataset {model['dataset_version']}, data is {dataset_version}; pass force=True to override")
    features = model["features"]
    Xf = X.reindex(columns=features)
    text_model = model.get("text_model")
    if text_model is not None and "text_risk" in features:
        if "rpt_text" in X.columns:
            Xf["text_risk"] = text_model.predict_proba(X["rpt_text"]).values
        else:
            LOGGER.warning("no 'rpt_text' column: the stacked text_risk feature is imputed with its training median")
    missing = [f for f in features if f not in X.columns and f != "text_risk"]
    if missing:
        LOGGER.warning("%s feature(s) absent and imputed with training medians: %s", len(missing), missing)
    members = model.get("ensemble_members")
    if members:
        scores = np.mean([p.predict_proba(Xf)[:, 1] for p in members.values()], axis=0)
    else:
        scores = model["pipeline"].predict_proba(Xf)[:, 1]
    out = pd.DataFrame({
        "cik": X["cik"].values if "cik" in X.columns else np.arange(len(X)),
        "fiscal_year": X["fiscal_year"].values if "fiscal_year" in X.columns else np.nan,
        "risk_score": scores,
        "flagged": (scores >= model["threshold"]).astype(int),
        "threshold": model["threshold"],
        "model_dataset_version": model["dataset_version"],
    })
    if "ticker" in X.columns:
        out.insert(1, "ticker", X["ticker"].values)
    return out
