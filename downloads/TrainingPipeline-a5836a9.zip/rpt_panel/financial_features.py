"""Layer 1 (financial) features, controls and peer-relative z-scores from as-first-reported XBRL."""
from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np
import pandas as pd

KEY = ["cik", "fiscal_year"]


def _col(df: pd.DataFrame, name: str) -> pd.Series:
    """XBRL column (prefixed ``xbrl_`` in master_panel), NaN if absent."""
    for candidate in (f"xbrl_{name}", name):
        if candidate in df.columns:
            return pd.to_numeric(df[candidate], errors="coerce")
    return pd.Series(np.nan, index=df.index, dtype=float)


def _safe_ratio(num: pd.Series, den: pd.Series) -> pd.Series:
    den = den.where(den.abs() > 0)
    return num / den


def _bounded(series: pd.Series, lo: float, hi: float) -> pd.Series:
    """Clip a ratio at fixed economic bounds; NaN stays NaN."""
    return series.clip(lower=lo, upper=hi)


def layer1(df: pd.DataFrame) -> pd.DataFrame:
    """RPT materiality, related receivables, abnormal related sales, earnings-cash divergence, accruals."""
    df = df.sort_values(KEY)
    revenue, assets = _col(df, "revenue"), _col(df, "total_assets")
    net_income, ocf = _col(df, "net_income"), _col(df, "operating_cash_flow")
    rp_amount = _col(df, "rp_transaction_amount").fillna(_col(df, "rp_revenue") + _col(df, "rp_expenses").fillna(0))
    rp_receivables = (
        _col(df, "due_from_related_parties_current").fillna(0)
        + _col(df, "due_from_related_parties_noncurrent").fillna(0)
        + _col(df, "notes_receivable_related_parties").fillna(0)
    )
    any_rp_rec = _col(df, "due_from_related_parties_current").notna() | _col(df, "due_from_related_parties_noncurrent").notna() | _col(df, "notes_receivable_related_parties").notna()
    rp_sales_ratio = _safe_ratio(_col(df, "rp_revenue"), revenue)
    lag_assets = assets.groupby(df["cik"]).shift(1)
    consecutive = (df["fiscal_year"] - df.groupby("cik")["fiscal_year"].shift(1)) == 1
    out = pd.DataFrame({
        "cik": df["cik"],
        "fiscal_year": df["fiscal_year"],
        # Disclosed RPT amount scaled by revenue; NaN when no RPT tag was reported (hand-collect from rp_note.txt).
        "rpt_to_revenue": _safe_ratio(rp_amount, revenue),
        "rp_receivables_to_assets": _safe_ratio(rp_receivables.where(any_rp_rec), assets),
        "rp_sales_ratio": rp_sales_ratio,
        # Year-on-year change in the related-sales share (firm-level residual; industry model needs a wider universe).
        "abnormal_rp_sales": (rp_sales_ratio - rp_sales_ratio.groupby(df["cik"]).shift(1)).where(consecutive),
        # Asset-scaled flows are bounded at +/-1: values beyond that arise only from near-zero
        # denominators (shells) and would otherwise dominate any standardised model (label-free, fixed bounds).
        "earnings_cash_divergence": _bounded(_safe_ratio(net_income - ocf, assets), -1, 1),
        "accruals": _bounded(_safe_ratio(net_income - ocf, lag_assets).where(consecutive), -1, 1),
        "rpt_tag_reported": rp_amount.notna().astype(int),
    })
    return out.reset_index(drop=True)


def controls(df: pd.DataFrame, filing_manifest: pd.DataFrame | None = None) -> pd.DataFrame:
    """ln(assets), leverage, ROA and listing age (years since the first 10-K in the manifest)."""
    assets = _col(df, "total_assets")
    out = pd.DataFrame({
        "cik": df["cik"],
        "fiscal_year": df["fiscal_year"],
        "ln_assets": np.log(assets.where(assets > 0)),
        "leverage": _bounded(_safe_ratio(_col(df, "total_liabilities"), assets), 0, 3),
        "roa": _bounded(_safe_ratio(_col(df, "net_income"), assets), -1, 1),
    })
    if filing_manifest is not None and len(filing_manifest):
        first = pd.to_numeric(filing_manifest["fiscal_year"], errors="coerce").groupby(filing_manifest["cik"]).min()
        out["listing_age"] = out["fiscal_year"] - out["cik"].map(first)
    else:
        out["listing_age"] = np.nan
    return out.reset_index(drop=True)


def peer_relative_z(
    df: pd.DataFrame,
    cols: Sequence[str],
    by: Iterable[str] = ("cluster_id", "fiscal_year"),
    min_peers: int = 2,
    baseline: str = "loo_all",
) -> pd.DataFrame:
    """z = (x - baseline mean) / baseline sd within each cluster-year.

    baseline="loo_all" (default, used for model inputs): every *other* firm in the
    cluster-year, cases and peers alike (leave-one-out). This uses no role or
    label information, so the z-scores are legitimate model features.
    baseline="peers": only ``case_role == 'peer'`` rows (descriptive use).
    sd == 0 or fewer than ``min_peers`` reference firms -> NaN (never +/-inf).
    """
    by = list(by)
    out = df[KEY + [b for b in by if b not in KEY]].copy()
    for col in cols:
        x = pd.to_numeric(df[col], errors="coerce")
        if baseline == "peers":
            ref = x.where(df["case_role"] == "peer")
            g = ref.groupby([df[b] for b in by])
            mean, sd, n = g.transform("mean"), g.transform("std"), g.transform("count")
        elif baseline == "loo_all":
            g = x.groupby([df[b] for b in by])
            n_all, s1, s2 = g.transform("count"), g.transform("sum"), (x ** 2).groupby([df[b] for b in by]).transform("sum")
            own = x.notna().astype(int)
            n = n_all - own
            s1_o, s2_o = s1 - x.fillna(0), s2 - (x.fillna(0) ** 2)
            mean = s1_o / n.where(n > 0)
            var = (s2_o - n * mean ** 2) / (n - 1).where(n > 1)
            sd = np.sqrt(var.clip(lower=0))
        else:
            raise ValueError(f"unknown baseline {baseline!r}")
        sd = sd.where((sd > 0) & (n >= min_peers))
        out[f"{col}_z"] = ((x - mean) / sd).values
        out[f"{col}_peer_n"] = n.fillna(0).astype(int).values
    return out.drop(columns=[b for b in by if b not in KEY]).reset_index(drop=True)
