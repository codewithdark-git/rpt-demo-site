"""Layer 2 (monitoring failure): ICFR flags from Item 9A, restatement proxy, hand-collected governance."""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)
KEY = ["cik", "fiscal_year"]
MANUAL_COLUMNS = ("big4", "ceo_duality", "board_indep", "ac_indep", "auditor_change", "going_concern_opinion")
AMENDMENT_FORMS = {"10-K/A", "10-K405/A", "10-KSB/A", "10-KSB40/A", "10-KT/A"}


def _flag(df: pd.DataFrame, name: str) -> pd.Series:
    for candidate in (f"extract_{name}", name):
        if candidate in df.columns:
            return pd.to_numeric(df[candidate], errors="coerce")
    return pd.Series(np.nan, index=df.index, dtype=float)


def layer2(
    df: pd.DataFrame,
    filing_manifest: pd.DataFrame | None = None,
    governance_manual_csv: Path | None = None,
) -> pd.DataFrame:
    df = df.sort_values(KEY)
    reported = _flag(df, "material_weakness_reported")
    prev_reported = reported.groupby(df["cik"]).shift(1)
    consecutive = (df["fiscal_year"] - df.groupby("cik")["fiscal_year"].shift(1)) == 1
    out = pd.DataFrame({
        "cik": df["cik"],
        "fiscal_year": df["fiscal_year"],
        "icfr_text_available": _flag(df, "icfr_text_available"),
        "icfr_not_effective": _flag(df, "icfr_not_effective"),
        "dcp_not_effective": _flag(df, "dcp_not_effective"),
        "material_weakness_reported": reported,
        "material_weakness_remediated": _flag(df, "material_weakness_remediated"),
        "mw_count": _flag(df, "material_weakness_mentions"),
        # ICFR is assessed annually: persistence = weakness reported in this and the previous fiscal year.
        "mw_persistence_2yr": ((reported == 1) & (prev_reported == 1)).astype(float).where(consecutive & reported.notna() & prev_reported.notna()),
        "auditor_attestation_exempt": _flag(df, "auditor_attestation_exempt"),
    })
    out["restatement_proxy"] = _restatement_proxy(df, filing_manifest)
    manual = _load_manual(governance_manual_csv)
    if manual is not None:
        out = out.merge(manual, on=KEY, how="left")
    else:
        for col in MANUAL_COLUMNS:
            out[col] = np.nan
    return out.reset_index(drop=True)


def _restatement_proxy(df: pd.DataFrame, manifest: pd.DataFrame | None) -> pd.Series:
    """1 if an amended annual report (10-K/A) exists for the same fiscal year.

    Only a proxy: many 10-K/As add Part III rather than restate. NaN when the
    manifest was built without ``--include-amendments``.
    """
    if manifest is None or "form" not in manifest.columns or not manifest["form"].isin(AMENDMENT_FORMS).any():
        return pd.Series(np.nan, index=df.index, dtype=float)
    amended = manifest[manifest["form"].isin(AMENDMENT_FORMS)]
    keys = set(zip(amended["cik"], pd.to_numeric(amended["fiscal_year"], errors="coerce")))
    return pd.Series([(c, y) in keys for c, y in zip(df["cik"], df["fiscal_year"])], index=df.index).astype(float)


def _load_manual(path: Path | None) -> pd.DataFrame | None:
    """Hand-collected DEF 14A variables: cik, fiscal_year, big4, ceo_duality, board_indep, ac_indep, auditor_change, source_url."""
    if not path or not Path(path).exists():
        LOGGER.warning("No governance_manual.csv: board/audit-committee/CEO-duality/Big-4 variables are NaN")
        return None
    manual = pd.read_csv(path, dtype={"cik": str})
    manual["cik"] = manual["cik"].str.zfill(10)
    manual["fiscal_year"] = pd.to_numeric(manual["fiscal_year"], errors="coerce").astype("Int64")
    keep = KEY + [c for c in MANUAL_COLUMNS if c in manual.columns]
    return manual[keep].drop_duplicates(KEY)
