"""Lexicon-free text signals for the related-party disclosure.

1. ``TextRiskModel`` — TF-IDF (uni+bigrams) + penalised logistic regression on
   the RPT text. It is *stacked* into the main model with nested grouped folds
   (``nested_text_risk``): inside every outer training fold the text model is
   fitted on inner folds to score the training rows, and on the whole outer
   training fold to score the held-out cluster, so the stacked feature never
   sees its own label.
2. ``peer_text_distance`` — the novel peer-relative textual anomaly: cosine
   distance between a firm-year's RPT text and the centroid of the *other*
   firms' RPT texts in the same cluster-year (leave-one-out, label-free). It
   operationalises "concealment language relative to matched peers" without a
   hand-built lexicon.
"""
from __future__ import annotations

from typing import Iterable, List, Tuple

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut

MIN_WORDS = 20
MIN_FIRMS = 3   # a term must occur in the texts of at least this many distinct firms
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, CountVectorizer  # noqa: E402

MONTHS = {"january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
          "november", "december", "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec"}
HONORIFICS = {"mr", "mrs", "ms", "dr", "messrs", "mses", "jr", "sr", "esq", "ii", "iii", "iv", "phd", "cpa", "md"}
# Common given names: a firm's executives recur in every one of its filings, so even the >= 3-firm rule
# lets frequent first names through on small panels (observed: "jeffrey" as a top risk term).
FIRST_NAMES = set("""
james john robert michael william david richard joseph thomas charles christopher daniel matthew anthony mark donald steven
paul andrew joshua kenneth kevin brian george timothy ronald edward jason jeffrey ryan jacob gary nicholas eric jonathan
stephen larry justin scott brandon benjamin samuel gregory frank alexander raymond patrick jack dennis jerry tyler aaron jose
henry adam douglas nathan peter zachary kyle walter harold jeremy ethan carl keith roger gerald christian terry sean arthur
austin noah lawrence jesse joe bryan billy jordan albert dylan bruce willie gabriel alan juan logan wayne ralph roy eugene
randy vincent russell louis philip bobby johnny bradley howard fred stanley leonard craig neil glenn marc todd curtis mitchell
mary patricia jennifer linda elizabeth barbara susan jessica sarah karen lisa nancy betty sandra margaret ashley kimberly
emily donna michelle carol amanda melissa deborah stephanie rebecca sharon laura cynthia dorothy amy kathleen angela shirley
anna brenda pamela emma nicole helen samantha katherine christine debra rachel carolyn janet catherine maria heather diane
ruth julie olivia joyce virginia victoria kelly lauren christina joan evelyn judith megan andrea cheryl hannah jacqueline
martha gloria teresa ann sara madison frances kathryn janice jean abigail alice judy sophia grace denise amber doris marilyn
danielle beverly isabella theresa diana natalie brittany charlotte marie kayla alexis lori steve jim bill tom dave mike bob
dan chris jeff ken ron rick doug greg tim pat ed al ted fred stan russ jon rob matt sam ben nick phil pete
""".split())
STOP_WORDS = list(ENGLISH_STOP_WORDS | MONTHS | HONORIFICS | FIRST_NAMES)
TOKEN = r"(?u)\b[a-zA-Z][a-zA-Z'-]+\b"


def _vectorizer(min_df: int = 2, vocabulary=None) -> TfidfVectorizer:
    return TfidfVectorizer(ngram_range=(1, 2), min_df=min_df, max_features=20_000, sublinear_tf=True,
                           stop_words=STOP_WORDS, token_pattern=TOKEN, vocabulary=vocabulary)


def shared_vocabulary(texts: pd.Series, firms: pd.Series, min_firms: int = MIN_FIRMS) -> list[str]:
    """Terms that appear in at least ``min_firms`` distinct firms' texts.

    Firm-specific proper nouns (executives, subsidiaries, product names) occur in
    one firm only; a model that keys on them memorises identity rather than
    disclosure style and cannot generalise to a new firm.
    """
    cv = CountVectorizer(ngram_range=(1, 2), binary=True, stop_words=STOP_WORDS, token_pattern=TOKEN, min_df=1)
    M = cv.fit_transform(texts.fillna(""))
    firm_codes = pd.factorize(firms)[0]
    n_firms = firm_codes.max() + 1
    # firm x term presence
    import scipy.sparse as sp
    F = sp.csr_matrix((np.ones(len(firm_codes)), (firm_codes, np.arange(len(firm_codes)))), shape=(n_firms, len(firm_codes)))
    presence = (F @ M > 0).astype(int)
    firm_df = np.asarray(presence.sum(axis=0)).ravel()
    terms = cv.get_feature_names_out()
    return [t for t, k in zip(terms, firm_df) if k >= min_firms]


def _has_text(texts: pd.Series) -> pd.Series:
    return texts.fillna("").str.split().str.len() >= MIN_WORDS


class TextRiskModel:
    def __init__(self, seed: int = 42, C: float = 0.5, min_firms: int = MIN_FIRMS):
        self.vec = _vectorizer()
        self.clf = LogisticRegression(C=C, class_weight="balanced", max_iter=5000, random_state=seed)
        self.min_firms = min_firms
        self.fitted = False

    def fit(self, texts: pd.Series, y: pd.Series, firms: pd.Series | None = None) -> "TextRiskModel":
        ok = _has_text(texts)
        if ok.sum() < 4 or y[ok].nunique() < 2:
            self.fitted = False
            return self
        if firms is not None:
            vocab = shared_vocabulary(texts[ok], firms.loc[texts[ok].index], self.min_firms)
            if len(vocab) < 10:
                self.fitted = False
                return self
            self.vec = _vectorizer(min_df=1, vocabulary=vocab)
        self.clf.fit(self.vec.fit_transform(texts[ok].fillna("")), y[ok].astype(int))
        self.fitted = True
        return self

    def predict_proba(self, texts: pd.Series) -> pd.Series:
        out = pd.Series(np.nan, index=texts.index, dtype=float)
        if not self.fitted:
            return out
        ok = _has_text(texts)
        if ok.any():
            out[ok] = self.clf.predict_proba(self.vec.transform(texts[ok].fillna("")))[:, 1]
        return out

    def top_terms(self, k: int = 25) -> pd.DataFrame:
        if not self.fitted:
            return pd.DataFrame(columns=["term", "coef"])
        terms = np.asarray(self.vec.get_feature_names_out())
        coef = self.clf.coef_[0]
        order = np.argsort(coef)
        rows = [{"term": terms[i], "coef": float(coef[i]), "direction": "risk"} for i in order[::-1][:k]]
        rows += [{"term": terms[i], "coef": float(coef[i]), "direction": "protective"} for i in order[:k]]
        return pd.DataFrame(rows)


def _inner_splits(groups: pd.Series) -> List[Tuple[np.ndarray, np.ndarray]]:
    X_dummy = np.zeros((len(groups), 1))
    if groups.nunique() <= 10:
        return list(LeaveOneGroupOut().split(X_dummy, groups=groups))
    return list(GroupKFold(n_splits=min(5, groups.nunique())).split(X_dummy, groups=groups))


def nested_text_risk(texts: pd.Series, y: pd.Series, groups: pd.Series, train_index: pd.Index, test_index: pd.Index,
                     seed: int, firms: pd.Series | None = None) -> Tuple[pd.Series, pd.Series]:
    """(scores for training rows from inner folds, scores for test rows from the full training fold).

    ``firms`` (e.g. CIK per row) restricts the vocabulary to terms shared by
    several firms, so the stacked score cannot key on firm identity.
    """
    tr_texts, tr_y, tr_groups = texts.loc[train_index], y.loc[train_index], groups.loc[train_index]
    inner_scores = pd.Series(np.nan, index=train_index, dtype=float)
    if tr_groups.nunique() >= 2:
        for i_tr, i_te in _inner_splits(tr_groups):
            a, b = train_index[i_tr], train_index[i_te]
            if tr_y.loc[a].nunique() < 2:
                continue
            inner_scores.loc[b] = TextRiskModel(seed).fit(tr_texts.loc[a], tr_y.loc[a], firms).predict_proba(tr_texts.loc[b])
    test_scores = TextRiskModel(seed).fit(tr_texts, tr_y, firms).predict_proba(texts.loc[test_index])
    return inner_scores, test_scores


def peer_text_distance(texts: pd.Series, panel: pd.DataFrame, by: Iterable[str] = ("cluster_id", "fiscal_year"),
                       min_others: int = 2) -> pd.Series:
    """Cosine distance from each firm-year's RPT text to the centroid of the other firms in its cluster-year.

    Label-free and role-free: every firm in the group (cases and peers alike)
    contributes to the others' baselines. NaN when the firm has no text or
    fewer than ``min_others`` other firms with text exist in the group.
    """
    by = list(by)
    texts = texts.reindex(panel.index)
    ok = _has_text(texts)
    out = pd.Series(np.nan, index=panel.index, dtype=float)
    if ok.sum() < 3:
        return out
    vec = _vectorizer(min_df=1)
    M = vec.fit_transform(texts[ok].fillna(""))
    norms = np.sqrt(np.asarray(M.multiply(M).sum(axis=1)).ravel())
    pos = {idx: i for i, idx in enumerate(texts[ok].index)}
    for _, group in panel[ok].groupby(by):
        rows = [pos[i] for i in group.index]
        if len(rows) < min_others + 1:
            continue
        sub = M[rows]
        total = np.asarray(sub.sum(axis=0)).ravel()
        for local, idx in zip(range(len(rows)), group.index):
            others = total - sub[local].toarray().ravel()
            denom = norms[rows[local]] * np.linalg.norm(others)
            if denom > 0:
                out.loc[idx] = 1.0 - float(sub[local].toarray().ravel() @ others) / denom
    return out
