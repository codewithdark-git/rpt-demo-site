"""P4: bootstrap mediation of Layer 1/2 indicators on enforcement through disclosure (V, A).

Replaces the legacy ``se = 0.15 * |coef|`` shortcut. Standard errors and
confidence intervals come from a cluster bootstrap (firms resampled with
replacement), which is the only honest option with few clusters. The result is
framed as *consistent with* mediation; it does not establish causation.
"""
from __future__ import annotations

import logging
import warnings
from dataclasses import asdict, dataclass
from typing import Sequence

import numpy as np
import pandas as pd
import statsmodels.api as sm

LOGGER = logging.getLogger(__name__)


@dataclass
class MediationResult:
    x: str
    mediator: str
    y: str
    covariates: str
    n: int
    n_clusters: int
    a: float            # x -> mediator (OLS, standardised)
    b: float            # mediator -> y | x (logit)
    c_prime: float      # x -> y | mediator (logit, direct)
    c_total: float      # x -> y (logit, total)
    indirect: float     # a * b
    se_boot: float
    ci_low: float
    ci_high: float
    prop_mediated: float
    n_boot: int
    n_boot_ok: int

    def as_row(self) -> dict:
        return asdict(self)


def _standardise(df: pd.DataFrame, cols: Sequence[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        sd = out[c].std(ddof=1)
        out[c] = (out[c] - out[c].mean()) / sd if sd and sd > 0 else 0.0
    return out


def _logit_coefs(y: pd.Series, X: pd.DataFrame) -> pd.Series:
    """Logit coefficients; falls back to a lightly penalised fit under (quasi-)separation."""
    Xc = sm.add_constant(X, has_constant="add")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            res = sm.Logit(y, Xc).fit(disp=0, maxiter=200, method="bfgs")
            if np.isfinite(res.params).all() and res.params.abs().max() < 25:
                return res.params
        except Exception:
            pass
        res = sm.Logit(y, Xc).fit_regularized(alpha=0.5, L1_wt=0.0, disp=0, maxiter=500)
        return pd.Series(np.asarray(res.params).ravel(), index=Xc.columns)


def _paths(data: pd.DataFrame, x: str, m: str, y: str, cov: Sequence[str]) -> tuple[float, float, float, float]:
    cov = list(cov)
    a = sm.OLS(data[m], sm.add_constant(data[[x] + cov], has_constant="add")).fit().params[x]
    full = _logit_coefs(data[y], data[[x, m] + cov])
    total = _logit_coefs(data[y], data[[x] + cov])
    return float(a), float(full[m]), float(full[x]), float(total[x])


def bootstrap_mediation(
    df: pd.DataFrame,
    x: str,
    mediator: str,
    y: str = "fraud_aaer_label",
    covariates: Sequence[str] = (),
    n_boot: int = 1000,
    cluster: str = "cik",
    seed: int = 42,
) -> MediationResult:
    cols = [x, mediator, y, *covariates]
    data = df[cols + [cluster]].dropna().copy()
    data[y] = data[y].astype(int)
    data = _standardise(data, [x, mediator, *covariates])
    if data[y].nunique() < 2 or len(data) < 10:
        raise ValueError(f"mediation needs both outcome classes and >=10 complete rows (got {len(data)})")
    a, b, c_prime, c_total = _paths(data, x, mediator, y, covariates)
    indirect = a * b
    rng = np.random.default_rng(seed)
    clusters = data[cluster].unique()
    by_cluster = {g: data.index[data[cluster] == g] for g in clusters}
    boots = []
    for _ in range(n_boot):
        idx = np.concatenate([by_cluster[g] for g in rng.choice(clusters, size=len(clusters), replace=True)])
        sample = data.loc[idx]
        if sample[y].nunique() < 2 or sample[mediator].std() == 0 or sample[x].std() == 0:
            continue
        try:
            ba, bb, *_ = _paths(sample, x, mediator, y, covariates)
            boots.append(ba * bb)
        except Exception:
            continue
    boots_arr = np.asarray(boots, dtype=float)
    se = float(boots_arr.std(ddof=1)) if len(boots_arr) > 1 else np.nan
    lo, hi = (float(np.percentile(boots_arr, 2.5)), float(np.percentile(boots_arr, 97.5))) if len(boots_arr) > 1 else (np.nan, np.nan)
    prop = indirect / (indirect + c_prime) if (indirect + c_prime) != 0 and np.sign(indirect) == np.sign(c_prime) else np.nan
    return MediationResult(
        x=x, mediator=mediator, y=y, covariates="+".join(covariates), n=int(len(data)), n_clusters=int(len(clusters)),
        a=a, b=b, c_prime=c_prime, c_total=c_total, indirect=float(indirect), se_boot=se, ci_low=lo, ci_high=hi,
        prop_mediated=float(prop) if prop is not None else np.nan, n_boot=n_boot, n_boot_ok=int(len(boots_arr)),
    )


def run_mediation_suite(df: pd.DataFrame, n_boot: int, seed: int, covariates: Sequence[str] = ("ln_assets",)) -> pd.DataFrame:
    """P4 paths: Layer 1 and Layer 2 indicators -> enforcement, through V and A."""
    specs = [
        ("earnings_cash_divergence", "rpt_vagueness"),
        ("earnings_cash_divergence", "rpt_agency_masking"),
        ("rpt_to_revenue", "rpt_vagueness"),
        ("rpt_to_revenue", "rpt_agency_masking"),
        ("material_weakness_reported", "rpt_vagueness"),
        ("material_weakness_reported", "rpt_agency_masking"),
    ]
    rows = []
    cov = [c for c in covariates if c in df.columns and df[c].notna().any()]
    # Ratio variables are winsorised (1st/99th percentile) as in the regression tables; a handful of
    # extreme accrual or leverage values otherwise dominate the bootstrap distribution.
    from .inference_stats import winsorise
    df = df.copy()
    for c in {x for x, _ in specs} | {m for _, m in specs} | set(cov):
        if c in df.columns:
            df[c] = winsorise(df[c])
    for x, m in specs:
        if x not in df.columns or m not in df.columns or df[x].notna().sum() < 10 or df[x].std() == 0:
            rows.append({"x": x, "mediator": m, "status": "skipped: insufficient data"})
            continue
        try:
            res = bootstrap_mediation(df, x, m, covariates=cov, n_boot=n_boot, seed=seed)
            rows.append({**res.as_row(), "status": "ok"})
        except Exception as exc:
            rows.append({"x": x, "mediator": m, "status": f"failed: {exc}"})
    return pd.DataFrame(rows)
