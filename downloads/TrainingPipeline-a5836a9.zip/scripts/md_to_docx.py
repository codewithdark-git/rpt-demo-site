"""Convert a simple Markdown report (headings, paragraphs, bullet lists, pipe tables, inline code/bold) to .docx.

    python scripts/md_to_docx.py docs/REPORT.md [docs/REPORT.docx]
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt

INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`)")


def add_inline(paragraph, text: str) -> None:
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(9)
        else:
            paragraph.add_run(part)


def flush_table(doc, rows: list[list[str]]) -> None:
    if not rows:
        return
    body = [r for r in rows if not all(re.fullmatch(r":?-{2,}:?", c.strip()) for c in r)]
    ncol = max(len(r) for r in body)
    table = doc.add_table(rows=len(body), cols=ncol)
    table.style = "Light Grid Accent 1"
    for i, row in enumerate(body):
        for j in range(ncol):
            cell = table.cell(i, j)
            cell.text = ""
            p = cell.paragraphs[0]
            add_inline(p, row[j].strip() if j < len(row) else "")
            for run in p.runs:
                run.font.size = Pt(8.5)
                if i == 0:
                    run.bold = True
    doc.add_paragraph()


def convert(md_path: Path, out_path: Path) -> Path:
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)
    table_rows: list[list[str]] = []
    for raw in md_path.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip()
        if line.startswith("|"):
            table_rows.append([c for c in line.strip().strip("|").split("|")])
            continue
        flush_table(doc, table_rows)
        table_rows = []
        if not line.strip():
            continue
        m = re.match(r"^(#{1,4})\s+(.*)", line)
        if m:
            doc.add_heading(m.group(2).strip(), level=len(m.group(1)))
            continue
        m = re.match(r"^!\[(.*?)\]\((.*?)\)\s*$", line.strip())
        if m:
            img = Path(m.group(2))
            if not img.is_absolute():
                img = md_path.parent / img
            if img.exists():
                doc.add_picture(str(img), width=Inches(6.0))
                cap = doc.add_paragraph(m.group(1))
                cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in cap.runs:
                    run.italic = True
                    run.font.size = Pt(9)
            continue
        m = re.match(r"^\s*[-*]\s+(.*)", line)
        if m:
            add_inline(doc.add_paragraph(style="List Bullet"), m.group(1))
            continue
        m = re.match(r"^\s*(\d+)\.\s+(.*)", line)
        if m:
            add_inline(doc.add_paragraph(style="List Number"), m.group(2))
            continue
        if line.startswith("```"):
            continue
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        add_inline(p, line.strip())
    flush_table(doc, table_rows)
    doc.save(out_path)
    return out_path


if __name__ == "__main__":
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_suffix(".docx")
    print(convert(src, dst))
