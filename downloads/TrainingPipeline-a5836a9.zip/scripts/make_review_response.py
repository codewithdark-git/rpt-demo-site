"""Response document to the researcher's review of 9 Oct 2026: every instruction and red note answered from the
re-run design battery (scripts/design_tests_v2.py). Numbers are read from the run folders so the document can be
regenerated after any re-run.

    python scripts/make_review_response.py docs/CLIENT_RESPONSE_to_Review_2026-10-10.md
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DT = ROOT / "outputs" / "full_all" / "design_tests_v2"
RUNS = {"core21": "21 misstatement/misappropriation cases only (first battery's sample)", "all30": "30 cases before Gulfport was approved (21 + 9)",
        "main31": "MAIN SAMPLE: 31 cases (21 + 10 disclosure-only incl. Gulfport, approved 10 Oct)", "all36_threereport": "36 cases: the 31 + five three-report cases (needs D3 relaxed; for discussion)",
        "main31_rankall": "31 cases, ranks over all FY2004-2024 firm-years (sensitivity)"}


def md(df: pd.DataFrame, digits: int = 3, cols=None, index=False) -> str:
    df = df.copy()
    if cols:
        df = df[[c for c in cols if c in df.columns]]
    if index:
        df = df.reset_index()
    for c in df.columns:
        if pd.api.types.is_float_dtype(df[c]):
            df[c] = df[c].round(digits)
    head = "| " + " | ".join(str(c) for c in df.columns) + " |"
    sep = "|" + "---|" * len(df.columns)
    rows = ["| " + " | ".join("" if (isinstance(v, float) and np.isnan(v)) else str(v) for v in r) + " |" for r in df.values]
    return "\n".join([head, sep] + rows)


def load(name: str) -> dict | None:
    d = DT / name
    if not (d / "summary.md").exists():
        return None
    out = {"dir": d}
    for f in d.glob("*.csv"):
        try:
            out[f.stem] = pd.read_csv(f)
        except Exception:  # noqa: BLE001
            pass
    out["m3"] = pd.read_csv(d / "m3_layer_correlations.csv", index_col=0)
    out["text_src"] = pd.read_csv(d / "m1_text_source_by_group.csv", index_col=0) if (d / "m1_text_source_by_group.csv").exists() else None
    return out


def sample_line(r: dict) -> dict:
    """Counts from the run's summary line: analysed firm-years, fraud firm-years, sets, cases, matched firms."""
    import re
    txt = (r["dir"] / "summary.md").read_text(encoding="utf-8")
    m = re.search(r"Analysed firm-years: (\d+) \((\d+) fraud firm-years\) in (\d+) matched sets: (\d+) RPT-fraud cases.*?and (\d+) matched firms", txt)
    return {"n": int(m.group(1)), "fraud": int(m.group(2)), "sets": int(m.group(3)), "cases": int(m.group(4)), "peers": int(m.group(5))} if m else {"n": 0, "fraud": 0, "sets": 0, "cases": 0, "peers": 0}


def fmt_eq(p) -> str:
    """'= 0.055' or '< 0.001' for use after the word p."""
    return "" if pd.isna(p) else ("< 0.001" if p < 0.001 else f"= {p:.3f}")


def fmt_p(p: float) -> str:
    return "" if pd.isna(p) else ("< 0.001" if p < 0.001 else f"{p:.3f}")


def h13_table(r: dict) -> str:
    h = r["h1_h3_layer_tests"].copy()
    h["OR per SD [95 % CI]"] = h.apply(lambda x: f"{x['odds_ratio_per_sd']:.2f} [{x['or_ci_low']:.2f}, {x['or_ci_high']:.2f}]", axis=1)
    h["OR 95 % CI, firm-clustered"] = h.apply(lambda x: f"[{x['or_ci_low_firm_cluster']:.2f}, {x['or_ci_high_firm_cluster']:.2f}]", axis=1)
    h["p (model-based)"] = h["p_unadjusted"].map(fmt_p)
    h["p Holm"] = h["p_holm"].map(fmt_p)
    h["p firm-clustered"] = h["p_firm_cluster"].map(fmt_p)
    h["p Holm, firm-clustered"] = h["p_holm_firm_cluster"].map(fmt_p)
    h["firm-years / firms / sets"] = h.apply(lambda x: f"{int(x['n_firm_years'])} / {int(x['n_firms'])} / {int(x['n_matched_sets'])}", axis=1)
    h["fraud firm-years"] = h["n_fraud_firm_years"].astype(int)
    h["direction"] = np.where(h["coef_per_sd"] > 0, "as predicted", "OPPOSITE")
    h["supported (design rule: direction + Holm p < 0.05)"] = np.where(h["supported_design_rule"], "yes", "no")
    h["supported with firm-clustered SE"] = np.where(h["supported_firm_cluster"], "yes", "no")
    return md(h, cols=["hypothesis", "layer_score", "firm-years / firms / sets", "fraud firm-years", "OR per SD [95 % CI]", "p (model-based)", "p Holm",
                       "OR 95 % CI, firm-clustered", "p firm-clustered", "p Holm, firm-clustered", "direction", "supported (design rule: direction + Holm p < 0.05)", "supported with firm-clustered SE"])


def variants_table(r: dict) -> str:
    v = r["h1_h3_variants"].copy()
    v = v[v["n_firm_years"] > 0]
    v["OR per SD [95 % CI]"] = v.apply(lambda x: f"{x['odds_ratio_per_sd']:.2f} [{x['or_ci_low']:.2f}, {x['or_ci_high']:.2f}]" if x["odds_ratio_per_sd"] < 1e6 else "not estimable (separation)", axis=1)
    v["p"] = v["p_unadjusted"].map(fmt_p)
    v["p firm-clustered"] = v["p_firm_cluster"].map(fmt_p)
    v["firm-years / sets"] = v.apply(lambda x: f"{int(x['n_firm_years'])} / {int(x['n_matched_sets'])}", axis=1)
    return md(v, cols=["hypothesis", "variant", "layer_score", "firm-years / sets", "OR per SD [95 % CI]", "p", "p firm-clustered"])


def h5_lines(r: dict) -> list[str]:
    h = r["h5_model_ab"].iloc[0]
    rule = r["h5_design_rule"]
    rule.columns = ["criterion", "met"] if len(rule.columns) == 2 else rule.columns
    return [
        "| Quantity | Value |", "|---|---|",
        f"| Model A (TRAD_INDEX + LEV + ROA), leave-one-set-out AUC | {h['loso_auc_model_A']:.3f} |",
        f"| Model B (Model A + AI_SCORE), leave-one-set-out AUC | {h['loso_auc_model_B']:.3f} |",
        f"| Gain B − A [set-bootstrap 95 % CI] | {h['auc_gain_B_minus_A']:.3f} [{h['auc_gain_ci_low']:.3f}, {h['auc_gain_ci_high']:.3f}] |",
        f"| TRAD_INDEX alone (AUC) / AI_SCORE alone (AUC) | {h['auc_trad_index_alone']:.3f} / {h['auc_ai_score_alone']:.3f} |",
        f"| AI_SCORE in Model B, pooled logit, firm-clustered: coefficient per SD, OR 95 % CI, p | {h['AI_SCORE_coef_per_sd_model_B_pooled']:.3f}, {h['AI_SCORE_or_ci_pooled']}, {fmt_p(h['AI_SCORE_p_model_B_pooled_firm_cluster'])} |",
        f"| AI_SCORE in Model B, conditional logit: coefficient per SD, p (model-based), p (firm-clustered) | {h['AI_SCORE_coef_per_sd_model_B_conditional']:.3f}, {fmt_p(h['AI_SCORE_p_model_B_conditional'])}, {fmt_p(h['AI_SCORE_p_model_B_conditional_firm_cluster'])} |",
        f"| Firm-years / fraud firm-years / sets in Models A and B | {int(h['n_firm_years'])} / {int(h['n_fraud_firm_years'])} / {int(h['n_matched_sets'])} |",
        f"| AI rule at 5 % false-alarm rate: threshold, matched-firm rate, cases flagged / never flagged | {h['ai_threshold_5pct_far']:.2f}, {h['ai_far_at_5pct_rule']:.3f}, {int(h['cases_flagged_ai_5pct'])} / {int(h['cases_never_flagged_ai_5pct'])} of {int(h['cases'])} |",
        f"| Traditional rule at ≤ 5 % false-alarm rate | {h['trad_rule_equal_far']} (matched-firm rate {h['trad_far']:.3f}), flags {int(h['cases_flagged_trad_equal_far'])} cases |",
        f"| AI rule at the SAME false-alarm rate: threshold, rate, cases flagged | {h['ai_threshold_equal_far']:.2f}, {h['ai_far_equal_rule']:.3f}, {int(h['cases_flagged_ai_equal_far'])} |",
        f"| Timing at equal false-alarm rate: AI earlier / same year / traditional earlier / neither flags | {int(h['cases_ai_earlier_equal_far'])} / {int(h['cases_same_year_equal_far'])} / {int(h['cases_trad_earlier_equal_far'])} / {int(h['cases_flagged_by_neither_equal_far'])} |",
        f"| Union of the two rules: false-alarm rate, cases flagged; AI alone at that rate; traditional alone at that rate | {h['union_far']:.3f}, {int(h['cases_flagged_union'])}; {int(h['cases_flagged_ai_alone_at_union_far'])}; {int(h['cases_flagged_trad_alone_at_union_far'])} ({h['trad_rule_at_union_far']}) |",
        "", "Design rule for H5:", "", md(rule),
    ]


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/CLIENT_RESPONSE_to_Review_2026-10-10.md")
    runs = {k: load(k) for k in RUNS}
    A = runs["main31"]
    assert A is not None, "run main31 first"
    C = runs["core21"]
    SL = sample_line(A)
    h = A["h1_h3_layer_tests"].set_index("hypothesis")
    h5 = A["h5_model_ab"].iloc[0]
    h4r = A["h4_design_rule"].set_index("layer_score")
    a2 = A["a2_stability_summary"].iloc[0]
    a3 = A["a3_layers_in_flagged_fraud_firm_years"]
    m1 = A["m1_coverage_by_group"]
    rules = A["scoring_rules"]
    dev = A["deviations"]
    power = A.get("power_simulation")
    expl = A.get("exploratory_fitted_score")
    lead = A["lead_time_by_case"]
    sets_peers = pd.read_csv(ROOT / "cases_core.csv", dtype=str)
    peers_per = sets_peers[sets_peers["role"] == "peer"].groupby("matched_case_id").size()

    def verdict(hyp):
        r = h.loc[hyp]
        d = "as predicted" if r["coef_per_sd"] > 0 else "in the OPPOSITE direction"
        base = f"OR {r['odds_ratio_per_sd']:.2f} per SD [{r['or_ci_low']:.2f}, {r['or_ci_high']:.2f}], {d}; p {fmt_eq(r['p_unadjusted'])}, Holm p {fmt_eq(r['p_holm'])}; firm-clustered p {fmt_eq(r['p_firm_cluster'])} (Holm {fmt_eq(r['p_holm_firm_cluster'])}); {int(r['n_firm_years'])} firm-years, {int(r['n_firms'])} firms, {int(r['n_matched_sets'])} sets"
        s1 = "supported" if r["supported_design_rule"] else "not supported"
        s2 = "supported" if r["supported_firm_cluster"] else "not supported"
        return f"**{s1}** by the design rule with model-based errors; **{s2}** with the firm-clustered errors the design asks for — {base}"

    # cross-sample comparison
    comp = []
    for k, label in RUNS.items():
        r = runs[k]
        if r is None:
            continue
        hh = r["h1_h3_layer_tests"].set_index("hypothesis")
        h5r = r["h5_model_ab"].iloc[0]
        h4x = r["h4_design_rule"].set_index("layer_score")
        comp.append({"sample": label,
                     "H1 OR (p / firm-cl p)": f"{hh.loc['H1','odds_ratio_per_sd']:.2f} ({fmt_p(hh.loc['H1','p_unadjusted'])} / {fmt_p(hh.loc['H1','p_firm_cluster'])})",
                     "H2 OR (p / firm-cl p)": f"{hh.loc['H2','odds_ratio_per_sd']:.2f} ({fmt_p(hh.loc['H2','p_unadjusted'])} / {fmt_p(hh.loc['H2','p_firm_cluster'])})",
                     "H3 OR (p / firm-cl p)": f"{hh.loc['H3','odds_ratio_per_sd']:.2f} ({fmt_p(hh.loc['H3','p_unadjusted'])} / {fmt_p(hh.loc['H3','p_firm_cluster'])})",
                     "H4 layers meeting the rule": ", ".join(i for i, v in h4x["design_rule_met_before_final_year"].items() if v) or "none",
                     "H5 AUC A / B / TRAD alone": f"{h5r['loso_auc_model_A']:.2f} / {h5r['loso_auc_model_B']:.2f} / {h5r['auc_trad_index_alone']:.2f}",
                     "H5 AI_SCORE p (pooled firm-cl)": fmt_p(h5r["AI_SCORE_p_model_B_pooled_firm_cluster"]),
                     "cases flagged by AI rule (5 % FAR) / total": f"{int(h5r['cases_flagged_ai_5pct'])} / {int(h5r['cases'])}",
                     "timing AI earlier / trad earlier (equal FAR)": f"{int(h5r['cases_ai_earlier_equal_far'])} / {int(h5r['cases_trad_earlier_equal_far'])}"})
    comp = pd.DataFrame(comp)

    P: list[str] = []
    P += ["# Response to the researcher's review of 9 October 2026", "",
          "**RPT fraud-risk study — design tests re-run exactly as the design and the review specify** · 10 October 2026 · research assistant", "",
          "This document answers every red note and every numbered instruction in *RPT Research Design – 06.10.26 – REVIEWED against RA report 09.10.26*. "
          "Nothing in the agreed design was changed: the research question, objectives, hypotheses, the eight characteristics, the scoring steps and the AI risk score are as written on 6 October. "
          "The tests were re-run on all qualifying RPT-fraud cases with the design's own rank-averaged AI risk score. Everything built on the fitted 36-input score is now in a separate, labelled exploratory section (§6). "
          "The researcher approved Gulfport Energy as the 31st case on 10 October; the main sample is therefore 31 cases. One thing still needs the researcher's and supervisors' decision before any result is final: the M2 threshold and human coding (§5).", "",
          "## 1. Summary of the honest results (31 cases, design rules applied)", "",
          f"- **Sample.** {int(h5['cases'])} RPT-fraud cases (21 misstatement/misappropriation + 10 disclosure-only including Gulfport Energy, all FRAUD = 1) with {int(peers_per.sum())} matched firms in {int(h5['cases'])} sets; "
          f"{int(A['h1_h3_layer_tests']['n_firm_years'].max())} firm-years in the largest layer test, {SL['n']} window firm-years in all ({SL['fraud']} fraud firm-years).",
          f"- **H1 (financial exposure)**: {verdict('H1')}.",
          f"- **H2 (disclosure less complete and vaguer)**: {verdict('H2')}. The design's second run without the disclosure-only cases gives OR {A['h1_h3_variants'].iloc[0]['odds_ratio_per_sd']:.2f} (p {fmt_eq(A['h1_h3_variants'].iloc[0]['p_unadjusted'])}). H2 is reported as not supported; no re-wording.",
          f"- **H3 (weaker governance)**: {verdict('H3')}. The layer is carried by CEO duality (board share observed in {m1.loc[m1.characteristic=='BRD_NONIND','coverage_all'].iloc[0]:.0%} of firm-years).",
          f"- **H4 (differences in earlier years)**: with the conditional logit as the primary test, the design rule (a significant year before the final year) is met for: {', '.join(i for i, v in h4r['design_rule_met_before_final_year'].items() if v) or 'no layer'}. "
          f"The closest is governance in year −3 (p {fmt_eq(A['h4_by_year'].query('event_year==-3 and layer_score==\"L3_SCORE\"')['cond_p'].iloc[0])}). Fifteen tests with 7–21 informative sets each: limited evidence either way.",
          f"- **H5 (layers add to audit and internal-control signals)**: **not supported** for the design's AI risk score. AI_SCORE is not significant in Model B with firm-clustered errors (p {fmt_eq(h5['AI_SCORE_p_model_B_pooled_firm_cluster'])}); "
          f"Model B's out-of-set AUC ({h5['loso_auc_model_B']:.2f}) is above Model A ({h5['loso_auc_model_A']:.2f}) but below the traditional index alone ({h5['auc_trad_index_alone']:.2f}); at an equal false-alarm rate the AI rule flags {int(h5['cases_flagged_ai_equal_far'])} cases and is earlier than the traditional rule in {int(h5['cases_ai_earlier_equal_far'])}, later in {int(h5['cases_trad_earlier_equal_far'])}; "
          f"{int(h5['cases_flagged_by_neither_equal_far'])} of {int(h5['cases'])} cases are flagged by neither rule.",
          "- **P1**: reported as a pattern only (§4.7). **M1** coverage is now reported by group: a related-party amount is stated in about three times as many fraud firm-years as matched firm-years, so the H1 subset is selected on the outcome (§4.1). **M3** met. **M2** not done (workbook delivered, §5).",
          f"- **A1–A3** re-done on the design score: every assessment is named evidence (A1); re-ranking without each set in turn changes the largest layer in {1-a2['share_largest_layer_unchanged']:.1%} of firm-years (A2); "
          f"in the fraud firm-years the AI rule flags, the largest layer is {a3.sort_values('flagged_fraud_firm_years_where_largest', ascending=False).iloc[0]['layer']} — and the disclosure layer runs *against* its prediction (A3, §4.8).",
          "- **Reading.** On the design as written and on the data as coded, the governance layer separates fraud firms from their matched firms, the financial layer does so only on the small disclosing subset, and the disclosure layer separates them the other way. The rank-averaged AI risk score built from the three does not add to the traditional signals. These are the results to report; the exploratory section shows what a fitted score does, labelled as such.", "",
          ]
    # 2. Sample
    P += ["## 2. The sample (instructions 1 and 10)", "",
          "### 2.1 Qualifying cases restored to one main sample", "",
          "The disclosure-only cases (nine from the screen plus Gulfport Energy, approved on 10 October) are FRAUD = 1 in every test below, as the design specifies. The stratum label is kept only for the design's second H2 run and for descriptive splits. "
          "The first battery's choice to keep them out of the primary test was the assistant's, not the design's; it is withdrawn.", "",
          "| Group | Cases | Firms |", "|---|---|---|",
          "| Misstatement or misappropriation (RPT is the mechanism) | 21 | Ault Alliance, Co-Diagnostics, Eagle Bancorp, Ocwen Financial, Valeant, Manitex, Singularity Future Technology, Puda Coal, General Employment, SAExploration, Ideanomics, United Development Funding IV, FAT Brands, Ammo/Outdoor Holding, MusclePharm, China Valves, Cemtrex, Quadrant 4, Provectus, Corporate Resource Services, Premier Holding |",
          "| Disclosure-only (charge is the missing or incomplete RPT disclosure) | 10 | Skechers, American Electric Power, RCI Hospitality, Greenbrier, Energy XXI, Maximus, Shift4 Payments, First Bancorp (NC), American Equity Investment Life, Gulfport Energy (approved 10 Oct) |",
          f"| Matched firms (rule D4) | — | {int(peers_per.sum())}: {int((peers_per==5).sum())} sets with five, {int((peers_per==4).sum())} with four, {int((peers_per==3).sum())} with three (thin industry pools: {', '.join(peers_per[peers_per<5].index)}) |", "",
          "### 2.2 The screening report and the case for each firm the review asked about", "",
          "The candidate screening report of 8 October (`docs/REPORT_Candidate_Screen_2026-10-08.docx`) is attached again with this response. It records the four discovery sources (every AAER 2005–2024, every litigation release 2010–2025, EDGAR full-text search of issuers' filings, the client workbook), the 58 candidates and the rule each was screened by. "
          "The firms the review lists as 'added' were all found by those searches and pass D1–D4; none was added by judgement:", "",
          "| Firm | Found through | Why it qualifies (D1) | Revelation (D2) | Window / reports |", "|---|---|---|---|---|",
          "| Cemtrex | litigation-release sweep | misappropriation through undisclosed insider dealing and related-party transactions (SEC press release 2021-132) | short-seller report 22 Feb 2017 (medium) | FY2012–2016 / 5 |",
          "| Quadrant 4 System | EDGAR full-text search | misappropriation; CEO and CFO charged (Nov 2016) | 10-K/A revising the Item 13 related-party disclosure, 23 Sep 2016 (medium) | FY2011–2015 / 5 |",
          "| Provectus Biopharmaceuticals | litigation-release sweep | misappropriation: CEO expense reimbursements, undisclosed related-party payments | CEO resignation amid audit-committee review, 29 Feb 2016 (medium) | FY2011–2015 / 5 |",
          "| Corporate Resource Services | AAER sweep (AAER-4007) | misstatement tied to the related-party payroll entity (Tri-State); D1 confirmation open: was the issuer itself charged? | disclosure of unpaid payroll taxes / going concern, 10 Feb 2015 (medium) | FY2010–2014 / 4 |",
          "| Premier Holding Corp | litigation-release sweep (LR-24000) | misstatement through related-party arrangements; revelation date is the SEC action (low confidence; 2016–2017 8-Ks to be read) | 4 Dec 2017 (low) | FY2012–2016 / 5 |",
          "| First Bancorp (NC) | AAER sweep (AAER-3660) | disclosure-only: related-party disclosure failure charged; no earlier public revelation | 1 Jun 2015 (high) | FY2010–2014 / 5 |",
          "| American Equity Investment Life | litigation-release sweep (LR-21431) | disclosure-only: 2006 proxy related-party disclosure (company, CEO, CFO charged) | 3 Mar 2010 (high) | FY2005–2009 / 5 |",
          "| Skechers, AEP, Greenbrier, Maximus, Shift4, RCI, Energy XXI | workbook / AAER sweep | disclosure-only orders (undisclosed perquisites or related-person transactions); no misstatement element in the order | as in the screening report | ≥ 4 reports each |", "",
          "### 2.3 Gulfport Energy — why it was absent and what was found", "",
          "Gulfport was screened NEED_REVELATION_DATE on 2 October: its order (Release 33-10930, 24 Feb 2021; undisclosed CEO perquisites and related-person transactions 2014–2018) is not on the AAER list and no public revelation date had been established, so no window could be set and it entered no group. "
          "On 10 October the firm's own filings were read: the Form 10-Q for Q3 2018 (filed 1 Nov 2018, accession 0001628280-18-013345) discloses that in September 2018 the Audit Committee was informed of the CEO's unauthorised use of chartered aircraft and personal credit-card charges, not identified or disclosed in the proxy statements, and that the CEO stepped down on 29 October 2018. "
          "That is the first public event (D2, high confidence). Window FY2013–2017 with five 10-Ks (D3 met); five SIC-1311 peers matched by rule D4 (log-asset gaps 0.06–0.16). "
          "Gulfport therefore qualifies as a disclosure-only RPT case. Its data were built, its tables and raw filings merged into the core data set, and **the researcher approved it as the 31st case on 10 October 2026**; the main sample in §4 includes it.", "",
          "### 2.4 Reaching 30–35 cases: the options", "",
          "| Option | Cases | What it requires | Status |", "|---|---|---|---|",
          "| A | 30 | nothing: the design's own qualifying cases (21 + 9) | run (§2.5, for comparison) |",
          "| B | 31 | approval of Gulfport Energy (§2.3) | **approved 10 Oct; the main sample (§4)** |",
          "| C | 36 | relaxing D3 from four to three annual reports for the five three-report cases that have five rule-matched peers (American Realty Capital Properties, Apple REIT Nine, China North East Petroleum, HF Foods, iFresh) | run for information (§2.5); a design change, so only on the researcher's decision |",
          "| D | 40 | the design's target: no further qualifying cases exist in the AAER, litigation-release and EDGAR full-text records searched (screening report §2); the remaining three-report cases have thin peer pools (one peer) and the pre-2005 cases have no Item 9A | not available without changing D1 or D3 |", "",
          "Option B is the main sample. Option C remains a stated sensitivity, because it changes a pre-registered rule; it is run for information only.", "",
          "### 2.5 Do the results change with the sample?", "", md(comp), "",
          "The direction of every layer is the same in every sample. Adding the nine disclosure-only cases to the 21 halves the governance odds ratio (their boards differ less from their matched firms') and lowers the financial one from about 2.0 to 1.5; the ranking population makes no material difference; Gulfport and the five three-report cases change nothing of substance. The disclosure layer stays reversed in every sample, and H5 is not supported for the design score in any sample. A larger sample will therefore not reverse these readings; it will narrow the intervals.", ""]
    # 3. instruction status
    P += ["## 3. Status of every instruction and red note", "",
          "| # | Instruction (9 Oct) | Done | Where |", "|---|---|---|---|",
          "| 1 | Restore the 9 non-disclosure cases (FRAUD = 1); run H1–H5 on all; run H2 again without them | **Done** | §4.3, §4.4 |",
          "| 2 | Keep the rank-averaged AI risk score for H5 and A1–A3; report H2 and H5 as not supported if so; no re-wording | **Done**: H2 and H5 not supported; wording unchanged | §4.3, §4.6, §4.8 |",
          "| 3 | Move the fitted score, text-distance / abnormality measures and the stress tests to an exploratory section stating the fitted score contains the traditional signals | **Done** | §6 |",
          "| 4 | Complete M2 at a threshold agreed with the supervisors; do not set M1/M2 thresholds | **Not possible for the assistant**: human coding is the researcher's/supervisors' task. The coding workbook (2,075 rows, evidence attached, instructions and a signature line for the agreed threshold) and the agreement calculator are delivered. No threshold has been applied: the layer tests use complete cases with n reported | §5 |",
          "| 5 | H1–H3: odds ratios with 95 % CIs, unadjusted and Holm p, firms and sets, firm-clustered SEs | **Done**: both model-based and firm-clustered intervals and p-values | §4.3 |",
          "| 6 | Conditional logit as the primary H4 test; H5 timing for the AI risk score at an equal false-alarm rate | **Done** | §4.5, §4.6 |",
          "| 7 | AUD_OPIN as modified or going-concern; RESTATE from 8-K 4.02 and 10-K/A | **Done**: audit reports re-coded for qualified / adverse / disclaimer opinions (none found in the sample after excluding other-auditor paragraphs, so AUD_OPIN equals the going-concern flag in practice); every 10-K/A of every firm fetched and read for restatement language | §4.2 |",
          "| 8 | A2 by refitting with each matched set left out; A3 on the three design layers | **Done** | §4.8 |",
          "| 9 | Explain incompleteness coding for firms that disclose no RPT; coverage and text source by group | **Done** | §4.1 |",
          "| 10 | Send the screening report, the reason Gulfport is absent and the case for each added firm; no sample change without approval | **Done**; Gulfport approved by the researcher on 10 Oct and added as the 31st case | §2 |",
          "| 11 | Restate power for the final number of cases | **Done** by simulation | §4.9 |",
          "| 12 | Describe results as association and identification of fraud under way; lead time as the earliest separating year with the count never flagged | **Done** throughout; lead-time table in §4.6 | — |", "",
          "Section notes not covered above:", "",
          "- *Overall verdict (1)–(3)*: the fitted score is no longer recommended as the headline; the hypotheses are not re-worded; the nine disclosure-only cases (ten with Gulfport) are in the main sample.",
          "- *§1 Research question*: wording adopted — the measures identify fraud already under way; any flag lies inside the window by construction.",
          "- *§4 Role of AI*: recorded as a deviation. The characteristics were coded by rule with evidence passages, not by a language model reading the filings; the thesis will say so until the human check (M2) and, if the researcher wants it, a model-based reading pass are done. The fitted-model work is reported as exploratory.",
          "- *§4 Design point (fitted versus rank-averaged score)*: the rank-averaged score is the AI risk score in every design test; the fitted score appears only in §6.",
          "- *§4 Method (firm-clustered SEs)*: now reported for every conditional logit (sandwich over per-observation scores, firms nested in sets) and for the pooled logit.",
          "- *§6 Layer score with missing characteristics; ranking population*: stated in §4.2 (scoring rules) and recorded in `scoring_rules.csv`.",
          "- *§6 M1 threshold*: no threshold was applied by the assistant in this battery; the earlier ≥ 20 % / ≥ 50 % entry rules are withdrawn and recorded as having been set after M1 was seen.",
          "- *§7 H1 interval; H3 as a duality result; H4 as limited evidence; H5 timing at equal false-alarm rates; the fitted score cannot test H5*: all adopted.",
          "- *§8 A1 on the design score; A2 leave-one-set-out; A3 three layers with honest direction*: done.",
          "- *§10 Holm*: unadjusted values are now beside the adjusted ones. *Power*: §4.9. *Clean-firm false-positive rate*: the 5 % rate is a threshold set by construction and is no longer presented as evidence of accuracy.",
          "- *§11.1, 11.5, 11.6*: the theory text is not revised; the information-asymmetry prediction is reported as not supported under the competing (efficient-transaction) prediction; the H5 contribution is stated conditionally; the 'union of the two rules' claim is replaced by the equal-false-alarm comparison in §4.6, which does not support it.",
          "- *§12 Thresholds*: not set by the assistant; proposal restated in §5 as a proposal.",
          "- *LQ1, LQ2*: belong to the researcher's section 2.7; not part of this report.", ""]
    # 4. results
    tsrc = A["text_src"]
    P += ["## 4. Results as the design defines them (31 cases)", "",
          "### 4.1 M1 coverage by group, text source, and how 'no transactions' is coded", "",
          md(m1.rename(columns={"coverage_all": "all", "coverage_fraud_firm_years": "fraud firm-years", "coverage_matched_firm_years": "matched firm-years", "fisher_p_coverage_differs": "Fisher p (coverage differs)"}),
             cols=["characteristic", "layer", "all", "fraud firm-years", "matched firm-years", "Fisher p (coverage differs)", "n_fraud_observed", "n_matched_observed"]), "",
          "A related-party *amount* is stated in about 28 % of fraud firm-years and 9–10 % of matched firm-years for lending and payables (Fisher p < 0.001). The H1 subset is therefore selected on the outcome: fraud firms disclose amounts more often, and H1 is tested only among firm-years that do. "
          "The same holds for the board share (25 % vs 13 %). Sales and purchases do not differ. This must be stated with every H1 result.", "",
          "Text source by group (share of firm-years):", "", md(tsrc, index=True) if tsrc is not None else "", "",
          "Fraud firm-years draw more often on the financial-statement note and matched firm-years more often on the Item 13 / proxy section; the share whose text states that there were *no* related-party transactions is similar (6 % vs 5 %).", "",
          "**Incompleteness when a firm discloses no RPT.** The coder reads the related-party text of the firm-year. If the text is shorter than 20 words or absent, RP_INCOMP is missing (not scored). If the text exists but says there were no transactions, the four items are scored on that text: typically no counterparty, no amount, no terms, no purpose, so RP_INCOMP is high (mean 0.48 among such firm-years against 0.29 for others). "
          "That is a coding convention, not a disclosure failure, and it could produce the H2 reversal mechanically. The robustness run in §4.4 therefore drops those firm-years: the reversal shrinks and is no longer significant (OR " + f"{A['h1_h3_variants'].iloc[1]['odds_ratio_per_sd']:.2f}, p {fmt_eq(A['h1_h3_variants'].iloc[1]['p_unadjusted'])}" + "), so part of the H2 result is the convention and the rest is a null.", "",
          "### 4.2 Scoring rules, definitions and deviations", "", md(rules), "",
          "Deviations recorded for this battery: " + "; ".join(dev["deviation"].tolist()) + ".", "",
          "### 4.3 H1–H3", "", h13_table(A), "",
          "Both error estimates are shown because the design asks for firm-clustered errors and the first battery reported model-based ones. The firm-clustered errors are about twice the model-based ones: the layer scores change little from year to year within a firm (CEO duality rarely changes; amounts are stated in the same firms each year), so the five years of one firm are far from five independent observations. The firm-clustered column is the design's test.", "",
          "### 4.4 H2 re-runs and the single characteristics", "", variants_table(A), "",
          "### 4.5 H4 by event year (conditional logit primary)", "",
          md(A["h4_by_year"].rename(columns={"cond_or_per_sd": "OR per SD", "cond_p": "p", "cond_p_firm_cluster": "p firm-clustered", "mannwhitney_p_greater": "Mann–Whitney p (supplementary)"}),
             cols=["event_year", "layer_score", "n_firm_years", "n_matched_sets", "mean_fraud", "mean_matched", "OR per SD", "p", "p firm-clustered", "Mann–Whitney p (supplementary)"]), "",
          md(A["h4_design_rule"]), "",
          "### 4.6 H5 — Model A versus Model B with the design's AI risk score; timing at an equal false-alarm rate", ""] + h5_lines(A) + ["",
          "Lead time, worded as the review asks — the earliest window year in which the AI risk score separated the fraud firm from its matched firms (5 % matched-firm rate), beside the cases never flagged:", "",
          md(lead), "",
          "### 4.7 P1 (descriptive, no significance claim)", "", md(A["p1_rpt_types_by_form"], index=True), "",
          "### 4.8 A1–A3 on the design score", "",
          "A1 — share of each firm-year's AI risk score by layer and characteristic (direct arithmetic; per firm-year in `a1_attribution_by_firm_year.csv`, with the named evidence, e.g. 'mainly DUAL and RP_INCOMP'):", "",
          md(A["a1_attribution_summary"], index=True), "",
          "A2 — the division recalculated with each matched set left out in turn:", "", md(A["a2_stability_summary"].T.reset_index().rename(columns={"index": "quantity", 0: "value"})), "",
          "A3 — reading against theory, three design layers, fraud firm-years flagged by the AI rule:", "", md(a3), "",
          "### 4.9 Power restated for the final sample", "",
          (md(power) if power is not None else "(power simulation not run)"), "",
          "Simulation under the conditional-logit model with five matched firms, five window years per firm, the layer score observed throughout and a within-firm correlation of 0.5, tested with firm-clustered errors at the 5 % level in the predicted direction (100 replications per cell). It replaces the design's 40-case figure. Because the layer tests actually use 16–24 informative sets and a fraction of the firm-years (amounts stated in 22 % of firm-years; board or duality in 32 %), their power is nearer the 21-set rows than the 30-set rows and lower where firm-years are missing. Non-significant results (H1 with firm-clustered errors, H5, the disclosure layer in H4) remain weak evidence of no difference.", ""]
    # 5 M2
    P += ["## 5. M2 reliability — delivered for human coding", "",
          "`data/M2_coding_workbook.xlsx`: 2,075 rows (10 % per variable, drawn at random on 8 October), one sheet per variable, the machine value and its evidence passage beside an empty `human_value` column, dropdowns for binary items, instructions and a line for the agreed threshold and signature. "
          "`python scripts/make_m2_workbook.py score --workbook …` computes Cohen's kappa for binary items and the share of amounts within 10 % (with bootstrap intervals) once the sheet is filled. "
          "The assistant's earlier figures (kappa ≥ 0.70; 90 % of amounts within 10 %) are a proposal only. Until M2 is done every result above rests on rule-based coding with evidence attached.", ""]
    # 6 exploratory
    P += ["## 6. Exploratory section (kept apart from the design tests)", "",
          "Everything here uses the fitted 36-input ensemble score or measures found after looking at the data. **The fitted score contains the traditional signals** (ICFR flags, going-concern opinion, auditor change, restatement, Big-4 status) and general financial ratios, so it cannot test whether the RPT layers add to the benchmark and plays no part in H5.", ""]
    if expl is not None:
        e = expl.iloc[0]
        P += [f"- Fitted score (trained on the 30 sets before Gulfport; Gulfport's firm-years unscored): AUC {e['auc_fitted_score_alone_oof']:.2f} alone; Model A + fitted score {e['loso_auc_model_A_plus_fitted_score']:.2f} against Model A {e['loso_auc_model_A']:.2f}; at its 5 % matched-firm threshold it flags {int(e['cases_flagged_fitted'])} of 30 cases and never flags {int(e['cases_never_flagged_fitted'])}.",]
    P += ["- First-battery results on the 21 core cases (unchanged, now exploratory): ensemble AUC 0.73 [0.63, 0.83]; 9 of 21 cases flagged, 12 never flagged; external validation on ten unseen three-report cases AUC 0.73; stress tests T1–T5; peer-text distance and year-on-year drift higher in fraud firm-years. Tables in `docs/run3_results/`.",
          "- The 'abnormality' reading of the disclosure layer (drift, distance from peers) is an exploratory observation, not a restatement of H2.", ""]
    # 7 H2/H5 discussion
    P += ["## 7. H2 and H5 — what the results mean and the options (for discussion; nothing changed)", "",
          "**H2.** Fraud firms' related-party text is, if anything, more complete and plainer than their matched firms'. Three readings, none of which changes the hypothesis: (i) the efficient-transaction prediction set out in design §11.1 — disclosure characteristics do not mark harmful RPTs; (ii) part of the reversal is the coding convention for 'no transactions' texts (§4.1); dropping those firm-years leaves a null; (iii) fraud firms *have* related-party transactions to describe, matched firms often do not, so completeness partly measures the presence of RPTs. The thesis can report (i) as the finding and (ii)–(iii) as the limits of the measure. If the researcher wants a disclosure measure that is not confounded by presence, it would be a new exploratory measure, labelled as such.", "",
          "**H5.** The rank-averaged score mixes a layer that works in the predicted direction (governance), one that is observed in a third of firm-years (financial) and one that works against the prediction (disclosure); averaged, it does not add to the four traditional signals. Options for discussion: (a) report as is — the honest outcome of the design; (b) a pre-specified variant in the thesis's robustness section, e.g. the governance layer alone against the traditional index, clearly labelled as post hoc; (c) the fitted score as exploratory evidence that a model with more inputs separates fraud firms, without claiming added value over the benchmark. The assistant recommends (a) with (c) as the exploratory section, and will not implement (b) without the researcher's decision.", ""]
    P += ["## 8. Wording adopted throughout", "",
          "- Results are associations within matched sets; they identify fraud already under way, not fraud before it begins.",
          "- 'Lead time' is the earliest window year in which the measure separated the fraud firm from its matched firms, always reported beside the number of cases never flagged.",
          "- The 5 % matched-firm rate is a threshold fixed by construction, not an accuracy result; matched firms are not known to be clean.",
          "- 'Supported' means direction as predicted and Holm-adjusted p < 0.05 with the design's firm-clustered errors.", "",
          "## 9. Files", "",
          "- Design battery: `scripts/design_tests_v2.py`; outputs `outputs/full_all/design_tests_v2/<sample>/` (summary.md and the CSVs named in this document; copies under `docs/design_tests_v2/`): `main31` (the main sample), `core21`, `all30`, `all36_threereport` and `main31_rankall`.",
          "- Coding: `rpt_panel/inference_stats.py` (firm-clustered conditional logit), `rpt_panel/governance_coder.py` (modified-opinion rule), `scripts/code_audit_opinions.py` → `data/audit_opinions*.csv`; `SEC-EDGAR-Downloader/scripts/tenka_restatements.py` → `data_core/tenka_restatements.csv` (every 10-K/A read).",
          "- Sample: `cases_core.csv` (31 cases + 145 matched firms; Gulfport and its peers merged from `cases_gulfport.csv` / `data_gulf/` by `scripts/merge_build_into_core.py`); `cases_sensitivity.csv` (three-report cases); screening report `docs/REPORT_Candidate_Screen_2026-10-08.docx`.",
          "- M2: `data/M2_coding_workbook.xlsx`, `scripts/make_m2_workbook.py`.",
          "- Thesis chapters regenerated on these results: `docs/THESIS_Methodology_and_Results.docx`; companies: `docs/THESIS_Companies_Used_in_the_Research.docx`.", ""]
    out.write_text("\n".join(P), encoding="utf-8")
    print(out, len(" ".join(P).split()), "words")


if __name__ == "__main__":
    main()
