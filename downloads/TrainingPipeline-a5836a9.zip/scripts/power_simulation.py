"""Power of the within-set test for the final sample sizes, run on its own because each conditional-logit fit with
five case years per set is slow.

    python scripts/power_simulation.py --out outputs/full_all/design_tests_v2/all30/power_simulation.csv --reps 100
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from design_tests_v2 import power_simulation  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--reps", type=int, default=100)
    ap.add_argument("--sets", nargs="*", type=int, default=[21, 30, 40])
    ap.add_argument("--ors", nargs="*", type=float, default=[1.5, 1.65, 2.0])
    args = ap.parse_args()
    df = power_simulation(args.sets, args.ors, peers=5, reps=args.reps)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    print(df.to_string())


if __name__ == "__main__":
    main()
