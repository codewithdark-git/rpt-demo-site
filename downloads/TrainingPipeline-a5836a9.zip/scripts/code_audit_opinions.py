"""AUD_OPIN as the design defines it: 1 if the audit opinion is modified (qualified, adverse, disclaimer) or
carries a going-concern paragraph. Reads the primary 10-K of every panel firm-year of a config and writes
``<out>`` with the going-concern flag, the modified-opinion flag, their evidence passages and the combined flag.

    python scripts/code_audit_opinions.py --config rpt_panel.full_all.json --out data/audit_opinions.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rpt_panel import governance_coder as gc  # noqa: E402
from rpt_panel.config import load_config  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="rpt_panel.full_all.json")
    ap.add_argument("--out", default="data/audit_opinions.csv")
    args = ap.parse_args()
    cfg = load_config(args.config)
    X = pd.read_csv(cfg.output_dir / "panel_features.csv", dtype={"cik": str, "accession_number": str})
    X["cik"] = X["cik"].str.zfill(10)
    rows = []
    for _, r in X.iterrows():
        year = str(int(float(r.get("report_date", "")[:4]) if isinstance(r.get("report_date"), str) and r.get("report_date") else r["fiscal_year"]))
        base = Path(cfg.local_dir) / "raw" / "filings" / r["cik"]
        # the builder stores filings under raw/filings/<cik>/<year>/<accession>; the year folder may be the
        # filing year or the report year, so look the accession up in either.
        filing = ""
        for y in {year, str(int(r["fiscal_year"])), str(int(r["fiscal_year"]) + 1)}:
            p = base / y / str(r["accession_number"]) / "filing.txt"
            if p.exists():
                filing = p.read_text(encoding="utf-8", errors="replace")
                break
        gcf, gc_ev = gc.going_concern(filing) if filing else (np.nan, "")
        mo, mo_ev = gc.modified_opinion(filing) if filing else (np.nan, "")
        combined = np.nan if (pd.isna(gcf) and pd.isna(mo)) else float(max(0 if pd.isna(gcf) else gcf, 0 if pd.isna(mo) else mo))
        rows.append({"cik": r["cik"], "fiscal_year": int(r["fiscal_year"]), "going_concern_opinion": gcf, "modified_opinion": mo,
                     "audit_opinion_modified_or_gc": combined, "going_concern_evidence": gc_ev, "modified_opinion_evidence": mo_ev,
                     "audit_report_found": int(bool(filing) and bool(gc.audit_report_window(filing)))})
    out = pd.DataFrame(rows)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.out, index=False)
    print(f"{args.out}: {len(out)} firm-years; audit report found {out['audit_report_found'].mean():.1%}; "
          f"going concern {out['going_concern_opinion'].mean():.3f}; modified {out['modified_opinion'].mean():.3f}; "
          f"either {out['audit_opinion_modified_or_gc'].mean():.3f}")
    print(out.loc[out["modified_opinion"] == 1, ["cik", "fiscal_year", "modified_opinion_evidence"]].head(15).to_string())


if __name__ == "__main__":
    main()
