"""The client design's test battery, run exactly as the design (6 Oct 2026) and the researcher's review of
9 Oct 2026 specify. Supersedes scripts/design_tests.py.

What changed against the first battery, following the review:
  * all qualifying RPT-fraud cases are FRAUD = 1 (the disclosure-only cases are back in the main sample);
    H2 is run twice (all cases; without the disclosure-only cases), as the design says
  * H1-H3: odds ratios per SD with 95% intervals, unadjusted and Holm p-values, firm-years, firms and matched
    sets; firm-clustered sandwich standard errors next to the model-based ones; no coverage floor is applied
    (complete cases, n reported)
  * coverage (M1) and the text source are reported separately for fraud firms and matched firms, with a test of
    whether stating an amount is more common in one group (selection on the outcome for H1)
  * how a layer score is formed when a characteristic is missing is stated and recorded (mean of the available
    ranks; ranks taken over the analysed window firm-years only)
  * H4: conditional logit per event year is the primary test; Mann-Whitney is supplementary; the design rule
    ("a significant difference in at least one year before the final year") is applied per layer
  * H5: Model A (TRAD_INDEX + LEV + ROA) against Model B (+ the design's rank-averaged AI_SCORE), leave-one-set-out
    AUC with a set-bootstrap interval for the gain, AI_SCORE's coefficient with interval, and the timing test for
    the AI risk score at an equal false-alarm rate; the union of the two rules is compared with each rule at the
    union's own false-alarm rate
  * A1: each firm-year's AI risk score divided by layer and by characteristic (direct arithmetic); A2: the
    division recalculated with each matched set left out in turn; A3: the largest contributing layer among the
    fraud firm-years the AI risk score flags, three design layers only, with the direction of each layer stated
  * AUD_OPIN = modified or going-concern opinion; RESTATE = 8-K Item 4.02 or a restating 10-K/A, when the coded
    files exist (otherwise the narrower definitions are used and the output says so)
  * lead time is reported as the earliest window year in which the score separated the firm from its matched
    firms, next to the number of cases never flagged
  * power is restated by simulation for the final number of matched sets
  * everything built on the fitted 36-input score is written to exploratory_*.csv and labelled as such

    python scripts/design_tests_v2.py --config rpt_panel.full_all.json --name all30
    python scripts/design_tests_v2.py --config rpt_panel.full_all.json --strata core --name core21
    python scripts/design_tests_v2.py --config rpt_panel.full_all.json --extra-config rpt_panel.gulf.json --name all31_gulfport
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rpt_panel import data_access as da  # noqa: E402
from rpt_panel import inference_stats as inf  # noqa: E402
from rpt_panel import run as R  # noqa: E402
from rpt_panel.config import load_config  # noqa: E402

CHARACTERISTICS = {  # design code -> (panel column, layer, higher value = more risk?)
    "RP_LEND": ("rp_lend_to_assets", "L1", True),
    "RP_PAY": ("rp_pay_to_assets", "L1", True),
    "RP_SALES": ("rp_sales_to_revenue", "L1", True),
    "RP_PURCH": ("rp_purch_to_assets", "L1", True),
    "RP_INCOMP": ("rp_incomp", "L2", True),
    "RP_VAGUE": ("rpt_vagueness", "L2", True),
    "BRD_NONIND": ("board_indep", "L3", False),  # 1 - independent share
    "DUAL": ("ceo_duality", "L3", True),
}
LAYER_NAME = {"L1": "financial (conflict of interest)", "L2": "disclosure (information asymmetry)", "L3": "governance (weak monitoring)"}
CONTROLS = ["leverage", "roa"]
Y = "fraud_aaer_label"


# ----------------------------------------------------------------------------- helpers
def holm(p: pd.Series) -> pd.Series:
    order = p.sort_values().index
    m = int(p.notna().sum())
    adj, running = {}, 0.0
    for i, idx in enumerate(order):
        if pd.isna(p[idx]):
            adj[idx] = np.nan
            continue
        running = max(running, (m - i) * p[idx])
        adj[idx] = min(1.0, running)
    return pd.Series(adj).reindex(p.index)


def characteristic_values(X: pd.DataFrame) -> pd.DataFrame:
    """The eight characteristics oriented so that higher = more risk (BRD_NONIND = 1 - board_indep)."""
    out = pd.DataFrame(index=X.index)
    for code, (col, layer, higher) in CHARACTERISTICS.items():
        if col in X.columns:
            s = pd.to_numeric(X[col], errors="coerce")
            out[code] = s if higher else 1 - s
        else:
            out[code] = np.nan
    return out


def rank_scores(values: pd.DataFrame, ref: pd.DataFrame | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Design steps 3-5. Each characteristic is ranked 0-1 against the reference firm-years (``ref``; the rows
    themselves when None), ranks are averaged within layer over the characteristics that are observed for the
    firm-year, the three layer scores are averaged over the layers that have a score, x10 = AI_SCORE.

    Returns (scores, ranks). ``ranks`` holds the 0-1 rank of every characteristic (NaN where missing)."""
    ranks = pd.DataFrame(index=values.index)
    for code in CHARACTERISTICS:
        v = values[code]
        if ref is None:
            ranks[code] = v.rank(pct=True)  # average ranks for ties, NaN stays NaN
        else:
            r = ref[code].dropna().values
            if len(r) == 0:
                ranks[code] = np.nan
                continue
            r_sorted = np.sort(r)
            # mid-rank ECDF against the reference distribution, on the same 0-1 scale as rank(pct=True)
            lo = np.searchsorted(r_sorted, v.values, side="left")
            hi = np.searchsorted(r_sorted, v.values, side="right")
            ranks[code] = np.where(v.notna(), (lo + hi) / 2 / len(r_sorted), np.nan)
            ranks.loc[v.notna(), code] = ranks.loc[v.notna(), code].clip(lower=1 / (len(r_sorted) + 1), upper=1.0)
    scores = pd.DataFrame(index=values.index)
    for layer in ("L1", "L2", "L3"):
        cols = [c for c, (_, l, _) in CHARACTERISTICS.items() if l == layer]
        scores[f"{layer}_SCORE"] = ranks[cols].mean(axis=1, skipna=True)
        scores[f"{layer}_n_obs"] = ranks[cols].notna().sum(axis=1)
    scores["n_layers"] = scores[["L1_SCORE", "L2_SCORE", "L3_SCORE"]].notna().sum(axis=1)
    scores["AI_SCORE"] = scores[["L1_SCORE", "L2_SCORE", "L3_SCORE"]].mean(axis=1, skipna=True) * 10
    return scores, ranks


def attribution(scores: pd.DataFrame, ranks: pd.DataFrame) -> pd.DataFrame:
    """A1: share of each firm-year's AI risk score that comes from each layer and each characteristic.

    AI_SCORE = 10 x mean over available layers of L_k, so layer k contributes 10 x L_k / n_layers; within a layer,
    characteristic c contributes 10 x rank_c / (n_obs_k x n_layers)."""
    out = pd.DataFrame(index=scores.index)
    denom = scores["AI_SCORE"].replace(0, np.nan)
    for layer in ("L1", "L2", "L3"):
        contrib = 10 * scores[f"{layer}_SCORE"] / scores["n_layers"]
        out[f"share_{layer}"] = (contrib / denom).fillna(0.0).where(scores[f"{layer}_SCORE"].notna(), 0.0)
        cols = [c for c, (_, l, _) in CHARACTERISTICS.items() if l == layer]
        for c in cols:
            cc = 10 * ranks[c] / (scores[f"{layer}_n_obs"].replace(0, np.nan) * scores["n_layers"])
            out[f"share_{c}"] = (cc / denom).fillna(0.0)
    layer_cols = [f"share_{l}" for l in ("L1", "L2", "L3")]
    out["largest_layer"] = out[layer_cols].idxmax(axis=1).str.replace("share_", "")
    char_cols = [f"share_{c}" for c in CHARACTERISTICS]
    top = out[char_cols].apply(lambda r: [c.replace("share_", "") for c in r.sort_values(ascending=False).index[:2] if r[c] > 0], axis=1)
    out["named_evidence"] = top.map(lambda t: "mainly " + " and ".join(t) if t else "no characteristic observed")
    return out


def loco_auc(train: pd.DataFrame, feats: list[str], seed: int = 0) -> pd.Series:
    """Leave-one-matched-set-out logit predictions (standardised inside the training part)."""
    import statsmodels.api as sm
    pred = pd.Series(np.nan, index=train.index)
    d = train[feats + [Y, "cluster_id"]].dropna()
    for g in d["cluster_id"].unique():
        tr, te = d[d["cluster_id"] != g], d[d["cluster_id"] == g]
        if tr[Y].nunique() < 2:
            continue
        mu, sd = tr[feats].mean(), tr[feats].std(ddof=1).replace(0, 1)
        Xtr, Xte = (tr[feats] - mu) / sd, (te[feats] - mu) / sd
        try:
            m = sm.Logit(tr[Y].astype(int), sm.add_constant(Xtr, has_constant="add")).fit(disp=0, maxiter=200)
        except Exception:  # noqa: BLE001
            m = sm.Logit(tr[Y].astype(int), sm.add_constant(Xtr, has_constant="add")).fit_regularized(alpha=1.0, L1_wt=0.0, disp=0)
        pred.loc[te.index] = np.asarray(m.predict(sm.add_constant(Xte, has_constant="add")))
    return pred


def set_bootstrap_auc_gain(y: pd.Series, pa: pd.Series, pb: pd.Series, sets: pd.Series, n: int = 500, seed: int = 42) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    ids = sets.unique()
    gains = []
    for _ in range(n):
        pick = rng.choice(ids, size=len(ids), replace=True)
        idx = np.concatenate([np.where(sets.values == s)[0] for s in pick])
        yy = y.values[idx]
        if yy.min() == yy.max():
            continue
        gains.append(roc_auc_score(yy, pb.values[idx]) - roc_auc_score(yy, pa.values[idx]))
    return (float(np.percentile(gains, 2.5)), float(np.percentile(gains, 97.5))) if gains else (np.nan, np.nan)


def power_simulation(n_sets_list, ors, peers=5, years=5, reps=300, icc=0.5, seed=7) -> pd.DataFrame:
    """Power of the H1-H3 test (conditional logit within matched sets, firm-clustered p < 0.05, one-sided
    direction as predicted) when one standard deviation of the layer score multiplies the odds by OR.

    Firm-years are generated with a firm random effect (intra-firm correlation ``icc``) and the case firm of
    each set is drawn under the conditional logit model: P(firm f is the case) proportional to
    exp(beta x sum_t x_ft). Standard errors are firm-clustered as in the reported tests."""
    rng = np.random.default_rng(seed)
    inf_min = inf.MIN_COVERAGE
    inf.MIN_COVERAGE = 0
    rows = []
    for n_sets in n_sets_list:
        for orr in ors:
            beta = np.log(orr)
            hits = 0
            for _ in range(reps):
                rec = []
                for s in range(n_sets):
                    u = rng.normal(0, np.sqrt(icc), size=peers + 1)
                    e = rng.normal(0, np.sqrt(1 - icc), size=(peers + 1, years))
                    x = u[:, None] + e
                    w = np.exp(beta * x.sum(axis=1) / np.sqrt(years))  # one SD of the firm-mean score -> OR
                    case = rng.choice(peers + 1, p=w / w.sum())
                    for f in range(peers + 1):
                        for t in range(years):
                            rec.append({"cluster_id": s, "cik": f"{s}_{f}", Y: int(f == case), "score": x[f, t],
                                        "leverage": rng.normal(), "roa": rng.normal()})
                df = pd.DataFrame(rec)
                t = inf.conditional_logit(df, ["score", "leverage", "roa"])
                r = t[t["term"] == "score"]
                if len(r):
                    p = r["p_cluster"].iloc[0] if "p_cluster" in r.columns and pd.notna(r["p_cluster"].iloc[0]) else r["p"].iloc[0]
                    hits += int(r["coef"].iloc[0] > 0 and p < 0.05)
            rows.append({"matched_sets": n_sets, "odds_ratio_per_sd": orr, "power": round(hits / reps, 3), "reps": reps,
                         "peers_per_set": peers, "years": years, "firm_icc": icc})
    inf.MIN_COVERAGE = inf_min
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="rpt_panel.full_all.json")
    ap.add_argument("--extra-config", nargs="*", default=[], help="configs whose panel_features are appended (e.g. the Gulfport or three-report sets)")
    ap.add_argument("--extra-case-ids", nargs="*", default=None, help="restrict the appended panels to these cluster ids")
    ap.add_argument("--strata", nargs="*", default=None, help="case strata to analyse (default: all qualifying cases)")
    ap.add_argument("--name", default="all")
    ap.add_argument("--audit-opinions", nargs="*", default=["data/audit_opinions.csv"])
    ap.add_argument("--tenka", nargs="*", default=["../SEC-EDGAR-Downloader/data_core/tenka_restatements.csv"])
    ap.add_argument("--rank-basis", choices=["window", "all_firm_years"], default="window",
                    help="population the eight characteristics are ranked against (design: 'all firm-years' = the analysed window rows)")
    ap.add_argument("--power-reps", type=int, default=300)
    ap.add_argument("--no-power", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    out = R._out(cfg, "design_tests_v2", args.name)
    inf.MIN_COVERAGE = 0  # no coverage floor: complete cases, n reported (the review: thresholds are not the assistant's to set)

    # ---- panel (+ appended panels)
    X = R._load_features(cfg)
    X["source_panel"] = cfg.output_dir.name
    cases = da.read_cases(cfg)
    coded_text = []
    if cfg.rp_note_coded_csv and Path(cfg.rp_note_coded_csv).exists():
        coded_text.append(pd.read_csv(cfg.rp_note_coded_csv, dtype={"cik": str}, keep_default_na=False))
    for extra in args.extra_config:
        ecfg = load_config(extra)
        E = R._load_features(ecfg)
        if "stratum" not in E.columns:
            E = R._attach_stratum(ecfg, E)
        if args.extra_case_ids:
            E = E[E["cluster_id"].isin(args.extra_case_ids)]
        E["source_panel"] = ecfg.output_dir.name
        X = pd.concat([X, E], ignore_index=True, sort=False)
        ec = da.read_cases(ecfg)
        if ec is not None:
            cases = pd.concat([cases, ec], ignore_index=True) if cases is not None else ec
        if ecfg.rp_note_coded_csv and Path(ecfg.rp_note_coded_csv).exists():
            coded_text.append(pd.read_csv(ecfg.rp_note_coded_csv, dtype={"cik": str}, keep_default_na=False))
    X["cik"] = X["cik"].str.zfill(10)
    X["stratum"] = X["stratum"].fillna("core")

    # ---- traditional signals as the design defines them (coded files; fall back and record the deviation)
    deviations = []
    aud = pd.concat([pd.read_csv(p, dtype={"cik": str}) for p in args.audit_opinions if Path(p).exists()], ignore_index=True) if any(Path(p).exists() for p in args.audit_opinions) else pd.DataFrame()
    if len(aud):
        aud["cik"] = aud["cik"].str.zfill(10)
        aud = aud.drop_duplicates(["cik", "fiscal_year"])[["cik", "fiscal_year", "audit_opinion_modified_or_gc", "modified_opinion"]]
        X = X.merge(aud, on=["cik", "fiscal_year"], how="left")
        X["AUD_OPIN"] = X["audit_opinion_modified_or_gc"].where(X["audit_opinion_modified_or_gc"].notna(), X["going_concern_opinion"])
        aud_def = "modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report"
    else:
        X["AUD_OPIN"] = X["going_concern_opinion"]
        aud_def = "going-concern opinion only"
        deviations.append("AUD_OPIN coded as going-concern opinion only (modified-opinion coding file not found)")
    ten = pd.concat([pd.read_csv(p, dtype={"cik": str}) for p in args.tenka if Path(p).exists()], ignore_index=True) if any(Path(p).exists() for p in args.tenka) else pd.DataFrame()
    if len(ten):
        ten["cik"] = ten["cik"].str.zfill(10)
        ten = ten.drop_duplicates(["cik", "fiscal_year"])[["cik", "fiscal_year", "restatement_10ka"]]
        X = X.merge(ten, on=["cik", "fiscal_year"], how="left")
        X["restatement_10ka"] = X["restatement_10ka"].fillna(0.0)
        X["RESTATE"] = X[["restatement_8k", "restatement_10ka"]].max(axis=1, skipna=True)
        restate_def = "8-K Item 4.02 or a 10-K/A that restates the financial statements"
    else:
        X["RESTATE"] = X["restatement_8k"]
        restate_def = "8-K Item 4.02 only"
        deviations.append("RESTATE coded from 8-K Item 4.02 only (10-K/A coding file not found)")
    X["ICFR_MW"] = X["material_weakness_reported"]
    X["AUD_CHG"] = X["auditor_change_8k"]
    trad_cols = ["ICFR_MW", "AUD_OPIN", "AUD_CHG", "RESTATE"]
    X["TRAD_INDEX"] = X[trad_cols].sum(axis=1, min_count=1)

    # ---- analysed firm-years: the five-year window of every qualifying case and its matched firms
    train = R._training(cfg, X)
    if args.strata:
        train = train[train["stratum"].isin(args.strata)].copy()
    train = train.copy()
    n_sets_all = train["cluster_id"].nunique()
    n_cases = int(train.loc[train["case_role"] == "case", "cik"].nunique())
    n_peers = int(train.loc[train["case_role"] != "case", "cik"].nunique())

    # ---- M1 coverage overall and by group; text source by group
    values = characteristic_values(train)
    m1 = []
    is_case = train[Y] == 1
    for code, (col, layer, _) in CHARACTERISTICS.items():
        v = values[code]
        a, b = v[is_case].notna(), v[~is_case].notna()
        tab = [[int(a.sum()), int((~a).sum())], [int(b.sum()), int((~b).sum())]]
        fisher_p = stats.fisher_exact(tab)[1] if min(map(sum, tab)) > 0 else np.nan
        m1.append({"characteristic": code, "layer": layer, "panel_column": col, "coverage_all": round(v.notna().mean(), 3),
                   "coverage_fraud_firm_years": round(a.mean(), 3), "coverage_matched_firm_years": round(b.mean(), 3),
                   "fisher_p_coverage_differs": fisher_p, "n_fraud_observed": int(a.sum()), "n_matched_observed": int(b.sum())})
    for code in trad_cols:
        v = train[code]
        m1.append({"characteristic": f"{code} (traditional signal)", "layer": "TRAD", "panel_column": {"ICFR_MW": "material_weakness_reported", "AUD_OPIN": aud_def, "AUD_CHG": "auditor_change_8k", "RESTATE": restate_def}[code],
                   "coverage_all": round(v.notna().mean(), 3), "coverage_fraud_firm_years": round(v[is_case].notna().mean(), 3),
                   "coverage_matched_firm_years": round(v[~is_case].notna().mean(), 3), "fisher_p_coverage_differs": np.nan,
                   "n_fraud_observed": int(v[is_case].notna().sum()), "n_matched_observed": int(v[~is_case].notna().sum())})
    m1 = pd.DataFrame(m1)
    m1.to_csv(out / "m1_coverage_by_group.csv", index=False)
    text_src = pd.DataFrame()
    if coded_text:
        ct = pd.concat(coded_text, ignore_index=True)
        ct["cik"] = ct["cik"].str.zfill(10)
        ct["fiscal_year"] = pd.to_numeric(ct["fiscal_year"], errors="coerce")
        mt = train[["cik", "fiscal_year", Y]].merge(ct[["cik", "fiscal_year", "text_source", "no_transactions_stated", "amount_stated"]], on=["cik", "fiscal_year"], how="left")
        mt["text_source"] = mt["text_source"].fillna("none")
        text_src = pd.crosstab(mt[Y].map({1: "fraud firm-years", 0: "matched firm-years"}), mt["text_source"], normalize="index").round(3)
        text_src["n"] = mt.groupby(mt[Y].map({1: "fraud firm-years", 0: "matched firm-years"})).size()
        text_src["share_stating_no_transactions"] = mt.groupby(mt[Y].map({1: "fraud firm-years", 0: "matched firm-years"}))["no_transactions_stated"].apply(lambda s: pd.to_numeric(s, errors="coerce").mean()).round(3)
        text_src.to_csv(out / "m1_text_source_by_group.csv")
        train = train.merge(mt[["cik", "fiscal_year", "no_transactions_stated"]].drop_duplicates(["cik", "fiscal_year"]), on=["cik", "fiscal_year"], how="left")
        train["no_transactions_stated"] = pd.to_numeric(train["no_transactions_stated"], errors="coerce").fillna(0)
        values = characteristic_values(train)

    # ---- scores (design steps 3-5), ranks over the analysed window firm-years (or, as a sensitivity, over every
    # firm-year of the same firms FY2004-2024 as the first battery did)
    if args.rank_basis == "all_firm_years":
        pool = X[X["cluster_id"].isin(train["cluster_id"].unique())]
        scores, ranks = rank_scores(values, ref=characteristic_values(pool))
    else:
        scores, ranks = rank_scores(values)
    train = pd.concat([train.reset_index(drop=True), scores.reset_index(drop=True)], axis=1)
    ranks = ranks.reset_index(drop=True)
    layer_rule = pd.DataFrame([
        {"rule": "ranking population", "value": (f"the {len(train)} analysed firm-years (five-year windows of the {n_sets_all} matched sets); firm-years outside the windows and the external set are not ranked"
                                                  if args.rank_basis == "window" else "SENSITIVITY: every FY2004-2024 firm-year of the analysed firms (the first battery's choice); window rows scored against that distribution")},
        {"rule": "layer score with a missing characteristic", "value": "mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score"},
        {"rule": "AI_SCORE with a missing layer", "value": "10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE"},
        {"rule": "firm-years with L1 from 1/2/3/4 characteristics", "value": str(train["L1_n_obs"].value_counts().sort_index().to_dict())},
        {"rule": "firm-years with L2 from 0/1/2 characteristics", "value": str(train["L2_n_obs"].value_counts().sort_index().to_dict())},
        {"rule": "firm-years with L3 from 0/1/2 characteristics", "value": str(train["L3_n_obs"].value_counts().sort_index().to_dict())},
        {"rule": "firm-years with 1/2/3 layers in AI_SCORE", "value": str(train["n_layers"].value_counts().sort_index().to_dict())},
        {"rule": "AUD_OPIN definition", "value": aud_def}, {"rule": "RESTATE definition", "value": restate_def},
    ])
    layer_rule.to_csv(out / "scoring_rules.csv", index=False)
    m3 = train[["L1_SCORE", "L2_SCORE", "L3_SCORE"]].corr().round(3)
    m3.to_csv(out / "m3_layer_correlations.csv")
    train[["cik", "fiscal_year", "cluster_id", "case_role", "stratum", Y, "event_time", "L1_SCORE", "L2_SCORE", "L3_SCORE", "AI_SCORE", "TRAD_INDEX"] + trad_cols].to_csv(out / "scores_by_firm_year.csv", index=False)

    # ---- H1-H3 (and the H2 variants)
    def layer_test(df: pd.DataFrame, hyp: str, layer: str, variant: str) -> dict:
        t = inf.conditional_logit(df, [layer] + CONTROLS)
        r = t[t["term"] == layer] if "term" in t.columns else pd.DataFrame()
        if not len(r):
            return {"hypothesis": hyp, "variant": variant, "layer_score": layer, "n_firm_years": 0}
        r = r.iloc[0]
        d = {"hypothesis": hyp, "variant": variant, "layer_score": layer, "n_firm_years": int(r["n"]), "n_matched_sets": int(r["n_clusters"]),
             "n_firms": int(r.get("n_firms", np.nan)) if pd.notna(r.get("n_firms", np.nan)) else np.nan,
             "n_fraud_firm_years": int(df.dropna(subset=[layer] + CONTROLS)[Y].sum()),
             "coef_per_sd": float(r["coef"]), "odds_ratio_per_sd": float(np.exp(r["coef"])),
             "or_ci_low": float(np.exp(r["ci_low"])), "or_ci_high": float(np.exp(r["ci_high"])), "se": float(r["se"]), "p_unadjusted": float(r["p"]),
             "se_firm_cluster": float(r.get("se_cluster", np.nan)), "p_firm_cluster": float(r.get("p_cluster", np.nan)),
             "or_ci_low_firm_cluster": float(np.exp(r["ci_low_cluster"])) if pd.notna(r.get("ci_low_cluster", np.nan)) else np.nan,
             "or_ci_high_firm_cluster": float(np.exp(r["ci_high_cluster"])) if pd.notna(r.get("ci_high_cluster", np.nan)) else np.nan}
        return d

    main_rows = [layer_test(train, "H1", "L1_SCORE", "all cases"), layer_test(train, "H2", "L2_SCORE", "all cases"), layer_test(train, "H3", "L3_SCORE", "all cases")]
    h13 = pd.DataFrame(main_rows)
    h13["p_holm"] = holm(h13["p_unadjusted"]).values
    h13["p_holm_firm_cluster"] = holm(h13["p_firm_cluster"]).values
    h13["direction_as_predicted"] = h13["coef_per_sd"] > 0
    h13["supported_design_rule"] = h13["direction_as_predicted"] & (h13["p_holm"] < 0.05)
    h13["supported_firm_cluster"] = h13["direction_as_predicted"] & (h13["p_holm_firm_cluster"] < 0.05)
    h13.to_csv(out / "h1_h3_layer_tests.csv", index=False)
    variants = []
    no_disc = train[train["stratum"] != "disclosure_only"]
    if no_disc["cluster_id"].nunique() < n_sets_all:
        variants.append(layer_test(no_disc, "H2", "L2_SCORE", "without disclosure-only cases (design re-run)"))
    if "no_transactions_stated" in train.columns:
        variants.append(layer_test(train[train["no_transactions_stated"] != 1], "H2", "L2_SCORE", "all cases, excluding firm-years whose text states that there were no related-party transactions (robustness)"))
        variants.append(layer_test(train[train["RP_INCOMP_amount_any"] == 1] if "RP_INCOMP_amount_any" in train.columns else train[values["RP_INCOMP"].notna() & values["RP_VAGUE"].notna()], "H2", "L2_SCORE", "all cases, firm-years with both disclosure characteristics observed (robustness)"))
    # each characteristic on its own (what carries each layer)
    for code, (col, layer, _) in CHARACTERISTICS.items():
        d = train.copy()
        d[code] = values[code].values
        variants.append(layer_test(d, {"L1": "H1", "L2": "H2", "L3": "H3"}[layer], code, "single characteristic"))
    pd.DataFrame(variants).to_csv(out / "h1_h3_variants.csv", index=False)

    # ---- H4 by event year: conditional logit per year primary, Mann-Whitney supplementary
    h4 = []
    for yr in range(-cfg.window, 0):
        sub = train[train["event_time"] == yr]
        for layer in ("L1_SCORE", "L2_SCORE", "L3_SCORE"):
            t = inf.conditional_logit(sub, [layer] + CONTROLS, group="cluster_id")
            r = t[t["term"] == layer] if "term" in t.columns else pd.DataFrame()
            a, b = sub.loc[sub[Y] == 1, layer].dropna(), sub.loc[sub[Y] == 0, layer].dropna()
            mw = stats.mannwhitneyu(a, b, alternative="greater").pvalue if len(a) > 2 and len(b) > 2 else np.nan
            rr = r.iloc[0] if len(r) else None
            h4.append({"event_year": yr, "layer_score": layer, "n_firm_years": int(rr["n"]) if rr is not None else 0,
                       "n_matched_sets": int(rr["n_clusters"]) if rr is not None else 0, "n_fraud": int(sub[Y].sum()),
                       "mean_fraud": a.mean(), "mean_matched": b.mean(),
                       "cond_coef": float(rr["coef"]) if rr is not None else np.nan, "cond_or_per_sd": float(np.exp(rr["coef"])) if rr is not None else np.nan,
                       "cond_p": float(rr["p"]) if rr is not None else np.nan, "cond_p_firm_cluster": float(rr.get("p_cluster", np.nan)) if rr is not None else np.nan,
                       "mannwhitney_p_greater": mw})
    h4 = pd.DataFrame(h4)
    h4["significant_as_predicted_cond"] = (h4["cond_coef"] > 0) & (h4["cond_p"] < 0.05)
    h4.to_csv(out / "h4_by_year.csv", index=False)
    h4_rule = h4[h4["event_year"] < -1].groupby("layer_score")["significant_as_predicted_cond"].any().rename("design_rule_met_before_final_year").to_frame()
    h4_rule["years_significant"] = h4[h4["significant_as_predicted_cond"]].groupby("layer_score")["event_year"].apply(lambda s: ", ".join(map(str, s)))
    h4_rule["tests_run"] = h4.groupby("layer_score").size()
    h4_rule.to_csv(out / "h4_design_rule.csv")

    # ---- H5: Model A vs Model B (design AI_SCORE), timing at equal false-alarm rate
    feats_a, feats_b = ["TRAD_INDEX"] + CONTROLS, ["TRAD_INDEX"] + CONTROLS + ["AI_SCORE"]
    pa, pb = loco_auc(train, feats_a), loco_auc(train, feats_b)
    mask = pa.notna() & pb.notna()
    y = train.loc[mask, Y].astype(int)
    auc_a, auc_b = roc_auc_score(y, pa[mask]), roc_auc_score(y, pb[mask])
    gain_lo, gain_hi = set_bootstrap_auc_gain(y, pa[mask], pb[mask], train.loc[mask, "cluster_id"])
    full_b = inf.clustered_logit(train, feats_b)
    ai_row = full_b[full_b["term"] == "AI_SCORE"].iloc[0] if "term" in full_b.columns and (full_b["term"] == "AI_SCORE").any() else None
    cond_b = inf.conditional_logit(train, feats_b)
    ai_cond = cond_b[cond_b["term"] == "AI_SCORE"].iloc[0] if "term" in cond_b.columns and (cond_b["term"] == "AI_SCORE").any() else None
    m_ai = train["AI_SCORE"].notna()
    auc_ai_alone = roc_auc_score(train.loc[m_ai, Y].astype(int), train.loc[m_ai, "AI_SCORE"])
    m_tr = train["TRAD_INDEX"].notna()
    auc_trad_alone = roc_auc_score(train.loc[m_tr, Y].astype(int), train.loc[m_tr, "TRAD_INDEX"])
    peers = train[train[Y] == 0]
    # the traditional rule whose matched-firm (false-alarm) rate is <= 5%, and the AI threshold at the SAME rate
    trad_k = next((k for k in (1, 2, 3, 4) if (peers["TRAD_INDEX"] >= k).mean() <= cfg.target_fpr), 4)
    far_trad = float((peers["TRAD_INDEX"] >= trad_k).mean())
    thr_ai_5 = float(peers["AI_SCORE"].quantile(1 - cfg.target_fpr))
    thr_ai_eq = float(peers["AI_SCORE"].quantile(1 - far_trad)) if far_trad > 0 else float(peers["AI_SCORE"].max()) + 1e-9
    far_ai_5 = float((peers["AI_SCORE"] >= thr_ai_5).mean())
    far_ai_eq = float((peers["AI_SCORE"] >= thr_ai_eq).mean())
    train["AI_FLAG_5"] = train["AI_SCORE"] >= thr_ai_5
    train["AI_FLAG_EQ"] = train["AI_SCORE"] >= thr_ai_eq
    train["TRAD_FLAG"] = train["TRAD_INDEX"] >= trad_k
    train["TRAD_FLAG_GE1"] = train["TRAD_INDEX"] >= 1
    timing = []
    for cid, g in train[train["case_role"] == "case"].groupby("cluster_id"):
        g = g.sort_values("event_time")
        first = lambda col: g.loc[g[col] == True, "event_time"].min()  # noqa: E712
        ai5, aieq, tr, tr1 = first("AI_FLAG_5"), first("AI_FLAG_EQ"), first("TRAD_FLAG"), first("TRAD_FLAG_GE1")
        timing.append({"case": cid, "stratum": g["stratum"].iloc[0], "ai_first_year_5pct_far": ai5, "ai_first_year_equal_far": aieq,
                       f"trad_ge{trad_k}_first_year": tr, "trad_ge1_first_year": tr1,
                       "ai_earlier_equal_far": bool(pd.notna(aieq) and (pd.isna(tr) or aieq < tr)),
                       "same_year_equal_far": bool(pd.notna(aieq) and pd.notna(tr) and aieq == tr),
                       "trad_earlier_equal_far": bool(pd.notna(tr) and (pd.isna(aieq) or tr < aieq)),
                       "flagged_by_neither_equal_far": bool(pd.isna(aieq) and pd.isna(tr)),
                       "ai_years_flagged_5pct": int(g["AI_FLAG_5"].sum()), "window_years": len(g)})
    timing = pd.DataFrame(timing)
    timing.to_csv(out / "h5_timing_by_case.csv", index=False)
    # union of the two rules vs each rule at the union's own false-alarm rate
    union_far = float(((peers["AI_SCORE"] >= thr_ai_eq) | (peers["TRAD_INDEX"] >= trad_k)).mean())
    thr_ai_union = float(peers["AI_SCORE"].quantile(1 - union_far)) if union_far > 0 else thr_ai_eq
    case_rows = train[train["case_role"] == "case"]
    cases_union = case_rows.groupby("cluster_id").apply(lambda g: bool(((g["AI_SCORE"] >= thr_ai_eq) | (g["TRAD_INDEX"] >= trad_k)).any())).sum()
    cases_ai_at_union_far = case_rows.groupby("cluster_id").apply(lambda g: bool((g["AI_SCORE"] >= thr_ai_union).any())).sum()
    trad_k_union = next((k for k in (1, 2, 3, 4) if (peers["TRAD_INDEX"] >= k).mean() <= union_far), trad_k)
    cases_trad_at_union_far = case_rows.groupby("cluster_id").apply(lambda g: bool((g["TRAD_INDEX"] >= trad_k_union).any())).sum()
    h5 = pd.DataFrame([{
        "model_A": "+".join(feats_a), "model_B": "+".join(feats_b), "n_firm_years": int(mask.sum()), "n_fraud_firm_years": int(y.sum()), "n_matched_sets": int(train.loc[mask, "cluster_id"].nunique()),
        "loso_auc_model_A": round(auc_a, 3), "loso_auc_model_B": round(auc_b, 3), "auc_gain_B_minus_A": round(auc_b - auc_a, 3),
        "auc_gain_ci_low": round(gain_lo, 3), "auc_gain_ci_high": round(gain_hi, 3),
        "auc_trad_index_alone": round(auc_trad_alone, 3), "auc_ai_score_alone": round(auc_ai_alone, 3),
        "AI_SCORE_coef_per_sd_model_B_pooled": float(ai_row["coef"]) if ai_row is not None else np.nan,
        "AI_SCORE_or_ci_pooled": f"{np.exp(ai_row['ci_low']):.2f}-{np.exp(ai_row['ci_high']):.2f}" if ai_row is not None else "",
        "AI_SCORE_p_model_B_pooled_firm_cluster": float(ai_row["p"]) if ai_row is not None else np.nan,
        "AI_SCORE_coef_per_sd_model_B_conditional": float(ai_cond["coef"]) if ai_cond is not None else np.nan,
        "AI_SCORE_p_model_B_conditional": float(ai_cond["p"]) if ai_cond is not None else np.nan,
        "AI_SCORE_p_model_B_conditional_firm_cluster": float(ai_cond.get("p_cluster", np.nan)) if ai_cond is not None else np.nan,
        "ai_threshold_5pct_far": round(thr_ai_5, 3), "ai_far_at_5pct_rule": round(far_ai_5, 3),
        "trad_rule_equal_far": f"TRAD_INDEX >= {trad_k}", "trad_far": round(far_trad, 3), "ai_threshold_equal_far": round(thr_ai_eq, 3), "ai_far_equal_rule": round(far_ai_eq, 3),
        "cases": len(timing), "cases_flagged_ai_5pct": int(timing["ai_first_year_5pct_far"].notna().sum()), "cases_never_flagged_ai_5pct": int(timing["ai_first_year_5pct_far"].isna().sum()),
        "cases_flagged_ai_equal_far": int(timing["ai_first_year_equal_far"].notna().sum()), "cases_flagged_trad_equal_far": int(timing[f"trad_ge{trad_k}_first_year"].notna().sum()),
        "cases_ai_earlier_equal_far": int(timing["ai_earlier_equal_far"].sum()), "cases_same_year_equal_far": int(timing["same_year_equal_far"].sum()),
        "cases_trad_earlier_equal_far": int(timing["trad_earlier_equal_far"].sum()), "cases_flagged_by_neither_equal_far": int(timing["flagged_by_neither_equal_far"].sum()),
        "earliest_ai_year_median_5pct": float(timing["ai_first_year_5pct_far"].median()) if timing["ai_first_year_5pct_far"].notna().any() else np.nan,
        "union_far": round(union_far, 3), "cases_flagged_union": int(cases_union), "cases_flagged_ai_alone_at_union_far": int(cases_ai_at_union_far),
        "cases_flagged_trad_alone_at_union_far": int(cases_trad_at_union_far), "trad_rule_at_union_far": f"TRAD_INDEX >= {trad_k_union}",
        "trad_ge1_matched_rate": round(float((peers["TRAD_INDEX"] >= 1).mean()), 3),
    }])
    h5.to_csv(out / "h5_model_ab.csv", index=False)
    # H5 supported by the design's rule?
    h5_supported = {
        "AI_SCORE significant in Model B (pooled, firm-clustered)": bool(ai_row is not None and ai_row["coef"] > 0 and ai_row["p"] < 0.05),
        "Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0)": bool(auc_b > auc_a and gain_lo > 0),
        "AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)": bool(timing["ai_earlier_equal_far"].sum() > timing["trad_earlier_equal_far"].sum()),
    }
    pd.Series(h5_supported).to_frame("met").to_csv(out / "h5_design_rule.csv")

    # ---- P1 (descriptive)
    p1 = pd.DataFrame()
    if cases is not None and "d1_class" in cases.columns:
        form = dict(zip(cases.loc[cases["role"] == "case", "case_id"], cases.loc[cases["role"] == "case", "d1_class"]))
        cf = pd.DataFrame({"lending": values["RP_LEND"], "sales": values["RP_SALES"], "purchases": values["RP_PURCH"], "cluster_id": train["cluster_id"], "role": train["case_role"]})
        cf = cf[cf["role"] == "case"].groupby("cluster_id").agg(lending=("lending", lambda s: int((s.fillna(0) > 0).any())), sales=("sales", lambda s: int((s.fillna(0) > 0).any())),
                                                                 purchases=("purchases", lambda s: int((s.fillna(0) > 0).any())))
        cf["form"] = cf.index.map(form)
        cf["form_group"] = np.where(cf["form"].str.contains("misappropriation", na=False) & ~cf["form"].str.contains("misstatement", na=False), "managerial",
                           np.where(cf["form"].str.contains("misstatement", na=False) & ~cf["form"].str.contains("misappropriation", na=False), "corporate",
                           np.where(cf["form"].str.contains("disclosure_only", na=False), "disclosure-only (not in P1)", "both")))
        p1 = cf.groupby("form_group")[["lending", "sales", "purchases"]].agg(["sum", "count"])
        p1.columns = ["_".join(c) for c in p1.columns]
        p1.to_csv(out / "p1_rpt_types_by_form.csv")

    # ---- A1 attribution (direct arithmetic), A2 stability (leave one set out), A3 reading against theory
    attr = attribution(train[["L1_SCORE", "L2_SCORE", "L3_SCORE", "L1_n_obs", "L2_n_obs", "L3_n_obs", "n_layers", "AI_SCORE"]], ranks)
    a1 = pd.concat([train[["cik", "company_name", "cluster_id", "case_role", "stratum", "fiscal_year", "event_time", Y, "AI_SCORE", "AI_FLAG_5"]], attr], axis=1)
    a1.to_csv(out / "a1_attribution_by_firm_year.csv", index=False)
    flagged = a1[(a1[Y] == 1) & (a1["AI_FLAG_5"])]
    a1_summary = pd.DataFrame({
        "mean_share_all_firm_years": a1[[c for c in attr.columns if c.startswith("share_")]].mean(),
        "mean_share_fraud_firm_years": a1.loc[a1[Y] == 1, [c for c in attr.columns if c.startswith("share_")]].mean(),
        "mean_share_flagged_fraud_firm_years": flagged[[c for c in attr.columns if c.startswith("share_")]].mean(),
    }).round(3)
    a1_summary.to_csv(out / "a1_attribution_summary.csv")
    # A2: refit (re-rank) without each matched set in turn; score the held-out set against the remaining firm-years
    a2_rows = []
    for g in train["cluster_id"].unique():
        held = train["cluster_id"] == g
        sc_h, rk_h = rank_scores(values[held], ref=values[~held])
        at_h = attribution(sc_h, rk_h)
        for i in np.where(held)[0]:
            full_shares = attr.loc[i, [f"share_{l}" for l in ("L1", "L2", "L3")]].values.astype(float)
            held_shares = at_h.loc[i, [f"share_{l}" for l in ("L1", "L2", "L3")]].values.astype(float)
            a2_rows.append({"cluster_id": g, "row": i, "ai_full": train.loc[i, "AI_SCORE"], "ai_loso": sc_h.loc[i, "AI_SCORE"],
                            "max_abs_layer_share_change": float(np.nanmax(np.abs(full_shares - held_shares))) if np.isfinite(full_shares).any() else np.nan,
                            "largest_layer_unchanged": attr.loc[i, "largest_layer"] == at_h.loc[i, "largest_layer"],
                            "named_evidence_unchanged": attr.loc[i, "named_evidence"] == at_h.loc[i, "named_evidence"]})
    a2 = pd.DataFrame(a2_rows)
    a2.to_csv(out / "a2_stability_by_firm_year.csv", index=False)
    ok = a2.dropna(subset=["ai_full", "ai_loso"])
    a2_summary = pd.DataFrame([{
        "firm_years": len(a2), "spearman_ai_score_full_vs_loso": float(stats.spearmanr(ok["ai_full"], ok["ai_loso"]).statistic) if len(ok) > 2 else np.nan,
        "mean_abs_ai_score_change": float((ok["ai_full"] - ok["ai_loso"]).abs().mean()), "median_max_abs_layer_share_change": float(a2["max_abs_layer_share_change"].median()),
        "share_largest_layer_unchanged": float(a2["largest_layer_unchanged"].mean()), "share_named_evidence_unchanged": float(a2["named_evidence_unchanged"].mean()),
        "method": "ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions"}])
    a2_summary.to_csv(out / "a2_stability_summary.csv", index=False)
    # A3: largest contributing layer among the fraud firm-years flagged by the AI risk score; direction per layer
    direction = []
    for layer in ("L1", "L2", "L3"):
        a_, b_ = train.loc[train[Y] == 1, f"{layer}_SCORE"].dropna(), train.loc[train[Y] == 0, f"{layer}_SCORE"].dropna()
        direction.append({"layer": layer, "agency_idea": LAYER_NAME[layer], "mean_fraud": round(a_.mean(), 3), "mean_matched": round(b_.mean(), 3),
                          "direction": "fraud firms higher (as predicted)" if a_.mean() > b_.mean() else "fraud firms LOWER (against the prediction)",
                          "flagged_fraud_firm_years_where_largest": int((flagged["largest_layer"] == layer).sum())})
    a3 = pd.DataFrame(direction)
    a3["flagged_fraud_firm_years"] = len(flagged)
    a3["flagged_cases"] = flagged["cluster_id"].nunique()
    a3.to_csv(out / "a3_layers_in_flagged_fraud_firm_years.csv", index=False)
    flagged[["company_name", "cluster_id", "fiscal_year", "event_time", "AI_SCORE", "largest_layer", "named_evidence"]].to_csv(out / "a3_flagged_fraud_firm_years.csv", index=False)

    # ---- lead time as the review words it
    lead = timing[["case", "stratum", "ai_first_year_5pct_far", "ai_years_flagged_5pct", "window_years"]].rename(columns={"ai_first_year_5pct_far": "earliest_window_year_separated_from_matched_firms"})
    lead.to_csv(out / "lead_time_by_case.csv", index=False)

    # ---- power restated for the final sample
    power = pd.DataFrame()
    if not args.no_power:
        peers_per_set = int(round(train[train["case_role"] != "case"].groupby("cluster_id")["cik"].nunique().mean()))
        power = power_simulation(sorted({21, n_sets_all, 35, 40}), [1.5, 1.65, 2.0], peers=peers_per_set, reps=args.power_reps)
        power.to_csv(out / "power_simulation.csv", index=False)

    # ---- exploratory: the fitted 36-input score (contains the traditional signals) -- labelled, kept apart
    expl = pd.DataFrame()
    spec_path = R._out(cfg, "model_spec.json")
    if spec_path.exists() and not args.extra_config:
        spec0 = json.loads(spec_path.read_text(encoding="utf-8"))
        train["ML_SCORE"] = R._scores_for(cfg, train, spec0.get("alert_model", spec0["primary_model"]))
        pb2 = loco_auc(train, feats_a + ["ML_SCORE"])
        m2 = pa.notna() & pb2.notna()
        thr_ml = float(spec0["threshold"])
        ml_flag_cases = train[train["case_role"] == "case"].groupby("cluster_id")["ML_SCORE"].apply(lambda s: bool((s >= thr_ml).any()))
        expl = pd.DataFrame([{
            "note": "EXPLORATORY: the fitted ensemble score uses 36 inputs including ICFR, audit-opinion, auditor-change and restatement signals, Big-4 status and general financial ratios; it cannot test whether the RPT layers add to the benchmark",
            "loso_auc_model_A": round(roc_auc_score(train.loc[m2, Y].astype(int), pa[m2]), 3),
            "loso_auc_model_A_plus_fitted_score": round(roc_auc_score(train.loc[m2, Y].astype(int), pb2[m2]), 3),
            "auc_fitted_score_alone_oof": round(roc_auc_score(train.loc[train["ML_SCORE"].notna(), Y].astype(int), train.loc[train["ML_SCORE"].notna(), "ML_SCORE"]), 3),
            "fitted_threshold": round(thr_ml, 3), "fitted_far_matched": round(float((peers.index.map(lambda i: train.loc[i, "ML_SCORE"]) >= thr_ml).mean()), 3) if "ML_SCORE" in train else np.nan,
            "cases_flagged_fitted": int(ml_flag_cases.sum()), "cases_never_flagged_fitted": int((~ml_flag_cases).sum()),
        }])
        expl.to_csv(out / "exploratory_fitted_score.csv", index=False)

    # ---- deviations and summary
    pd.DataFrame({"deviation": deviations or ["none: AUD_OPIN and RESTATE coded as the design defines them"]}).to_csv(out / "deviations.csv", index=False)
    sets_by_stratum = train.drop_duplicates("cluster_id")["stratum"].value_counts().to_dict()
    L = ["# Design test battery (v2) — " + args.name, "",
         f"Analysed firm-years: {len(train)} ({int(train[Y].sum())} fraud firm-years) in {n_sets_all} matched sets: {n_cases} RPT-fraud cases (FRAUD = 1; strata {sets_by_stratum}) and {n_peers} matched firms.",
         f"AUD_OPIN: {aud_def}. RESTATE: {restate_def}.", "",
         "## M1 coverage by group (selection on the outcome where the Fisher p is small)", "", m1.round(3).to_markdown(index=False), ""]
    if len(text_src):
        L += ["## Text source by group", "", text_src.to_markdown(), ""]
    L += ["## Scoring rules", "", layer_rule.to_markdown(index=False), "",
          "## M3 layer-score correlations", "", m3.to_markdown(), "",
          "## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)", "", h13.round(3).to_markdown(index=False), "",
          "## H2 re-runs and single-characteristic tests", "", pd.DataFrame(variants).round(3).to_markdown(index=False), "",
          "## H4 by event year (conditional logit primary; Mann–Whitney supplementary)", "", h4.round(3).to_markdown(index=False), "", h4_rule.to_markdown(), "",
          "## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate", "", h5.T.to_markdown(), "", pd.Series(h5_supported).to_frame("met").to_markdown(), "",
          "## Timing by case", "", timing.to_markdown(index=False), ""]
    if len(p1):
        L += ["## P1 RPT types by form of fraud (descriptive)", "", p1.to_markdown(), ""]
    L += ["## A1 attribution summary (share of AI_SCORE)", "", a1_summary.to_markdown(), "",
          "## A2 stability (leave one matched set out)", "", a2_summary.T.to_markdown(), "",
          "## A3 layers in the flagged fraud firm-years", "", a3.to_markdown(index=False), ""]
    if len(power):
        L += ["## Power (simulation)", "", power.to_markdown(index=False), ""]
    if len(expl):
        L += ["## EXPLORATORY — fitted 36-input score", "", expl.T.to_markdown(), ""]
    L += ["## Deviations", "", "\n".join(f"- {d}" for d in (deviations or ["none"])), ""]
    (out / "summary.md").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L))


if __name__ == "__main__":
    main()
