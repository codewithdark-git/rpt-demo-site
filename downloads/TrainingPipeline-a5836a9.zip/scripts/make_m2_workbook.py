"""M2 reliability: the human-coding workbook and the agreement calculator.

The design (RO2, M2) compares the machine coding of the amounts and disclosure items with human coding on a
random subsample, at an agreement level agreed with the supervisors before the result is used. The sample was
drawn on 8 Oct 2026 (``data/m2_hand_check_sample.csv``, 10 % per variable, evidence passage attached). This
script (a) writes that sample as an Excel workbook a coder can fill in — one sheet per variable, the evidence
passage next to the machine value, a ``human_value`` column with the allowed values, a ``note`` column — and
(b) once the workbook is filled, computes the agreement statistics per variable: Cohen's kappa for binary
items, Spearman and the share within 10 % for amounts, with 95 % bootstrap intervals.

    python scripts/make_m2_workbook.py build   --out data/M2_coding_workbook.xlsx
    python scripts/make_m2_workbook.py score   --workbook data/M2_coding_workbook.xlsx --out docs/m2_agreement.csv
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

BINARY = {"big4", "auditor_change", "going_concern_opinion", "ceo_duality", "ac_indep", "counterparty_named", "amount_stated",
          "terms_stated", "purpose_stated", "no_transactions_stated"}
AMOUNTS = {"RP_LEND", "RP_PAY", "RP_SALES", "RP_PURCH"}
SHARES = {"board_indep", "rp_incomp"}
INSTRUCTIONS = [
    "M2 reliability check — instructions for the coder",
    "",
    "1. Each sheet holds one variable. Read the evidence passage (column 'evidence') and, where needed, the filing itself",
    "   (SEC-EDGAR-Downloader/data_core/raw/filings/<cik>/<year>/<accession>/). Do NOT look at the machine value first.",
    "2. Enter your value in 'human_value':",
    "   - binary items (big4, auditor_change, going_concern_opinion, ceo_duality, ac_indep, counterparty_named, amount_stated,",
    "     terms_stated, purpose_stated): 1 = yes, 0 = no, blank = cannot be determined from the filing",
    "   - board_indep: independent directors ÷ board size as a decimal (e.g. 0.714); rp_incomp: (4 − items stated) ÷ 4",
    "   - RP_LEND / RP_PAY / RP_SALES / RP_PURCH: the largest amount of that flow in US dollars (e.g. 1250000), 0 if the",
    "     flow is disclosed with no amount, blank if the flow is not disclosed",
    "3. Use 'note' for anything unusual (amount in a table the text missed; wrong direction; wrong counterparty).",
    "4. Do not change any other column. Save the workbook and run: python scripts/make_m2_workbook.py score --workbook <file>",
    "",
    "Threshold: to be agreed with the supervisors before the scores are read (the assistant's proposal, Cohen's kappa ≥ 0.70",
    "for binary items and ≥ 90 % of amounts within 10 %, is a proposal and not a decision). Record the agreed level here:",
    "AGREED THRESHOLD: ______________________   DATE: ____________   SIGNED: ____________",
]


def build(sample: Path, out: Path) -> None:
    s = pd.read_csv(sample, dtype={"cik": str}, keep_default_na=False)
    s["cik"] = s["cik"].str.zfill(10)
    with pd.ExcelWriter(out, engine="openpyxl") as xw:
        pd.DataFrame({"instructions": INSTRUCTIONS}).to_excel(xw, sheet_name="README", index=False)
        summary = s.groupby(["source", "variable"]).size().rename("rows").reset_index()
        summary.to_excel(xw, sheet_name="sample_summary", index=False)
        for var, g in s.groupby("variable"):
            g = g[["source", "variable", "cik", "fiscal_year", "coded_value", "evidence", "proxy_accession", "text_source", "human_value", "note"]].copy()
            g["human_value"] = ""
            g["note"] = ""
            g.to_excel(xw, sheet_name=str(var)[:31], index=False)
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.datavalidation import DataValidation
        wb = xw.book
        for ws in wb.worksheets:
            if ws.title in ("README", "sample_summary"):
                ws.column_dimensions["A"].width = 120
                continue
            ws.freeze_panes = "A2"
            widths = {"A": 16, "B": 18, "C": 12, "D": 8, "E": 12, "F": 90, "G": 22, "H": 14, "I": 14, "J": 30}
            for col, w in widths.items():
                ws.column_dimensions[col].width = w
            for cell in ws[1]:
                cell.font = Font(bold=True)
            fill = PatternFill("solid", fgColor="FFF2CC")
            for row in ws.iter_rows(min_row=2):
                row[5].alignment = Alignment(wrap_text=True, vertical="top")
                row[8].fill = fill
            if ws.title in BINARY:
                dv = DataValidation(type="list", formula1='"0,1"', allow_blank=True)
                dv.add(f"I2:I{ws.max_row}")
                ws.add_data_validation(dv)
    print(f"{out}: {len(s)} rows in {s['variable'].nunique()} sheets")


def kappa(a: np.ndarray, b: np.ndarray) -> float:
    cats = np.unique(np.concatenate([a, b]))
    n = len(a)
    po = float((a == b).mean())
    pe = float(sum((a == c).mean() * (b == c).mean() for c in cats))
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def score(workbook: Path, out: Path, n_boot: int = 2000, seed: int = 42) -> None:
    rng = np.random.default_rng(seed)
    sheets = pd.read_excel(workbook, sheet_name=None, dtype={"cik": str})
    rows = []
    for name, df in sheets.items():
        if name in ("README", "sample_summary") or "human_value" not in df.columns:
            continue
        d = df.dropna(subset=["human_value"]).copy()
        d = d[d["human_value"].astype(str).str.strip() != ""]
        if d.empty:
            rows.append({"variable": name, "n_coded": 0, "statistic": "", "value": np.nan, "note": "no human values yet"})
            continue
        m = pd.to_numeric(d["coded_value"], errors="coerce")
        h = pd.to_numeric(d["human_value"], errors="coerce")
        ok = m.notna() & h.notna()
        m, h = m[ok].values, h[ok].values
        if name in BINARY:
            k = kappa(m.astype(int), h.astype(int))
            boots = [kappa(m[i].astype(int), h[i].astype(int)) for i in (rng.integers(0, len(m), len(m)) for _ in range(n_boot))]
            rows.append({"variable": name, "n_coded": int(ok.sum()), "statistic": "Cohen kappa", "value": round(k, 3),
                         "ci_low": round(float(np.percentile(boots, 2.5)), 3), "ci_high": round(float(np.percentile(boots, 97.5)), 3),
                         "percent_agreement": round(float((m == h).mean()), 3)})
        elif name in AMOUNTS:
            both = (m > 0) & (h > 0)
            within = np.abs(m[both] - h[both]) <= 0.10 * np.maximum(h[both], 1)
            rho = float(pd.Series(m).corr(pd.Series(h), method="spearman")) if len(m) > 2 else np.nan
            rows.append({"variable": name, "n_coded": int(ok.sum()), "statistic": "share of amounts within 10 % (both > 0)", "value": round(float(within.mean()), 3) if both.any() else np.nan,
                         "spearman": round(rho, 3), "presence_kappa": round(kappa((m > 0).astype(int), (h > 0).astype(int)), 3)})
        else:
            rho = float(pd.Series(m).corr(pd.Series(h), method="spearman")) if len(m) > 2 else np.nan
            rows.append({"variable": name, "n_coded": int(ok.sum()), "statistic": "Spearman (share within 0.10)", "value": round(rho, 3),
                         "share_within_0_10": round(float((np.abs(m - h) <= 0.10).mean()), 3)})
    res = pd.DataFrame(rows)
    out.parent.mkdir(parents=True, exist_ok=True)
    res.to_csv(out, index=False)
    print(res.to_string())


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--sample", default="data/m2_hand_check_sample.csv")
    b.add_argument("--out", default="data/M2_coding_workbook.xlsx")
    s = sub.add_parser("score")
    s.add_argument("--workbook", default="data/M2_coding_workbook.xlsx")
    s.add_argument("--out", default="docs/m2_agreement.csv")
    a = ap.parse_args()
    if a.cmd == "build":
        build(Path(a.sample), Path(a.out))
    else:
        score(Path(a.workbook), Path(a.out))


if __name__ == "__main__":
    main()
