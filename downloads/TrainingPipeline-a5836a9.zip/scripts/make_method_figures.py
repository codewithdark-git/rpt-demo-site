"""Draw the methodology figures for the thesis chapter (matplotlib only).

    python scripts/make_method_figures.py docs/thesis_figures

Boxes size themselves to their wrapped text so nothing overflows.
"""
from __future__ import annotations

import sys

import numpy as np
import textwrap
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

LINE_H = 0.0165        # axis units per text line at fs=8 on a 15-inch-tall figure (scaled below)


def wrap(lines, width):
    out = []
    for ln in lines:
        out += textwrap.wrap(ln, width=width, subsequent_indent="   ") or [""]
    return out


def box(ax, x, y, w, h, title, lines, fc="#eef3fb", ec="#2b4c7e", fs=8.0):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.004,rounding_size=0.012", fc=fc, ec=ec, lw=1.2))
    ax.text(x + w / 2, y + h - 0.012, title, ha="center", va="top", fontsize=fs + 1.3, fontweight="bold", color="#1f2d3d")
    ax.text(x + 0.012, y + h - 0.012 - 0.03, "\n".join(lines), ha="left", va="top", fontsize=fs, color="#1f2d3d", linespacing=1.3)


def arrow(ax, x1, y1, x2, y2, label=None, dy=0.012):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=13, lw=1.2, color="#2b4c7e"))
    if label:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + dy, label, ha="center", va="bottom", fontsize=7.5, color="#2b4c7e")


def methodology_flow(path: Path) -> None:
    fig_h = 16
    fig, ax = plt.subplots(figsize=(13, fig_h))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    lh = 0.0155  # line height for fs 8 at this figure height
    ax.text(0.5, 0.992, "Three-stage methodology: sample and data  ->  measurement  ->  modelling, inference and validation",
            ha="center", va="top", fontsize=13, fontweight="bold")
    stages = [
        ("Stage 1 - Sample and data (Phase A discovery and matching; Phase B download and extraction)", [
            "A1 Discovery of RPT enforcement cases: every AAER 2005-2024 (2,383 texts), every SEC litigation release 2010-2025 (5,086 texts), EDGAR full-text search of issuers' own filings, client workbook (58 candidates).",
            "A2 Inclusion rule D1: the SEC order or complaint describes a misstatement or misappropriation in which an RPT is the mechanism (core); disclosure-only charges form a separate stratum; no-RPT or controls-only orders are excluded.",
            "A3 Revelation date D2: first public event (8-K Item 4.02 non-reliance, auditor resignation, investigation, short report, restatement, else the SEC action) with a confidence level; window = the five fiscal years before the revelation year.",
            "A4 Four annual reports in the window and window >= FY2005 (Item 9A exists); three-report cases form the external validation set.",
            "A5 Peer matching D4: same SIC-4 (fallback SIC-3, SIC-2), nearest ln(total assets) at FY(revelation - 1), a 10-K in every window year, no AAER match; five per case without replacement.",
            "B1 EDGAR download: 10-K / 10-KT, a DEF 14A for every filing year, XBRL company facts, 8-K items 4.01 and 4.02, AAER texts; QA report.",
            "B2 Extraction: Item 1, Item 9A, Item 13 body, related-party note, proxy RPT section, audit-report signature and going-concern paragraph, board statements.",
        ], "#eef3fb", "#2b4c7e",
         ["company_universe.csv", "filing_manifest.csv", "proxy_links.csv", "eightk_items.csv", "xbrl_financials.csv", "fraud_labels.csv (FRAUD, event time)",
          "master_panel.csv", "dataset_qa.json", "raw/filings/<CIK>/<year>/<accession>/*.txt"]),
        ("Stage 2 - Measurement: four layers, a text model and controls", [
            "L1 Financial (conflict of interest): RP_LEND, RP_PAY, RP_SALES, RP_PURCH coded from the related-party text (largest classified amount per flow, scaled by assets or revenue); earnings-cash divergence and accruals from XBRL, bounded.",
            "L2 Monitoring and governance: ICFR not effective, material weakness and its two-year persistence (Item 9A); Big-4, auditor change, going concern (audit report; 8-K 4.01); restatement (8-K 4.02); CEO duality, board and audit-committee independence (proxy, rule-coded with evidence).",
            "L3 Disclosure (information asymmetry): RP_INCOMP (four items), vagueness, relabeling, indeterminacy, transparency, agency masking (SFL), passive ratio, Fog, year-on-year drift, boilerplate similarity, specificity gap versus Item 1.",
            "L4 Peer-relative: leave-one-out z-scores within each matched set and year; RPT text distance to the peers' TF-IDF centroid.",
            "Stacked text risk: TF-IDF logistic regression on the related-party text fitted in nested grouped folds; vocabulary limited to terms used by three or more firms.",
            "Controls: ln assets, leverage, ROA, listing age. Missing values stay missing (median imputation inside the training fold only).",
        ], "#f3f8ee", "#3b6e22",
         ["governance_manual.csv (values + evidence)", "rp_note_coded.csv (values + evidence)", "panel_features.csv (feature matrix X)", "panel_texts.csv",
          "tables/feature_coverage", "tables/descriptives"]),
        ("Stage 3 - Modelling, inference and validation", [
            "Design scores: each characteristic ranked 0-1 over all firm-years; layer score = mean rank; AI_SCORE = 10 x mean of the layer scores; TRAD_INDEX = count of the four traditional signals.",
            "H1-H3: conditional (fixed-effects) logit within matched sets with leverage and ROA; standardised predictors; Holm adjustment across the three tests. H4: Mann-Whitney and conditional logit per event year. H5: Model A (TRAD_INDEX + controls) versus Model B (+ score), leave-one-set-out AUC; timing at comparable false-alarm rates. P1: cross-tabulation by form of fraud.",
            "Fitted alert: L2 logit (primary), random forest, XGBoost in fold-local pipelines; mean-probability ensemble; leave-one-matched-set-out; threshold at a clean-firm false-positive rate of 5 % or less; AUC, PR-AUC, cluster-bootstrap intervals (2,000 resamples of matched sets).",
            "Stress tests: T1 specificity, T2 ablation, T3 lead time, T4 material-weakness persistence, T5 clean-firm FPR; mediation P4 by cluster bootstrap.",
            "RO4: SHAP attributions, stability (Spearman across models and 200 resamples), traceability of top-3 attributions to filing evidence.",
            "Validation: robustness cuts (matching quality, text availability, era, date confidence), strata, three independent runs, external set of ten unseen cases, measurement checks M1-M3, revelation-date evidence pass.",
        ], "#fdf3ec", "#9a4e12",
         ["oof_scores.csv, oof_shap_<model>.csv", "tables/oof_metrics(_by_stratum)", "stress_tests/t1..t5", "tables/mediation, logit_clustered_*, logit_conditional_*",
          "explainability/attribution, stability, traceability", "design_tests/*", "external_validation.json", "figures/*"]),
    ]
    y = 0.965
    for i, (title, lines, fc, ec, outputs) in enumerate(stages):
        body = wrap(lines, 118)
        h = 0.05 + lh * len(body)
        box(ax, 0.02, y - h, 0.71, h, title, body, fc=fc, ec=ec, fs=8.0)
        obody = wrap(outputs, 34)
        box(ax, 0.76, y - h, 0.22, h, "Data products", obody, fc="#f5f5f5", ec="#555555", fs=7.6)
        arrow(ax, 0.73, y - h / 2, 0.76, y - h / 2)
        y_next = y - h - 0.035
        if i < 2:
            arrow(ax, 0.375, y - h, 0.375, y_next + 0.002, "firm-year panel with labels" if i == 0 else "feature matrix X and texts", dy=0.004)
        y = y_next
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def variable_framework(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(13, 7.2))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    lh = 0.034
    ax.text(0.5, 0.985, "Variable framework: three agency-theory layers, peer-relative layer, benchmark, controls and the outcome",
            ha="center", va="top", fontsize=12, fontweight="bold")
    left = [
        ("L1 Financial - conflict of interest - H1", ["RP_LEND, RP_PAY, RP_SALES, RP_PURCH: coded amounts / assets (sales / revenue)", "earnings-cash divergence, accruals (XBRL, bounded)", "FIN_SCORE = mean of 0-1 ranks"], "#eef3fb", "#2b4c7e"),
        ("L2 Disclosure - information asymmetry - H2", ["RP_INCOMP (4 items), RP_VAGUE, relabeling, indeterminacy, transparency,", "agency masking, passive ratio, Fog, drift (d_vagueness, d_fog),", "boilerplate similarity, specificity gap vs Item 1", "LING_SCORE = mean of ranks"], "#f3f8ee", "#3b6e22"),
        ("L3 Governance - weak monitoring - H3", ["BRD_NONIND = 1 - independent share of the board; DUAL (CEO = chair);", "audit-committee independence; Big-4 auditor", "GOV_SCORE = mean of ranks"], "#fdf3ec", "#9a4e12"),
    ]
    mid = [
        ("L4 Peer-relative - within set and year", ["leave-one-out z-scores of the L1-L3 measures", "RPT text distance to the matched firms' centroid", "stacked TF-IDF text risk (nested folds)", "-> fitted alert score (logit / RF / XGB, mean)"], "#f7f0fb", "#5e3a8c"),
        ("Traditional signals - benchmark - H5", ["ICFR_MW (Item 9A), AUD_OPIN (going concern),", "AUD_CHG (8-K 4.01), RESTATE (8-K 4.02)", "TRAD_INDEX = count 0-4"], "#f5f5f5", "#555555"),
        ("Controls and matching", ["LEV = liabilities / assets; ROA = net income / assets;", "ln assets; listing age", "industry (SIC), size and year held fixed by matching"], "#f5f5f5", "#555555"),
    ]
    # left column
    y = 0.93
    lw_, mw_ = 0.34, 0.29
    left_mid = []
    for title, lines, fc, ec in left:
        body = wrap(lines, 58)
        h = 0.05 + lh * len(body)
        box(ax, 0.02, y - h, lw_, h, title, body, fc=fc, ec=ec, fs=7.8)
        left_mid.append(y - h / 2)
        y -= h + 0.03
    y = 0.93
    mid_mid = []
    for title, lines, fc, ec in mid:
        body = wrap(lines, 49)
        h = 0.05 + lh * len(body)
        box(ax, 0.41, y - h, mw_, h, title, body, fc=fc, ec=ec, fs=7.8)
        mid_mid.append(y - h / 2)
        y -= h + 0.03
    obody = wrap(["FRAUD_it = 1 for a case firm's fiscal years in the five years before first public revelation (event time -5 .. -1); 0 for matched firm-years",
                  "FORM_i (managerial / corporate) for P1", "lead time, flags and strata for H4, H5 and T3"], 36)
    oh = 0.05 + lh * len(obody)
    oy = 0.60
    box(ax, 0.74, oy - oh / 2, 0.24, oh, "Outcome", obody, fc="#fbeeee", ec="#8c2b2b", fs=7.8)
    for ym in left_mid:
        arrow(ax, 0.02 + lw_, ym, 0.41, ym)          # layers feed the peer-relative / design-score column
    for ym in mid_mid:
        arrow(ax, 0.41 + mw_, ym, 0.74, oy)
    ax.text(0.5, 0.03, "Arrows are associations tested in the study, not claims of cause (design document, Figure 1).", ha="center", fontsize=8, style="italic")
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def validation_scheme(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(13, 5.2))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.text(0.5, 0.97, "Leave-one-matched-set-out validation with nested text stacking", ha="center", va="top", fontsize=12, fontweight="bold")
    for i in range(21):
        x = 0.03 + i * 0.045
        fc = "#8c2b2b" if i == 6 else "#2b4c7e"
        ax.add_patch(FancyBboxPatch((x, 0.70), 0.036, 0.16, boxstyle="round,pad=0.003", fc=fc, ec="white"))
        ax.text(x + 0.018, 0.78, f"S{i+1}", ha="center", va="center", fontsize=6.5, color="white")
    ax.text(0.5, 0.655, "Fold k: hold out matched set S_k (its case firm and its 3-5 matched firms, all window years); fit everything on the other 20 sets.",
            ha="center", va="top", fontsize=8.5)
    lh = 0.052
    cols = [
        ("Inside each training fold", ["1. median imputation and standardisation fitted on the fold", "2. inner grouped folds fit the TF-IDF logit on RPT texts -> out-of-inner-fold text_risk for training rows",
                                       "3. text model refit on the whole fold -> text_risk for S_k", "4. L2 logit, random forest and XGBoost fitted on the fold"], "#eef3fb", "#2b4c7e"),
        ("Out-of-fold outputs for S_k", ["risk probabilities from the four models and their mean", "SHAP values from the fold model", "assertion: no firm appears in both fit and test",
                                         "repeated for k = 1..21, so every row is scored once"], "#f3f8ee", "#3b6e22"),
        ("Evaluation on the pooled out-of-fold scores", ["AUC and PR-AUC", "95 % CI: resample matched sets with replacement (2,000 times)", "threshold: smallest score with clean-firm FPR <= 5 %",
                                                         "per-set AUC, lead time, calibration, stability"], "#fdf3ec", "#9a4e12"),
    ]
    x = 0.02
    for title, lines, fc, ec in cols:
        body = wrap(lines, 44)
        h = 0.10 + lh * len(body)
        box(ax, x, 0.58 - h, 0.31, h, title, body, fc=fc, ec=ec, fs=7.8)
        x += 0.325
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def methodology_blocks(path: Path) -> None:
    """One labelled block diagram of the whole methodology with minimal text: numbered blocks, three stage bands,
    arrows for the order of work. The explanation of every block is written separately in the methodology chapter
    (section 3.1.1 'Reading the diagram')."""
    fig, ax = plt.subplots(figsize=(13, 8.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.text(0.5, 0.985, "Figure 3.1  Methodology of the study: three stages, eighteen blocks", ha="center", va="top", fontsize=13, fontweight="bold")

    def band(y0, y1, title, fc):
        ax.add_patch(FancyBboxPatch((0.01, y0), 0.98, y1 - y0, boxstyle="round,pad=0.002,rounding_size=0.01", fc=fc, ec="none"))
        ax.text(0.02, y1 - 0.012, title, ha="left", va="top", fontsize=10.5, fontweight="bold", color="#1f2d3d")

    def block(x, y, w, h, num, label, fc, ec, fs=8.6):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.003,rounding_size=0.01", fc=fc, ec=ec, lw=1.3))
        ax.text(x + 0.012, y + h - 0.014, str(num), ha="left", va="top", fontsize=9.5, fontweight="bold", color=ec)
        ax.text(x + w / 2, y + h / 2 - 0.012, label, ha="center", va="center", fontsize=fs, color="#1f2d3d", linespacing=1.25)

    def arr(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12, lw=1.1, color="#444444"))

    # Stage 1 band
    band(0.665, 0.945, "Stage 1 — Sample and data", "#eef3fb")
    s1 = [("Case discovery\nAAER · LR · EDGAR FTS\n· client workbook"), ("Inclusion rule D1\nRPT is the mechanism;\ndisclosure-only stratum"),
          ("Revelation date D2\nfirst public event;\nconfidence level"), ("Window D3\nfive fiscal years before;\n≥ 4 annual reports"),
          ("Peer matching D4\nSIC-4 → 3 → 2; nearest\nln assets; 5 per case"), ("EDGAR download\n10-K · DEF 14A · XBRL\n8-K items · 10-K/A")]
    xs = np.linspace(0.025, 0.975 - 0.145, 6)
    for i, (x, lab) in enumerate(zip(xs, s1), 1):
        block(x, 0.70, 0.145, 0.19, i, lab, "#ffffff", "#2b4c7e")
        if i < 6:
            arr(x + 0.145, 0.795, xs[i] , 0.795)
    arr(0.5, 0.70, 0.5, 0.655)
    ax.text(0.515, 0.672, "firm-year panel (filings, labels, raw texts)", ha="left", va="center", fontsize=8, color="#444444")

    # Stage 2 band
    band(0.40, 0.65, "Stage 2 — Measurement", "#f3f8ee")
    block(0.025, 0.415, 0.15, 0.175, 7, "Section extraction\nItem 1 · 9A · 13 ·\nRP note · audit report\n· proxy", "#ffffff", "#3b6e22")
    block(0.195, 0.415, 0.245, 0.175, 8, "Eight RPT characteristics\nL1 lending · payables · sales · purchases\nL2 incompleteness · vagueness\nL3 board non-independence · duality", "#ffffff", "#3b6e22", fs=8.0)
    block(0.46, 0.415, 0.165, 0.175, 9, "Traditional signals\nICFR_MW · AUD_OPIN\nAUD_CHG · RESTATE\n→ TRAD_INDEX", "#ffffff", "#3b6e22")
    block(0.645, 0.415, 0.15, 0.175, 10, "Controls\nLEV · ROA\n(+ matching on\nindustry, size, year)", "#ffffff", "#3b6e22")
    block(0.815, 0.415, 0.16, 0.175, 11, "Scores (steps 1–5)\nrank 0–1 → layer\nmeans → AI_SCORE\n= 10 × mean", "#ffffff", "#3b6e22")
    arr(0.175, 0.505, 0.195, 0.505)
    arr(0.44, 0.505, 0.46, 0.505)
    arr(0.625, 0.505, 0.645, 0.505)
    arr(0.795, 0.505, 0.815, 0.505)
    arr(0.5, 0.415, 0.5, 0.385)
    ax.text(0.515, 0.405, "measured firm-years", ha="left", va="center", fontsize=8, color="#444444")

    # Stage 3 band
    band(0.045, 0.38, "Stage 3 — Tests, attribution and validation", "#fdf3ec")
    row1 = [(12, "M1 M2 M3\ncoverage · reliability ·\ndistinctness"), (13, "H1 H2 H3\nconditional logit within\nmatched sets; Holm;\nfirm-clustered SE"),
            (14, "H4\nthe same test\nby event year"), (15, "H5\nModel A vs Model B;\ntiming at equal\nfalse-alarm rate"), (16, "P1\nRPT types by\nform of fraud")]
    xs3 = np.linspace(0.025, 0.975 - 0.175, 5)
    for (num, lab), x in zip(row1, xs3):
        block(x, 0.195, 0.175, 0.135, num, lab, "#ffffff", "#9a4e12", fs=8.0)
    block(0.025, 0.05, 0.37, 0.125, 17, "A1 A2 A3 attribution\nscore divided by layer and characteristic ·\nrefit without each set · reading against theory", "#ffffff", "#9a4e12", fs=8.0)
    block(0.42, 0.05, 0.555, 0.125, 18, "Validation and exploratory work (kept apart)\nrobustness cuts · external set · power · deviations log\nEXPLORATORY: fitted 36-input score, stress tests T1–T5, peer-text distance", "#ffffff", "#8c2b2b", fs=8.0)
    for x in xs3[1:4]:
        arr(x + 0.0875, 0.195, x + 0.0875, 0.178)
    ax.text(0.5, 0.012, "Blocks are numbered in the order of work; each is explained in §3.1.1. Arrows show what passes to the next stage.",
            ha="center", va="bottom", fontsize=8, color="#444444", style="italic")
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/thesis_figures")
    out.mkdir(parents=True, exist_ok=True)
    methodology_blocks(out / "fig_methodology_blocks.png")
    methodology_flow(out / "fig_methodology_flow.png")
    variable_framework(out / "fig_variable_framework.png")
    validation_scheme(out / "fig_validation_scheme.png")
    print("figures written to", out)
