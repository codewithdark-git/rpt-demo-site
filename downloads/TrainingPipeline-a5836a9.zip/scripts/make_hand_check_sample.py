"""M2 reliability: draw the 10 % random sample of rule-coded firm-years for human checking.

Writes one workbook/CSV with the coded value, the evidence passage and empty columns for the human code and a
note, for (a) the governance coder and (b) the related-party note coder. Agreement is computed later by
scripts/m2_agreement.py once the human columns are filled.

    python scripts/make_hand_check_sample.py --governance data/governance_manual.csv --rp data/rp_note_coded.csv --share 0.10 --seed 42
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

GOV_ITEMS = [("big4", "auditor_evidence"), ("auditor_change", "auditor_evidence"), ("going_concern_opinion", "going_concern_evidence"),
             ("ceo_duality", "ceo_duality_evidence"), ("board_indep", "board_indep_evidence"), ("ac_indep", "ac_indep_evidence")]
RP_ITEMS = [("RP_LEND", "RP_LEND_evidence"), ("RP_PAY", "RP_PAY_evidence"), ("RP_SALES", "RP_SALES_evidence"), ("RP_PURCH", "RP_PURCH_evidence"),
            ("counterparty_named", ""), ("amount_stated", ""), ("terms_stated", ""), ("purpose_stated", "")]


def sample(df: pd.DataFrame, items, share: float, seed: int, source: str) -> pd.DataFrame:
    rows = []
    for col, ev in items:
        if col not in df.columns:
            continue
        coded = df[df[col].notna()] if ev else df
        n = max(5, int(round(len(coded) * share)))
        pick = coded.sample(min(n, len(coded)), random_state=seed)
        for _, r in pick.iterrows():
            rows.append({"source": source, "variable": col, "cik": r["cik"], "fiscal_year": r["fiscal_year"],
                         "coded_value": r[col], "evidence": (str(r[ev]) if ev and ev in r else "")[:400],
                         "proxy_accession": r.get("proxy_accession", ""), "text_source": r.get("text_source", ""),
                         "human_value": "", "agree": "", "note": ""})
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--governance", default="data/governance_manual.csv")
    ap.add_argument("--rp", default="data/rp_note_coded.csv")
    ap.add_argument("--share", type=float, default=0.10)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--output", default="data/m2_hand_check_sample.csv")
    args = ap.parse_args()
    parts = []
    if Path(args.governance).exists():
        g = pd.read_csv(args.governance, dtype={"cik": str}, keep_default_na=False).replace("", pd.NA)
        for c, _ in GOV_ITEMS:
            if c in g:
                g[c] = pd.to_numeric(g[c], errors="coerce")
        parts.append(sample(g, GOV_ITEMS, args.share, args.seed, "governance_coder"))
    if Path(args.rp).exists():
        r = pd.read_csv(args.rp, dtype={"cik": str}, keep_default_na=False).replace("", pd.NA)
        for c, _ in RP_ITEMS:
            if c in r:
                r[c] = pd.to_numeric(r[c], errors="coerce")
        parts.append(sample(r, RP_ITEMS, args.share, args.seed, "rp_note_coder"))
    out = pd.concat(parts, ignore_index=True)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    try:
        out.to_excel(args.output.replace(".csv", ".xlsx"), index=False)
    except Exception:  # noqa: BLE001
        pass
    print(f"{len(out)} rows to hand-check -> {args.output}")
    print(out.groupby(["source", "variable"]).size().to_string())


if __name__ == "__main__":
    main()
