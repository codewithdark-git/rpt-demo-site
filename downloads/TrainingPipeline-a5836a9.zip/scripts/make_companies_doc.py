"""Generate the 'Companies used in this research' document (Markdown; converted to Word by md_to_docx.py).

Covers the 30 confirmatory cases (21 core + 9 disclosure-only) with their rule-matched peers, the 10 external
validation cases, and the five pilot anchors with their hand-picked competitors. Every fact comes from the
project's own files (cases files, screen, candidate notes, matching tables, EDGAR universe tables, run-3 outputs).

    python scripts/make_companies_doc.py docs/THESIS_Companies_Used_in_the_Research.md
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DL = ROOT.parent / "SEC-EDGAR-Downloader"


def z10(s: pd.Series) -> pd.Series:
    return s.astype(str).str.replace(r"\D", "", regex=True).str.zfill(10)


def load() -> dict:
    d = {}
    d["core"] = pd.read_csv(DL / "cases_core.csv", dtype=str).fillna("")
    d["core"]["cik"] = z10(d["core"]["cik"])
    d["sens"] = pd.read_csv(DL / "cases_sensitivity.csv", dtype=str).fillna("")
    d["sens"]["cik"] = z10(d["sens"]["cik"])
    d["pilot"] = pd.read_csv(DL / "cases.csv", dtype=str).fillna("")
    d["pilot"]["cik"] = z10(d["pilot"]["cik"])
    d["screen"] = pd.read_csv(DL / "scripts/phase_a_screen_v2.csv", dtype=str).fillna("")
    d["cand"] = pd.read_csv(DL / "scripts/candidates_v02.csv", dtype=str).fillna("")
    uni = pd.concat([pd.read_csv(DL / "data_core/company_universe.csv", dtype=str).fillna(""),
                     pd.read_csv(DL / "data_sens/company_universe.csv", dtype=str).fillna("") if (DL / "data_sens/company_universe.csv").exists() else pd.DataFrame(),
                     pd.read_csv(DL / "data_gulf/company_universe.csv", dtype=str).fillna("") if (DL / "data_gulf/company_universe.csv").exists() else pd.DataFrame(),
                     pd.read_csv(DL / "data/company_universe.csv", dtype=str).fillna("")], ignore_index=True)
    uni["cik"] = z10(uni["cik"])
    d["uni"] = uni.drop_duplicates("cik").set_index("cik")
    frames = []
    for f in ("peers_matched_v1.csv", "peers_matched_v2_relaxed.csv", "peers_matched_puda.csv", "peers_matched_gulfport.csv"):
        p = DL / "scripts" / f
        if p.exists():
            frames.append(pd.read_csv(p, dtype=str).fillna(""))
    m = pd.concat(frames, ignore_index=True)
    m["cik"] = z10(m["cik"])
    d["match"] = m.drop_duplicates(["cik", "matched_case_id"], keep="last").set_index(["cik", "matched_case_id"])
    fm = pd.concat([pd.read_csv(DL / "data_core/filing_manifest.csv", dtype=str).fillna("")] +
                   [pd.read_csv(DL / f"{x}/filing_manifest.csv", dtype=str).fillna("") for x in ("data_sens", "data_gulf") if (DL / f"{x}/filing_manifest.csv").exists()], ignore_index=True)
    fm["cik"] = z10(fm["cik"])
    fm = fm.drop_duplicates(["cik", "accession_number"])
    fm = fm[fm["is_primary_filing"].isin(["1", "1.0", "True"])]
    d["fy"] = fm.groupby("cik")["fiscal_year"].agg(lambda s: sorted(int(float(x)) for x in s))
    pc = ROOT / "docs/run3_results/per_case_detection.csv"
    d["det"] = pd.read_csv(pc, dtype={"first_flag_fy": str}).set_index("case_id") if pc.exists() else pd.DataFrame()
    ev = ROOT / "outputs/sens/external_validation_by_case.csv"
    d["ext"] = pd.read_csv(ev).set_index("cluster_id") if ev.exists() else pd.DataFrame()
    return d


def uni_row(d, cik):
    return d["uni"].loc[cik] if cik in d["uni"].index else None


def years_in(d, cik, window):
    fys = d["fy"].get(cik, [])
    if not window or "-" not in str(window):
        return len(fys), fys
    a, b = (int(x) for x in str(window).split("-"))
    return sum(a <= y <= b for y in fys), fys


def fmt_assets(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return ""
    if v >= 1e9:
        return f"${v/1e9:,.1f} bn"
    if v >= 1e6:
        return f"${v/1e6:,.0f} m"
    return f"${v:,.0f}"


def case_section(d, c, screen_row, cand_row, idx, stratum_label, peers: pd.DataFrame, detection=None, external=None) -> list[str]:
    cik = c["cik"]
    u = uni_row(d, cik)
    name = c.get("company_name") or (u["name"] if u is not None else "")
    sic = (u["sic"] if u is not None else screen_row.get("sic", "")) or screen_row.get("sic", "")
    sic_desc = u["sic_description"] if u is not None else ""
    state = u["state_of_incorporation_description"] if u is not None else ""
    fye = u["fiscal_year_end"] if u is not None else ""
    window = screen_row.get("window", "")
    n_in, fys = years_in(d, cik, window)
    lines = [f"### {idx}. {name}", "",
             f"| Item | Value |", "|---|---|",
             f"| CIK | {cik} |",
             f"| EDGAR name | {u['name'] if u is not None else name} |",
             f"| SIC | {sic} {('— ' + sic_desc) if sic_desc else ''} |",
             f"| State of incorporation / fiscal year end | {state or '—'} / {fye or '—'} |",
             f"| Stratum | {stratum_label} |",
             f"| Form of RPT fraud (D1 class) | {c.get('d1_class', '') or screen_row.get('d1_class', '')} |",
             f"| RPT element (from the enforcement documents) | {cand_row.get('rpt_element', '') or '—'} |",
             f"| Misconduct years / enforcement year | {cand_row.get('misconduct_years', '') or '—'} / {cand_row.get('enforcement_year', '') or '—'} |",
             f"| Enforcement references | {c.get('aaer_numbers', '') or cand_row.get('notes', '') or '—'} |",
             f"| First public revelation (D2) | {c.get('revelation_date', '')} — {c.get('revelation_source', '')} |",
             f"| Revelation-date confidence | {c.get('confidence', '') or screen_row.get('confidence', '')}{(' — to verify: ' + screen_row['verify']) if screen_row.get('verify') else ''} |",
             f"| Assessment window (five fiscal years before revelation) | {window or '—'} |",
             f"| Annual reports in the window / on file FY2004–2024 | {n_in} / {len(fys)} ({fys[0] if fys else ''}–{fys[-1] if fys else ''}) |",
             f"| Screening notes | {cand_row.get('notes', '') or '—'} |"]
    if detection is not None:
        ff = detection.get("first_flag_fy", "")
        lines += [f"| Model result (run 3, out of fold) | within-set AUC {detection['within_auc']}; case-year mean score {detection['case_mean']} vs matched {detection['peer_mean']}; max {detection['case_max']}; flagged years {int(detection['flag_years'])}{(' (first FY' + str(ff).replace('.0','') + ')') if str(ff) not in ('', 'nan') else ''} |"]
    if external is not None:
        ff = external.get("first_flag_fy", "")
        lines += [f"| External validation (never used in fitting) | max score {external['max_score']:.3f}; flagged years {int(external['flagged_years'])}{(' (FY' + str(ff).replace('.0','') + ')') if str(ff) not in ('', 'nan', '<NA>') else ''}; matched-firm window rows {'' if pd.isna(external.get('peer_window_rows')) else int(external['peer_window_rows'])} |"]
    lines += ["", f"**Matched firms ({len(peers)})**", ""]
    if len(peers):
        lines += ["| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |", "|---|---|---|---|---|---|---|---|"]
        for _, p in peers.iterrows():
            pu = uni_row(d, p["cik"])
            pname = pu["name"] if pu is not None else (p.get("company_name") or "")
            psic = pu["sic"] if pu is not None else ""
            key = (p["cik"], c["case_id"])
            mrow = d["match"].loc[key] if key in d["match"].index else None
            level = mrow["sic_level"] if mrow is not None else ("hand-picked competitor" if stratum_label.startswith("Pilot") else "")
            gap = f"{abs(float(mrow['ln_assets_gap'])):.2f}" if mrow is not None and mrow["ln_assets_gap"] not in ("", "nan") else ""
            syear = mrow["size_year"] if mrow is not None else ""
            passets = fmt_assets(mrow["peer_assets"]) if mrow is not None else ""
            n_in_p, _ = years_in(d, p["cik"], window)
            lines.append(f"| {pname} | {p['cik']} | {psic} | {level} | {gap} | {syear} | {passets} | {n_in_p if window else ''} |")
    lines.append("")
    return lines


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/THESIS_Companies_Used_in_the_Research.md")
    d = load()
    core = d["core"]
    cases = core[core["role"] == "case"]
    peers = core[core["role"] == "peer"]
    screen = d["screen"].set_index("company")
    cand = d["cand"].set_index("company")

    def srow(name):
        for key in (name, name.replace(" (NC)", ""), name.split(" (")[0]):
            if key in screen.index:
                return screen.loc[key]
        # fuzzy: first word match
        hits = [k for k in screen.index if k.split()[0].lower() == name.split()[0].lower()]
        return screen.loc[hits[0]] if hits else pd.Series(dtype=str)

    def crow(name):
        for key in (name, name.split(" (")[0]):
            if key in cand.index:
                return cand.loc[key]
        hits = [k for k in cand.index if k.split()[0].lower() == name.split()[0].lower()]
        return cand.loc[hits[0]] if hits else pd.Series(dtype=str)

    md = ["# Companies used in the research", "",
          "This document lists every firm in the study: the 31 qualifying RPT-fraud cases of the main sample (21 misstatement/misappropriation, 10 disclosure-only including Gulfport Energy, approved on 10 October 2026; all FRAUD = 1 in the design tests) with their rule-matched firms, "
          "the 10 external-validation cases with theirs, and the five pilot anchors with the hand-picked competitors used in the pilot. "
          "Facts are taken from the project's own files: the cases files, the Phase A screen (`scripts/phase_a_screen_v2.csv`), the candidate notes "
          "(`scripts/candidates_v02.csv`), the matching tables (`scripts/peers_matched_*.csv`), the EDGAR company tables of the builds, and the run-3 "
          "model outputs. Matching rule D4: same four-digit SIC code (fallback three-, then two-digit), nearest log total assets in the fiscal year "
          "before revelation, a 10-K on file in every window year, and no SEC accounting enforcement match. 'Gap in ln(assets)' is the absolute "
          "difference between the matched firm's and the case's log total assets at the anchor year (0.69 = a factor of two).", "",
          "## Summary", "",
          "| Group | Cases | Matched firms | Firm-years FY2004–2024 |", "|---|---|---|---|",
          f"| Main sample: RPT misstatement / misappropriation | {int((cases['stratum']=='core').sum())} | {int(peers['matched_case_id'].isin(cases.loc[cases['stratum']=='core','case_id']).sum())} | 272 cases + 2,151 matched (all 30 sets) |",
          f"| Main sample: disclosure-only (stratum label kept for the design's second H2 run) | {int((cases['stratum']=='disclosure_only').sum())} | {int(peers['matched_case_id'].isin(cases.loc[cases['stratum']=='disclosure_only','case_id']).sum())} | (included above) |",
          f"| External validation (three annual reports in the window) | {int((d['sens']['role']=='case').sum())} | {int((d['sens']['role']=='peer').sum())} | 549 |",
          f"| Pilot anchors (first study) | 5 | {int((d['pilot']['role']=='peer').sum())} | 384 (FY2004–2024 pilot build) |", ""]

    # Core cases
    md += ["## Part A — Main sample, misstatement or misappropriation cases (21)", ""]
    i = 0
    for _, c in cases[cases["stratum"] == "core"].sort_values("company_name").iterrows():
        i += 1
        det = d["det"].loc[c["case_id"]].to_dict() if len(d["det"]) and c["case_id"] in d["det"].index else None
        md += case_section(d, c, srow(c["company_name"]), crow(c["company_name"]), i, "Main sample — RPT misstatement or misappropriation", peers[peers["matched_case_id"] == c["case_id"]], det)
    md += [f"## Part B — Main sample, disclosure-only cases ({int((cases['stratum']=='disclosure_only').sum())})", "",
           "These firms were charged for a missing or incomplete related-party disclosure. Under the design they are RPT-fraud firms (FRAUD = 1) and are part of the main sample in every test; the design's second H2 run leaves them out. The exploratory fitted score places them at chance within the stratum (AUC 0.52).", ""]
    for _, c in cases[cases["stratum"] == "disclosure_only"].sort_values("company_name").iterrows():
        i += 1
        md += case_section(d, c, srow(c["company_name"]), crow(c["company_name"]), i, "Main sample — disclosure-only", peers[peers["matched_case_id"] == c["case_id"]], None)

    # Gulfport candidate
    gpath = ROOT.parent / "SEC-EDGAR-Downloader" / "cases_gulfport.csv"
    if gpath.exists() and "GULFPORT_ENERG" not in set(cases["case_id"]):
        g = pd.read_csv(gpath, dtype=str).fillna("")
        g["cik"] = g["cik"].str.zfill(10)
        gc_, gp_ = g[g["role"] == "case"], g[g["role"] == "peer"]
        md += ["## Part C — Candidate 31st case: Gulfport Energy (pending approval)", "",
               "Screened NEED_REVELATION_DATE on 2 October 2026 (SEC Release 33-10930 of 24 February 2021 is not on the AAER list). On 10 October the revelation date was established from the firm's own Form 10-Q for Q3 2018 (filed 1 November 2018, accession 0001628280-18-013345): in September 2018 the Audit Committee was informed of the CEO's unauthorised use of chartered aircraft and personal credit-card charges, not identified or disclosed in the proxy statements; the CEO stepped down on 29 October 2018. Window FY2013–2017 (five 10-Ks); five SIC-1311 peers matched by rule D4. Built in `data_gulf/`; enters the sample only on the researcher's approval.", ""]
        for _, c in gc_.iterrows():
            i += 1
            gs = srow("Gulfport Energy").copy()
            gs["window"] = "2013-2017"
            gs["tenk_in_window"] = "5"
            gs["confidence"] = "high"
            gs["verify"] = ""
            gs["revelation_date"] = "2018-11-01"
            gs["revelation_source"] = "10-Q Q3 2018 (0001628280-18-013345): Audit Committee informed Sept 2018 of undisclosed CEO aircraft use and personal charges; CEO stepped down 2018-10-29"
            gs["screen"] = "CANDIDATE (dated 10 Oct 2026; pending approval)"
            gcr = crow("Gulfport Energy").copy()
            if len(gcr):
                for k in gcr.index:
                    if "note" in k.lower() or "screen" in k.lower():
                        gcr[k] = "Order 33-10930 (24 Feb 2021) not on the AAER list; revelation date established 10 Oct 2026 from the Q3 2018 10-Q"
            md += case_section(d, c, gs, gcr, i, "Candidate (disclosure-only), pending approval", gp_[gp_["matched_case_id"] == c["case_id"]], None)
    else:
        g = pd.DataFrame(columns=core.columns)
    # External validation cases
    md += ["## Part C — External validation cases (10)", "",
           "Cases that fail the design's four-report rule but have three annual reports in the window. They and their matched firms were never used in fitting; the final model was applied to them once (AUC 0.73, matched-firm false-alarm rate 5.8 %).", ""]
    s = d["sens"]
    sc, sp = s[s["role"] == "case"], s[s["role"] == "peer"]
    for _, c in sc.sort_values("company_name").iterrows():
        i += 1
        ext = d["ext"].loc[c["case_id"]].to_dict() if len(d["ext"]) and c["case_id"] in d["ext"].index else None
        md += case_section(d, c, srow(c["company_name"]), crow(c["company_name"]), i, "External validation (three-report rule)", sp[sp["matched_case_id"] == c["case_id"]], None, ext)

    # Pilot anchors
    md += ["## Part D — Pilot anchors (5) and their hand-picked competitors", "",
           "The pilot (October 2026, FY2014–2024 then FY2004–2024) used five anchors from the client's workbook with competitors chosen by hand from the research design rather than by rule. Three of the anchors (Ault Alliance, Co-Diagnostics, Skechers) are in the main sample above; Gulfport was dated from its own filings on 10 October 2026 and approved as the 31st case (Part B); ProPetro fails the four-report rule (two annual reports before revelation) and stays out. Pilot results are reported separately in the thesis as the development stage.", ""]
    p = d["pilot"]
    pc, pp = p[p["role"] == "case"], p[p["role"] == "peer"]
    for _, c in pc.iterrows():
        i += 1
        md += case_section(d, c, srow(c["company_name"].split(",")[0]), crow(c["company_name"].split(",")[0]), i, "Pilot anchor", pp[pp["matched_case_id"] == c["case_id"]], None)
    md += ["## Part E — Index of all firms", "", "| # | Firm | CIK | Role | Set |", "|---|---|---|---|---|"]
    k = 0
    for label, frame in (("main sample", core), ("external validation", s), ("pilot", p)):
        for _, r in frame.iterrows():
            k += 1
            u = uni_row(d, r["cik"])
            nm = r.get("company_name") or (u["name"] if u is not None else "")
            md.append(f"| {k} | {nm} | {r['cik']} | {r['role']}{(' of ' + r['matched_case_id']) if r['role']=='peer' else ''} | {label} |")
    out.write_text("\n".join(md), encoding="utf-8")
    print(out, "cases listed:", i, "index rows:", k)


if __name__ == "__main__":
    main()
