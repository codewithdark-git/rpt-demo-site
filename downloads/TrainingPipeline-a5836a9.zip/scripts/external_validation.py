"""External validation: score a panel the model never saw (e.g. the sensitivity set) with a saved model.

    python scripts/external_validation.py --config rpt_panel.sens.json --model outputs/full/models/rpt_panel_ensemble.pkl

Writes <output_dir>/external_validation.json and external_validation_by_case.csv. The texts are merged in so the
stacked text-risk feature is computed exactly as in training.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
from sklearn.metrics import roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rpt_panel.config import load_config  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--label", default="sensitivity set (three-report cases)")
    args = ap.parse_args()
    cfg = load_config(args.config)
    out = Path(cfg.output_dir)
    X = pd.read_csv(out / "panel_features.csv", dtype={"cik": str})
    t = pd.read_csv(out / "panel_texts.csv", dtype={"cik": str}, keep_default_na=False)
    X["cik"], t["cik"] = X["cik"].str.zfill(10), t["cik"].str.zfill(10)
    merged = out / "panel_features_with_text.csv"
    X.merge(t, on=["cik", "fiscal_year"], how="left").to_csv(merged, index=False)
    subprocess.run([sys.executable, "main.py", "infer", "--config", args.config, "--model-path", args.model, "--data", str(merged)], check=True,
                   cwd=Path(__file__).resolve().parents[1])
    p = pd.read_csv(out / "predictions.csv", dtype={"cik": str})
    p["cik"] = p["cik"].str.zfill(10)
    m = X.merge(p[["cik", "fiscal_year", "risk_score", "flagged", "threshold"]], on=["cik", "fiscal_year"])
    w = m[m["event_time"].between(-cfg.window, -1)]
    y = w["fraud_aaer_label"].astype(int)
    by_case = (w[w["case_role"] == "case"].groupby("cluster_id")
               .agg(window_years=("fiscal_year", "size"), max_score=("risk_score", "max"), flagged_years=("flagged", "sum"),
                    first_flag_fy=("fiscal_year", lambda s: s[w.loc[s.index, "flagged"] == 1].min() if (w.loc[s.index, "flagged"] == 1).any() else pd.NA))
               .reset_index())
    peers = w[w["case_role"] == "peer"].groupby("cluster_id").size().rename("peer_window_rows").reset_index()
    by_case = by_case.merge(peers, on="cluster_id", how="left")
    by_case.to_csv(out / "external_validation_by_case.csv", index=False)
    summary = {
        "label": args.label, "model": args.model, "threshold": float(p["threshold"].iloc[0]),
        "cases": int(by_case.shape[0]), "window_rows": int(len(w)), "positives": int(y.sum()), "peer_rows": int((y == 0).sum()),
        "auc": round(float(roc_auc_score(y, w["risk_score"])), 3) if y.nunique() > 1 else None,
        "peer_fpr": round(float(w.loc[y == 0, "flagged"].mean()), 3), "case_year_recall": round(float(w.loc[y == 1, "flagged"].mean()), 3),
        "cases_flagged": int((by_case["flagged_years"] > 0).sum()),
        "cases_without_peers": int(by_case["peer_window_rows"].isna().sum()),
    }
    (out / "external_validation.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(by_case.to_string(index=False))


if __name__ == "__main__":
    main()
