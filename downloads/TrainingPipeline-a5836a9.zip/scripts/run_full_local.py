"""Wait for the local dataset build, then run the full training pipeline and render the reports.

    python scripts/run_full_local.py --build-log ../SEC-EDGAR-Downloader/data_core_build.log \
        --configs rpt_panel.full.json rpt_panel.full_all.json

Everything is local: no Hub download (``--skip-download``) and no upload.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def wait_for_build(log: Path, interval: int) -> int:
    while True:
        if log.exists():
            tail = log.read_text(encoding="utf-8", errors="replace")[-4000:]
            for line in reversed(tail.splitlines()):
                if line.startswith("BUILD EXIT"):
                    return int(line.split()[-1])
        print(time.strftime("%H:%M:%S"), "build still running", flush=True)
        time.sleep(interval)


def run(cmd: list[str], log: Path) -> int:
    print(time.strftime("%H:%M:%S"), "RUN", " ".join(cmd), "->", log, flush=True)
    with log.open("w", encoding="utf-8") as fh:
        proc = subprocess.run(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT)
    print(time.strftime("%H:%M:%S"), "EXIT", proc.returncode, flush=True)
    return proc.returncode


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build-log", type=Path, required=True)
    ap.add_argument("--configs", nargs="+", default=["rpt_panel.full.json", "rpt_panel.full_all.json"])
    ap.add_argument("--interval", type=int, default=120)
    ap.add_argument("--no-wait", action="store_true")
    args = ap.parse_args()

    if not args.no_wait:
        code = wait_for_build(args.build_log, args.interval)
        print("build finished with exit", code, flush=True)
        if code != 0:
            sys.exit(f"dataset build failed (exit {code}); not training")

    py = sys.executable
    for cfg_path in args.configs:
        cfg = json.loads((ROOT / cfg_path).read_text(encoding="utf-8"))
        out = ROOT / cfg.get("output_dir", "outputs/panel")
        out.mkdir(parents=True, exist_ok=True)
        rc = run([py, "-u", "main.py", "all", "--config", cfg_path, "--skip-download"], out / "run.log")
        if rc != 0:
            print("training failed for", cfg_path, "- see", out / "run.log", flush=True)
            continue
        title = f"{cfg_path} (strata: {cfg.get('case_strata') or 'all'})"
        run([py, "scripts/make_results_report.py", str(out), title, str(out / "RESULTS.md")], out / "report.log")
        run([py, "scripts/md_to_docx.py", str(out / "RESULTS.md"), str(out / "RESULTS.docx")], out / "docx.log")
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
