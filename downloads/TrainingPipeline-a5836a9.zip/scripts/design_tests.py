"""The client design's own test battery (RPT Research Design, 6 Oct 2026) run on the built panel.

Produces, under <output_dir>/design_tests/:
  m1_coverage.csv        M1  share of firm-years with each of the eight characteristics (and substitutes)
  m3_layer_correlations  M3  correlations between the three rank-averaged layer scores
  h1_h3_layer_tests.csv  H1-H3 conditional logit FRAUD ~ layer score + LEV + ROA within matched sets (Holm-adjusted)
  h4_by_year.csv         H4  the same test separately for event years -5 .. -1
  h5_model_ab.csv        H5  Model A (TRAD_INDEX + LEV + ROA) vs Model B (+ AI_SCORE), leave-one-cluster-out AUC,
                             and whether the AI score flags fraud firms earlier than the traditional index
  h5_timing_by_case.csv  H5  first flagged year per case: AI score vs traditional index
  p1_rpt_types_by_form.csv P1 lending / purchases / sales presence by form of fraud (descriptive)
  a3_layer_shares.csv    A3  share of |SHAP| by layer for the flagged fraud firm-years (primary model)
  summary.md             one-page reading of the above

Scores follow the design: each continuous characteristic ranked 0-1 over all firm-years, ranks averaged within
layer, the three layer scores averaged and x10 = AI_SCORE. Characteristics the data cannot supply are reported
as missing under M1, not silently replaced.

    python scripts/design_tests.py --config rpt_panel.full.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rpt_panel import data_access as da  # noqa: E402
from rpt_panel import inference_stats as inf  # noqa: E402
from rpt_panel import run as R  # noqa: E402
from rpt_panel.config import load_config  # noqa: E402

# Design characteristic -> panel column (None = not obtainable from the current build)
CHARACTERISTICS = {
    "RP_LEND (lending to related parties / assets)": ("rp_lend_to_assets", "L1"),
    "RP_PAY (payables to related parties / assets)": ("rp_pay_to_assets", "L1"),
    "RP_SALES (sales to related parties / sales)": ("rp_sales_to_revenue", "L1"),
    "RP_PURCH (purchases from related parties / assets)": ("rp_purch_to_assets", "L1"),
    "RP_INCOMP (incompleteness of the disclosure, 4 items)": ("rp_incomp", "L2"),
    "RP_VAGUE (vagueness of the RPT text)": ("rpt_vagueness", "L2"),
    "BRD_NONIND (1 - independent share of the board)": ("board_indep", "L3"),   # sign flipped below
    "DUAL (CEO chairs the board)": ("ceo_duality", "L3"),
}
# Substitutes used for the layer scores where the design characteristic is missing (flagged in the output)
SUBSTITUTES: dict = {}  # the eight design characteristics are now coded; no substitutes
TRADITIONAL = {"ICFR_MW": "material_weakness_reported", "AUD_OPIN": "going_concern_opinion",
               "AUD_CHG": "auditor_change_8k", "RESTATE": "restatement_8k"}
CONTROLS = ["leverage", "roa"]


def rank01(s: pd.Series) -> pd.Series:
    return s.rank(pct=True)


def layer_scores(X: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Rank-averaged layer scores over ALL firm-years (label-free), with the columns used per layer."""
    used: dict[str, list[str]] = {"L1": [], "L2": [], "L3": []}
    parts: dict[str, list[pd.Series]] = {"L1": [], "L2": [], "L3": []}
    for name, (col, layer) in CHARACTERISTICS.items():
        if col is None or col not in X.columns or X[col].notna().mean() < 0.05:
            continue
        s = X[col].astype(float)
        if col == "board_indep":
            s = 1 - s
        parts[layer].append(rank01(s))
        used[layer].append(col)
    for layer, subs in SUBSTITUTES.items():
        for col in subs:
            if col in X.columns and X[col].notna().mean() >= 0.5:
                parts[layer].append(rank01(X[col].astype(float)))
                used[layer].append(col + " (substitute)")
    out = pd.DataFrame({"cik": X["cik"], "fiscal_year": X["fiscal_year"]})
    for layer in ("L1", "L2", "L3"):
        out[f"{layer}_SCORE"] = pd.concat(parts[layer], axis=1).mean(axis=1, skipna=True) if parts[layer] else np.nan
    out["AI_SCORE"] = out[["L1_SCORE", "L2_SCORE", "L3_SCORE"]].mean(axis=1, skipna=True) * 10
    return out, used


def traditional_index(X: pd.DataFrame) -> pd.Series:
    cols = [c for c in TRADITIONAL.values() if c in X.columns and X[c].notna().any()]
    return X[cols].sum(axis=1, min_count=1)


def holm(p: pd.Series) -> pd.Series:
    order = p.sort_values().index
    m = p.notna().sum()
    adj, running = {}, 0.0
    for i, idx in enumerate(order):
        if pd.isna(p[idx]):
            adj[idx] = np.nan
            continue
        running = max(running, (m - i) * p[idx])
        adj[idx] = min(1.0, running)
    return pd.Series(adj)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="rpt_panel.full.json")
    args = ap.parse_args()
    cfg = load_config(args.config)
    X = R._load_features(cfg)
    train = R._training(cfg, X)
    out = R._out(cfg, "design_tests")
    cases = da.read_cases(cfg)

    # M1 coverage over the training window
    rows = []
    for name, (col, layer) in CHARACTERISTICS.items():
        cov = float(train[col].notna().mean()) if col and col in train.columns else 0.0
        rows.append({"characteristic": name, "layer": layer, "panel_column": col or "— not obtainable from XBRL/10-K text",
                     "coverage_training_window": round(cov, 3), "usable": cov >= 0.5})
    for k, col in TRADITIONAL.items():
        cov = float(train[col].notna().mean()) if col in train.columns else 0.0
        rows.append({"characteristic": f"{k} (traditional signal)", "layer": "TRAD", "panel_column": col, "coverage_training_window": round(cov, 3), "usable": cov >= 0.5})
    m1 = pd.DataFrame(rows)
    m1.to_csv(out / "m1_coverage.csv", index=False)

    # Layer scores (ranked over all firm-years) and M3
    scores, used = layer_scores(X)
    X = X.merge(scores, on=["cik", "fiscal_year"], how="left")
    X["TRAD_INDEX"] = traditional_index(X)
    train = R._training(cfg, X)
    m3 = train[["L1_SCORE", "L2_SCORE", "L3_SCORE"]].corr().round(3)
    m3.to_csv(out / "m3_layer_correlations.csv")

    # H1-H3 conditional logit within matched sets (train rows only), Holm across the three.
    # The governance score is observed in about a third of firm-years (proxy fetched only when Item 13 is
    # incorporated by reference), so the regression coverage floor is lowered for these layer tests and n is reported.
    inf.MIN_COVERAGE = 0.2
    h = []
    for hyp, layer in (("H1", "L1_SCORE"), ("H2", "L2_SCORE"), ("H3", "L3_SCORE")):
        t = inf.conditional_logit(train, [layer] + CONTROLS)
        r = t[t["term"] == layer] if "term" in t.columns else pd.DataFrame()
        pooled = inf.clustered_logit(train, [layer] + CONTROLS)
        rp = pooled[pooled["term"] == layer] if "term" in pooled.columns else pd.DataFrame()
        h.append({"hypothesis": hyp, "layer_score": layer, "columns_used": "; ".join(used[layer[:2]]),
                  "cond_coef": float(r["coef"].iloc[0]) if len(r) else np.nan, "cond_se": float(r["se"].iloc[0]) if len(r) else np.nan,
                  "cond_p": float(r["p"].iloc[0]) if len(r) else np.nan, "cond_odds_ratio_per_sd": float(r["odds_ratio"].iloc[0]) if len(r) else np.nan,
                  "cond_n": int(r["n"].iloc[0]) if len(r) else 0, "cond_clusters": int(r["n_clusters"].iloc[0]) if len(r) else 0,
                  "pooled_coef": float(rp["coef"].iloc[0]) if len(rp) else np.nan, "pooled_p": float(rp["p"].iloc[0]) if len(rp) else np.nan})
    h13 = pd.DataFrame(h)
    h13["cond_p_holm"] = holm(h13["cond_p"]).reindex(h13.index).values
    h13["supported"] = (h13["cond_coef"] > 0) & (h13["cond_p_holm"] < 0.05)
    h13.to_csv(out / "h1_h3_layer_tests.csv", index=False)

    # H4 by event year: within-cluster comparison per year (conditional logit per year; Mann-Whitney as fallback)
    h4 = []
    for yr in range(-cfg.window, 0):
        sub = train[train["event_time"] == yr]
        for layer in ("L1_SCORE", "L2_SCORE", "L3_SCORE"):
            t = inf.conditional_logit(sub, [layer] + CONTROLS, group="cluster_id")
            r = t[t["term"] == layer] if "term" in t.columns else pd.DataFrame()
            a, b = sub.loc[sub["fraud_aaer_label"] == 1, layer].dropna(), sub.loc[sub["fraud_aaer_label"] == 0, layer].dropna()
            mw = stats.mannwhitneyu(a, b, alternative="greater").pvalue if len(a) > 2 and len(b) > 2 else np.nan
            h4.append({"event_year": yr, "layer_score": layer, "n": len(sub), "n_fraud": int(sub["fraud_aaer_label"].sum()),
                       "mean_fraud": a.mean(), "mean_matched": b.mean(), "mannwhitney_p_greater": mw,
                       "cond_coef": float(r["coef"].iloc[0]) if len(r) else np.nan, "cond_p": float(r["p"].iloc[0]) if len(r) else np.nan})
    pd.DataFrame(h4).to_csv(out / "h4_by_year.csv", index=False)

    # H5: Model A vs Model B, each cluster scored by a model fitted without it
    def loco_scores(feats: list[str]) -> pd.Series:
        pred = pd.Series(np.nan, index=train.index)
        d = train[feats + ["fraud_aaer_label", "cluster_id"]].dropna()
        for g in d["cluster_id"].unique():
            tr, te = d[d["cluster_id"] != g], d[d["cluster_id"] == g]
            if tr["fraud_aaer_label"].nunique() < 2:
                continue
            Xtr = (tr[feats] - tr[feats].mean()) / tr[feats].std(ddof=1).replace(0, 1)
            Xte = (te[feats] - tr[feats].mean()) / tr[feats].std(ddof=1).replace(0, 1)
            import statsmodels.api as sm
            try:
                m = sm.Logit(tr["fraud_aaer_label"].astype(int), sm.add_constant(Xtr, has_constant="add")).fit(disp=0, maxiter=200)
                pred.loc[te.index] = m.predict(sm.add_constant(Xte, has_constant="add"))
            except Exception:
                m = sm.Logit(tr["fraud_aaer_label"].astype(int), sm.add_constant(Xtr, has_constant="add")).fit_regularized(alpha=1.0, L1_wt=0.0, disp=0)
                pred.loc[te.index] = m.predict(sm.add_constant(Xte, has_constant="add"))
        return pred

    feats_a = ["TRAD_INDEX"] + CONTROLS
    feats_b = feats_a + ["AI_SCORE"]
    # B2: the same benchmark plus the pipeline's out-of-fold ensemble alert score (already fitted without the
    # cluster it scores), i.e. the ML version of the design's AI_SCORE.
    spec0 = json.loads(R._out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    train["ML_SCORE"] = R._scores_for(cfg, train, spec0.get("alert_model", spec0["primary_model"]))
    feats_b2 = feats_a + ["ML_SCORE"]
    pa, pb, pb2 = loco_scores(feats_a), loco_scores(feats_b), loco_scores(feats_b2)
    mask = pa.notna() & pb.notna() & pb2.notna()
    y = train.loc[mask, "fraud_aaer_label"].astype(int)
    auc_a, auc_b, auc_b2 = roc_auc_score(y, pa[mask]), roc_auc_score(y, pb[mask]), roc_auc_score(y, pb2[mask])
    auc_trad_alone = roc_auc_score(train.loc[train["TRAD_INDEX"].notna(), "fraud_aaer_label"].astype(int), train.loc[train["TRAD_INDEX"].notna(), "TRAD_INDEX"])
    auc_ml_alone = roc_auc_score(train.loc[train["ML_SCORE"].notna(), "fraud_aaer_label"].astype(int), train.loc[train["ML_SCORE"].notna(), "ML_SCORE"])
    full_b = inf.clustered_logit(train, feats_b)
    ai_row = full_b[full_b["term"] == "AI_SCORE"] if "term" in full_b.columns else pd.DataFrame()
    full_b2 = inf.clustered_logit(train, feats_b2)
    ml_row = full_b2[full_b2["term"] == "ML_SCORE"] if "term" in full_b2.columns else pd.DataFrame()
    # timing: first year the AI score exceeds the 95th percentile of matched firm-years vs first year TRAD_INDEX >= 1
    thr_ai = train.loc[train["fraud_aaer_label"] == 0, "AI_SCORE"].quantile(0.95)
    thr_ml = float(spec0["threshold"])
    # Equal-false-alarm comparison: the smallest count of traditional signals whose matched-firm rate is <= target FPR.
    peers = train[train["fraud_aaer_label"] == 0]
    trad_k = next((k for k in (1, 2, 3, 4) if (peers["TRAD_INDEX"] >= k).mean() <= cfg.target_fpr), 4)
    trad_fpr_k = float((peers["TRAD_INDEX"] >= trad_k).mean())
    timing = []
    for cid, g in train[train["case_role"] == "case"].groupby("cluster_id"):
        g = g.sort_values("fiscal_year")
        ai_first = g.loc[g["AI_SCORE"] >= thr_ai, "fiscal_year"].min()
        ml_first = g.loc[g["ML_SCORE"] >= thr_ml, "fiscal_year"].min()
        tr_first = g.loc[g["TRAD_INDEX"] >= 1, "fiscal_year"].min()
        trk_first = g.loc[g["TRAD_INDEX"] >= trad_k, "fiscal_year"].min()
        timing.append({"case": cid, "ai_first_flag_fy": ai_first, "ml_first_flag_fy": ml_first, "trad_first_flag_fy": tr_first,
                       f"trad_ge{trad_k}_first_flag_fy": trk_first,
                       "ml_earlier_equal_fpr": bool(pd.notna(ml_first) and (pd.isna(trk_first) or ml_first < trk_first)),
                       "same_year_equal_fpr": bool(pd.notna(ml_first) and pd.notna(trk_first) and ml_first == trk_first),
                       "trad_earlier_equal_fpr": bool(pd.notna(trk_first) and (pd.isna(ml_first) or trk_first < ml_first)),
                       "ai_earlier": bool(pd.notna(ai_first) and (pd.isna(tr_first) or ai_first < tr_first)),
                       "same_year": bool(pd.notna(ai_first) and pd.notna(tr_first) and ai_first == tr_first),
                       "trad_earlier": bool(pd.notna(tr_first) and (pd.isna(ai_first) or tr_first < ai_first)),
                       "ml_earlier": bool(pd.notna(ml_first) and (pd.isna(tr_first) or ml_first < tr_first)),
                       "ml_same_year": bool(pd.notna(ml_first) and pd.notna(tr_first) and ml_first == tr_first),
                       "trad_earlier_than_ml": bool(pd.notna(tr_first) and (pd.isna(ml_first) or tr_first < ml_first))})
    timing = pd.DataFrame(timing)
    timing.to_csv(out / "h5_timing_by_case.csv", index=False)
    h5 = pd.DataFrame([{
        "model_A_features": "+".join(feats_a), "model_B_features": "+".join(feats_b), "n": int(mask.sum()), "n_fraud": int(y.sum()),
        "loco_auc_model_A": round(auc_a, 3), "loco_auc_model_B": round(auc_b, 3), "auc_gain_B_minus_A": round(auc_b - auc_a, 3),
        "AI_SCORE_coef_model_B": float(ai_row["coef"].iloc[0]) if len(ai_row) else np.nan, "AI_SCORE_p_model_B": float(ai_row["p"].iloc[0]) if len(ai_row) else np.nan,
        "ai_threshold_95pct_matched": round(float(thr_ai), 3), "cases_ai_flags_earlier": int(timing["ai_earlier"].sum()),
        "cases_same_year": int(timing["same_year"].sum()), "cases_trad_earlier": int(timing["trad_earlier"].sum()),
        "cases_flagged_by_neither": int(((timing["ai_first_flag_fy"].isna()) & (timing["trad_first_flag_fy"].isna())).sum()), "cases": len(timing),
        "loco_auc_model_B2_ml": round(auc_b2, 3), "auc_gain_B2_minus_A": round(auc_b2 - auc_a, 3),
        "ML_SCORE_coef_model_B2": float(ml_row["coef"].iloc[0]) if len(ml_row) else np.nan, "ML_SCORE_p_model_B2": float(ml_row["p"].iloc[0]) if len(ml_row) else np.nan,
        "auc_trad_index_alone": round(auc_trad_alone, 3), "auc_ml_score_alone_oof": round(auc_ml_alone, 3), "ml_threshold": round(thr_ml, 3),
        "cases_ml_flags_earlier": int(timing["ml_earlier"].sum()), "cases_ml_same_year": int(timing["ml_same_year"].sum()),
        "cases_trad_earlier_than_ml": int(timing["trad_earlier_than_ml"].sum()),
        "trad_rule_equal_fpr": f"TRAD_INDEX >= {trad_k} (matched-firm rate {trad_fpr_k:.3f})",
        "trad_ge1_matched_rate": round(float((peers["TRAD_INDEX"] >= 1).mean()), 3),
        "cases_ml_earlier_equal_fpr": int(timing["ml_earlier_equal_fpr"].sum()), "cases_same_year_equal_fpr": int(timing["same_year_equal_fpr"].sum()),
        "cases_trad_earlier_equal_fpr": int(timing["trad_earlier_equal_fpr"].sum()),
        "cases_flagged_trad_equal_fpr": int(timing[f"trad_ge{trad_k}_first_flag_fy"].notna().sum()), "cases_flagged_ml": int(timing["ml_first_flag_fy"].notna().sum())}])
    h5.to_csv(out / "h5_model_ab.csv", index=False)

    # P1: RPT types by form of fraud (descriptive; presence of the tagged amount in any window year)
    p1 = pd.DataFrame()
    if cases is not None and "d1_class" in cases.columns:
        form = dict(zip(cases.loc[cases["role"] == "case", "case_id"], cases.loc[cases["role"] == "case", "d1_class"]))
        lend_col = "rp_lend_to_assets" if "rp_lend_to_assets" in train.columns else "rp_receivables_to_assets"
        sales_col = "rp_sales_to_revenue" if "rp_sales_to_revenue" in train.columns else "rp_sales_ratio"
        purch_col = "rp_purch_to_assets" if "rp_purch_to_assets" in train.columns else "rpt_to_revenue"
        cf = train[train["case_role"] == "case"].groupby("cluster_id").agg(
            lending=(lend_col, lambda s: int((s.fillna(0) > 0).any())),
            sales=(sales_col, lambda s: int((s.fillna(0) > 0).any())),
            purchases=(purch_col, lambda s: int((s.fillna(0) > 0).any())),
            any_rpt_amount=(lend_col, lambda s: int(s.notna().any())))
        cf["form"] = cf.index.map(form)
        cf["form_group"] = np.where(cf["form"].str.contains("misappropriation", na=False) & ~cf["form"].str.contains("misstatement", na=False), "managerial",
                           np.where(cf["form"].str.contains("misstatement", na=False) & ~cf["form"].str.contains("misappropriation", na=False), "corporate", "both/other"))
        p1 = cf.groupby("form_group")[["lending", "sales", "purchases", "any_rpt_amount"]].agg(["sum", "count"])
        p1.columns = ["_".join(c) for c in p1.columns]
        p1.to_csv(out / "p1_rpt_types_by_form.csv")

    # A3: share of |SHAP| by layer in the flagged fraud firm-years (primary model)
    spec = json.loads(R._out(cfg, "model_spec.json").read_text(encoding="utf-8"))
    primary = spec["primary_model"]
    a3 = pd.DataFrame()
    shap_path = R._out(cfg, f"oof_shap_{primary}.csv")
    if shap_path.exists():
        shp = pd.read_csv(shap_path, dtype={"cik": str})
        shp["cik"] = shp["cik"].str.zfill(10)
        groups = spec["feature_groups"]
        alert = R._scores_for(cfg, train, spec.get("alert_model", primary))
        flagged = train[(train["case_role"] == "case") & (alert >= float(spec["threshold"]))][["cik", "fiscal_year", "cluster_id"]]
        m = flagged.merge(shp, on=["cik", "fiscal_year"], how="left")
        rows = []
        for _, r in m.iterrows():
            tot = sum(abs(r.get(f, 0) or 0) for fs in groups.values() for f in fs if f in m.columns) + abs(r.get("text_risk", 0) or 0)
            share = {g: sum(abs(r.get(f, 0) or 0) for f in fs if f in m.columns) / tot if tot else np.nan for g, fs in groups.items()}
            share["text_stack"] = abs(r.get("text_risk", 0) or 0) / tot if tot else np.nan
            rows.append({"case": r["cluster_id"], "fiscal_year": r["fiscal_year"], **share,
                         "largest_layer": max(share, key=lambda k: (share[k] if pd.notna(share[k]) else -1))})
        a3 = pd.DataFrame(rows)
        a3.to_csv(out / "a3_layer_shares.csv", index=False)

    # Summary
    lines = ["# Design test battery — summary", "",
             f"Training window: {len(train)} firm-years, {int(train['fraud_aaer_label'].sum())} fraud firm-years, {train['cluster_id'].nunique()} matched sets.", "",
             "## M1 coverage", "", m1.to_markdown(index=False), "",
             "## M3 layer-score correlations", "", m3.to_markdown(), "",
             "Columns used per layer: " + "; ".join(f"{k}: {', '.join(v) or 'none'}" for k, v in used.items()), "",
             "## H1–H3 (conditional logit within matched sets; Holm across three)", "", h13.round(3).to_markdown(index=False), "",
             "## H5 Model A vs Model B", "", h5.to_markdown(index=False), "",
             "## H4 by event year (Mann–Whitney, fraud > matched)", "", pd.DataFrame(h4).round(3).to_markdown(index=False), ""]
    if not p1.empty:
        lines += ["## P1 RPT types by form of fraud (cases with a tagged amount in any window year)", "", p1.to_markdown(), ""]
    if not a3.empty:
        lines += ["## A3 largest contributing layer in flagged fraud firm-years", "", a3["largest_layer"].value_counts().to_frame("firm_years").to_markdown(), ""]
    (out / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
