# RPT Fraud-Risk Panel — PhD research pipeline

Leak-free, firm-year modelling of related-party-transaction (RPT) fraud risk on
the `alphatechlogics/SEC-RPT-Panel` dataset (built by the companion repository
`SEC-EDGAR-Downloader`). Every table and figure in the thesis chapters is
produced by the `rpt_panel` package in this repository.

> The previous pipeline (`legacy/`) produced no usable results: it ran on stub
> text and hand-typed financials, fabricated mediation standard errors and leaked
> labels. See `legacy/README.md` and `docs/PROJECT_STATUS_AND_ROADMAP.md`.

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
# One command, full-performance configuration (rpt_panel.full.json): install, test, download, all stages
bash train_full.sh
```

```bash
# 1. Build the dataset (companion repo), publish to the Hub
#    python -m sec_rpt_dataset.cli run-all --output-dir data --start-year 2014 --end-year 2024 \
#        --cases-csv cases.csv --aaer-start-year 2014 --upload

# 2. Everything, from download to figures
python main.py all --config rpt_panel.json

# or step by step
python main.py download --config rpt_panel.json
python main.py build    --config rpt_panel.json     # panel_features.csv, coverage + descriptives tables
python main.py model    --config rpt_panel.json     # leave-one-cluster-out OOF scores, SHAP, models/
python main.py stress   --config rpt_panel.json     # T1-T5
python main.py mediate  --config rpt_panel.json     # bootstrap mediation + clustered / conditional logit
python main.py explain  --config rpt_panel.json     # attribution stability + traceability
python main.py report   --config rpt_panel.json     # figures, z-score table
python main.py infer    --config rpt_panel.json --data new_firm_years.csv
```

`rpt_panel.json` holds every parameter (years, window, FPR target, bootstrap
reps, model list). No firm, CIK or SIC code is a default anywhere in the code.
The local mirror of the dataset goes to `data/hf_cache/` and results to
`outputs/panel/`.

## Design (Thesis_Revision_Plan, Sep 2026)

Matched case-control panel, unit = firm-year. Case firms are named in an
RPT-related SEC enforcement action; peers are SIC- and size-matched. The
label is 1 for a case firm's fiscal years in the five years *before the first
public revelation*; peers in the same event-time window are 0. Post-revelation
years never enter training.

| Layer | Variables (`panel_features.csv`) | Source |
|---|---|---|
| L1 financial | `rpt_to_revenue`, `rp_receivables_to_assets`, `rp_sales_ratio`, `abnormal_rp_sales`, `earnings_cash_divergence`, `accruals` | XBRL as first reported |
| L2 monitoring | `icfr_not_effective`, `material_weakness_reported`, `mw_count`, `mw_persistence_2yr`, `restatement_proxy`; `big4`, `ceo_duality`, `board_indep`, `ac_indep` (hand-collected CSV) | 10-K Item 9A, manifest, DEF 14A |
| L3 disclosure | `rpt_vagueness` (V), `rpt_agency_masking` (A), `rpt_fog`, `rpt_passive_ratio`, `d_rpt_*`, `rpt_boilerplate_sim`, `spec_gap_*`; `item1_*` baseline | Item 13 body or DEF 14A section + RP note; Item 1 |
| Controls | `ln_assets`, `leverage`, `roa`, `listing_age` | XBRL, manifest |
| L4 peer-relative | `*_z` leave-one-out z-scores within cluster-year (label-free; NaN with < 2 reference firms); `rpt_peer_text_distance` = cosine distance of the firm's RPT text to its cluster-year peers' centroid (lexicon-free) | derived |
| Stacked | `text_risk` = TF-IDF + logit on the RPT text, fitted in *nested* grouped folds; vocabulary limited to terms used by ≥ 3 firms so it cannot memorise names | `panel_texts.csv` |

Config keys: `alert_model` (`"ensemble"` = mean probability of all models, or a model name) sets the score used for the threshold, T3 and T5; `stack_text` toggles the stacked text score; `peer_baseline` (`"loo_all"` or `"peers"`) sets the z-score reference set.

Missing text or tags are NaN (imputed with training-fold medians inside the
model pipeline), never 0.

## What each step produces

| Step | Thesis use | Output |
|---|---|---|
| `build` | descriptives, text-coverage boundary condition | `panel_features.csv`, `tables/descriptives.*`, `tables/feature_coverage.*` |
| `model` | H1 discrimination | `oof_scores.csv`, `oof_shap_<model>.csv`, `tables/oof_metrics.*`, `fold_metrics.csv`, `models/*.pkl`, `model_spec.json` |
| `stress` | T1 specificity (H4), T2 ablation (H2), T3 lead time (H3), T4 MW persistence, T5 clean-firm FPR | `stress_tests/t1..t5*`, `stress_summary.*` |
| `mediate` | P4 mediation; primary inference | `tables/mediation.*`, `tables/logit_clustered_*.*`, `tables/logit_conditional_*.*` |
| `explain` | RO4 stability and traceability | `explainability/attribution.*`, `stability.*`, `traceability.*` |
| `report` | figures | `figures/fig_oof_roc.png`, `fig_z_heatmap.png`, `fig_drift.png`, `tables/z_scores.*` |

Modelling rules: folds are grouped by case cluster (leave-one-cluster-out);
imputer and scaler are fitted inside each fold; all scores, SHAP values and
lead times are out-of-fold; the alert threshold is the one giving a clean-firm
false-positive rate ≤ `target_fpr`; the primary model is the first in
`models` (pre-specified, not the best-scoring); mediation CIs come from a
cluster bootstrap; regressions use firm-clustered or conditional logit.

## Tests

```bash
python -m unittest discover -s tests/rpt_panel -t .
```

`test_known_answer_ault.py` checks the feature path on a real filing (Ault
Alliance FY2018); `test_leakage.py` proves no firm crosses a fold and that
imputation is fold-local; `test_mediation.py` checks bootstrap SEs are real;
`test_predict.py` checks the saved pipeline reproduces training imputation.

## Repository layout

```
rpt_panel/        the pipeline (config, data_access, panel, *_features, modelling, stress_tests,
                  mediation, inference_stats, explainability, reporting, figures, predict, run)
nlp/              validated lexicon scorers reused by rpt_panel (vagueness, SFL, readability, drift)
core/config.py    thresholds for the nlp scorers
tests/rpt_panel/  unit + known-answer tests; tests/fixtures/ault_fy2018/ frozen fixture
legacy/           quarantined pre-2026 code, not runnable
docs/             status and roadmap
```
