"""
Vagueness Scorer
================
Implements the linguistic vagueness framework from Li (2008) for RPT disclosures.

Measures:
  1. Categorical Re-labeling Score (IV1) — use of generic service labels
  2. Indeterminate Word Ratio — vague quantifiers and hedging language
  3. Boilerplate Ratio — cosine similarity to prior year text
  4. Composite Vagueness Score — weighted combination

Reference:
  Li, F. (2008). Annual report readability, current earnings, and earnings
  persistence. Journal of Accounting and Economics, 45(2-3), 221-247.
"""

import re
import math
import logging
from collections import Counter
from typing import Dict, Any, List

from core.config import Config
from nlp.text_cleaner import TextCleaner


logger = logging.getLogger("forensic_rpt.vagueness")


class VaguenessScorer:
    """
    Computes vagueness and obfuscation scores for RPT disclosures.
    All methods return float scores in [0, 1] unless noted.
    """

    # Li (2008) indeterminate/hedging words
    INDETERMINATE_WORDS = {
        "approximately", "roughly", "generally", "typically", "usually",
        "substantially", "primarily", "principally", "largely", "mainly",
        "certain", "various", "some", "other", "similar",  # "related" removed: it is the topic word of RPT text
        "reasonable", "appropriate", "adequate", "sufficient",
        "customary", "ordinary", "normal", "standard",
        "believe", "expect", "anticipate", "estimate", "intend",
        "may", "might", "could", "should", "would",
        "considered", "determined", "established", "deemed",
    }

    # Red-flag keywords from the Linguistic Variables tests sheet
    RED_FLAG_KEYWORDS = {
        "control_influence": [
            "significant influence", "common control", "de facto",
            "affiliate of", "principal shareholder",
        ],
        "financing_loans": [
            "non-interest bearing", "unsecured note", "forgiven",
            "below market rate", "oral agreement",
        ],
        "entity_types": [
            "variable interest entity", "vie", "special purpose entity",
            "spe", "offshore", "trustee", "nominee",
        ],
        "relationship_ties": [
            "family member", "immediate relative", "estate of",
            "former executive",
        ],
        "vague_value": [
            "nominal consideration", "appraised value",
            "management's estimate", "in-kind",
        ],
    }

    MODAL_VERBS = {"may", "might", "could", "potentially"}

    # "pursuant to" / "in accordance with" are transparency terms below; a phrase
    # cannot count as both evasion and transparency.
    LEGAL_JARGON_TERMS = {
        "herein", "thereof", "therein", "whereas", "hereby", "subject to",
        "indemnify", "covenant", "warrant", "representations",
        "set forth", "including without limitation",
    }

    THIRD_PERSON_TERMS = {
        "the company", "the entity", "the registrant", "the issuer",
    }

    FIRST_PERSON_TERMS = {"we", "our", "us", "ours"}

    # High-risk re-labeling terms (categorical obfuscation)
    RELABELING_TERMS = {
        "consulting": 3.0,
        "consulting services": 3.0,
        "professional fees": 2.0,
        "advisory services": 2.0,
        "management fees": 2.0,
        "administrative services": 2.0,
        "service fees": 1.5,
        "business development": 1.5,
        "general services": 1.5,
        "strategic services": 2.0,
        "miscellaneous": 2.5,
        "other fees": 2.0,
        "professional services": 1.5,
    }

    # Positive transparency terms (reduce vagueness score)
    TRANSPARENCY_TERMS = {
        "pursuant to": 0.8,
        "as described in note": 0.9,
        "as required by": 0.8,
        "audit committee approved": 1.0,
        "audit committee reviewed": 1.0,
        "disclosed in": 0.7,
        "in accordance with": 0.7,
        "at arm's length": 0.9,
        "fair market value": 0.8,
        "independent appraisal": 1.0,
        "third-party valuation": 1.0,
    }

    def __init__(self, config: Config):
        self.cfg = config
        self.cleaner = TextCleaner()
        self._prior_year_texts: Dict[str, str] = {}  # cik+year → text (for boilerplate)

    def score(self, text: str) -> Dict[str, Any]:
        """
        Compute full vagueness score suite for one RPT section.

        Returns dict with:
          vagueness_score          – composite [0,1], higher = more obfuscated
          categorical_relabeling   – presence of generic service labels [0,1]
          indeterminate_ratio      – fraction of hedging words [0,1]
          transparency_score       – presence of clear, specific language [0,1]
          word_count               – section length
          high_risk_terms          – list of detected relabeling terms
          transparency_terms_found – list of detected transparency terms
        """
        if not text or len(text.strip()) < 20:
            return self._empty_scores()

        text_lower = text.lower()
        words = self.cleaner.tokenize_words(text)
        n_words = max(len(words), 1)

        # 1. Categorical re-labeling score
        relabeling_score, relabeling_terms = self._categorical_relabeling_score(text_lower)

        # 2. Indeterminate word ratio
        indeterminate_count = sum(1 for w in words if w in self.INDETERMINATE_WORDS)
        indeterminate_ratio = indeterminate_count / n_words

        # 2b. Red-flag keywords
        red_flag_count, red_flag_terms = self._red_flag_score(text_lower)
        red_flag_ratio = red_flag_count / n_words

        # 2c. Modal verbs and legal jargon (evasion score)
        modal_count = sum(1 for w in words if w in self.MODAL_VERBS)
        legal_jargon_count = self._count_phrases(text_lower, self.LEGAL_JARGON_TERMS)
        modal_ratio = modal_count / n_words
        legal_jargon_ratio = legal_jargon_count / n_words
        evasion_score = (modal_count + legal_jargon_count) / n_words

        # 2d. Distancing (third-person vs first-person references)
        third_person_count = self._count_phrases(text_lower, self.THIRD_PERSON_TERMS)
        first_person_count = sum(1 for w in words if w in self.FIRST_PERSON_TERMS)
        third_person_ratio = third_person_count / max(first_person_count, 1)

        # 3. Transparency score (inverse of vagueness)
        transparency_score, transparency_found = self._transparency_score(text_lower)

        # 4. Composite vagueness (weighted, capped at 1.0)
        composite = min(
            0.40 * relabeling_score
            + 0.35 * min(indeterminate_ratio * 3, 1.0)  # scale ratio to [0,1]
            + 0.25 * (1.0 - transparency_score),
            1.0,
        )

        return {
            "vagueness_score": round(composite, 4),
            "categorical_relabeling": round(relabeling_score, 4),
            "indeterminate_ratio": round(indeterminate_ratio, 4),
            "red_flag_keyword_ratio": round(red_flag_ratio, 4),
            "red_flag_terms_found": red_flag_terms,
            "modal_verb_ratio": round(modal_ratio, 4),
            "legal_jargon_ratio": round(legal_jargon_ratio, 4),
            "evasion_score": round(evasion_score, 4),
            "third_person_ratio": round(third_person_ratio, 4),
            "transparency_score": round(transparency_score, 4),
            "word_count": n_words,
            "high_risk_terms": relabeling_terms,
            "transparency_terms_found": transparency_found,
            "flag_vague": int(composite > self.cfg.nlp.vagueness_score_threshold),
        }

    def score_boilerplate(self, text: str, prior_text: str) -> float:
        """
        Compute cosine similarity between current and prior year RPT text.
        High similarity (>0.85) = boilerplate — no new disclosure information.
        Returns similarity float in [0, 1].
        """
        if not text or not prior_text:
            return 0.0
        vec1 = self._tfidf_vector(text)
        vec2 = self._tfidf_vector(prior_text)
        return _cosine_similarity(vec1, vec2)

    # -----------------------------------------------------------------------
    # PRIVATE
    # -----------------------------------------------------------------------

    def _categorical_relabeling_score(self, text_lower: str) -> tuple:
        """Returns (score, found_terms) where score ∈ [0, 1]."""
        found = []
        raw_score = 0.0

        # Longest match wins: "consulting services" must not also count as "consulting".
        remaining = text_lower
        for term, weight in sorted(self.RELABELING_TERMS.items(), key=lambda kv: -len(kv[0])):
            pattern = r"\b" + re.escape(term) + r"\b"
            count = len(re.findall(pattern, remaining))
            if count > 0:
                found.append((term, count))
                raw_score += weight * count
                remaining = re.sub(pattern, " ", remaining)

        # Normalise by word count context
        n_words = max(len(text_lower.split()), 1)
        normalised = min(raw_score / (n_words / 100), 1.0)
        return normalised, found

    def _transparency_score(self, text_lower: str) -> tuple:
        """Returns (score, found_terms) where higher score = more transparent."""
        found = []
        raw_score = 0.0

        for term, weight in self.TRANSPARENCY_TERMS.items():
            if term in text_lower:
                found.append(term)
                raw_score += weight

        normalised = min(raw_score / 3.0, 1.0)  # 3.0 = "max expected" anchor
        return normalised, found

    def _red_flag_score(self, text_lower: str) -> tuple:
        """Return (count, found_terms) for red-flag keyword categories."""
        found = []
        total = 0
        for category, terms in self.RED_FLAG_KEYWORDS.items():
            for term in terms:
                pattern = r"\b" + re.escape(term) + r"\b"
                matches = re.findall(pattern, text_lower)
                if matches:
                    found.append({
                        "category": category,
                        "term": term,
                        "count": len(matches),
                    })
                    total += len(matches)
        return total, found

    def _count_phrases(self, text_lower: str, terms: set) -> int:
        total = 0
        for term in terms:
            pattern = r"\b" + re.escape(term) + r"\b"
            total += len(re.findall(pattern, text_lower))
        return total

    def _tfidf_vector(self, text: str) -> Counter:
        """Simple TF (term frequency) vector for cosine similarity."""
        words = self.cleaner.tokenize_words(text)
        return Counter(words)

    def _empty_scores(self) -> Dict[str, Any]:
        return {
            "vagueness_score": 0.0,
            "categorical_relabeling": 0.0,
            "indeterminate_ratio": 0.0,
            "red_flag_keyword_ratio": 0.0,
            "red_flag_terms_found": [],
            "modal_verb_ratio": 0.0,
            "legal_jargon_ratio": 0.0,
            "evasion_score": 0.0,
            "third_person_ratio": 0.0,
            "transparency_score": 0.0,
            "word_count": 0,
            "high_risk_terms": [],
            "transparency_terms_found": [],
            "flag_vague": 0,
        }


def _cosine_similarity(vec1: Counter, vec2: Counter) -> float:
    """Compute cosine similarity between two term-frequency counters."""
    if not vec1 or not vec2:
        return 0.0
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum(vec1[x] * vec2[x] for x in intersection)
    sum1 = sum(v**2 for v in vec1.values())
    sum2 = sum(v**2 for v in vec2.values())
    denom = math.sqrt(sum1) * math.sqrt(sum2)
    return numerator / denom if denom > 0 else 0.0
