"""
Linguistic Drift Tracker
=========================
Tracks how linguistic patterns evolve year-over-year in 10-K RPT sections.

The "Linguistic Drift" hypothesis (PhD Framework):
  As fraud escalates, language becomes progressively more obfuscated:
    - Vagueness scores trend upward
    - Fog index increases
    - Agency masking increases
    - Section length may decrease (less disclosed as scrutiny increases)
    - Boilerplate ratio increases (copying prior year to avoid new commitments)

Output supports the DV3: Linguistic Obfuscation Score as a time series.
"""

import logging
from typing import Dict, Any, List

from core.config import Config


logger = logging.getLogger("forensic_rpt.drift")


class LinguisticDriftTracker:
    """
    Computes year-over-year changes in NLP metrics to detect escalating obfuscation.
    """

    DRIFT_METRICS = [
        # NLP obfuscation signals (escalation = increasing)
        "vagueness_score",
        "categorical_relabeling",
        "fog_index",
        "indeterminate_ratio",
        "complex_word_ratio",
        # SFL agency masking (escalation = increasing)
        "passive_voice_ratio",
        "agency_masking_score",
        "relational_process_ratio",
        # Transparency / disclosure (escalation = decreasing)
        "transparency_score",
        "named_executive_mentions",
        "word_count",
        "total_sentences",
        # Advanced NLP
        "semantic_shift",
    ]

    ESCALATION_DIRECTION = {
        "vagueness_score":          "increasing",
        "categorical_relabeling":   "increasing",
        "fog_index":                "increasing",
        "indeterminate_ratio":      "increasing",
        "complex_word_ratio":       "increasing",
        "passive_voice_ratio":      "increasing",
        "agency_masking_score":     "increasing",
        "relational_process_ratio": "increasing",
        "transparency_score":       "decreasing",
        "named_executive_mentions": "decreasing",
        "word_count":               "decreasing",
        "total_sentences":          "decreasing",
        "semantic_shift":           "increasing",
    }

    def __init__(self, config: Config):
        self.cfg = config

    def compute(self, years_data: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Compute drift statistics for one firm across its years.

        Args:
            years_data: {year_str: {metric: value}}

        Returns:
            {
              "year_over_year": {metric: [{year, value, delta, pct_change}]},
              "trend_direction": {metric: "increasing"|"decreasing"|"stable"},
              "escalation_flags": {metric: True/False},
              "drift_summary": {cumulative_change, acceleration}
            }
        """
        if not years_data:
            return {}

        sorted_years = sorted(years_data.keys(), key=lambda y: int(y))
        result = {"year_over_year": {}, "trend_direction": {}, "escalation_flags": {}}

        for metric in self.DRIFT_METRICS:
            series = []
            for year in sorted_years:
                val = years_data[year].get(metric)
                if val is not None:
                    series.append((int(year), float(val)))

            if len(series) < 2:
                continue

            yoy = []
            for i in range(1, len(series)):
                prev_year, prev_val = series[i - 1]
                curr_year, curr_val = series[i]
                delta = curr_val - prev_val
                pct = (delta / prev_val * 100) if prev_val != 0 else 0.0
                yoy.append({
                    "from_year": prev_year,
                    "to_year": curr_year,
                    "value": round(curr_val, 4),
                    "delta": round(delta, 4),
                    "pct_change": round(pct, 2),
                })

            result["year_over_year"][metric] = yoy

            # Trend direction
            values = [s[1] for s in series]
            trend = self._trend_direction(values)
            result["trend_direction"][metric] = trend

            # Escalation flag: use per-metric direction from ESCALATION_DIRECTION
            expected = self.ESCALATION_DIRECTION.get(metric, "increasing")
            result["escalation_flags"][metric] = (trend == expected)

        # Drift summary
        n_escalating = sum(1 for v in result["escalation_flags"].values() if v)
        result["drift_summary"] = {
            "n_escalating_metrics": n_escalating,
            "n_total_metrics": len(result["escalation_flags"]),
            "escalation_ratio": round(
                n_escalating / max(len(result["escalation_flags"]), 1), 4
            ),
            "high_escalation": n_escalating >= 3,
        }

        return result

    def _trend_direction(self, values: List[float]) -> str:
        """
        Classify trend as increasing, decreasing, or stable.
        Uses simple linear regression slope sign.
        """
        n = len(values)
        if n < 2:
            return "stable"

        x_mean = (n - 1) / 2
        y_mean = sum(values) / n

        numerator = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
        denominator = sum((i - x_mean) ** 2 for i in range(n))

        if denominator == 0:
            return "stable"

        slope = numerator / denominator
        threshold = abs(y_mean) * 0.05 if y_mean != 0 else 0.01

        if slope > threshold:
            return "increasing"
        elif slope < -threshold:
            return "decreasing"
        return "stable"
