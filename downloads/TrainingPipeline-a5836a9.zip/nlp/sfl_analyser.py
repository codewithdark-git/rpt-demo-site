"""
SFL (Systemic Functional Linguistics) Analyser
================================================
Implements Halliday's Transitivity framework for agency-masking detection
in SEC 10-K Related Party Transaction disclosures.

Agency Masking Hypothesis:
  Fraudulent disclosures systematically obscure the human agent responsible
  for transactions by using:
    (a) Passive constructions ("An agreement was reached")
    (b) Nominalization ("The entering into of agreements")
    (c) Relational processes ("The Company had an arrangement")
    (d) Material process avoidance (rarely using "X did Y" with named actor)

SFL Transitivity System (Halliday 2004):
  - Material processes: doing/happening ("The CEO approved")
  - Mental processes: thinking/feeling ("Management believes")
  - Relational processes: being/having ("The Company had")
  - Verbal processes: saying ("The Company disclosed")

Reference:
  Halliday, M.A.K. (2004). An Introduction to Functional Grammar (3rd ed.).
  Eggins, S. (2004). An Introduction to Systemic Functional Linguistics.
"""

import re
import logging
from typing import Dict, Any, List, Tuple

from core.config import Config
from nlp.text_cleaner import TextCleaner


logger = logging.getLogger("forensic_rpt.sfl")


# Process type lexicons
MATERIAL_PROCESS_VERBS = {
    "approved", "directed", "authorized", "signed", "executed",
    "paid", "transferred", "acquired", "purchased", "sold",
    "loaned", "borrowed", "invested", "received", "issued",
    "delivered", "completed", "made", "recorded", "filed",
}

MENTAL_PROCESS_VERBS = {
    "believes", "considered", "determined", "concluded", "expected",
    "anticipated", "estimated", "assessed", "judged", "thought",
    "understood", "knew", "intended", "decided",
}

RELATIONAL_PROCESS_VERBS = {
    "is", "was", "are", "were", "has", "have", "had",
    "remains", "remained", "constitute", "constitutes",
    "represents", "represented", "includes", "included",
    "consists", "consisted",
}

VERBAL_PROCESS_VERBS = {
    "disclosed", "stated", "reported", "described", "noted",
    "indicated", "announced", "represented", "disclosed",
}

# Named executive actors — agency is present when these appear as subjects.
# Role titles only: firm-specific surnames would make the score a firm fingerprint.
EXECUTIVE_ACTOR_PATTERNS = [
    r"\bexecutive\s+chairman\b",
    r"\bchief\s+executive\s+officer\b",
    r"\bceo\b",
    r"\bcfo\b",
    r"\bthe\s+chairman\b",
]

# Agency-masking patterns: actor hidden or obscured
MASKING_PATTERNS = [
    (r"\ban?\s+agreement\s+was\s+(?:reached|entered|executed)", "passive_agreement"),
    (r"\bit\s+was\s+(?:determined|concluded|decided|considered)", "impersonal_determination"),
    (r"\bfees\s+were\s+paid", "passive_payment"),
    (r"\bwas\s+authorized", "passive_authorization"),
    (r"\bwas\s+approved", "passive_approval"),
    (r"\bwas\s+facilitated", "passive_facilitation"),
    (r"\bservices\s+were\s+(?:provided|rendered|performed)", "passive_service"),
    (r"\bpayments?\s+were\s+(?:made|recorded|processed)", "passive_payment"),
    (r"\ba\s+payment\s+of\s+\$", "nominalized_payment"),
    (r"\bthe\s+company\s+entered\s+into", "impersonal_company_subject"),
    (r"\bmanagement\s+(?:believes|considered|determined)", "management_collective_actor"),
    (r"\bit\s+was\s+(?:agreed|determined|established)", "passive_impersonal"),
    (r"\bwere\s+considered\s+to\s+be", "passive_evaluation"),
    (r"\bin\s+the\s+ordinary\s+course", "routine_framing"),
    # "at arm's length" is scored as transparency by VaguenessScorer; it is not masking.
    (r"\bno\s+less\s+favorable", "vague_comparison"),
    (r"\bconducted\s+on\s+terms", "vague_terms"),
]

# Transparency patterns: clear, named-agent disclosure
TRANSPARENCY_PATTERNS = [
    (r"\b(?:the\s+)?(?:ceo|cfo|chief\s+executive\s+officer|chief\s+financial\s+officer|chairman)\s+(?:directed|approved|authorized|signed|paid)", "named_role_action"),
    (r"\baudit\s+committee\s+(?:approved|reviewed|authorized)", "governance_approval"),
    (r"\bpursuant\s+to\s+(?:section|rule|item)", "regulatory_grounding"),
]


class SFLAnalyser:
    """
    Performs Transitivity analysis on RPT disclosure text.
    Quantifies agency masking as ratio of passive/impersonal constructions.
    """

    def __init__(self, config: Config):
        self.cfg = config
        self.cleaner = TextCleaner()

    def analyse(self, text: str) -> Dict[str, Any]:
        """
        Run full SFL analysis on RPT section text.

        Returns:
          passive_voice_ratio      – fraction of clauses using passive constructions
          agency_masking_score     – [0,1], higher = more obscured agency
          process_distribution     – breakdown by process type
          masking_instances        – list of (pattern_type, matched_text)
          transparency_instances   – list of clear-agency patterns
          named_executive_mentions – count of named actor appearances
          relational_process_ratio – fraction using "be/have" verbs (low agency)
          flag_agency_masking      – 1 if score > threshold
        """
        if not text or len(text.strip()) < 30:
            return self._empty()

        text_lower = text.lower()
        sentences = self.cleaner.tokenize_sentences(text)
        n_sentences = max(len(sentences), 1)

        # --- Passive voice detection ---
        passive_patterns = [p for p, _ in MASKING_PATTERNS[:8]]  # First 8 are passive
        passive_count = sum(
            1 for sent in sentences
            if any(re.search(pat, sent.lower()) for pat in passive_patterns)
        )
        passive_ratio = passive_count / n_sentences

        # --- Masking pattern detection ---
        masking_instances = []
        masking_score_raw = 0.0
        for pattern, label in MASKING_PATTERNS:
            matches = re.findall(pattern, text_lower)
            if matches:
                masking_instances.append({
                    "type": label,
                    "count": len(matches),
                    "examples": matches[:2],
                })
                masking_score_raw += len(matches)

        # --- Transparency pattern detection ---
        transparency_instances = []
        transparency_score_raw = 0.0
        for pattern, label in TRANSPARENCY_PATTERNS:
            matches = re.findall(pattern, text_lower)
            if matches:
                transparency_instances.append({"type": label, "count": len(matches)})
                transparency_score_raw += len(matches)

        # --- Named executive actor mentions ---
        named_mentions = sum(
            len(re.findall(pat, text_lower))
            for pat in EXECUTIVE_ACTOR_PATTERNS
        )

        # --- Process type distribution ---
        words = self.cleaner.tokenize_words(text)
        process_dist = self._compute_process_distribution(words)

        # --- Composite agency masking score [0, 1] ---
        # Higher masking + lower transparency + fewer named actors = higher score
        norm_masking = min(masking_score_raw / max(n_sentences, 1), 1.0)
        norm_transparency = min(transparency_score_raw / max(n_sentences, 1) * 2, 1.0)
        actor_penalty = max(0, 1 - named_mentions * 0.1)  # named actors reduce score

        agency_score = min(
            0.45 * norm_masking
            + 0.30 * passive_ratio
            + 0.15 * process_dist.get("relational_ratio", 0)
            + 0.10 * actor_penalty
            - 0.20 * norm_transparency,  # transparency subtracts from score
            1.0,
        )
        agency_score = max(0.0, agency_score)

        return {
            "passive_voice_ratio": round(passive_ratio, 4),
            "agency_masking_score": round(agency_score, 4),
            "process_distribution": process_dist,
            "masking_instances": masking_instances,
            "transparency_instances": transparency_instances,
            "named_executive_mentions": named_mentions,
            "relational_process_ratio": round(process_dist.get("relational_ratio", 0), 4),
            "total_sentences": n_sentences,
            "flag_agency_masking": int(agency_score > self.cfg.nlp.agency_masking_threshold),
        }

    def _compute_process_distribution(self, words: List[str]) -> Dict[str, float]:
        """Classify verbs by SFL process type and return distribution."""
        n = max(len(words), 1)
        material = sum(1 for w in words if w in MATERIAL_PROCESS_VERBS)
        mental = sum(1 for w in words if w in MENTAL_PROCESS_VERBS)
        relational = sum(1 for w in words if w in RELATIONAL_PROCESS_VERBS)
        verbal = sum(1 for w in words if w in VERBAL_PROCESS_VERBS)
        total_process = max(material + mental + relational + verbal, 1)

        return {
            "material_ratio": round(material / total_process, 4),
            "mental_ratio": round(mental / total_process, 4),
            "relational_ratio": round(relational / total_process, 4),
            "verbal_ratio": round(verbal / total_process, 4),
            "total_process_words": total_process,
        }

    def _empty(self) -> Dict[str, Any]:
        return {
            "passive_voice_ratio": 0.0,
            "agency_masking_score": 0.0,
            "process_distribution": {},
            "masking_instances": [],
            "transparency_instances": [],
            "named_executive_mentions": 0,
            "relational_process_ratio": 0.0,
            "total_sentences": 0,
            "flag_agency_masking": 0,
        }
