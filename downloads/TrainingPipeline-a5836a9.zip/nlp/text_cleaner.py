"""
Text Cleaner
=============
Normalises 10-K text for NLP analysis.
Removes boilerplate, page headers/footers, excessive whitespace.
"""

import re
from typing import List


def _clean(text: str) -> str:
    if not text:
        return ""
    # Remove EDGAR HTML artifacts
    text = re.sub(r"<[^>]+>", " ", text)
    # Remove page number artifacts: "F-12", "Page 45", etc.
    text = re.sub(r"\bpage\s+\d+\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bF-\d+\b", " ", text)
    # Remove EDGAR boilerplate patterns
    text = re.sub(r"table\s+of\s+contents", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"see\s+accompanying\s+notes", " ", text, flags=re.IGNORECASE)
    # Remove dollar sign formatting artifacts
    text = re.sub(r"\$\s+", "$", text)
    # Collapse whitespace
    text = re.sub(r"\s+", " ", text)
    return text.strip()


class TextCleaner:
    """Stateless text normalisation."""

    def clean(self, text: str) -> str:
        return _clean(text)

    def tokenize_sentences(self, text: str) -> list:
        """
        Simple sentence tokeniser — splits on '. ', '! ', '? '.
        Does not require NLTK punkt model.
        """
        text = _clean(text)
        # Split on sentence-ending punctuation followed by space + capital
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z])", text)
        return [s.strip() for s in sentences if len(s.strip()) > 20]

    def tokenize_words(self, text: str) -> list:
        """Return lowercase word tokens, removing punctuation."""
        text = _clean(text).lower()
        return re.findall(r"\b[a-z][a-z']*\b", text)

    def word_count(self, text: str) -> int:
        return len(self.tokenize_words(text))

    def sentence_count(self, text: str) -> int:
        return len(self.tokenize_sentences(text))
