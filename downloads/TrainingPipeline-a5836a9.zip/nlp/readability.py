"""
Readability Analyser
=====================
Computes readability metrics for 10-K RPT sections.

Implements:
  - Gunning Fog Index (primary readability measure per Li 2008)
  - Flesch Reading Ease
  - Average sentence length
  - Complex word ratio (words ≥ 3 syllables)

These are used as Dependent Variable 3: Linguistic Obfuscation Score.

Reference:
  Li, F. (2008). Annual report readability, current earnings,
  and earnings persistence. JAE 45(2-3), 221-247.

  Gunning, R. (1952). The Technique of Clear Writing.
"""

import re
import logging
from typing import Dict, Any

from core.config import Config
from nlp.text_cleaner import TextCleaner


logger = logging.getLogger("forensic_rpt.readability")


def count_syllables(word: str) -> int:
    """
    Estimate syllable count using heuristic rules.
    Accurate for ~85% of English words without a pronunciation dictionary.
    """
    word = word.lower().strip(".,;:!?\"'()-")
    if len(word) <= 3:
        return 1

    # Remove silent e at end
    if word.endswith("e"):
        word = word[:-1]

    # Count vowel groups
    vowel_groups = re.findall(r"[aeiouy]+", word)
    count = len(vowel_groups)

    # Adjustments
    if word.endswith("le") and len(word) > 2 and word[-3] not in "aeiouy":
        count += 1
    if count == 0:
        count = 1

    return count


def is_complex_word(word: str) -> bool:
    """Returns True if word has ≥ 3 syllables (Gunning Fog definition)."""
    return count_syllables(word) >= 3


class ReadabilityAnalyser:
    """
    Computes Gunning Fog Index and supporting readability metrics.
    """

    def __init__(self, config: Config):
        self.cfg = config
        self.cleaner = TextCleaner()

    def analyse(self, text: str) -> Dict[str, Any]:
        """
        Compute all readability metrics for one text section.

        Returns:
          fog_index              – Gunning Fog score (12 = high school, 17+ = obfuscating)
          flesch_reading_ease    – Flesch score (60-70 = plain English, <30 = very difficult)
          avg_sentence_length    – Average words per sentence
          complex_word_ratio     – Fraction of words with ≥ 3 syllables
          total_sentences        – Sentence count
          total_words            – Word count
          flag_complex           – 1 if Fog > threshold
        """
        if not text or len(text.strip()) < 50:
            return self._empty()

        sentences = self.cleaner.tokenize_sentences(text)
        words = self.cleaner.tokenize_words(text)
        n_sentences = max(len(sentences), 1)
        n_words = max(len(words), 1)

        # Complex words
        complex_words = [w for w in words if is_complex_word(w)]
        n_complex = len(complex_words)
        complex_ratio = n_complex / n_words

        # Avg sentence length
        avg_sent_len = n_words / n_sentences

        # Gunning Fog Index
        # Formula: 0.4 × (avg_sentence_length + 100 × complex_word_ratio)
        fog_index = 0.4 * (avg_sent_len + 100 * complex_ratio)

        # SMOG Grade
        # Formula: 1.0430 * sqrt(30 * (complex_words / sentences)) + 3.1291
        smog_index = 1.0430 * (30 * (n_complex / n_sentences)) ** 0.5 + 3.1291

        # Flesch Reading Ease
        # 206.835 - 1.015 × avg_sent_len - 84.6 × avg_syllables_per_word
        total_syllables = sum(count_syllables(w) for w in words)
        avg_syllables = total_syllables / n_words
        flesch = 206.835 - 1.015 * avg_sent_len - 84.6 * avg_syllables
        flesch = max(0.0, min(100.0, flesch))

        return {
            "fog_index": round(fog_index, 2),
            "smog_index": round(smog_index, 2),
            "flesch_reading_ease": round(flesch, 2),
            "avg_sentence_length": round(avg_sent_len, 2),
            "complex_word_ratio": round(complex_ratio, 4),
            "total_sentences": n_sentences,
            "total_words": n_words,
            "flag_complex": int(fog_index > self.cfg.nlp.fog_index_threshold),
        }

    def _empty(self) -> Dict[str, Any]:
        return {
            "fog_index": 0.0,
            "smog_index": 0.0,
            "flesch_reading_ease": 0.0,
            "avg_sentence_length": 0.0,
            "complex_word_ratio": 0.0,
            "total_sentences": 0,
            "total_words": 0,
            "flag_complex": 0,
        }
