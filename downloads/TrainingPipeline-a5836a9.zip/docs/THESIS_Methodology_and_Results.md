# Chapter 3 — Methodology

This chapter describes how the study was carried out, in the order in which the work was done: how the sample of fraud cases and matched firms was built, where every data item was downloaded from and how it was extracted, how each variable was measured, how the hypotheses were tested, and how the results were checked. Every statistic, model and rule is defined before it is used so that a reader who did not take part in the work can reproduce every table in Chapter 4 from the files named in Appendix 3.A. The research design of 6 October 2026 fixed the hypotheses, the eight characteristics, the scoring steps and the tests before any firm data were collected; the chapter follows that design and records, in §3.11, every point at which the execution departed from it.

## 3.1 The methodology in one diagram

Figure 3.1 shows the whole methodology as eighteen numbered blocks in three stages. The blocks carry only a label; each is explained in §3.1.1, and the sections that follow give the full procedures.

![Figure 3.1 — Methodology of the study: three stages, eighteen blocks](thesis_figures/fig_methodology_blocks.png)

### 3.1.1 Reading the diagram

**Stage 1 — Sample and data** produces the firm-year panel: the list of fraud cases and matched firms, their labels, and the raw filings.

1. *Case discovery.* Every US issuer whose SEC enforcement involved a related party transaction (RPT) is searched for in four sources: the full text of every Accounting and Auditing Enforcement Release (AAER) 2005–2024, the full text of every SEC litigation release (LR) 2010–2025, EDGAR full-text search (FTS) of issuers' own filings for disclosures of an SEC related-party action, and the client's workbook of candidate firms (§3.4).
2. *Inclusion rule D1.* A candidate qualifies when the SEC order or complaint describes a misstatement or a misappropriation in which an RPT is the mechanism, or when the charge is the failure to disclose an RPT (the disclosure-only stratum). Both groups are RPT-fraud firms (FRAUD = 1); the stratum label is kept for the design's second H2 run.
3. *Revelation date D2.* The first public event that revealed the problem (a non-reliance 8-K, an auditor resignation, an audit-committee investigation, a short-seller report, a restatement, or the SEC action itself), with a confidence level and a source document.
4. *Window D3.* The five fiscal years before the revelation year; a case needs at least four annual reports in that window and a window starting in 2005 or later.
5. *Peer matching D4.* Five firms per case from the same four-digit SIC industry (three- or two-digit when the pool is thin), nearest in log total assets in the year before revelation, with a 10-K in every window year and no AAER match, matched without replacement.
6. *EDGAR download.* For every firm: the filing list from the submissions API, every annual report (10-K, 10-KT), every proxy statement (DEF 14A), the XBRL company facts, the 8-K item codes, and every amended annual report (10-K/A) (§3.5).

**Stage 2 — Measurement** turns the panel into measured firm-years.

7. *Section extraction.* From each annual report: Item 1 (Business), Item 9A (Controls and Procedures), Item 13 (Certain Relationships and Related Transactions), the related-party note to the financial statements, and the audit report; from each proxy statement: the related-party section and the board statements (§3.6).
8. *Eight RPT characteristics.* Layer 1 financial: lending to, payables to, sales to and purchases from related parties, scaled by assets or revenue; Layer 2 disclosure: incompleteness of the related-party disclosure (four items) and vagueness of its language; Layer 3 governance: the share of non-independent directors and CEO duality (§3.7.1).
9. *Traditional signals.* Material weakness in internal control (Item 9A), a modified or going-concern audit opinion, an auditor change (8-K Item 4.01) and a restatement (8-K Item 4.02 or a restating 10-K/A), summed into the traditional index (§3.7.2).
10. *Controls.* Leverage and return on assets from XBRL; industry, size and year are controlled by the matching itself (§3.7.3).
11. *Scores.* The design's five steps: raw figures, the eight ratios, each characteristic ranked 0–1 against all analysed firm-years, ranks averaged within layer, the three layer scores averaged and multiplied by ten (§3.7.4).

**Stage 3 — Tests, attribution and validation** answers the objectives.

12. *Measurement checks M1–M3.* Coverage of every characteristic (by group), reliability of the machine coding against human coding, and distinctness of the three layer scores (§3.7.5).
13. *H1–H3.* Each layer score against FRAUD within matched sets by conditional logit with leverage and ROA, Holm-adjusted across the three, with firm-clustered standard errors (§3.8.1–3.8.3).
14. *H4.* The same test run separately in each of the five years before revelation (§3.8.4).
15. *H5.* Model A (traditional index and controls) against Model B (plus the AI risk score), each matched set scored by a model fitted without it; and the timing test at an equal false-alarm rate (§3.8.5).
16. *P1.* Lending, purchases and sales tabulated by form of fraud, as a pattern only (§3.8.6).
17. *A1–A3.* Each firm's AI risk score divided by layer and characteristic; the division repeated with each matched set left out; the largest layer in the flagged fraud firms read against the three agency ideas (§3.8.7).
18. *Validation and exploratory work.* Robustness cuts, the alternative samples, the external set of three-report cases, the power calculation and the deviations log; and, kept apart, the exploratory fitted score with its stress tests (§3.9, §3.10).

## 3.2 Research design

**Design.** A matched case-control study of US listed firms. A *case* is a firm named in an SEC enforcement action in which an RPT is the mechanism of a misstatement or misappropriation, or the subject of the disclosure charge. Each case is compared with up to five *matched firms* from the same industry and of similar size that were never subject to an SEC accounting enforcement action. The unit of analysis is the **firm-year**: one row per annual report per firm.

**Why case-control.** Enforcement for RPT fraud is rare: about thirty usable cases in twenty years. A random sample of listed firms would contain almost none, so the design samples on the outcome and supplies the comparison group by matching. The price is that base rates cannot be estimated; what can be estimated is *within-set association* (conditional on industry, size and year, is the measure higher in the case firm?) and *discrimination* (does a score separate case firm-years from matched firm-years?).

**Outcome and window.** FRAUD_it = 1 for a case firm i in each of the five fiscal years before the fiscal year in which the problem became public (event time t = −5 … −1) and 0 for every matched firm-year; matched firms take the window of their case. Years at or after revelation are never analysed. Because the fraud is usually under way during the window, the study measures earlier *identification* of fraud in progress, not prediction before it begins; any flag lies inside the window by construction.

**Pre-specification and what counts as support.** The hypotheses H1–H5, the proposition P1, the measurement checks M1–M3 and the attribution checks A1–A3 were fixed in the design before data collection. A hypothesis is *supported* when the coefficient has the predicted sign and the Holm-adjusted p-value is below 0.05 with the design's firm-clustered standard errors. Results that fail this rule are reported as not supported; no hypothesis was re-worded after the results were seen.

**Association, not cause.** Every test is an association within matched sets. Matched firms are firms without enforcement, not firms known to be clean.

## 3.3 Theoretical framework and variables

Agency theory supplies the three ideas that become the three layers: *conflict of interest* (an insider on both sides of a transaction can move resources; Layer 1), *information asymmetry* (extraction succeeds while outsiders cannot see it; Layer 2), and *monitoring* (boards, auditors and internal control constrain insiders; Layer 3, with audit and internal-control signals as the benchmark in H5). The efficient-transaction hypothesis supplies the competing prediction throughout: that the layers do not differ between fraud firms and matched firms. The fraud diamond labels the variables in the discussion (opportunity: RPTs and weak oversight; pressure: leverage and profitability; capability: CEO duality; rationalisation: not measured). Figure 3.2 shows the variable framework.

![Figure 3.2 — Variable framework: layers, benchmark, controls and outcome](thesis_figures/fig_variable_framework.png)

### 3.3.1 Dependent variables

| Code | Variable | Definition | Used in |
|---|---|---|---|
| FRAUD_it | RPT fraud firm-year | 1 for a case firm's fiscal years at event time −5 … −1; 0 for matched firms in the same window | H1–H5 |
| FORM_i | Form of fraud | *managerial* (misappropriation, self-dealing), *corporate* (misstatement of the accounts), *both*, or *disclosure-only*; coded once per case from the SEC order or complaint | P1 |
| STRATUM_i | Case stratum | *core* (RPT in the misstatement or misappropriation) or *disclosure-only* (the charge is the missing or incomplete disclosure) | H2 second run; descriptive splits |

### 3.3.2 The eight design characteristics

| Code | Characteristic | Measured as | Source in the filings | Layer |
|---|---|---|---|---|
| RP_LEND | Lending to related parties | loans, advances, notes and receivables due *from* related parties ÷ total assets | related-party note; Item 13; proxy section | 1 financial |
| RP_PAY | Payables to related parties | loans, notes and amounts due *to* related parties ÷ total assets | same | 1 |
| RP_SALES | Sales to related parties | revenue from related parties ÷ total revenue | same | 1 |
| RP_PURCH | Purchases from related parties | purchases, fees, rent and services paid *to* related parties ÷ total assets | same | 1 |
| RP_INCOMP | Incompleteness of the disclosure | (4 − items stated) ÷ 4; items: counterparty named, amount stated, terms stated, business purpose stated | same | 2 disclosure |
| RP_VAGUE | Vagueness of the disclosure | uncertainty and weak-modal words ÷ total words of the related-party text | same | 2 |
| BRD_NONIND | Non-independent directors | 1 − (independent directors ÷ board size) | proxy statement | 3 governance |
| DUAL | CEO duality | 1 if the chief executive also chairs the board | proxy statement | 3 |

### 3.3.3 Traditional signals (the reactive benchmark) and controls

| Code | Variable | Definition | Source |
|---|---|---|---|
| ICFR_MW | Material weakness | 1 if Item 9A reports a material weakness in internal control over financial reporting | 10-K Item 9A |
| AUD_OPIN | Modified or going-concern opinion | 1 if the audit report is qualified, adverse or a disclaimer, or raises substantial doubt about going concern (an adverse opinion on internal control is excluded: that is ICFR_MW) | 10-K audit report |
| AUD_CHG | Auditor change | 1 if an 8-K Item 4.01 (change in certifying accountant) was filed in the fiscal year | submissions API |
| RESTATE | Restatement | 1 if an 8-K Item 4.02 (non-reliance) was filed in the fiscal year, or a 10-K/A filed in the year states that previously issued financial statements are restated | submissions API; 10-K/A text |
| TRAD_INDEX | Traditional index | ICFR_MW + AUD_OPIN + AUD_CHG + RESTATE (0–4) | calculated |
| LEV | Leverage | total liabilities ÷ total assets, bounded to [0, 3] | XBRL company facts |
| ROA | Profitability | net income ÷ total assets, bounded to [−1, 1] | XBRL company facts |

## 3.4 Stage 1 — Sample construction (blocks 1–5)

**Discovery (block 1).** (i) Every AAER from 2005 to 2024 (2,383 releases) was downloaded from the SEC's AAER listing pages and its PDF text searched for related-party terms; (ii) every litigation release from 2010 to 2025 (5,086 releases) was read the same way, because civil actions are not all on the AAER list; (iii) EDGAR full-text search was queried for issuers' own 10-K, 10-Q and 8-K disclosures of an SEC related-party action (1,354 issuers matched; 89 on two or more query families); (iv) the client's workbook of 2 October 2026 (39 firms). Fifty-eight candidates were recorded with the order or complaint that names them.

**Inclusion (block 2).** Each candidate's order or complaint was read and classed: *misstatement*, *misappropriation*, *both*, *disclosure-only*, or *excluded* (no RPT element; internal-controls-only order). The class is FORM_i for P1 and sets the stratum.

**Revelation date (block 3).** For each case the first public event was located in the firm's own filings (8-K Items 4.02 and 4.01, 10-Q and 10-K text, press-release exhibits) and in the enforcement document; when nothing earlier exists the SEC action date is used and the confidence is *low*. An evidence pass (§3.9) later searched every medium- and low-confidence case's filings for earlier candidates with the passage extracted for reading.

**Window and reports (block 4).** The window is the five fiscal years before the revelation year (a fiscal year ending January–May belongs to the previous calendar year). A case needs at least four annual reports in the window and a window beginning in 2005 or later, so that Item 9A exists. Candidates with three reports form the external set; those with earlier windows an extended tier not used here.

**Peer matching (block 5).** For case i with revelation year r and SIC code s, the pool is every EDGAR registrant with the same four-digit SIC (three-digit, then two-digit, when fewer than eight candidates remain) that has a 10-K on file for every window year, no AAER match, and XBRL total assets A_j,r−1 for the year before revelation. The five firms minimising |ln A_j,r−1 − ln A_i,r−1| are selected without replacement across cases. The universe behind the pool is 13,110 registrants in the candidates' 33 SIC codes with total assets by calendar year from the XBRL frames API.

**Result.** 31 qualifying cases (21 misstatement/misappropriation, 10 disclosure-only) and 145 matched firms: 24 sets with five, 4 with four and 3 with three (thin industry pools). 123 matched firms share the case's four-digit SIC, 5 the three-digit and 12 the two-digit code; the median gap in log assets is 0.40. Three sets (Ocwen, Energy XXI, Singularity) are poorly size-matched and are reported with and without. Gulfport Energy, screened in October 2026 without a revelation date, was later dated from its own 10-Q of 1 November 2018 (audit-committee review of undisclosed CEO perquisites and related-person transactions; SEC Release 33-10930 of 24 February 2021), matched with five peers by rule D4 and, with the researcher's approval of 10 October 2026, added as the 31st case; its tables and raw filings were merged into the core data set. Ten three-report cases with 28 matched firms form the external set. The design's target of 40 cases does not exist in the records searched; the alternatives are reported in §4.9.

## 3.5 Stage 1 — Where the data are downloaded from (block 6)

All data are public SEC EDGAR data, fetched by the project's own Python downloader (`SEC-EDGAR-Downloader`, package `sec_rpt_dataset`) under the SEC's fair-access policy: every request carries a research User-Agent with a contact address and requests are paced below ten per second. Nothing is bought, scraped from third parties or taken from Compustat.

| Data item | Endpoint | What is taken |
|---|---|---|
| Company metadata and filing lists | `https://data.sec.gov/submissions/CIK##########.json` (plus the paged `filings/files` entries) | name, SIC, fiscal-year end, every filing with form type, filing date, report date, accession number, primary document and 8-K item codes |
| Annual reports | `https://www.sec.gov/Archives/edgar/data/<CIK>/<accession>/<primary document>` | the primary 10-K / 10-KT document of every fiscal year FY2004–2024 (the first original filing per fiscal year is the *primary* filing); amended 10-K/A documents are fetched separately for the restatement test |
| Proxy statements | same Archives path, form DEF 14A | the DEF 14A filed within nine months after each fiscal year end; one proxy per filing year so that board statements exist for every firm-year (85 % linked) |
| Financial statement values | `https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json` | total assets, total liabilities, net income, revenue, operating cash flow, as first reported for each fiscal year (FY2009 onwards; earlier years missing) |
| Size of the matching universe | `https://data.sec.gov/api/xbrl/frames/us-gaap/Assets/USD/CY<year>I.json` | total assets of every registrant by calendar year, for the peer pool |
| Industry lists | `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&SIC=<code>` | every registrant in each candidate SIC code |
| 8-K items | submissions API (above) | Items 4.01 and 4.02 with filing dates, attributed to the fiscal year in progress |
| Enforcement documents | `https://www.sec.gov/enforcement-litigation/accounting-auditing-enforcement-releases` and `.../litigation-releases` listing pages and their PDFs | AAER and LR texts for discovery and for FORM_i |
| Issuers' own disclosures of SEC actions | `https://efts.sec.gov/LATEST/search-index?q=…&ciks=…&forms=…` (EDGAR full-text search, filings since 2001) | candidate discovery and the revelation-date evidence pass |

**Storage.** Each build writes one directory (`data_core` for the 31 cases and 145 matched firms, after the Gulfport build `data_gulf` was merged into it; `data_sens` for the external set; `data_gulf` for the Gulfport candidate) with the tables `company_universe.csv`, `filing_manifest.csv`, `proxy_links.csv`, `eightk_items.csv`, `tenka_restatements.csv`, `xbrl_financials.csv`, `fraud_labels.csv`, `master_panel.csv` and `dataset_qa.json`, and the raw documents under `raw/filings/<CIK>/<year>/<accession>/` (`filing.txt`, `item1.txt`, `item9a.txt`, `item13.txt`, `rp_note.txt`, `rpt_disclosure.txt`) and `raw/proxies/<CIK>/<accession>/proxy.txt`. Any value in any table can be traced to the document it came from.

**Quality.** The core build of 8 October 2026: 170 firms, 2585 annual reports, zero extraction errors, related-party text for 79 % of filings, Item 9A for 90 %, XBRL total assets for 76 %. The data set is about 1.5 GB and was built and used locally.

## 3.6 Stage 1 — Section extraction (block 7)

Items are located in the 10-K text by line-anchored headings; table-of-contents lines are skipped and the longest candidate body is kept. Item 13 is often incorporated by reference to the proxy statement; in that case the related-party section of the DEF 14A is extracted and the source is recorded (`rpt_source` = 10k_item13 / def14a / rp_note / none). The related-party note is located by its heading in the financial statements. The audit report is the text from the heading *Report of Independent Registered Public Accounting Firm* to the signature that follows it. Texts shorter than 40 words are treated as missing, never as zero.

## 3.7 Stage 2 — Measurement (blocks 8–12)

### 3.7.1 The eight characteristics

**Related-party amounts (RP_LEND, RP_PAY, RP_SALES, RP_PURCH).** The related-party note and the Item 13 / proxy section are read together and split into sentences. Every money expression ('$1.2 million', '750,000', scaled by an *in thousands* or *in millions* header) is classified by the words of its sentence into one of four flows: lending (loan to, advance to, note or receivable from, due from), payables (loan from, borrowed from, note payable to, due to), sales (sales to, revenue from, billed to) and purchases (purchased from, paid to, fees, rent, royalties or services paid to). Direction words set the flow ('loan *to the Company*' is a payable; 'advanced *by the Company*' is lending). Sentences that state the Item 404 $120,000 materiality threshold and exhibit-index lines are not transactions and are excluded. The largest amount per flow is kept with its sentence as evidence and scaled by XBRL total assets (revenue for sales). A text with no amount gives a missing amount, never zero, as the design requires.

**Incompleteness (RP_INCOMP).** The four items are flagged on the same text: counterparty named (a titled person, an officer or director, or a named entity), amount stated (any money expression), terms stated (interest, maturity, due date, repayment, secured/unsecured, rate), purpose stated (purpose, in connection with, to fund, services, office space, …). RP_INCOMP = (4 − items)/4. When the text exists but states that there were no related-party transactions, the items are scored on that text and RP_INCOMP is high; this convention is tested in §4.3 by re-running H2 without such firm-years. When no related-party text exists the characteristic is missing.

**Vagueness (RP_VAGUE).** (uncertainty words + weak-modal words) ÷ total words of the related-party text, using the Loughran–McDonald uncertainty and weak-modal lists ('may', 'could', 'approximately', 'believes', 'certain', …).

**Governance (BRD_NONIND, DUAL).** From the proxy statement of the filing year: CEO duality = 1 when the statement that one person serves as both chair and chief executive is found (titles held at other companies and conditional language — 'whether to separate or combine' — excluded), 0 when the roles are stated to be separate or the chair is stated to be independent, missing otherwise; board independence = independent directors ÷ board size when the proxy states a count ('six of our seven directors are independent'; 'the Board has determined that Messrs A, B and C are independent' with a stated board size), and BRD_NONIND = 1 − that share.

**Evidence and the human check.** Every coded value stores the passage it was taken from. A 10 % random sample per variable (2,075 rows) is drawn for the human check M2, in a workbook with the evidence beside an empty column for the human value; the agreement statistics (Cohen's kappa for binary items; the share of amounts within 10 %) are computed by `scripts/make_m2_workbook.py score`. The coding is rule-based, not a language model reading the filings; this is recorded as a deviation (§3.11).

### 3.7.2 Traditional signals

ICFR_MW from Item 9A (the statement that a material weakness exists); AUD_OPIN from the audit report: substantial-doubt language for going concern, and qualified / adverse / disclaimer language for a modified opinion, excluding the paragraph on another auditor's prior-year statements and any adverse opinion on internal control; AUD_CHG from 8-K Item 4.01; RESTATE from 8-K Item 4.02, or from a 10-K/A whose text says that previously issued financial statements are restated (amendments that only add Part III or an exhibit are not restatements; every 10-K/A of every firm was fetched and read). 8-K items and 10-K/A filings are attributed to the fiscal year in progress at the filing date using the firm's fiscal-year-end month.

### 3.7.3 Controls

LEV and ROA from XBRL values as first reported, bounded at fixed limits because near-zero denominators in shell companies otherwise produce values of ±2,000 that dominate any standardised model; the bounds are label-free and fixed in advance. Industry, size and year are controlled by the matching: in every within-set test a fraud firm is compared only with its own matched firms in the same window.

### 3.7.4 From the characteristics to the scores (design steps 1–5)

| Step | What is done | Result |
|---|---|---|
| 1 | Raw figures are coded for each firm-year | amounts with evidence, four disclosure items, word counts, board figures |
| 2 | The eight characteristics are calculated | the ratios of §3.3.2 |
| 3 | Each characteristic is ranked 0–1 against all analysed firm-years (average ranks for ties; a missing value stays missing) | characteristics on one scale, not driven by extreme firms |
| 4 | Ranks are averaged within each layer over the characteristics observed for that firm-year | L1_SCORE, L2_SCORE, L3_SCORE |
| 5 | The layer scores that exist are averaged and multiplied by ten | AI_SCORE, 0–10 |

Two rules the design left open are fixed here and recorded with every run: the *ranking population* is the analysed window firm-years (the five-year windows of the matched sets); firm-years outside the windows and the external set are not ranked (a sensitivity run ranks against every FY2004–2024 firm-year of the same firms). A layer with no observed characteristic has no score; AI_SCORE is the mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE. The traditional index is TRAD_INDEX = ICFR_MW + AUD_OPIN + AUD_CHG + RESTATE.

### 3.7.5 Measurement checks

**M1 coverage.** For each characteristic, the share of analysed firm-years in which it can be obtained from the filings, reported for all firm-years and separately for fraud and matched firm-years, with Fisher's exact test of whether coverage differs between the groups; a difference means the subset on which a layer is tested is selected on the outcome. No coverage threshold is applied by the assistant: the layer tests use complete cases and report n; the threshold is for the supervisors to agree. **M2 reliability.** Machine coding against human coding on the 10 % sample at a level agreed before the result is used. **M3 distinctness.** Pearson correlations between the three layer scores.

## 3.8 Stage 3 — Tests (blocks 13–17)

### 3.8.1 Conditional (fixed-effects) logit within matched sets

For matched set c with firm-years i, Pr(FRAUD_ic = 1) = Λ(α_c + β x_ic + γ LEV_ic + δ ROA_ic), where Λ is the logistic function, x is the layer score and α_c a set-specific intercept. The conditional likelihood eliminates α_c by conditioning on the number of fraud firm-years m_c in each set: L = Π_c [exp(Σ_{i∈F_c} β'x_i) ÷ Σ_{S⊂c, |S|=m_c} exp(Σ_{i∈S} β'x_i)], with F_c the fraud firm-years of set c. Only sets with both outcomes contribute. Predictors are winsorised at the 1st and 99th percentiles and standardised, so exp(β) is the odds ratio per standard deviation; 95 % intervals are exp(β ± 1.96 SE).

### 3.8.2 Firm-clustered standard errors

The design asks for standard errors clustered by firm, because the five years of one firm are not five independent observations. For the conditional logit the per-observation score is u_i = x_i (y_i − π_i), where π_i = Pr(y_i = 1 | the set's total m_c) is computed from the elementary symmetric polynomials of the set's weights w_i = exp(β'x_i). Firms are nested in sets, so the firm sums u_f = Σ_{i∈f} u_i give the sandwich V = H⁻¹ (Σ_f u_f u_f') H⁻¹ · G/(G−1), with H the negative Hessian and G the number of firms. Both the model-based and the firm-clustered errors are reported; the firm-clustered ones are the design's test. The same clustering is used in the pooled logit (§3.8.5).

### 3.8.3 Holm adjustment

H1, H2 and H3 are three tests of one idea, so Holm's step-down adjustment is applied: order the three p-values p_(1) ≤ p_(2) ≤ p_(3); the adjusted values are max of the running (3 − k + 1) p_(k), capped at 1. Unadjusted values are reported beside them. H2 is run twice, with all cases and without the disclosure-only cases, as the design specifies; a third run without firm-years whose text states that there were no transactions tests the coding convention of §3.7.1, and each characteristic is also tested on its own to show what carries each layer.

### 3.8.4 H4 — year by year

For each event year t ∈ {−5, …, −1} the conditional logit of §3.8.1 is run on that year's firm-years alone (the primary test), and a one-sided Mann–Whitney U test (fraud > matched) is reported as a supplement. The design rule is applied per layer: H4 is met for a layer when at least one year before the final year (t ≤ −2) is significant in the predicted direction. With fifteen tests and 7–21 informative sets each, the evidence is limited either way.

### 3.8.5 H5 — Model A against Model B; timing at an equal false-alarm rate

Model A: FRAUD = TRAD_INDEX + LEV + ROA. Model B: Model A + AI_SCORE. Each matched set is scored by a logit fitted on the other sets (leave-one-set-out), predictors standardised inside the fitting sets, and the area under the ROC curve (AUC = Pr(score of a random fraud firm-year > score of a random matched firm-year)) is computed on the pooled out-of-set probabilities; a set bootstrap (500 resamples of matched sets) gives an interval for the gain B − A. AI_SCORE's coefficient is reported from the pooled logit with firm-clustered errors and from the conditional logit. *Timing*: the traditional rule is TRAD_INDEX ≥ k with the smallest k whose matched-firm (false-alarm) rate is at most 5 %; the AI rule is AI_SCORE above the quantile of the matched firm-years that gives the *same* false-alarm rate (and, separately, the 5 % rate). For each case the first window year each rule flags is compared; the counts earlier / same / later / neither are reported. The union of the two rules is compared with each rule alone at the union's own false-alarm rate. H5 is supported when AI_SCORE is significant in Model B, Model B's out-of-set AUC exceeds Model A's with an interval excluding zero, and the AI rule is earlier than the traditional rule in more cases than the reverse.

### 3.8.6 P1

For each misstatement or misappropriation case, whether any window year states a lending, sales or purchases amount, cross-tabulated by form of fraud; disclosure-only cases are shown but are not part of P1. A pattern only; no test.

### 3.8.7 A1–A3 on the AI risk score

**A1 traceability.** Because AI_SCORE = 10 × mean of the available layer scores, layer k contributes 10 × L_k / n_layers and, within a layer, characteristic c contributes 10 × rank_c / (n_obs_k × n_layers). Each firm-year's score is therefore stated as shares by layer and by characteristic, and as named evidence ('mainly DUAL and RP_INCOMP'). **A2 stability.** The ranks are recomputed with each matched set left out in turn; the held-out firm-years are scored against the remaining firm-years' distributions and their shares recomputed; stability is the Spearman correlation of the two scores, the mean absolute change, and the share of firm-years whose largest layer and named evidence are unchanged. **A3 reading against theory.** Among the fraud firm-years the AI rule flags at the 5 % matched-firm rate, the largest contributing layer is counted, and the direction of each layer (fraud mean against matched mean) is stated so that a layer working against its prediction is named as such.

### 3.8.8 Power

Power is restated by simulation for the final number of matched sets (21, 30, 35, 40): five matched firms and five window years per firm, a firm random effect giving within-firm correlation 0.5, the case firm of each set drawn under the conditional-logit model with Pr(firm f is the case) ∝ exp(β Σ_t x_ft / √5), β = ln(OR) for OR ∈ {1.5, 1.65, 2.0}, and the test of §3.8.1–3.8.2 at 5 % in the predicted direction (300 replications).

## 3.9 Validation (block 18)

(i) The battery is run on the alternative samples (21 core cases; 30; 31 with Gulfport; 35 with the five three-report cases that have five rule-matched peers) and with the alternative ranking population, and the H1–H5 results are compared side by side; (ii) robustness cuts of the exploratory score (without the poorly matched sets; with and without related-party text; by era; by revelation-date confidence); (iii) the external set of ten never-seen cases scored once with the exploratory model; (iv) the revelation-date evidence pass; (v) the measurement checks M1–M3; (vi) a deviations log written with every run.

## 3.10 Exploratory methods (kept apart from the design tests)

A fitted alert score is built from the 36 measured features with adequate coverage — the design characteristics, the traditional signals, Big-4 status, general financial ratios, the disclosure-language measures of Appendix 3.C, the peer-relative z-scores and a stacked text model — with three model classes (L2 logistic regression, random forest, XGBoost) whose imputers and scalers are fitted inside each training fold, averaged into one probability. Validation is leave-one-matched-set-out (Figure 3.3) with a nested text model; the threshold is the smallest score at which the matched-firm false-positive rate is at most 5 %. Because the fitted score contains the traditional signals it cannot test H5; it is reported to show what a many-input model does, with its stress tests (T1 specificity, T2 ablation, T3 lead time, T4 material-weakness persistence, T5 matched-firm rate), mediation, SHAP attribution and the external validation. Definitions of the additional measures are in Appendix 3.C.

![Figure 3.3 — Leave-one-matched-set-out validation of the exploratory fitted score, with nested text stacking](thesis_figures/fig_validation_scheme.png)

## 3.11 Deviations from the design and pre-registration notes

1. **Role of AI.** The characteristics were coded by rule with evidence passages, not by a language model reading the filings; the human check M2 has not yet been done, so every result rests on rule-based coding.
2. **Sample.** 31 qualifying cases rather than 40; the disclosure-only cases are in the main sample as the design specifies (the first battery had kept them apart; that choice is withdrawn). Gulfport Energy was added on the researcher's approval of 10 October 2026 after its revelation date was established from its own filings.
3. **Thresholds.** No M1 coverage threshold is applied in the layer tests; the earlier ≥ 20 % / ≥ 50 % entry rules of the first battery were set after M1 was seen and are withdrawn. M2's threshold is for the supervisors.
4. **Ranking population and missing layers.** Fixed as stated in §3.7.4 (the design left them open).
5. **AUD_OPIN and RESTATE** are coded as the design defines them; no qualified, adverse or disclaimer opinion was found in the sample, so AUD_OPIN equals the going-concern flag in practice.
6. **Firm-clustered errors** are computed for the conditional logit by the sandwich of §3.8.2 (not available in the software's own implementation).
7. **Fitted score, text distance, abnormality and the stress tests** are exploratory; the first battery's recommendation to make the fitted score the headline is withdrawn.

## Appendix 3.A — Software and files

Python 3.14; pandas, numpy, scikit-learn, xgboost, statsmodels 0.15, scipy, shap, matplotlib, openpyxl. Dataset builder: `SEC-EDGAR-Downloader` (package `sec_rpt_dataset`, entry `run_pipeline.py`; `scripts/eightk_items.py`, `scripts/fetch_all_proxies.py`, `scripts/tenka_restatements.py`, `scripts/make_sensitivity_set.py`, `scripts/make_gulfport_set.py`). Modelling: `PrivateResearch` (package `rpt_panel`; `main.py` with steps build, model, stress, mediate, explain, report, infer; configurations `rpt_panel.full_all.json`, `rpt_panel.sens.json`, `rpt_panel.gulf.json`). Coders: `rpt_panel/rp_note_coder.py`, `rpt_panel/governance_coder.py`, `scripts/code_audit_opinions.py`. Design battery: `scripts/design_tests_v2.py`. M2: `scripts/make_m2_workbook.py`. Forty-two unit tests cover leakage, the known-answer path on a real filing, the coders, the mediation bootstrap, the T4 direction and the firm-clustered conditional logit.

## Appendix 3.C — Additional measures used only by the exploratory score

Relabeling ratio (euphemistic terms ÷ words); indeterminate ratio ('certain', 'various', 'from time to time' ÷ words); transparency (share of sentences stating counterparty, amount and term together); agency masking (share of clauses with the agent removed: agentless passives, nominalisations, existential constructions); passive ratio; Fog index 0.4 × (words per sentence + 100 × share of three-syllable words); year-on-year drift of vagueness and Fog; boilerplate similarity (TF-IDF cosine between the firm's related-party text in t and t−1); specificity gap (vagueness of the related-party text minus that of Item 1); earnings–cash divergence and accruals from XBRL, bounded; leave-one-out z-scores within each set-year; peer text distance (1 − cosine between the firm's TF-IDF vector and the centroid of its set-year peers, names and honorifics removed); and the stacked text risk (a bag-of-words logistic regression on the related-party text fitted in nested grouped folds, vocabulary restricted to terms used by at least three firms).

# Chapter 4 — Experimental set-up and results

## 4.1 Experimental set-up

| Element | Setting |
|---|---|
| Main sample | 31 RPT-fraud cases (21 misstatement/misappropriation, 10 disclosure-only including Gulfport Energy; all FRAUD = 1) and 145 matched firms in 31 sets; 862 window firm-years, 152 of them fraud firm-years (17.6%) |
| Alternative samples (§4.9) | 21 misstatement/misappropriation cases only; 30 (before Gulfport); 36 (+ five three-report cases, D3 relaxed, for information); 31 with ranks over all FY2004–2024 firm-years |
| Primary tests | conditional logit within matched sets with firm-clustered errors (H1–H4); leave-one-set-out logit AUC with set bootstrap (H5); direct arithmetic (A1–A3); 300-replication simulation (power) |
| Exploratory model | L2 logistic regression, random forest, XGBoost, mean-probability ensemble; leave-one-matched-set-out (21 folds on the core sample); nested 5-fold text stacking; 2,000 cluster-bootstrap resamples; threshold 0.702 (matched-firm rate ≤ 5 %) |
| External set | 10 three-report cases, 28 matched firms, 167 window firm-years, scored once with the exploratory model |
| Data | `data_core` (176 firms, 2,669 annual reports, FY2004–2024, including the merged Gulfport set), `data_sens` (38 firms); every 10-K/A of every firm read for restatement language |
| Hardware and time | 4-core workstation; core data build 3.5 h with two SEC workers; design battery about 10 minutes per sample; exploratory model about 3 h per configuration |

### 4.1.1 Development stage (pilot)

Before the confirmatory sample existed the pipeline was developed on five pilot anchors (Ault Alliance, ProPetro, Co-Diagnostics, Gulfport, Skechers) with hand-picked competitors. On the FY2004–2024 pilot build (24 firms, 4 usable sets, 107 window firm-years) the tree models reached out-of-fold AUC 0.68 with intervals spanning 0.36–0.95; the pilot established that the pipeline ran leak-free on real filings and that related-party amounts are rarely tagged in XBRL. It produced no thesis result.

## 4.2 Sample, coverage and the scores

### Table 4.1 — Firms and firm-years

| Group | Firms | Firm-years FY2004–2024 | Window firm-years |
|---|---|---|---|
| Misstatement / misappropriation cases | 21 | 272 | 102 |
| Disclosure-only cases (incl. Gulfport Energy) | 10 | 175 | 50 |
| Matched firms | 145 | 2,222 | 710 |
| External validation cases / matched firms | 10 / 28 | 549 | 30 / 137 |

### Table 4.2 — M1: coverage of the characteristics and traditional signals, by group

| characteristic | layer | all | fraud firm-years | matched firm-years | Fisher p | n_fraud_observed | n_matched_observed |
|---|---|---|---|---|---|---|---|
| RP_LEND | L1 | 0.118 | 0.276 | 0.085 | 0.0 | 42 | 60 |
| RP_PAY | L1 | 0.125 | 0.27 | 0.094 | 0.0 | 41 | 67 |
| RP_SALES | L1 | 0.077 | 0.099 | 0.072 | 0.244 | 15 | 51 |
| RP_PURCH | L1 | 0.158 | 0.158 | 0.158 | 1.0 | 24 | 112 |
| RP_INCOMP | L2 | 0.896 | 0.908 | 0.893 | 0.663 | 138 | 634 |
| RP_VAGUE | L2 | 0.893 | 0.908 | 0.89 | 0.664 | 138 | 632 |
| BRD_NONIND | L3 | 0.15 | 0.243 | 0.13 | 0.001 | 37 | 92 |
| DUAL | L3 | 0.552 | 0.599 | 0.542 | 0.21 | 91 | 385 |
| ICFR_MW (traditional signal) | TRAD | 0.918 | 0.822 | 0.938 |  | 125 | 666 |
| AUD_OPIN (traditional signal) | TRAD | 0.973 | 0.993 | 0.969 |  | 151 | 688 |
| AUD_CHG (traditional signal) | TRAD | 1.0 | 1.0 | 1.0 |  | 152 | 710 |
| RESTATE (traditional signal) | TRAD | 1.0 | 1.0 | 1.0 |  | 152 | 710 |

A related-party amount is stated in about 28 % of fraud firm-years and 9–10 % of matched firm-years for lending and payables (Fisher p < 0.001), and the board share in 25 % against 13 %. The financial layer and the board half of governance are therefore tested on subsets selected on the outcome: fraud firms state amounts more often. Sales and purchases, the disclosure characteristics and CEO duality do not differ in coverage.

### Table 4.3 — Source of the related-party text, by group (share of firm-years)

| fraud_aaer_label | none | rp_note | rpt_disclosure | n | share_stating_no_transactions |
|---|---|---|---|---|---|
| fraud firm-years | 0.092 | 0.553 | 0.355 | 152 | 0.059 |
| matched firm-years | 0.107 | 0.413 | 0.48 | 710 | 0.052 |

### Table 4.4 — Scoring rules recorded with the run

| rule | value |
|---|---|
| ranking population | the 862 analysed firm-years (five-year windows of the 31 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score |
| AI_SCORE with a missing layer | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 595, 1: 165, 2: 65, 3: 31, 4: 6} |
| firm-years with L2 from 0/1/2 characteristics | {0: 90, 1: 2, 2: 770} |
| firm-years with L3 from 0/1/2 characteristics | {0: 352, 1: 415, 2: 95} |
| firm-years with 1/2/3 layers in AI_SCORE | {0: 49, 1: 237, 2: 416, 3: 160} |
| AUD_OPIN definition | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |
| RESTATE definition | 8-K Item 4.02 or a 10-K/A that restates the financial statements |

### Table 4.5 — M3: correlations between the three layer scores

| index | L1_SCORE | L2_SCORE | L3_SCORE |
|---|---|---|---|
| L1_SCORE | 1.0 | -0.018 | -0.005 |
| L2_SCORE | -0.018 | 1.0 | -0.121 |
| L3_SCORE | -0.005 | -0.121 | 1.0 |

The layers are not near-duplicates (|r| ≤ 0.13); M3 is met.

### Table 4.6 — Coverage of every measured feature in the window (share of firm-years with a value)

| feature | available_all | available_cases | available_peers |
|---|---|---|---|
| rpt_to_revenue | 0.072 | 0.164 | 0.052 |
| rp_receivables_to_assets | 0.1 | 0.204 | 0.077 |
| rp_sales_ratio | 0.064 | 0.125 | 0.051 |
| abnormal_rp_sales | 0.044 | 0.079 | 0.037 |
| rp_lend_to_assets | 0.118 | 0.276 | 0.085 |
| rp_pay_to_assets | 0.125 | 0.27 | 0.094 |
| rp_sales_to_revenue | 0.077 | 0.099 | 0.072 |
| rp_purch_to_assets | 0.158 | 0.158 | 0.158 |
| earnings_cash_divergence | 0.887 | 0.895 | 0.886 |
| accruals | 0.831 | 0.842 | 0.828 |
| icfr_not_effective | 0.918 | 0.822 | 0.938 |
| material_weakness_reported | 0.918 | 0.822 | 0.938 |
| mw_count | 0.918 | 0.822 | 0.938 |
| mw_persistence_2yr | 0.863 | 0.737 | 0.89 |
| restatement_proxy | 0.0 | 0.0 | 0.0 |
| big4 | 0.841 | 0.789 | 0.852 |
| ceo_duality | 0.552 | 0.599 | 0.542 |
| board_indep | 0.15 | 0.243 | 0.13 |
| ac_indep | 0.375 | 0.487 | 0.351 |
| auditor_change | 0.783 | 0.717 | 0.797 |
| going_concern_opinion | 0.973 | 0.993 | 0.969 |
| restatement_8k | 1.0 | 1.0 | 1.0 |
| auditor_change_8k | 1.0 | 1.0 | 1.0 |
| rp_incomp | 0.896 | 0.908 | 0.893 |
| rpt_vagueness | 0.893 | 0.908 | 0.89 |
| rpt_relabeling | 0.893 | 0.908 | 0.89 |
| rpt_indeterminate_ratio | 0.893 | 0.908 | 0.89 |
| rpt_transparency | 0.893 | 0.908 | 0.89 |
| rpt_agency_masking | 0.893 | 0.908 | 0.89 |
| rpt_passive_ratio | 0.893 | 0.908 | 0.89 |
| rpt_fog | 0.893 | 0.908 | 0.89 |
| d_rpt_vagueness | 0.838 | 0.836 | 0.838 |
| d_rpt_fog | 0.838 | 0.836 | 0.838 |
| rpt_boilerplate_sim | 0.838 | 0.836 | 0.838 |
| spec_gap_vagueness | 0.827 | 0.789 | 0.835 |
| ln_assets | 0.903 | 0.901 | 0.903 |
| leverage | 0.741 | 0.783 | 0.732 |
| roa | 0.889 | 0.895 | 0.887 |
| listing_age | 1.0 | 1.0 | 1.0 |
| rpt_vagueness_z | 0.889 | 0.908 | 0.885 |
| rpt_agency_masking_z | 0.889 | 0.908 | 0.885 |
| rpt_fog_z | 0.889 | 0.908 | 0.885 |
| earnings_cash_divergence_z | 0.882 | 0.888 | 0.88 |
| accruals_z | 0.823 | 0.829 | 0.821 |
| rp_receivables_to_assets_z | 0.006 | 0.0 | 0.007 |
| rpt_to_revenue_z | 0.0 | 0.0 | 0.0 |
| rpt_peer_text_distance | 0.889 | 0.908 | 0.885 |

### Table 4.7 — Descriptive statistics over the window, case versus matched firm-years

| feature | group | n | mean | sd | median |
|---|---|---|---|---|---|
| rpt_to_revenue | case | 25 | 0.131 | 0.257 | 0.003 |
| rpt_to_revenue | peer | 37 | 0.173 | 0.303 | 0.013 |
| rp_receivables_to_assets | case | 31 | 0.039 | 0.126 | 0.002 |
| rp_receivables_to_assets | peer | 55 | 0.026 | 0.072 | 0.001 |
| rp_sales_ratio | case | 19 | 0.094 | 0.219 | 0.002 |
| rp_sales_ratio | peer | 36 | 0.163 | 0.309 | 0.007 |
| abnormal_rp_sales | case | 12 | -0.058 | 0.246 | 0.0 |
| abnormal_rp_sales | peer | 26 | -0.019 | 0.169 | -0.001 |
| rp_lend_to_assets | case | 42 | 0.068 | 0.148 | 0.009 |
| rp_lend_to_assets | peer | 60 | 0.13 | 0.289 | 0.006 |
| rp_pay_to_assets | case | 41 | 0.096 | 0.173 | 0.018 |
| rp_pay_to_assets | peer | 67 | 0.132 | 0.27 | 0.016 |
| rp_sales_to_revenue | case | 15 | 0.16 | 0.253 | 0.074 |
| rp_sales_to_revenue | peer | 51 | 0.104 | 0.265 | 0.007 |
| rp_purch_to_assets | case | 24 | 0.038 | 0.085 | 0.001 |
| rp_purch_to_assets | peer | 112 | 0.092 | 0.238 | 0.005 |
| earnings_cash_divergence | case | 136 | -0.115 | 0.243 | -0.049 |
| earnings_cash_divergence | peer | 629 | -0.099 | 0.222 | -0.055 |
| accruals | case | 128 | -0.102 | 0.303 | -0.06 |
| accruals | peer | 588 | -0.102 | 0.236 | -0.062 |
| icfr_not_effective | case | 125 | 0.224 | 0.419 | 0.0 |
| icfr_not_effective | peer | 666 | 0.096 | 0.295 | 0.0 |
| material_weakness_reported | case | 125 | 0.352 | 0.48 | 0.0 |
| material_weakness_reported | peer | 666 | 0.141 | 0.348 | 0.0 |
| mw_count | case | 125 | 1.816 | 3.383 | 0.0 |
| mw_count | peer | 666 | 0.809 | 2.363 | 0.0 |
| mw_persistence_2yr | case | 112 | 0.232 | 0.424 | 0.0 |
| mw_persistence_2yr | peer | 632 | 0.092 | 0.289 | 0.0 |
| restatement_proxy | case | 0 |  |  |  |
| restatement_proxy | peer | 0 |  |  |  |
| big4 | case | 120 | 0.325 | 0.47 | 0.0 |
| big4 | peer | 605 | 0.621 | 0.485 | 1.0 |
| ceo_duality | case | 91 | 0.681 | 0.469 | 1.0 |
| ceo_duality | peer | 385 | 0.494 | 0.501 | 0.0 |
| board_indep | case | 37 | 0.707 | 0.162 | 0.778 |
| board_indep | peer | 92 | 0.706 | 0.203 | 0.769 |
| ac_indep | case | 74 | 0.986 | 0.116 | 1.0 |
| ac_indep | peer | 249 | 1.0 | 0.0 | 1.0 |
| auditor_change | case | 109 | 0.165 | 0.373 | 0.0 |
| auditor_change | peer | 566 | 0.08 | 0.271 | 0.0 |
| going_concern_opinion | case | 151 | 0.06 | 0.238 | 0.0 |
| going_concern_opinion | peer | 688 | 0.061 | 0.24 | 0.0 |
| restatement_8k | case | 152 | 0.066 | 0.249 | 0.0 |
| restatement_8k | peer | 710 | 0.03 | 0.17 | 0.0 |
| auditor_change_8k | case | 152 | 0.197 | 0.399 | 0.0 |
| auditor_change_8k | peer | 710 | 0.086 | 0.28 | 0.0 |
| rp_incomp | case | 138 | 0.187 | 0.249 | 0.0 |
| rp_incomp | peer | 634 | 0.306 | 0.284 | 0.25 |
| rpt_vagueness | case | 138 | 0.267 | 0.135 | 0.242 |
| rpt_vagueness | peer | 632 | 0.252 | 0.129 | 0.234 |
| rpt_relabeling | case | 138 | 0.172 | 0.296 | 0.0 |
| rpt_relabeling | peer | 632 | 0.134 | 0.286 | 0.0 |
| rpt_indeterminate_ratio | case | 138 | 0.015 | 0.009 | 0.013 |
| rpt_indeterminate_ratio | peer | 632 | 0.019 | 0.01 | 0.018 |
| rpt_transparency | case | 138 | 0.271 | 0.24 | 0.267 |
| rpt_transparency | peer | 632 | 0.283 | 0.261 | 0.267 |
| rpt_agency_masking | case | 138 | 0.194 | 0.053 | 0.205 |
| rpt_agency_masking | peer | 632 | 0.206 | 0.048 | 0.208 |
| rpt_passive_ratio | case | 138 | 0.002 | 0.011 | 0.0 |
| rpt_passive_ratio | peer | 632 | 0.002 | 0.012 | 0.0 |
| rpt_fog | case | 138 | 22.321 | 4.439 | 21.19 |
| rpt_fog | peer | 632 | 25.384 | 5.632 | 24.595 |
| d_rpt_vagueness | case | 127 | -0.009 | 0.123 | 0.0 |
| d_rpt_vagueness | peer | 595 | -0.0 | 0.086 | 0.0 |
| d_rpt_fog | case | 127 | 0.309 | 3.994 | 0.0 |
| d_rpt_fog | peer | 595 | -0.114 | 3.218 | 0.0 |
| rpt_boilerplate_sim | case | 127 | 0.916 | 0.116 | 0.966 |
| rpt_boilerplate_sim | peer | 595 | 0.939 | 0.1 | 0.984 |
| spec_gap_vagueness | case | 120 | 0.053 | 0.156 | 0.032 |
| spec_gap_vagueness | peer | 593 | 0.057 | 0.151 | 0.042 |
| ln_assets | case | 137 | 19.631 | 2.741 | 19.578 |
| ln_assets | peer | 641 | 19.828 | 2.649 | 19.831 |
| leverage | case | 119 | 0.634 | 0.384 | 0.635 |
| leverage | peer | 520 | 0.629 | 0.417 | 0.586 |
| roa | case | 136 | -0.142 | 0.332 | 0.005 |
| roa | peer | 630 | -0.104 | 0.29 | 0.0 |
| listing_age | case | 152 | 7.211 | 4.731 | 6.0 |
| listing_age | peer | 710 | 8.027 | 4.83 | 7.0 |
| rpt_vagueness_z | case | 138 | -0.673 | 15.86 | 0.045 |
| rpt_vagueness_z | peer | 628 | 0.261 | 7.762 | -0.122 |
| rpt_agency_masking_z | case | 138 | -1.002 | 10.517 | -0.054 |
| rpt_agency_masking_z | peer | 628 | 0.209 | 3.756 | 0.076 |
| rpt_fog_z | case | 138 | -1.311 | 7.375 | -0.83 |
| rpt_fog_z | peer | 628 | 0.431 | 2.791 | 0.016 |
| earnings_cash_divergence_z | case | 135 | -0.085 | 3.334 | 0.332 |
| earnings_cash_divergence_z | peer | 625 | 100160.74 | 2504023.648 | 0.069 |
| accruals_z | case | 126 | -0.201 | 3.467 | 0.29 |
| accruals_z | peer | 583 | -0.333 | 5.443 | 0.056 |
| rp_receivables_to_assets_z | case | 0 |  |  |  |
| rp_receivables_to_assets_z | peer | 5 | 29.701 | 67.994 | -0.707 |
| rpt_to_revenue_z | case | 0 |  |  |  |
| rpt_to_revenue_z | peer | 0 |  |  |  |
| rpt_peer_text_distance | case | 138 | 0.873 | 0.047 | 0.88 |
| rpt_peer_text_distance | peer | 628 | 0.85 | 0.081 | 0.868 |

## 4.3 H1–H3: the three layers within matched sets

### Table 4.8 — H1–H3, conditional logit within matched sets (odds ratio per SD; model-based and firm-clustered; Holm across the three)

| hypothesis | layer_score | n (firm-years / firms / sets) | OR per SD [95 % CI] | p | p Holm | firm-clustered 95 % CI | p firm-cl. | p Holm firm-cl. | direction | supported (model-based) | supported (firm-clustered) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| H1 | L1_SCORE | 187 / 63 / 17 | 1.61 [1.04, 2.49] | 0.031 | 0.062 | [0.77, 3.38] | 0.206 | 0.459 | as predicted | no | no |
| H2 | L2_SCORE | 517 / 117 / 25 | 0.80 [0.63, 1.02] | 0.075 | 0.075 | [0.49, 1.31] | 0.374 | 0.459 | opposite | no | no |
| H3 | L3_SCORE | 284 / 71 / 18 | 1.70 [1.22, 2.37] | 0.002 | 0.006 | [0.82, 3.51] | 0.153 | 0.459 | as predicted | yes | no |

**H1.** The financial layer is higher in fraud firm-years (OR 1.61 per SD, 95 % CI 1.04–2.49) on the 187 firm-years of 63 firms in 17 sets that state an amount; p = 0.031 unadjusted, 0.062 Holm, 0.206 firm-clustered. By the design rule H1 is not supported with firm-clustered errors, and the subset is selected on the outcome (Table 4.2).
**H2.** The disclosure layer runs the *opposite* way: fraud firms' related-party text is more complete and plainer than their matched firms' (OR 0.80, 95 % CI 0.63–1.02; p = 0.075, Holm = 0.075, firm-clustered = 0.374). H2 is not supported.
**H3.** The governance layer is higher in fraud firm-years (OR 1.70, 95 % CI 1.22–2.37; p 0.002, Holm = 0.006; firm-clustered p = 0.153, Holm = 0.459). H3 is not supported with the firm-clustered errors the design asks for and supported with model-based errors. The layer is carried by CEO duality: board share is observed in 15 % of firm-years.

The firm-clustered errors are about twice the model-based ones because the layer scores change little within a firm across the five window years; the effective sample is closer to the number of firms than to the number of firm-years.

### Table 4.9 — H2 re-runs and the single characteristics

| hypothesis | variant | layer_score | n_firm_years | n_matched_sets | OR [95 % CI] | p | p firm-cl. |
|---|---|---|---|---|---|---|---|
| H2 | without disclosure-only cases (design re-run) | L2_SCORE | 338 | 17.0 | 0.72 [0.53, 0.99] | 0.042 | 0.270 |
| H2 | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE | 469 | 24.0 | 0.85 [0.66, 1.11] | 0.240 | 0.522 |
| H2 | all cases, firm-years with both disclosure characteristics observed (robustness) | L2_SCORE | 515 | 25.0 | 0.81 [0.63, 1.03] | 0.088 | 0.395 |
| H1 | single characteristic | RP_LEND | 58 | 8.0 | 0.96 [0.32, 2.85] | 0.942 | 0.962 |
| H1 | single characteristic | RP_PAY | 55 | 8.0 | 1.17 [0.56, 2.46] | 0.678 | 0.678 |
| H1 | single characteristic | RP_SALES | 0 |  | not estimable |  |  |
| H1 | single characteristic | RP_PURCH | 74 | 9.0 | 0.69 [0.26, 1.81] | 0.452 | 0.450 |
| H2 | single characteristic | RP_INCOMP | 517 | 25.0 | 0.75 [0.57, 0.99] | 0.039 | 0.346 |
| H2 | single characteristic | RP_VAGUE | 515 | 25.0 | 0.95 [0.75, 1.21] | 0.691 | 0.800 |
| H3 | single characteristic | BRD_NONIND | 54 | 6.0 | 3.38 [1.12, 10.20] | 0.031 | 0.376 |
| H3 | single characteristic | DUAL | 262 | 17.0 | 1.51 [1.08, 2.10] | 0.015 | 0.267 |

The design's second H2 run without the disclosure-only cases gives OR 0.72 (p = 0.042); dropping the firm-years whose text states that there were no related-party transactions gives OR 0.85 (p = 0.240), so part of the reversal is the coding convention of §3.7.1 and the rest is a null. Among the single characteristics, incompleteness carries the reversal (OR 0.75); vagueness is flat (OR 0.95); duality (OR 1.51) and board non-independence (OR 3.38, 6 sets) both point the predicted way; the four amounts, tested alone, are too sparse to estimate.

## 4.4 H4: the layers year by year

### Table 4.10 — Conditional logit per event year (primary) and Mann–Whitney (supplementary)

| event_year | layer_score | n_firm_years | n_matched_sets | mean_fraud | mean_matched | OR per SD | p | p firm-cl. | MW p |
|---|---|---|---|---|---|---|---|---|---|
| -5 | L1_SCORE | 21 | 7 | 0.547 | 0.564 | 1.006 | 0.99 | 0.99 | 0.524 |
| -5 | L2_SCORE | 98 | 22 | 0.458 | 0.524 | 0.67 | 0.154 | 0.222 | 0.933 |
| -5 | L3_SCORE | 43 | 13 | 0.565 | 0.492 | 1.566 | 0.375 | 0.447 | 0.092 |
| -4 | L1_SCORE | 22 | 7 | 0.526 | 0.483 | 26.08 | 0.092 | 0.522 | 0.335 |
| -4 | L2_SCORE | 89 | 20 | 0.446 | 0.507 | 0.72 | 0.224 | 0.212 | 0.916 |
| -4 | L3_SCORE | 49 | 15 | 0.568 | 0.499 | 1.367 | 0.415 | 0.393 | 0.115 |
| -3 | L1_SCORE | 25 | 9 | 0.46 | 0.451 | 2.38 | 0.207 | 0.245 | 0.504 |
| -3 | L2_SCORE | 95 | 22 | 0.481 | 0.506 | 1.027 | 0.916 | 0.916 | 0.704 |
| -3 | L3_SCORE | 58 | 17 | 0.634 | 0.49 | 1.816 | 0.088 | 0.091 | 0.005 |
| -2 | L1_SCORE | 29 | 9 | 0.522 | 0.427 | 5.473 | 0.075 | 0.225 | 0.084 |
| -2 | L2_SCORE | 95 | 22 | 0.436 | 0.506 | 0.715 | 0.231 | 0.314 | 0.937 |
| -2 | L3_SCORE | 55 | 16 | 0.567 | 0.477 | 1.566 | 0.205 | 0.216 | 0.117 |
| -1 | L1_SCORE | 24 | 7 | 0.499 | 0.472 | 1.217 | 0.751 | 0.76 | 0.355 |
| -1 | L2_SCORE | 85 | 21 | 0.448 | 0.515 | 0.879 | 0.64 | 0.697 | 0.929 |
| -1 | L3_SCORE | 42 | 14 | 0.518 | 0.459 | 1.561 | 0.327 | 0.429 | 0.077 |

| layer_score | design_rule_met_before_final_year | years_significant | tests_run |
|---|---|---|---|
| L1_SCORE | False |  | 5 |
| L2_SCORE | False |  | 5 |
| L3_SCORE | False |  | 5 |

By the design's rule (a significant year before the final year, conditional logit) H4 is met for: no layer. The governance layer is higher in fraud firms in every year with the closest result in year −3 (p = 0.088); the gap does not grow towards revelation, which is consistent with a stable difference between firms as much as with fraud emerging. The disclosure layer is lower in fraud firms in every year.

## 4.5 H5: do the layers add to the audit and internal-control signals?

### Table 4.11 — Model A against Model B with the design's AI risk score; timing at an equal false-alarm rate

| Quantity | Value |
|---|---|
| Model A (TRAD_INDEX + LEV + ROA), leave-one-set-out AUC | 0.448 |
| Model B (Model A + AI_SCORE), leave-one-set-out AUC | 0.519 |
| Gain B − A [set-bootstrap 95 % CI] | 0.071 [0.016, 0.123] |
| TRAD_INDEX alone / AI_SCORE alone (AUC, no fitting) | 0.603 / 0.528 |
| AI_SCORE in Model B, pooled logit, firm-clustered: coefficient per SD, OR 95 % CI, p | 0.167, 0.86-1.62, 0.296 |
| AI_SCORE in Model B, conditional logit: coefficient, p, p firm-clustered | 0.294, 0.024, 0.188 |
| AI rule at 5 % matched-firm rate: threshold, rate, cases flagged / never flagged | 7.92, 0.051, 2 / 29 of 31 |
| Traditional rule at ≤ 5 % rate | TRAD_INDEX >= 3 (rate 0.014); flags 3 cases |
| AI rule at the same rate: threshold, rate, cases flagged | 8.54, 0.014, 0 |
| Timing at equal rate: AI earlier / same year / traditional earlier / neither | 0 / 0 / 3 / 28 |
| Union of the rules: rate, cases; AI alone at that rate; traditional alone at that rate | 0.027, 3; 0; 3 |

| criterion | met |
|---|---|
| AI_SCORE significant in Model B (pooled, firm-clustered) | False |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) | True |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate) | False |

H5 is **not supported** for the design's AI risk score. Model B improves on Model A, but Model A performs below chance out of set and both are below the traditional index used on its own; AI_SCORE is not significant with firm-clustered errors; and at an equal false-alarm rate the AI rule flags 0 of 31 cases against 3 for the traditional rule. The union of the two rules does not flag more cases than the better single rule at the same false-alarm rate, so the claim that the two together do better than either alone is not shown.

### Table 4.12 — Lead time: the earliest window year in which the AI risk score separated the fraud firm from its matched firms (5 % rate), with the cases never flagged

| case | stratum | earliest_window_year_separated_from_matched_firms | ai_years_flagged_5pct | window_years |
|---|---|---|---|---|
| AMERICAN_ELECT | disclosure_only |  | 0 | 5 |
| AMERICAN_EQUIT | disclosure_only |  | 0 | 5 |
| AMMO_INC_OUTDO | core |  | 0 | 5 |
| AULT_ALLIANCE | core |  | 0 | 5 |
| CEMTREX | core |  | 0 | 5 |
| CHINA_VALVES_T | core |  | 0 | 5 |
| CORPORATE_RESO | core |  | 0 | 4 |
| CO_DIAGNOSTICS | core |  | 0 | 5 |
| EAGLE_BANCORP | core |  | 0 | 5 |
| ENERGY_XXI | disclosure_only |  | 0 | 5 |
| FAT_BRANDS | core |  | 0 | 5 |
| FIRST_BANCORP_ | disclosure_only |  | 0 | 5 |
| GENERAL_EMPLOY | core |  | 0 | 5 |
| GULFPORT_ENERG | disclosure_only |  | 0 | 5 |
| IDEANOMICS_SEV | core |  | 0 | 5 |
| MANITEX_INTERN | core |  | 0 | 5 |
| MAXIMUS | disclosure_only |  | 0 | 5 |
| MUSCLEPHARM | core | -4.0 | 2 | 4 |
| OCWEN_FINANCIA | core |  | 0 | 5 |
| PREMIER_HOLDIN | core |  | 0 | 5 |
| PROVECTUS_BIOP | core |  | 0 | 5 |
| PUDA_COAL | core |  | 0 | 4 |
| QUADRANT_4_SYS | core | -5.0 | 3 | 5 |
| RCI_HOSPITALIT | disclosure_only |  | 0 | 5 |
| SAEXPLORATION_ | core |  | 0 | 5 |
| SHIFT4_PAYMENT | disclosure_only |  | 0 | 5 |
| SINGULARITY_FU | core |  | 0 | 5 |
| SKECHERS_U_S_A | disclosure_only |  | 0 | 5 |
| THE_GREENBRIER | disclosure_only |  | 0 | 5 |
| UNITED_DEVELOP | core |  | 0 | 5 |
| VALEANT_PHARMA | core |  | 0 | 5 |

## 4.6 P1: related-party transaction types by form of fraud

### Table 4.13 — Cases with a stated amount of each type in any window year

| index | form_group | lending_sum | lending_count | sales_sum | sales_count | purchases_sum | purchases_count |
|---|---|---|---|---|---|---|---|
| 0 | both | 1 | 1 | 1 | 1 | 1 | 1 |
| 1 | corporate | 8 | 15 | 5 | 15 | 8 | 15 |
| 2 | disclosure-only (not in P1) | 4 | 10 | 1 | 10 | 3 | 10 |
| 3 | managerial | 3 | 5 | 1 | 5 | 1 | 5 |

Lending is the most frequent type in both forms; the predicted contrast (outward flows in managerial fraud, sales in corporate fraud) appears for sales only, and the groups are too small for a test. A pattern, as the design says.

## 4.7 A1–A3: attribution on the AI risk score

### Table 4.14 — A1: mean share of the AI risk score by layer and characteristic

| index | Unnamed: 0 | mean_share_all_firm_years | mean_share_fraud_firm_years | mean_share_flagged_fraud_firm_years |
|---|---|---|---|---|
| 0 | share_L1 | 0.124 | 0.165 | 0.0 |
| 1 | share_RP_LEND | 0.026 | 0.062 | 0.0 |
| 2 | share_RP_PAY | 0.035 | 0.057 | 0.0 |
| 3 | share_RP_SALES | 0.018 | 0.014 | 0.0 |
| 4 | share_RP_PURCH | 0.045 | 0.032 | 0.0 |
| 5 | share_L2 | 0.532 | 0.454 | 1.0 |
| 6 | share_RP_INCOMP | 0.276 | 0.2 | 0.51 |
| 7 | share_RP_VAGUE | 0.256 | 0.255 | 0.49 |
| 8 | share_L3 | 0.287 | 0.322 | 0.0 |
| 9 | share_BRD_NONIND | 0.048 | 0.069 | 0.0 |
| 10 | share_DUAL | 0.238 | 0.252 | 0.0 |

Every firm-year's score is stated as named evidence in `a1_attribution_by_firm_year.csv`; because amounts are rarely stated and board shares rarely observed, the disclosure layer carries about half of the average score and CEO duality most of the rest.

### Table 4.15 — A2: the division recalculated with each matched set left out in turn

| quantity | value |
|---|---|
| firm_years | 862 |
| spearman_ai_score_full_vs_loso | 0.9994508498846516 |
| mean_abs_ai_score_change | 0.0378095768358698 |
| median_max_abs_layer_share_change | 0.0015330605510697 |
| share_largest_layer_unchanged | 0.9895591647331786 |
| share_named_evidence_unchanged | 0.980278422273782 |
| method | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

The attributions are stable: the largest layer is unchanged in 99.0% of firm-years and the named evidence in 98.0%; ranks move by 0.038 points on average.

### Table 4.16 — A3: layers in the fraud firm-years the AI rule flags, with the direction of each layer

| layer | agency_idea | mean_fraud | mean_matched | direction | flagged_fraud_firm_years_where_largest | flagged_fraud_firm_years | flagged_cases |
|---|---|---|---|---|---|---|---|
| L1 | financial (conflict of interest) | 0.51 | 0.476 | fraud firms higher (as predicted) | 0 | 5 | 2 |
| L2 | disclosure (information asymmetry) | 0.454 | 0.511 | fraud firms LOWER (against the prediction) | 5 | 5 | 2 |
| L3 | governance (weak monitoring) | 0.572 | 0.483 | fraud firms higher (as predicted) | 0 | 5 | 2 |

Read against the three agency ideas: the monitoring idea is supported (governance higher in fraud firms), the conflict-of-interest idea is supported only on the disclosing subset, and the information-asymmetry idea is not supported by the disclosure measures as designed — the layer that contributes most to the flagged scores is the one that runs against its prediction. This is reported under the competing (efficient-transaction) prediction of the design.

## 4.8 Power for the final sample

### Table 4.17 — Simulated power of the within-set test (firm-clustered, one-sided at 5 %)

| matched_sets | odds_ratio_per_sd | power | reps | peers_per_set | years | firm_icc |
|---|---|---|---|---|---|---|
| 21.0 | 1.5 | 0.71 | 100.0 | 5.0 | 5.0 | 0.5 |
| 21.0 | 1.65 | 0.9 | 100.0 | 5.0 | 5.0 | 0.5 |
| 21.0 | 2.0 | 0.98 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 1.5 | 0.93 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 1.65 | 0.97 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 2.0 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 1.5 | 0.92 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 1.65 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 2.0 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |

The simulation assumes that every set contributes five matched firms and five years with the layer score observed throughout. The layer tests do not: the financial layer is observed in 16 sets and 184 firm-years, the governance layer in 17 sets and 270 firm-years, so their power is nearer the 21-set rows than the 30-set rows, and lower still where firm-years are missing. Non-significant results — H1 with firm-clustered errors, H5, the disclosure layer in H4 — are therefore weak evidence of no difference, and the H1 and H3 intervals are wide for the same reason.

## 4.9 Sensitivity to the sample and to the ranking population

### Table 4.18 — The battery on the alternative samples

| sample | sets | H1 OR (p / firm-cl.) | H2 OR (p / firm-cl.) | H3 OR (p / firm-cl.) | H4 rule met | H5 AUC A / B / TRAD | AI flags (5 %) / cases | timing AI earlier / trad earlier |
|---|---|---|---|---|---|---|---|---|
| 21 misstatement/misappropriation cases only | 21 | 1.98 (0.007 / 0.097) | 0.73 (0.044 / 0.273) | 4.26 (< 0.001 / 0.046) | L3_SCORE | 0.48 / 0.56 / 0.64 | 1 / 21 | 0 / 3 |
| 30 cases (before Gulfport) | 30 | 1.54 (0.055 / 0.266) | 0.77 (0.045 / 0.318) | 2.10 (< 0.001 / 0.077) | none | 0.46 / 0.54 / 0.61 | 2 / 30 | 0 / 3 |
| 31 cases (main sample) | 31 | 1.61 (0.031 / 0.206) | 0.80 (0.075 / 0.374) | 1.70 (0.002 / 0.153) | none | 0.45 / 0.52 / 0.60 | 2 / 31 | 0 / 3 |
| 36 cases (+ five three-report cases, D3 relaxed) | 36 | 1.47 (0.054 / 0.223) | 0.83 (0.109 / 0.417) | 1.71 (0.002 / 0.151) | none | 0.49 / 0.51 / 0.59 | 3 / 36 | 1 / 3 |
| 31 cases, ranks over all years | 31 | 1.60 (0.036 / 0.234) | 0.80 (0.070 / 0.367) | 1.77 (0.001 / 0.140) | none | 0.45 / 0.52 / 0.60 | 2 / 31 | 0 / 3 |

The direction of every layer is the same in every sample. The governance odds ratio halves when the nine disclosure-only cases are added to the 21 (their boards differ less from their matched firms' than those of the misstatement and misappropriation cases), and the financial odds ratio falls from about 2.0 to 1.5; the ranking population makes no material difference. The disclosure layer is reversed throughout, and the AI risk score does not add to the traditional index in any sample. Gulfport (now in the main sample) and the five three-report cases change nothing of substance.

## 4.10 Exploratory results (kept apart from the design tests)

Everything in this section uses the fitted 36-input score (which contains the traditional signals) or measures found after the data were seen. It shows what a many-input model does; it does not test H5 and does not change the readings above.

With the fitted ensemble trained on the 30 sets before Gulfport (Gulfport's firm-years unscored), it reaches leave-one-set-out AUC 0.66; Model A plus the fitted score reaches 0.57 against 0.47 for Model A; at its 5 % threshold it flags 7 of 30 cases and never flags 24.

### Table 4.19 — Out-of-fold discrimination of the exploratory score, 21 core cases

| model | n_features | n_rows | n_pos | n_clusters | oof_auc | oof_auc_ci_low | oof_auc_ci_high | oof_pr_auc | fold_auc_mean |
|---|---|---|---|---|---|---|---|---|---|
| logit | 36 | 577 | 102 | 21 | 0.727 | 0.632 | 0.815 | 0.362 | 0.735 |
| text_tfidf_only | 1 | 507 | 94 | 21 | 0.67 | 0.563 | 0.765 | 0.26 |  |
| rf | 36 | 577 | 102 | 21 | 0.73 | 0.626 | 0.83 | 0.304 | 0.738 |
| xgb | 36 | 577 | 102 | 21 | 0.705 | 0.602 | 0.797 | 0.301 | 0.683 |
| ensemble | 36 | 577 | 102 | 21 | 0.734 | 0.632 | 0.828 | 0.326 |  |

![Figure 4.1 — Leave-one-matched-set-out ROC curves of the exploratory score](../outputs/full/figures/fig_oof_roc.png)

![Figure 4.2 — Calibration of the exploratory score](../outputs/full/figures/fig_calibration.png)

### Table 4.20 — Per-set detection by the exploratory score (threshold 0.702; 9 of 21 cases flagged, 12 never flagged)

| case_id | within-set AUC | case_mean | peer_mean | case_max | flag_years | first_flag_fy | case_window_years | peer_window_rows |
|---|---|---|---|---|---|---|---|---|
| AMMO_INC_OUTDO | 0.917 | 0.437 | 0.177 | 0.676 | 0 |  | 5 | 24 |
| AULT_ALLIANCE | 0.96 | 0.506 | 0.177 | 0.636 | 0 |  | 5 | 25 |
| CEMTREX | 0.442 | 0.361 | 0.42 | 0.508 | 0 |  | 5 | 24 |
| CHINA_VALVES_T | 0.944 | 0.657 | 0.362 | 0.763 | 2 | 2007.0 | 5 | 18 |
| CORPORATE_RESO | 1.0 | 0.751 | 0.203 | 0.872 | 3 | 2011.0 | 4 | 25 |
| CO_DIAGNOSTICS | 0.9 | 0.553 | 0.228 | 0.789 | 1 | 2020.0 | 5 | 24 |
| EAGLE_BANCORP | 1.0 | 0.477 | 0.154 | 0.582 | 0 |  | 5 | 25 |
| FAT_BRANDS | 0.96 | 0.657 | 0.158 | 0.78 | 2 | 2019.0 | 5 | 25 |
| GENERAL_EMPLOY | 0.768 | 0.54 | 0.315 | 0.847 | 2 | 2013.0 | 5 | 25 |
| IDEANOMICS_SEV | 0.617 | 0.472 | 0.351 | 0.741 | 2 | 2013.0 | 5 | 24 |
| MANITEX_INTERN | 0.792 | 0.385 | 0.22 | 0.526 | 0 |  | 5 | 24 |
| MUSCLEPHARM | 0.625 | 0.546 | 0.465 | 0.594 | 0 |  | 4 | 14 |
| OCWEN_FINANCIA | 0.2 | 0.118 | 0.445 | 0.186 | 0 |  | 5 | 15 |
| PREMIER_HOLDIN | 0.44 | 0.346 | 0.389 | 0.474 | 0 |  | 5 | 25 |
| PROVECTUS_BIOP | 0.672 | 0.445 | 0.311 | 0.78 | 1 | 2011.0 | 5 | 25 |
| PUDA_COAL | 0.733 | 0.398 | 0.3 | 0.438 | 0 |  | 4 | 15 |
| QUADRANT_4_SYS | 0.416 | 0.175 | 0.262 | 0.261 | 0 |  | 5 | 25 |
| SAEXPLORATION_ | 0.5 | 0.319 | 0.332 | 0.578 | 0 |  | 5 | 24 |
| SINGULARITY_FU | 0.99 | 0.614 | 0.199 | 0.786 | 1 | 2021.0 | 5 | 20 |
| UNITED_DEVELOP | 0.692 | 0.261 | 0.21 | 0.41 | 0 |  | 5 | 24 |
| VALEANT_PHARMA | 0.744 | 0.374 | 0.188 | 0.716 | 1 | 2011.0 | 5 | 25 |

![Figure 4.3 — Out-of-fold scores by year before revelation](../outputs/full/figures/fig_scores_event_time.png)

### Table 4.21 — Across strata (model trained on all 30 sets)

| stratum | model | n_rows | n_pos | n_clusters | oof_auc | oof_auc_ci_low | oof_auc_ci_high |
|---|---|---|---|---|---|---|---|
| core | logit | 577 | 102 | 21 | 0.692 | 0.615 | 0.767 |
| core | rf | 577 | 102 | 21 | 0.712 | 0.622 | 0.803 |
| core | xgb | 577 | 102 | 21 | 0.7 | 0.609 | 0.779 |
| core | ensemble | 577 | 102 | 21 | 0.716 | 0.637 | 0.788 |
| disclosure_only | logit | 256 | 45 | 9 | 0.55 | 0.382 | 0.687 |
| disclosure_only | rf | 256 | 45 | 9 | 0.48 | 0.367 | 0.628 |
| disclosure_only | xgb | 256 | 45 | 9 | 0.489 | 0.355 | 0.626 |
| disclosure_only | ensemble | 256 | 45 | 9 | 0.521 | 0.368 | 0.672 |

### Table 4.22 — Stress tests T1–T5 of the exploratory score

| test | headline | value | p_holm |
|---|---|---|---|
| T1 specificity (H4) | case-minus-peer gap in RPT vs Item 1 vagueness | 0.255 | 0.255 |
| T2 ablation (H2) | AUC change when the disclosure layer is removed | 0.025 |  |
| T3 lead time (H3) | median months from first OOF alert to revelation | 46.0 |  |
| T4 MW persistence | case vs peer persistence rate (Fisher p) | 0.0 | 0.0 |
| T5 clean-firm FPR | FPR at threshold 0.702 | 0.048 |  |

### Table 4.23 — T3: first out-of-fold flag per case (exploratory score)

| cluster_id | window_years | scored_years | flagged_years | first_flag_fiscal_year | revelation_date | lead_time_months | max_oof_score |
|---|---|---|---|---|---|---|---|
| GENERAL_EMPLOY | 5 | 5 | 2 | 2013.0 | 2015-04-30 | 19.0 | 0.8 |
| PROVECTUS_BIOP | 5 | 5 | 1 | 2011.0 | 2016-02-29 | 50.0 | 0.8 |
| IDEANOMICS_SEV | 5 | 5 | 2 | 2013.0 | 2018-08-28 | 56.0 | 0.7 |
| OCWEN_FINANCIA | 5 | 5 | 0 |  | 2014-08-18 |  | 0.2 |
| QUADRANT_4_SYS | 5 | 5 | 0 |  | 2016-09-23 |  | 0.3 |
| VALEANT_PHARMA | 5 | 5 | 1 | 2011.0 | 2015-10-21 | 46.0 | 0.7 |
| AULT_ALLIANCE | 5 | 5 | 0 |  | 2023-04-14 |  | 0.6 |
| CORPORATE_RESO | 4 | 4 | 3 | 2011.0 | 2015-02-10 | 41.0 | 0.9 |
| AMMO_INC_OUTDO | 5 | 5 | 0 |  | 2024-07-29 |  | 0.7 |
| PREMIER_HOLDIN | 5 | 5 | 0 |  | 2017-12-04 |  | 0.5 |
| EAGLE_BANCORP | 5 | 5 | 0 |  | 2017-12-01 |  | 0.6 |
| CHINA_VALVES_T | 5 | 5 | 2 | 2007.0 | 2012-02-28 | 50.0 | 0.8 |
| PUDA_COAL | 4 | 4 | 0 |  | 2011-04-08 |  | 0.4 |
| MANITEX_INTERN | 5 | 5 | 0 |  | 2018-04-03 |  | 0.5 |
| MUSCLEPHARM | 4 | 4 | 0 |  | 2012-05-14 |  | 0.6 |
| SINGULARITY_FU | 5 | 5 | 1 | 2021.0 | 2023-03-06 | 21.0 | 0.8 |
| CEMTREX | 5 | 5 | 0 |  | 2017-02-22 |  | 0.5 |
| UNITED_DEVELOP | 5 | 5 | 0 |  | 2015-12-10 |  | 0.4 |
| SAEXPLORATION_ | 5 | 5 | 0 |  | 2019-08-15 |  | 0.6 |
| CO_DIAGNOSTICS | 5 | 5 | 1 | 2020.0 | 2023-07-05 | 31.0 | 0.8 |
| FAT_BRANDS | 5 | 5 | 2 | 2019.0 | 2024-05-10 | 53.0 | 0.8 |

### Table 4.24 — Mediation (P4), cluster bootstrap

| x | mediator | n | n_clusters | a | b | c_prime | indirect | se_boot | ci_low | ci_high | status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| earnings_cash_divergence | rpt_vagueness | 452 | 108 | -0.0217 | 0.187 | -0.0298 | -0.0041 | 0.0161 | -0.0446 | 0.024 | ok |
| earnings_cash_divergence | rpt_agency_masking | 452 | 108 | 0.0527 | -0.1487 | -0.0292 | -0.0078 | 0.0156 | -0.0475 | 0.0156 | ok |
| rpt_to_revenue | rpt_vagueness | 34 | 17 | -0.1882 | -0.5444 | -0.1845 | 0.1024 | 0.2904 | -0.2893 | 0.5704 | ok |
| rpt_to_revenue | rpt_agency_masking | 34 | 17 | -0.032 | 0.2782 | -0.0871 | -0.0089 | 0.4294 | -1.2418 | 0.4043 | ok |
| material_weakness_reported | rpt_vagueness | 434 | 107 | -0.0578 | 0.2454 | 0.5884 | -0.0142 | 0.0253 | -0.0652 | 0.0435 | ok |
| material_weakness_reported | rpt_agency_masking | 434 | 107 | -0.0582 | -0.154 | 0.5589 | 0.009 | 0.0236 | -0.0193 | 0.0757 | ok |

### Table 4.25 — SHAP attribution of the exploratory score (top 15 per model)

| model | feature | mean_abs_shap | rank |
|---|---|---|---|
| logit | earnings_cash_divergence_z | 3733.8846 | 1 |
| logit | rp_incomp | 0.818 | 2 |
| logit | big4 | 0.6323 | 3 |
| logit | listing_age | 0.558 | 4 |
| logit | rpt_fog_z | 0.5116 | 5 |
| logit | ln_assets | 0.4824 | 6 |
| logit | rpt_peer_text_distance | 0.435 | 7 |
| logit | rpt_fog | 0.4275 | 8 |
| logit | spec_gap_vagueness | 0.3093 | 9 |
| logit | rpt_vagueness | 0.2702 | 10 |
| logit | text_risk | 0.2188 | 11 |
| logit | ceo_duality | 0.2167 | 12 |
| logit | roa | 0.2156 | 13 |
| logit | d_rpt_fog | 0.1972 | 14 |
| logit | mw_persistence_2yr | 0.1942 | 15 |
| rf | rpt_fog_z | 0.0706 | 1 |
| rf | rpt_fog | 0.0448 | 2 |
| rf | listing_age | 0.0256 | 3 |
| rf | text_risk | 0.0237 | 4 |
| rf | rp_incomp | 0.0233 | 5 |
| rf | big4 | 0.0227 | 6 |
| rf | rpt_indeterminate_ratio | 0.0138 | 7 |
| rf | rpt_peer_text_distance | 0.0124 | 8 |
| rf | leverage | 0.0097 | 9 |
| rf | ln_assets | 0.009 | 10 |
| rf | ceo_duality | 0.0089 | 11 |
| rf | rpt_relabeling | 0.0085 | 12 |
| rf | accruals_z | 0.0078 | 13 |
| rf | rpt_boilerplate_sim | 0.0075 | 14 |
| rf | material_weakness_reported | 0.0071 | 15 |
| xgb | rpt_fog_z | 1.0094 | 1 |
| xgb | listing_age | 0.6763 | 2 |
| xgb | spec_gap_vagueness | 0.4499 | 3 |
| xgb | rpt_peer_text_distance | 0.3867 | 4 |
| xgb | rp_incomp | 0.3359 | 5 |
| xgb | big4 | 0.2998 | 6 |
| xgb | ln_assets | 0.2976 | 7 |
| xgb | rpt_relabeling | 0.2894 | 8 |
| xgb | leverage | 0.272 | 9 |
| xgb | text_risk | 0.2292 | 10 |
| xgb | accruals_z | 0.2091 | 11 |
| xgb | rpt_fog | 0.2065 | 12 |
| xgb | rpt_agency_masking | 0.198 | 13 |
| xgb | earnings_cash_divergence_z | 0.1891 | 14 |
| xgb | rpt_vagueness_z | 0.1889 | 15 |

![Figure 4.4 — SHAP summary](../outputs/full/explainability/fig_shap_summary.png)

### Table 4.26 — Stability of the SHAP ranking (Spearman)

| comparison | a | b | n_features | spearman_rho | rho_ci_low | rho_ci_high | n_resamples |
|---|---|---|---|---|---|---|---|
| across_models | logit | rf | 36 | 0.471 |  |  |  |
| across_models | logit | xgb | 36 | 0.594 |  |  |  |
| across_models | rf | xgb | 36 | 0.818 |  |  |  |
| bootstrap_within_model | logit | logit | 36 | 0.938 | 0.831 | 0.998 | 200.0 |
| bootstrap_within_model | rf | rf | 36 | 0.996 | 0.991 | 0.999 | 200.0 |
| bootstrap_within_model | xgb | xgb | 36 | 0.998 | 0.995 | 0.999 | 200.0 |

Traceability of the exploratory attributions: 95.9% of top-3 contributions resolve to a located source.

### Table 4.27 — External validation of the exploratory score on ten never-seen three-report cases

| quantity | value |
|---|---|
| label | sensitivity set (three-report cases) |
| model | outputs/full/models/rpt_panel_ensemble.pkl |
| threshold | 0.7022091372237802 |
| cases | 10 |
| window_rows | 167 |
| positives | 30 |
| peer_rows | 137 |
| auc | 0.73 |
| peer_fpr | 0.058 |
| case_year_recall | 0.033 |
| cases_flagged | 1 |
| cases_without_peers | 2 |

## 4.11 Summary of findings against the design

| Item | Finding on the 31-case main sample |
|---|---|
| M1 coverage | disclosure characteristics and CEO duality 54–89 %; amounts 8–16 % and board share 15 %, and stated about three times as often in fraud firm-years (selection on the outcome) |
| M2 reliability | workbook delivered; human coding and threshold pending |
| M3 distinctness | met (|r| ≤ 0.13) |
| H1 financial exposure | OR 1.61 per SD on the disclosing subset; not supported with firm-clustered errors |
| H2 disclosure | not supported; opposite direction (OR 0.80); part of it a coding convention |
| H3 governance | OR 1.70 per SD, carried by CEO duality; supported with model-based errors only (firm-clustered p = 0.153) |
| H4 earlier years | design rule met for: no layer; governance closest (year −3) |
| H5 added value | not supported for the design's AI risk score (strength or timing) |
| P1 forms of fraud | pattern only; contrast for sales only |
| A1–A3 | every score traceable to named evidence; stable under leave-one-set-out; the dominant layer runs against its prediction |
| Exploratory fitted score | AUC 0.73 [0.63, 0.83] on 21 cores, external 0.73; contains the benchmark, so not a test of H5 |


## Appendix 3.B — Glossary of terms, statistics and notation

| Term | Meaning in this study |
|---|---|
| Related party transaction (RPT) | A transaction between the reporting firm and a party that controls it, is controlled by it, or is one of its directors, officers, principal shareholders or their close family or affiliated entities (ASC 850; Regulation S-K Item 404). |
| AAER | SEC Accounting and Auditing Enforcement Release: the SEC's publication of an enforcement action involving accounting or auditing matters. |
| Litigation release (LR) | The SEC's publication of a civil court action; many RPT fraud cases appear here without an AAER. |
| Case firm / matched firm | A firm named in an RPT-related enforcement action / a firm from the same industry and size band with no enforcement, selected by rule D4. |
| Matched set (cluster) | One case firm and its matched firms; the unit of resampling and of cross-validation. |
| Firm-year | One annual report of one firm; the unit of analysis. |
| Event time | Fiscal year minus the revelation year; the window is event time −5 to −1. |
| Revelation date | First public event revealing the problem (8-K non-reliance, investigation, auditor resignation, short report, restatement or SEC action). |
| Primary filing | The first original annual report filed for a firm-year (amendments and duplicates are excluded). |
| Compustat fiscal-year rule | A fiscal year ending in January–May is assigned to the previous calendar year. |
| CIK | The SEC's Central Index Key, the firm identifier used throughout. |
| SIC | Standard Industrial Classification code (four digits); matching falls back to three and two digits. |
| XBRL company facts | Machine-readable financial statement values filed with the SEC (FY2009+); values are taken as first reported. |
| XBRL frames | Cross-sectional XBRL values (here total assets) for all registrants in a period; used for the matching universe. |
| Item 1 / 9A / 13 | Sections of Form 10-K: Business; Controls and Procedures (internal control over financial reporting); Certain Relationships and Related Transactions. |
| DEF 14A | The definitive proxy statement, which contains board, committee and related-person disclosures. |
| 8-K Item 4.01 / 4.02 | Current-report items for a change in the certifying accountant and for non-reliance on previously issued financial statements (restatement). |
| ICFR / material weakness | Internal control over financial reporting; a material weakness is a deficiency that creates a reasonable possibility of a material misstatement. |
| Big-4 | Deloitte, EY, KPMG, PwC. |
| Going-concern paragraph | Audit-report language raising substantial doubt about the firm's ability to continue as a going concern. |
| Vagueness ratio (V) | Share of words from the uncertainty and weak-modal word lists in the related-party text. |
| Agency masking (A) | Share of clauses whose agent is removed or backgrounded (agentless passive, nominalisation, existential), from a systemic-functional-linguistics analyser. |
| Fog index (F) | Gunning Fog readability: 0.4 × (average sentence length + 100 × share of words with three or more syllables). |
| Relabeling / indeterminate / transparency ratios | Lexicon measures of euphemistic terms, indeterminate quantifiers and fully specified sentences in the related-party text. |
| Drift (ΔV, ΔF) | Year-on-year change of a disclosure measure within the firm. |
| Boilerplate similarity | TF-IDF cosine similarity of the firm's related-party text with its own text a year earlier. |
| Specificity gap | V(related-party text) − V(Item 1) of the same filing. |
| Peer-relative z-score | (x_i − mean of the other firms in the cluster-year) ÷ their standard deviation, leave-one-out, label-free. |
| Peer text distance | 1 − cosine similarity between the firm's TF-IDF vector and the centroid of its cluster-year peers' vectors. |
| TF-IDF | Term frequency × inverse document frequency weighting of words and word pairs. |
| Text risk (stacked) | Out-of-fold probability from a TF-IDF logistic regression on the related-party text, fitted in nested grouped folds with a vocabulary limited to terms used by ≥ 3 firms. |
| Rank-average score | Each characteristic ranked to [0, 1] over all firm-years; layer score = mean of ranks; AI_SCORE = 10 × mean of layer scores (design document, steps 3–5). |
| TRAD_INDEX | Count of the four traditional signals (material weakness, going concern, auditor change, restatement), 0–4. |
| Logistic regression (logit) | Pr(y = 1) = 1 / (1 + exp(−x'β)); coefficients are log-odds; exp(β) is an odds ratio. |
| Conditional (fixed-effects) logit | Logit with a separate intercept per matched set, estimated by conditioning on the number of positives in each set so the intercepts drop out; only sets with both outcomes contribute. |
| Cluster-robust (sandwich) standard errors | Standard errors that allow arbitrary correlation of observations within a firm. |
| Winsorising | Replacing values beyond the 1st/99th percentile with those percentiles. |
| Standardised coefficient / odds ratio per SD | Effect of a one-standard-deviation increase of the predictor. |
| Holm adjustment | Step-down correction for multiple tests: the smallest p is compared with α/m, the next with α/(m−1), and so on. |
| Mann–Whitney U test | Non-parametric test of whether one group's values tend to exceed the other's; one-sided here. |
| Wilcoxon signed-rank test | Non-parametric paired test, used for within-filing differences (RPT text versus Item 1). |
| Fisher's exact test | Exact test of association in a 2×2 table; one-sided here. |
| Random forest | Average of many decision trees fitted on bootstrap samples with random feature subsets. |
| XGBoost | Gradient-boosted decision trees fitted stage-wise to the gradient of the logistic loss. |
| Ensemble (alert score) | Mean of the three models' predicted probabilities. |
| Leave-one-cluster-out (LOGO) | Cross-validation that holds out one matched set at a time. |
| Nested folds | Inner cross-validation inside each training fold, used so the stacked text score never comes from a model that saw the row it scores. |
| Out-of-fold (OOF) | Scores and SHAP values computed for rows by models that did not see them. |
| AUC | Area under the ROC curve = probability that a random positive scores above a random negative. |
| PR-AUC | Area under the precision–recall curve. |
| Cluster bootstrap | Resampling matched sets (or firms) with replacement to obtain percentile confidence intervals. |
| Threshold at 5 % FPR | The score above which at most 5 % of matched firm-years fall; fixed on out-of-fold scores. |
| Lead time | Months from the end of the first flagged fiscal year to the revelation date. |
| SHAP value | Shapley-value decomposition of a prediction into additive feature contributions. |
| Attribution stability | Spearman rank correlation of feature-importance rankings across models and across bootstrap resamples. |
| Traceability | Share of top-3 attributions that resolve to a located filing passage, signature, 8-K, XBRL tag or manifest entry. |
| Mediation (a, b, indirect) | a = effect of x on the mediator; b = effect of the mediator on the outcome given x; indirect = a × b; c′ = direct effect. |
| M1 / M2 / M3 | Measurement checks: coverage; reliability against human coding on a 10 % sample; distinctness of the layer scores. |
| A1 / A2 / A3 | Attribution checks: traceability; stability; reading of the dominant layer against theory. |
| Core / disclosure-only stratum | Cases where the RPT is the mechanism of misstatement or misappropriation / cases charged only for a disclosure failure. |
| External validation set | Ten three-report cases and their matched firms, never used in fitting. |
| Run 1 / 2 / 3 | Successive full runs: unbounded ratios; bounded ratios; bounded ratios plus coded characteristics, 8-K signals and every-year governance (final). |


| Firm-clustered standard error | A standard error that treats all observations of one firm as one cluster, computed from the sandwich of per-observation scores summed within firms. |
| Elementary symmetric polynomial | e_m(w) = the sum over all subsets of size m of the product of the w's; the denominator of the conditional logit likelihood for a set with m cases. |
| Set bootstrap | Resampling whole matched sets with replacement to obtain an interval that reflects variation across sets. |
| False-alarm rate | The share of matched firm-years a rule flags; used to put two rules on an equal footing before comparing timing. |
