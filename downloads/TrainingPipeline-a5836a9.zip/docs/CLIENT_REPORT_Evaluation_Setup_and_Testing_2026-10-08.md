# RPT fraud-risk study — evaluation set-up and test results

Prepared for the research design of 6 October 2026 ("Research design: question, objectives, hypotheses, variables and theoretical foundation"). Date of this report: 9 October 2026 (supersedes the 8 October version). Every number is taken from the run outputs listed in Appendix C; nothing is typed in by hand.

## 1. What was done

The design asked for a matched case-control study: US listed firms named in SEC enforcement actions in which a related party transaction (RPT) is central, each compared with five firms of the same industry and size over the five fiscal years before the fraud became public. This report covers what was built, which firms were tested, how the design's checks and hypotheses were run, and what the results say.

1. **Sample.** Every SEC Accounting and Auditing Enforcement Release 2005–2024, every SEC litigation release 2010–2025 and issuers' own filings were screened for RPT cases. Thirty cases met the design's rules (21 with an RPT misstatement or misappropriation, 9 where the charge is a disclosure failure only); 140 matched firms were drawn from the EDGAR universe of their industries by rule. A further 10 cases with three (not four) annual reports before revelation were built, with 28 matched firms, as an external validation set. The design's target of 40 core cases does not exist in the record under its own inclusion rules.
2. **Data.** 2,585 annual reports (10-K) for 170 firms, FY2004–2024, were downloaded from SEC EDGAR with a proxy statement for every filing year (85 % linked), XBRL financial data and the 8-K filings that report auditor changes (Item 4.01) and restatements (Item 4.02). Related-party notes and sections, Item 9A text, audit reports and board statements were extracted; the design's eight characteristics were coded from them by rule with the evidence passage kept for every value.
3. **Tests.** The design's measurement checks (M1, M3), hypotheses (H1–H5), descriptive proposition (P1) and attribution checks (A1–A3) were run as specified, with firm-level matching, leave-one-matched-set-out validation and significance levels adjusted for multiple tests. A fitted (machine-learning) version of the risk score was validated the same way, tested on the external set, and put through five forensic stress tests. The results below are from the third and final run of the pipeline; the first two runs (archived) differ by at most 0.02 on every headline.

## 2. Firms tested

| Group | Firms | Firm-years FY2004–2024 | Firm-years in the five-year window |
|---|---|---|---|
| Core cases (RPT misstatement or misappropriation) | 21 | 272 | 102 |
| Disclosure-only cases (separate stratum) | 9 | 157 | 45 |
| Matched firms (five per case by rule; three for three thin industries) | 140 | 2,151 | 686 |
| **Confirmatory panel** | **170** | **2,580** | **833** |
| External validation: three-report cases and their matched firms | 10 + 28 | 549 | 167 |

Core cases: Ault Alliance, Co-Diagnostics, Eagle Bancorp, Ocwen Financial, Valeant Pharmaceuticals, Manitex International, Singularity Future Technology, Puda Coal, General Employment Enterprises, SAExploration, Ideanomics, United Development Funding IV, FAT Brands, Ammo Inc (Outdoor Holding), MusclePharm, China Valves Technology, Cemtrex, Quadrant 4 System, Provectus Biopharmaceuticals, Corporate Resource Services, Premier Holding.

Disclosure-only stratum: Skechers, American Electric Power, RCI Hospitality, Greenbrier, Energy XXI, Maximus, Shift4 Payments, First Bancorp (NC), American Equity Investment Life.

External validation cases (never used in fitting): American Realty Capital Properties, Apple REIT Nine, ChinaCast Education, China Natural Gas, China North East Petroleum, Ener1, HF Foods, Home Loan Servicing Solutions, iFresh, RINO International.

Matching: 123 of 140 matched firms share the case's four-digit SIC code, 5 the three-digit and 12 the two-digit code; the median gap in log total assets is 0.40. Three matched sets (Ocwen, Energy XXI, Singularity) are poorly size-matched because their industries contain few registrants of the case's size; results are reported with and without them.

## 3. Measurement checks (RO2)

### M1 — coverage of the eight characteristics and the traditional signals

| Characteristic (design code) | Source used | Share of window firm-years with a value | Usable at 50 % |
|---|---|---|---|
| 1 RP_LEND lending to related parties / assets | related-party note and section, rule-coded amounts | 15 % | no |
| 2 RP_PAY payables to related parties / assets | same | 16 % | no |
| 3 RP_SALES sales to related parties / sales | same | 7 % | no |
| 4 RP_PURCH purchases from related parties / assets | same | 16 % | no |
| 5 RP_INCOMP incompleteness of the disclosure (4 items) | same, item flags | 88 % | yes |
| 6 RP_VAGUE vagueness of the RPT text | lexicon on the related-party text | 88 % | yes |
| 7 BRD_NONIND non-independent directors | proxy statement, rule-coded | 14 % | no |
| 8 DUAL CEO duality | proxy statement, rule-coded | 52 % | yes |
| ICFR_MW material weakness | 10-K Item 9A | 90 % | yes |
| AUD_OPIN going-concern opinion | 10-K audit report | 97 % | yes |
| AUD_CHG auditor change | 8-K Item 4.01 (0 where no 8-K) | 100 % | yes |
| RESTATE restatement | 8-K Item 4.02 (0 where no 8-K) | 100 % | yes |

**Finding.** The four related-party amounts can be coded from the notes, but only 7–16 % of firm-years state a classifiable amount: most related-party sections describe arrangements without a figure, or state only the Item 404 threshold. This is a property of US disclosure, not of the coder, and it is the design's main measurement limit. The amounts are therefore used in the design's layer scores (§4) but are too sparse for the fitted model (§5). Board independence remains thin because many proxies state independence by name rather than by count. The traditional signals are now complete.

### M2 — reliability

A 10 % random sample of every rule-coded value (2,075 rows: governance 921, related-party amounts 122, disclosure items 1,032) has been drawn with its evidence passage and empty human-coding columns (`data/m2_hand_check_sample.csv`). The human coding and the agreement statistic are the remaining step; the proposed threshold, to be agreed with the supervisors, is Cohen's κ ≥ 0.70 (or 90 % raw agreement) per variable, with any variable below it coded by hand.

### M3 — distinctness of the layers

| | Financial score | Disclosure score | Governance score |
|---|---|---|---|
| Financial score | 1.00 | 0.02 | 0.10 |
| Disclosure score | 0.02 | 1.00 | −0.07 |
| Governance score | 0.10 | −0.07 | 1.00 |

The three layer scores are not duplicates of one another; M3 is met.

## 4. Hypotheses (RO3)

Scores are built as the design specifies: each characteristic ranked 0–1 over all firm-years, ranks averaged within layer (financial: the four coded amounts; disclosure: incompleteness and vagueness; governance: non-independent share and duality), the three layer scores averaged and multiplied by ten. Tests are conditional (within-matched-set) logistic regressions with leverage and ROA as controls, on the five window years, with Holm adjustment across H1–H3. A regressor must be observed in at least 20 % of rows; complete cases only, so n varies by layer.

### H1–H3

| Hypothesis | Layer score (inputs) | Odds ratio per SD, within matched sets | p (Holm) | n firm-years / matched sets | Result |
|---|---|---|---|---|---|
| H1 financial exposure higher in fraud firms | lending, payables, sales, purchases (coded) | 2.14 | 0.009 | 147 / 13 | **supported** on the firm-years with a stated amount |
| H2 disclosure less complete and vaguer | incompleteness + vagueness | 0.72 | 0.040 | 338 / 17 | **opposite direction**: fraud firms' RPT disclosure scores *more* complete and plainer |
| H3 governance weaker | non-independent share + duality | 4.64 | < 0.001 | 180 / 12 | **supported** |

Reading. H1 and H3 hold where they can be tested, with large effects (the odds of being a fraud firm-year double per SD of related-party financial exposure and more than quadruple per SD of the governance score), but on the subsets of firm-years where amounts or board data are stated, so the effect sizes carry wide uncertainty and the M2 check applies to exactly these inputs. H2 is reversed on both of its components: fraud firms' related-party text names more parties, amounts and terms and reads more plainly than matched firms'; the disclosure measures that do rise in fraud firms are the year-on-year change in complexity and the distance of the text from peers' (§5).

### H4 — are the differences present in the earlier years?

Year-by-year comparison of each layer score between fraud and matched firms (Mann–Whitney, one-sided; conditional-logit p in brackets):

| Year before revelation | Financial score p | Disclosure score p | Governance score p |
|---|---|---|---|
| −5 | 0.38 (0.96) | 0.92 | 0.11 (1.00) |
| −4 | 0.11 (0.10) | 0.95 | 0.24 (0.14) |
| −3 | 0.32 (0.23) | 0.87 | **0.008** (0.033) |
| −2 | **0.039** (0.066) | 0.97 | **0.019** (0.057) |
| −1 | 0.31 (0.46) | 0.86 | 0.13 (0.17) |

**H4 is supported for the governance layer** (significant in years −3 and −2, not in the final year) and borderline for the financial layer (year −2). The disclosure score never differs. The fitted score (§5) shows the same shape: case firms score higher throughout the window and the gap does not grow towards revelation.

### H5 — do the layers add to the audit and internal-control signals?

Traditional index = material weakness + going-concern opinion + auditor change (8-K) + restatement (8-K), 0–4. Each matched set is scored by a model fitted without it.

| Model | Out-of-sample AUC | Note |
|---|---|---|
| Traditional index alone | 0.64 | no fitting needed |
| Model A: traditional index + leverage + ROA | 0.48 | the pooled logit does not generalise across matched sets |
| Model B: Model A + design AI score (rank-averaged layers) | 0.57 | AI score coefficient 0.25 per SD, p = 0.22 (not significant) |
| Model B′: Model A + fitted alert score (§5) | 0.66 | coefficient 0.64 per SD, **p = 0.002** |
| Fitted alert score alone | **0.73** | 95 % interval 0.63–0.83 |

Timing, at a comparable false-alarm rate among matched firm-years (traditional rule = two or more signals in a year, 8.4 %; fitted alert, 4.8 %): the traditional rule flags 11 of 21 cases, the fitted alert 9, they overlap on 4 and together flag 16. Where both fire the alert is earlier in 2 cases and the traditional rule in 2; across all cases the alert is the first signal in 7, the traditional rule in 7. **H5 is supported in strength and in coverage, not in timing**: the two kinds of signal find different fraud firms, which is the design's "the two together do better than either alone". The design's rank-averaged score does not add to the traditional signals; the fitted score does.

### P1 — RPT types by form of fraud (descriptive)

Of the 15 corporate-fraud cases with window data, 8 disclose related lending, 8 related purchases and 5 related sales; of the 5 managerial-fraud cases, 3 disclose lending, 1 purchases and 1 sales (one mixed case discloses all three). Lending is the most frequent type in both forms; the predicted contrast (sales in corporate fraud, lending and purchases in managerial fraud) appears for sales only. With 5 managerial cases this is a pattern, as the design says, not a test.

## 5. The fitted risk score, its validation and its external test

Because the design's rank-averaged score has sparse financial inputs, a second score was fitted from the 35 characteristics with adequate coverage (generic financial ratios, the ICFR, audit and 8-K signals, Big-4 status, CEO duality, audit-committee independence, nine measures of the related-party text including the incompleteness item, four controls, and peer-relative versions of each: how far the firm sits from its own matched firms in that year). Three model classes were fitted and averaged; every number is out of sample (each matched set scored by a model that never saw it).

| Model | Out-of-sample AUC | 95 % interval |
|---|---|---|
| Logistic regression (pre-specified) | 0.73 | 0.63–0.82 |
| Random forest | 0.73 | 0.63–0.83 |
| Gradient boosting | 0.71 | 0.60–0.80 |
| Average of the three (alert score) | 0.73 | 0.63–0.83 |
| Text of the RPT disclosure alone (bag of words, nested validation) | 0.67 | 0.56–0.77 |

![Leave-one-matched-set-out ROC curves of the five models on the core sample](run3_results/fig_oof_roc.png)

At a threshold set so that 5 % of matched firm-years are flagged, the alert fires in at least one window year for 9 of the 21 cases (15 % of case firm-years), a median of 46 months before the fraud became public (range 19–56). Three further cases (Eagle Bancorp, Ammo, Ault Alliance) are separated almost perfectly from their own matched firms but never cross the pooled threshold, which argues for an alert rule set within each industry rather than one cut-off for all.

**External test.** The ten three-report cases and their 28 matched firms were never used in fitting. Scored with the final model: AUC 0.73 on 167 window firm-years (30 fraud), matched-firm false-alarm rate 5.8 %, one of ten cases crossing the pooled threshold (HF Foods, FY2019). The discrimination seen in validation carries over to unseen firms; the low case-level recall at a 5 % false-alarm rate does too.

![Out-of-fold risk scores by year before revelation; grey points are matched firms, lines are case firms, dashed line is the alert threshold](run3_results/fig_scores_event_time.png)

What carries the signal (removing a layer and refitting): the peer-relative layer, the related-party text and the ICFR/auditor signals; the vagueness lexicon as a block adds nothing beyond those. The most informative single disclosure measure is a new one: the distance between a firm's related-party text and its matched firms' texts in the same year (within-set odds ratio 1.86 per SD, p = 0.009). The coded incompleteness item ranks among the five largest contributors in all three models, in the direction found under H2 (fraud firms disclose more of the four items). Robustness: 0.76 without the three poorly matched sets; 0.75 on firm-years with related-party text and 0.57 without; 0.77 for FY2012–2024 and 0.67 before; no dependence on the certainty of the revelation dates. Including the nine disclosure-only cases in training lowers the core result to 0.72 and scores the disclosure-only stratum at 0.52 [0.37, 0.67] (chance): disclosure failures leave no trace in these characteristics.

## 6. Attribution checks (RO4)

- **A1 traceability.** For every scored firm-year the three largest contributions were traced to their evidence: a related-party passage with the matched terms or the coded amount, an Item 9A passage, an audit-report signature, an 8-K accession, an XBRL tag and accession number, or the first annual report on file. 96 % of contributions (96 % for fraud firm-years) resolve to a located source.
- **A2 stability.** Attribution rankings re-computed over 200 resamples of the matched sets correlate at 0.94 (logit), 0.996 (random forest) and 0.998 (gradient boosting) with the full-sample ranking; the two tree models agree with each other at 0.82.
- **A3 reading against theory.** In the flagged fraud firm-years the largest contributing layer is the disclosure (information-asymmetry) layer in 10 of 15, the monitoring layer in 4 and the peer-relative layer in 1.

![Mean absolute SHAP contribution by characteristic and model](run3_results/fig_shap_summary.png)

## 7. Forensic stress tests

| Test | Result |
|---|---|
| Specificity: is the vagueness of RPT text, relative to the firm's own Item 1, higher in fraud firms? | No: RPT text is vaguer than Item 1 in fraud *and* matched firms alike (p = 0.25 for the difference) |
| Ablation: does the disclosure layer carry unique signal? | Removing the lexicon layer leaves AUC unchanged (+0.02 to +0.03); removing the peer-relative layer costs 2–6 points; controls alone lose 15–20 points |
| Lead time | 9 of 21 cases flagged; median 46 months, range 19–56 |
| Material-weakness persistence (two consecutive years) | 37 % of fraud firm-years vs 11 % of matched firm-years, p < 0.001 |
| Clean-firm false-positive rate at the alert threshold | 4.8 % (target ≤ 5 %) |

![First out-of-fold alert relative to revelation, per case](run3_results/fig_lead_time.png)

## 8. What the results mean for the design

1. **The eight characteristics can be measured from filings, with one structural limit:** related-party amounts are stated in only 7–16 % of firm-years. The design should state that the financial layer is tested on the disclosing subset, and treat a stated amount as itself informative.
2. **H1 and H3 are supported, with large within-set effects**, on the subsets where the inputs exist. H3 is the strongest result in the study.
3. **H2 should be re-stated.** Fraud firms' related-party disclosure is more complete and plainer than matched firms'; what rises is its abnormality — the year-on-year drift and the distance from peers. The information-asymmetry idea survives in that form.
4. **H4 holds for governance** (years −3 and −2) and is borderline for the financial layer; the differences are not confined to the final year.
5. **H5 holds for strength and coverage, not for timing**, and the combination of the two signal types is what adds value. The design's wording "or flags fraud firms earlier" should become "or flags fraud firms the traditional signals miss".
6. **The rank-averaged AI score (steps 3–5 of the design) does not add to the traditional signals; the fitted score does.** The design should adopt the fitted score as the headline and report the rank-average as the interpretable robustness check.
7. **The sample is 21 core cases, not 40**, with 10 external and 13 pre-2005 cases as robustness tiers; power is restated accordingly.
8. **Disclosure-only cases are a separate population** and stay a separate stratum with their own, weaker, hypothesis.

## 9. Status of the open items

| Item (8 October) | Status on 9 October | What remains |
|---|---|---|
| Code RP_LEND, RP_PAY, RP_SALES, RP_PURCH and RP_INCOMP from the related-party notes | **Done** by rule with evidence passages; amounts in 7–16 % of firm-years, incompleteness in 88 % | human check (M2); a reading model could raise amount coverage where figures appear in tables |
| 10 % human check (M2) | sample drawn (2,075 rows with evidence) | the human coding itself and the agreed threshold |
| Fetch the proxy for every filing year; re-run governance and H3 | **Done**: 85 % of filings linked; duality 52 %, audit-committee independence 35 %, board share 14 % | board share needs name-list parsing or hand coding |
| Code restatements and auditor changes from 8-K Items 4.02/4.01 | **Done** from the submissions API: 109 restatement and 295 auditor-change firm-years across 132 firms | — |
| Confirm the 15 medium/low-confidence revelation dates | **Evidence pass done**: every earlier non-reliance, investigation, auditor-change or related-party hit in the firm's own filings listed with its passage (34 hits); on reading, only Ault (8-K non-reliance, 18 Oct 2018) and Co-Diagnostics (10-Q/A restatement, 3 Nov 2020) could move a date | supervisor's reading of those two; no date changed |
| Agree M1/M2 thresholds | proposed: M1 ≥ 50 % coverage to enter the fitted model (≥ 20 % for the layer tests); M2 κ ≥ 0.70 | supervisors' decision |
| Generalisation beyond the fitted firms | **External validation done** on 10 unseen cases and 28 matched firms: AUC 0.73, false-alarm rate 5.8 % | scoring the full EDGAR universe (12,615 registrants) for the external alert rate remains a separate data run |

## Appendix A — how the data were built

Sources: SEC EDGAR submissions API (filings, 8-K items), 10-K and DEF 14A documents, XBRL company facts, AAER and litigation-release listings. Extraction: Item 1, Item 9A and Item 13 bodies with table-of-contents lines removed; the related-party note; the proxy RPT section; ICFR flags; audit-report signature and going-concern language; board statements. Coding: rule-based with the sentence or passage kept for every value; the $120,000 Item 404 threshold sentence and exhibit-index lines are excluded from amounts; direction words ("loan to the Company" vs "loan to the director") set the flow. Labels: 1 for a case firm's fiscal years in the five years before the revelation date, 0 otherwise; matched firms take their case's window. Validation: leave-one-matched-set-out; imputation and scaling fitted inside each fold; text model fitted in nested folds with a vocabulary restricted to terms used by at least three firms, honorifics and given names excluded. Asset-scaled ratios are bounded at fixed limits.

## Appendix B — coverage of the fitted model's inputs in the window

Financial ratios 83–88 %; ICFR flags 90 %; Big-4 auditor 80 %; auditor change 100 %; restatement 100 %; going-concern opinion 97 %; CEO duality 52 %; audit-committee independence 35 %; related-party text 88 %; incompleteness item 88 %; peer-relative measures 81–88 %. Related-party text source in the window: proxy statement 56 %, Item 13 body 28 %, related-party note 5 %, none 11 %.

## Appendix C — files

- Sample and screen: `cases_core.csv`, `cases_sensitivity.csv`; `docs/REPORT_Candidate_Screen_2026-10-08.docx`
- Data sets: `SEC-EDGAR-Downloader/data_core/` and `data_sens/` (tables, `dataset_qa.json`, raw texts, `proxy_links.csv`, `eightk_items.csv`)
- Coded characteristics with evidence: `data/rp_note_coded.csv`, `data/governance_manual.csv`; hand-check sample `data/m2_hand_check_sample.csv`
- Revelation-date evidence: `SEC-EDGAR-Downloader/scripts/revelation_verification.csv` (hits with passages) and `_summary.csv`
- Design test battery: `outputs/full/design_tests/` (`m1_coverage.csv`, `m3_layer_correlations.csv`, `h1_h3_layer_tests.csv`, `h4_by_year.csv`, `h5_model_ab.csv`, `h5_timing_by_case.csv`, `p1_rpt_types_by_form.csv`, `a3_layer_shares.csv`, `summary.md`)
- External validation: `outputs/sens/external_validation.json`, `external_validation_by_case.csv`
- Model results, stress tests, regressions, attributions and figures: `outputs/full/` (run 3, final) and `docs/run3_results/`; all-strata comparison in `outputs/full_all/`
- Full technical report: `docs/REPORT_Model_Performance_Explainability_Readiness.docx`
