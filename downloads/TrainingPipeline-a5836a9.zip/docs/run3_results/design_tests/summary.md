# Design test battery — summary

Training window: 577 firm-years, 102 fraud firm-years, 21 matched sets.

## M1 coverage

| characteristic                                        | layer   | panel_column               |   coverage_training_window | usable   |
|:------------------------------------------------------|:--------|:---------------------------|---------------------------:|:---------|
| RP_LEND (lending to related parties / assets)         | L1      | rp_lend_to_assets          |                      0.146 | False    |
| RP_PAY (payables to related parties / assets)         | L1      | rp_pay_to_assets           |                      0.156 | False    |
| RP_SALES (sales to related parties / sales)           | L1      | rp_sales_to_revenue        |                      0.068 | False    |
| RP_PURCH (purchases from related parties / assets)    | L1      | rp_purch_to_assets         |                      0.156 | False    |
| RP_INCOMP (incompleteness of the disclosure, 4 items) | L2      | rp_incomp                  |                      0.882 | True     |
| RP_VAGUE (vagueness of the RPT text)                  | L2      | rpt_vagueness              |                      0.879 | True     |
| BRD_NONIND (1 - independent share of the board)       | L3      | board_indep                |                      0.142 | False    |
| DUAL (CEO chairs the board)                           | L3      | ceo_duality                |                      0.522 | True     |
| ICFR_MW (traditional signal)                          | TRAD    | material_weakness_reported |                      0.905 | True     |
| AUD_OPIN (traditional signal)                         | TRAD    | going_concern_opinion      |                      0.971 | True     |
| AUD_CHG (traditional signal)                          | TRAD    | auditor_change_8k          |                      1     | True     |
| RESTATE (traditional signal)                          | TRAD    | restatement_8k             |                      1     | True     |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |      0.016 |      0.103 |
| L2_SCORE |      0.016 |      1     |     -0.072 |
| L3_SCORE |      0.103 |     -0.072 |      1     |

Columns used per layer: L1: rp_lend_to_assets, rp_pay_to_assets, rp_sales_to_revenue, rp_purch_to_assets; L2: rp_incomp, rpt_vagueness; L3: board_indep, ceo_duality

## H1–H3 (conditional logit within matched sets; Holm across three)

| hypothesis   | layer_score   | columns_used                                                                 |   cond_coef |   cond_se |   cond_p |   cond_odds_ratio_per_sd |   cond_n |   cond_clusters |   pooled_coef |   pooled_p |   cond_p_holm | supported   |
|:-------------|:--------------|:-----------------------------------------------------------------------------|------------:|----------:|---------:|-------------------------:|---------:|----------------:|--------------:|-----------:|--------------:|:------------|
| H1           | L1_SCORE      | rp_lend_to_assets; rp_pay_to_assets; rp_sales_to_revenue; rp_purch_to_assets |       0.76  |     0.268 |    0.005 |                    2.139 |      147 |              13 |         0.344 |      0.33  |         0.009 | True        |
| H2           | L2_SCORE      | rp_incomp; rpt_vagueness                                                     |      -0.329 |     0.161 |    0.04  |                    0.719 |      338 |              17 |        -0.361 |      0.097 |         0.04  | False       |
| H3           | L3_SCORE      | board_indep; ceo_duality                                                     |       1.534 |     0.318 |    0     |                    4.635 |      180 |              12 |         0.767 |      0.006 |         0     | True        |

## H5 Model A vs Model B

| model_A_features        | model_B_features                 |   n |   n_fraud |   loco_auc_model_A |   loco_auc_model_B |   auc_gain_B_minus_A |   AI_SCORE_coef_model_B |   AI_SCORE_p_model_B |   ai_threshold_95pct_matched |   cases_ai_flags_earlier |   cases_same_year |   cases_trad_earlier |   cases_flagged_by_neither |   cases |   loco_auc_model_B2_ml |   auc_gain_B2_minus_A |   ML_SCORE_coef_model_B2 |   ML_SCORE_p_model_B2 |   auc_trad_index_alone |   auc_ml_score_alone_oof |   ml_threshold |   cases_ml_flags_earlier |   cases_ml_same_year |   cases_trad_earlier_than_ml | trad_rule_equal_fpr                       |   trad_ge1_matched_rate |   cases_ml_earlier_equal_fpr |   cases_same_year_equal_fpr |   cases_trad_earlier_equal_fpr |   cases_flagged_trad_equal_fpr |   cases_flagged_ml |
|:------------------------|:---------------------------------|----:|----------:|-------------------:|-------------------:|---------------------:|------------------------:|---------------------:|-----------------------------:|-------------------------:|------------------:|---------------------:|---------------------------:|--------:|-----------------------:|----------------------:|-------------------------:|----------------------:|-----------------------:|-------------------------:|---------------:|-------------------------:|---------------------:|-----------------------------:|:------------------------------------------|------------------------:|-----------------------------:|----------------------------:|-------------------------------:|-------------------------------:|-------------------:|
| TRAD_INDEX+leverage+roa | TRAD_INDEX+leverage+roa+AI_SCORE | 395 |        76 |              0.484 |              0.565 |                 0.08 |                 0.24985 |             0.220318 |                        8.102 |                        0 |                 1 |                   20 |                          0 |      21 |                  0.664 |                  0.18 |                 0.635987 |            0.00210413 |                  0.643 |                    0.734 |          0.702 |                        1 |                    5 |                           15 | TRAD_INDEX >= 3 (matched-firm rate 0.017) |                   0.276 |                            9 |                           0 |                              2 |                              3 |                  9 |

## H4 by event year (Mann–Whitney, fraud > matched)

|   event_year | layer_score   |   n |   n_fraud |   mean_fraud |   mean_matched |   mannwhitney_p_greater |   cond_coef |   cond_p |
|-------------:|:--------------|----:|----------:|-------------:|---------------:|------------------------:|------------:|---------:|
|           -5 | L1_SCORE      | 112 |        19 |        0.63  |          0.596 |                   0.38  |       0.028 |    0.957 |
|           -5 | L2_SCORE      | 112 |        19 |        0.424 |          0.497 |                   0.915 |      -0.371 |    0.316 |
|           -5 | L3_SCORE      | 112 |        19 |        0.555 |          0.448 |                   0.105 |      33.726 |    1     |
|           -4 | L1_SCORE      | 118 |        21 |        0.632 |          0.502 |                   0.114 |       3.719 |    0.104 |
|           -4 | L2_SCORE      | 118 |        21 |        0.405 |          0.495 |                   0.947 |      -0.507 |    0.185 |
|           -4 | L3_SCORE      | 118 |        21 |        0.542 |          0.457 |                   0.239 |       1.484 |    0.137 |
|           -3 | L1_SCORE      | 118 |        21 |        0.525 |          0.462 |                   0.32  |       0.795 |    0.233 |
|           -3 | L2_SCORE      | 118 |        21 |        0.448 |          0.513 |                   0.867 |      -0.063 |    0.837 |
|           -3 | L3_SCORE      | 118 |        21 |        0.671 |          0.468 |                   0.008 |       1.693 |    0.033 |
|           -2 | L1_SCORE      | 118 |        21 |        0.577 |          0.444 |                   0.039 |       2.386 |    0.066 |
|           -2 | L2_SCORE      | 118 |        21 |        0.382 |          0.492 |                   0.968 |      -0.742 |    0.064 |
|           -2 | L3_SCORE      | 118 |        21 |        0.657 |          0.442 |                   0.019 |       2.585 |    0.057 |
|           -1 | L1_SCORE      | 111 |        20 |        0.535 |          0.481 |                   0.314 |       1.956 |    0.463 |
|           -1 | L2_SCORE      | 111 |        20 |        0.443 |          0.502 |                   0.856 |      -0.147 |    0.677 |
|           -1 | L3_SCORE      | 111 |        20 |        0.53  |          0.443 |                   0.13  |       2.278 |    0.174 |

## P1 RPT types by form of fraud (cases with a tagged amount in any window year)

| form_group   |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |   any_rpt_amount_sum |   any_rpt_amount_count |
|:-------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|---------------------:|-----------------------:|
| both/other   |             1 |               1 |           1 |             1 |               1 |                 1 |                    1 |                      1 |
| corporate    |             8 |              15 |           5 |            15 |               8 |                15 |                    8 |                     15 |
| managerial   |             3 |               5 |           1 |             5 |               1 |                 5 |                    3 |                      5 |

## A3 largest contributing layer in flagged fraud firm-years

| largest_layer    |   firm_years |
|:-----------------|-------------:|
| L3_disclosure    |           10 |
| L2_monitoring    |            4 |
| L4_peer_relative |            1 |
