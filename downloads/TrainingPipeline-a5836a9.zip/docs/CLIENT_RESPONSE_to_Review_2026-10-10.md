# Response to the researcher's review of 9 October 2026

**RPT fraud-risk study — design tests re-run exactly as the design and the review specify** · 10 October 2026 · research assistant

This document answers every red note and every numbered instruction in *RPT Research Design – 06.10.26 – REVIEWED against RA report 09.10.26*. Nothing in the agreed design was changed: the research question, objectives, hypotheses, the eight characteristics, the scoring steps and the AI risk score are as written on 6 October. The tests were re-run on all qualifying RPT-fraud cases with the design's own rank-averaged AI risk score. Everything built on the fitted 36-input score is now in a separate, labelled exploratory section (§6). The researcher approved Gulfport Energy as the 31st case on 10 October; the main sample is therefore 31 cases. One thing still needs the researcher's and supervisors' decision before any result is final: the M2 threshold and human coding (§5).

## 1. Summary of the honest results (31 cases, design rules applied)

- **Sample.** 31 RPT-fraud cases (21 misstatement/misappropriation + 10 disclosure-only including Gulfport Energy, all FRAUD = 1) with 145 matched firms in 31 sets; 517 firm-years in the largest layer test, 862 window firm-years in all (152 fraud firm-years).
- **H1 (financial exposure)**: **not supported** by the design rule with model-based errors; **not supported** with the firm-clustered errors the design asks for — OR 1.61 per SD [1.04, 2.49], as predicted; p = 0.031, Holm p = 0.062; firm-clustered p = 0.206 (Holm = 0.459); 187 firm-years, 63 firms, 17 sets.
- **H2 (disclosure less complete and vaguer)**: **not supported** by the design rule with model-based errors; **not supported** with the firm-clustered errors the design asks for — OR 0.80 per SD [0.63, 1.02], in the OPPOSITE direction; p = 0.075, Holm p = 0.075; firm-clustered p = 0.374 (Holm = 0.459); 517 firm-years, 117 firms, 25 sets. The design's second run without the disclosure-only cases gives OR 0.72 (p = 0.042). H2 is reported as not supported; no re-wording.
- **H3 (weaker governance)**: **supported** by the design rule with model-based errors; **not supported** with the firm-clustered errors the design asks for — OR 1.70 per SD [1.22, 2.37], as predicted; p = 0.002, Holm p = 0.006; firm-clustered p = 0.153 (Holm = 0.459); 284 firm-years, 71 firms, 18 sets. The layer is carried by CEO duality (board share observed in 15% of firm-years).
- **H4 (differences in earlier years)**: with the conditional logit as the primary test, the design rule (a significant year before the final year) is met for: no layer. The closest is governance in year −3 (p = 0.088). Fifteen tests with 7–21 informative sets each: limited evidence either way.
- **H5 (layers add to audit and internal-control signals)**: **not supported** for the design's AI risk score. AI_SCORE is not significant in Model B with firm-clustered errors (p = 0.296); Model B's out-of-set AUC (0.52) is above Model A (0.45) but below the traditional index alone (0.60); at an equal false-alarm rate the AI rule flags 0 cases and is earlier than the traditional rule in 0, later in 3; 28 of 31 cases are flagged by neither rule.
- **P1**: reported as a pattern only (§4.7). **M1** coverage is now reported by group: a related-party amount is stated in about three times as many fraud firm-years as matched firm-years, so the H1 subset is selected on the outcome (§4.1). **M3** met. **M2** not done (workbook delivered, §5).
- **A1–A3** re-done on the design score: every assessment is named evidence (A1); re-ranking without each set in turn changes the largest layer in 1.0% of firm-years (A2); in the fraud firm-years the AI rule flags, the largest layer is L2 — and the disclosure layer runs *against* its prediction (A3, §4.8).
- **Reading.** On the design as written and on the data as coded, the governance layer separates fraud firms from their matched firms, the financial layer does so only on the small disclosing subset, and the disclosure layer separates them the other way. The rank-averaged AI risk score built from the three does not add to the traditional signals. These are the results to report; the exploratory section shows what a fitted score does, labelled as such.

## 2. The sample (instructions 1 and 10)

### 2.1 Qualifying cases restored to one main sample

The disclosure-only cases (nine from the screen plus Gulfport Energy, approved on 10 October) are FRAUD = 1 in every test below, as the design specifies. The stratum label is kept only for the design's second H2 run and for descriptive splits. The first battery's choice to keep them out of the primary test was the assistant's, not the design's; it is withdrawn.

| Group | Cases | Firms |
|---|---|---|
| Misstatement or misappropriation (RPT is the mechanism) | 21 | Ault Alliance, Co-Diagnostics, Eagle Bancorp, Ocwen Financial, Valeant, Manitex, Singularity Future Technology, Puda Coal, General Employment, SAExploration, Ideanomics, United Development Funding IV, FAT Brands, Ammo/Outdoor Holding, MusclePharm, China Valves, Cemtrex, Quadrant 4, Provectus, Corporate Resource Services, Premier Holding |
| Disclosure-only (charge is the missing or incomplete RPT disclosure) | 10 | Skechers, American Electric Power, RCI Hospitality, Greenbrier, Energy XXI, Maximus, Shift4 Payments, First Bancorp (NC), American Equity Investment Life, Gulfport Energy (approved 10 Oct) |
| Matched firms (rule D4) | — | 145: 24 sets with five, 4 with four, 3 with three (thin industry pools: CHINA_VALVES_T, MUSCLEPHARM, OCWEN_FINANCIA, PUDA_COAL, SHIFT4_PAYMENT, SINGULARITY_FU, SKECHERS_U_S_A) |

### 2.2 The screening report and the case for each firm the review asked about

The candidate screening report of 8 October (`docs/REPORT_Candidate_Screen_2026-10-08.docx`) is attached again with this response. It records the four discovery sources (every AAER 2005–2024, every litigation release 2010–2025, EDGAR full-text search of issuers' filings, the client workbook), the 58 candidates and the rule each was screened by. The firms the review lists as 'added' were all found by those searches and pass D1–D4; none was added by judgement:

| Firm | Found through | Why it qualifies (D1) | Revelation (D2) | Window / reports |
|---|---|---|---|---|
| Cemtrex | litigation-release sweep | misappropriation through undisclosed insider dealing and related-party transactions (SEC press release 2021-132) | short-seller report 22 Feb 2017 (medium) | FY2012–2016 / 5 |
| Quadrant 4 System | EDGAR full-text search | misappropriation; CEO and CFO charged (Nov 2016) | 10-K/A revising the Item 13 related-party disclosure, 23 Sep 2016 (medium) | FY2011–2015 / 5 |
| Provectus Biopharmaceuticals | litigation-release sweep | misappropriation: CEO expense reimbursements, undisclosed related-party payments | CEO resignation amid audit-committee review, 29 Feb 2016 (medium) | FY2011–2015 / 5 |
| Corporate Resource Services | AAER sweep (AAER-4007) | misstatement tied to the related-party payroll entity (Tri-State); D1 confirmation open: was the issuer itself charged? | disclosure of unpaid payroll taxes / going concern, 10 Feb 2015 (medium) | FY2010–2014 / 4 |
| Premier Holding Corp | litigation-release sweep (LR-24000) | misstatement through related-party arrangements; revelation date is the SEC action (low confidence; 2016–2017 8-Ks to be read) | 4 Dec 2017 (low) | FY2012–2016 / 5 |
| First Bancorp (NC) | AAER sweep (AAER-3660) | disclosure-only: related-party disclosure failure charged; no earlier public revelation | 1 Jun 2015 (high) | FY2010–2014 / 5 |
| American Equity Investment Life | litigation-release sweep (LR-21431) | disclosure-only: 2006 proxy related-party disclosure (company, CEO, CFO charged) | 3 Mar 2010 (high) | FY2005–2009 / 5 |
| Skechers, AEP, Greenbrier, Maximus, Shift4, RCI, Energy XXI | workbook / AAER sweep | disclosure-only orders (undisclosed perquisites or related-person transactions); no misstatement element in the order | as in the screening report | ≥ 4 reports each |

### 2.3 Gulfport Energy — why it was absent and what was found

Gulfport was screened NEED_REVELATION_DATE on 2 October: its order (Release 33-10930, 24 Feb 2021; undisclosed CEO perquisites and related-person transactions 2014–2018) is not on the AAER list and no public revelation date had been established, so no window could be set and it entered no group. On 10 October the firm's own filings were read: the Form 10-Q for Q3 2018 (filed 1 Nov 2018, accession 0001628280-18-013345) discloses that in September 2018 the Audit Committee was informed of the CEO's unauthorised use of chartered aircraft and personal credit-card charges, not identified or disclosed in the proxy statements, and that the CEO stepped down on 29 October 2018. That is the first public event (D2, high confidence). Window FY2013–2017 with five 10-Ks (D3 met); five SIC-1311 peers matched by rule D4 (log-asset gaps 0.06–0.16). Gulfport therefore qualifies as a disclosure-only RPT case. Its data were built, its tables and raw filings merged into the core data set, and **the researcher approved it as the 31st case on 10 October 2026**; the main sample in §4 includes it.

### 2.4 Reaching 30–35 cases: the options

| Option | Cases | What it requires | Status |
|---|---|---|---|
| A | 30 | nothing: the design's own qualifying cases (21 + 9) | run (§2.5, for comparison) |
| B | 31 | approval of Gulfport Energy (§2.3) | **approved 10 Oct; the main sample (§4)** |
| C | 36 | relaxing D3 from four to three annual reports for the five three-report cases that have five rule-matched peers (American Realty Capital Properties, Apple REIT Nine, China North East Petroleum, HF Foods, iFresh) | run for information (§2.5); a design change, so only on the researcher's decision |
| D | 40 | the design's target: no further qualifying cases exist in the AAER, litigation-release and EDGAR full-text records searched (screening report §2); the remaining three-report cases have thin peer pools (one peer) and the pre-2005 cases have no Item 9A | not available without changing D1 or D3 |

Option B is the main sample. Option C remains a stated sensitivity, because it changes a pre-registered rule; it is run for information only.

### 2.5 Do the results change with the sample?

| sample | H1 OR (p / firm-cl p) | H2 OR (p / firm-cl p) | H3 OR (p / firm-cl p) | H4 layers meeting the rule | H5 AUC A / B / TRAD alone | H5 AI_SCORE p (pooled firm-cl) | cases flagged by AI rule (5 % FAR) / total | timing AI earlier / trad earlier (equal FAR) |
|---|---|---|---|---|---|---|---|---|
| 21 misstatement/misappropriation cases only (first battery's sample) | 1.98 (0.007 / 0.097) | 0.73 (0.044 / 0.273) | 4.26 (< 0.001 / 0.046) | L3_SCORE | 0.48 / 0.56 / 0.64 | 0.254 | 1 / 21 | 0 / 3 |
| 30 cases before Gulfport was approved (21 + 9) | 1.54 (0.055 / 0.266) | 0.77 (0.045 / 0.318) | 2.10 (< 0.001 / 0.077) | none | 0.46 / 0.54 / 0.61 | 0.235 | 2 / 30 | 0 / 3 |
| MAIN SAMPLE: 31 cases (21 + 10 disclosure-only incl. Gulfport, approved 10 Oct) | 1.61 (0.031 / 0.206) | 0.80 (0.075 / 0.374) | 1.70 (0.002 / 0.153) | none | 0.45 / 0.52 / 0.60 | 0.296 | 2 / 31 | 0 / 3 |
| 36 cases: the 31 + five three-report cases (needs D3 relaxed; for discussion) | 1.47 (0.054 / 0.223) | 0.83 (0.109 / 0.417) | 1.71 (0.002 / 0.151) | none | 0.49 / 0.51 / 0.59 | 0.353 | 3 / 36 | 1 / 3 |
| 31 cases, ranks over all FY2004-2024 firm-years (sensitivity) | 1.60 (0.036 / 0.234) | 0.80 (0.070 / 0.367) | 1.77 (0.001 / 0.140) | none | 0.45 / 0.52 / 0.60 | 0.252 | 2 / 31 | 0 / 3 |

The direction of every layer is the same in every sample. Adding the nine disclosure-only cases to the 21 halves the governance odds ratio (their boards differ less from their matched firms') and lowers the financial one from about 2.0 to 1.5; the ranking population makes no material difference; Gulfport and the five three-report cases change nothing of substance. The disclosure layer stays reversed in every sample, and H5 is not supported for the design score in any sample. A larger sample will therefore not reverse these readings; it will narrow the intervals.

## 3. Status of every instruction and red note

| # | Instruction (9 Oct) | Done | Where |
|---|---|---|---|
| 1 | Restore the 9 non-disclosure cases (FRAUD = 1); run H1–H5 on all; run H2 again without them | **Done** | §4.3, §4.4 |
| 2 | Keep the rank-averaged AI risk score for H5 and A1–A3; report H2 and H5 as not supported if so; no re-wording | **Done**: H2 and H5 not supported; wording unchanged | §4.3, §4.6, §4.8 |
| 3 | Move the fitted score, text-distance / abnormality measures and the stress tests to an exploratory section stating the fitted score contains the traditional signals | **Done** | §6 |
| 4 | Complete M2 at a threshold agreed with the supervisors; do not set M1/M2 thresholds | **Not possible for the assistant**: human coding is the researcher's/supervisors' task. The coding workbook (2,075 rows, evidence attached, instructions and a signature line for the agreed threshold) and the agreement calculator are delivered. No threshold has been applied: the layer tests use complete cases with n reported | §5 |
| 5 | H1–H3: odds ratios with 95 % CIs, unadjusted and Holm p, firms and sets, firm-clustered SEs | **Done**: both model-based and firm-clustered intervals and p-values | §4.3 |
| 6 | Conditional logit as the primary H4 test; H5 timing for the AI risk score at an equal false-alarm rate | **Done** | §4.5, §4.6 |
| 7 | AUD_OPIN as modified or going-concern; RESTATE from 8-K 4.02 and 10-K/A | **Done**: audit reports re-coded for qualified / adverse / disclaimer opinions (none found in the sample after excluding other-auditor paragraphs, so AUD_OPIN equals the going-concern flag in practice); every 10-K/A of every firm fetched and read for restatement language | §4.2 |
| 8 | A2 by refitting with each matched set left out; A3 on the three design layers | **Done** | §4.8 |
| 9 | Explain incompleteness coding for firms that disclose no RPT; coverage and text source by group | **Done** | §4.1 |
| 10 | Send the screening report, the reason Gulfport is absent and the case for each added firm; no sample change without approval | **Done**; Gulfport approved by the researcher on 10 Oct and added as the 31st case | §2 |
| 11 | Restate power for the final number of cases | **Done** by simulation | §4.9 |
| 12 | Describe results as association and identification of fraud under way; lead time as the earliest separating year with the count never flagged | **Done** throughout; lead-time table in §4.6 | — |

Section notes not covered above:

- *Overall verdict (1)–(3)*: the fitted score is no longer recommended as the headline; the hypotheses are not re-worded; the nine disclosure-only cases (ten with Gulfport) are in the main sample.
- *§1 Research question*: wording adopted — the measures identify fraud already under way; any flag lies inside the window by construction.
- *§4 Role of AI*: recorded as a deviation. The characteristics were coded by rule with evidence passages, not by a language model reading the filings; the thesis will say so until the human check (M2) and, if the researcher wants it, a model-based reading pass are done. The fitted-model work is reported as exploratory.
- *§4 Design point (fitted versus rank-averaged score)*: the rank-averaged score is the AI risk score in every design test; the fitted score appears only in §6.
- *§4 Method (firm-clustered SEs)*: now reported for every conditional logit (sandwich over per-observation scores, firms nested in sets) and for the pooled logit.
- *§6 Layer score with missing characteristics; ranking population*: stated in §4.2 (scoring rules) and recorded in `scoring_rules.csv`.
- *§6 M1 threshold*: no threshold was applied by the assistant in this battery; the earlier ≥ 20 % / ≥ 50 % entry rules are withdrawn and recorded as having been set after M1 was seen.
- *§7 H1 interval; H3 as a duality result; H4 as limited evidence; H5 timing at equal false-alarm rates; the fitted score cannot test H5*: all adopted.
- *§8 A1 on the design score; A2 leave-one-set-out; A3 three layers with honest direction*: done.
- *§10 Holm*: unadjusted values are now beside the adjusted ones. *Power*: §4.9. *Clean-firm false-positive rate*: the 5 % rate is a threshold set by construction and is no longer presented as evidence of accuracy.
- *§11.1, 11.5, 11.6*: the theory text is not revised; the information-asymmetry prediction is reported as not supported under the competing (efficient-transaction) prediction; the H5 contribution is stated conditionally; the 'union of the two rules' claim is replaced by the equal-false-alarm comparison in §4.6, which does not support it.
- *§12 Thresholds*: not set by the assistant; proposal restated in §5 as a proposal.
- *LQ1, LQ2*: belong to the researcher's section 2.7; not part of this report.

## 4. Results as the design defines them (31 cases)

### 4.1 M1 coverage by group, text source, and how 'no transactions' is coded

| characteristic | layer | all | fraud firm-years | matched firm-years | Fisher p (coverage differs) | n_fraud_observed | n_matched_observed |
|---|---|---|---|---|---|---|---|
| RP_LEND | L1 | 0.118 | 0.276 | 0.085 | 0.0 | 42 | 60 |
| RP_PAY | L1 | 0.125 | 0.27 | 0.094 | 0.0 | 41 | 67 |
| RP_SALES | L1 | 0.077 | 0.099 | 0.072 | 0.244 | 15 | 51 |
| RP_PURCH | L1 | 0.158 | 0.158 | 0.158 | 1.0 | 24 | 112 |
| RP_INCOMP | L2 | 0.896 | 0.908 | 0.893 | 0.663 | 138 | 634 |
| RP_VAGUE | L2 | 0.893 | 0.908 | 0.89 | 0.664 | 138 | 632 |
| BRD_NONIND | L3 | 0.15 | 0.243 | 0.13 | 0.001 | 37 | 92 |
| DUAL | L3 | 0.552 | 0.599 | 0.542 | 0.21 | 91 | 385 |
| ICFR_MW (traditional signal) | TRAD | 0.918 | 0.822 | 0.938 |  | 125 | 666 |
| AUD_OPIN (traditional signal) | TRAD | 0.973 | 0.993 | 0.969 |  | 151 | 688 |
| AUD_CHG (traditional signal) | TRAD | 1.0 | 1.0 | 1.0 |  | 152 | 710 |
| RESTATE (traditional signal) | TRAD | 1.0 | 1.0 | 1.0 |  | 152 | 710 |

A related-party *amount* is stated in about 28 % of fraud firm-years and 9–10 % of matched firm-years for lending and payables (Fisher p < 0.001). The H1 subset is therefore selected on the outcome: fraud firms disclose amounts more often, and H1 is tested only among firm-years that do. The same holds for the board share (25 % vs 13 %). Sales and purchases do not differ. This must be stated with every H1 result.

Text source by group (share of firm-years):

| fraud_aaer_label | none | rp_note | rpt_disclosure | n | share_stating_no_transactions |
|---|---|---|---|---|---|
| fraud firm-years | 0.092 | 0.553 | 0.355 | 152 | 0.059 |
| matched firm-years | 0.107 | 0.413 | 0.48 | 710 | 0.052 |

Fraud firm-years draw more often on the financial-statement note and matched firm-years more often on the Item 13 / proxy section; the share whose text states that there were *no* related-party transactions is similar (6 % vs 5 %).

**Incompleteness when a firm discloses no RPT.** The coder reads the related-party text of the firm-year. If the text is shorter than 20 words or absent, RP_INCOMP is missing (not scored). If the text exists but says there were no transactions, the four items are scored on that text: typically no counterparty, no amount, no terms, no purpose, so RP_INCOMP is high (mean 0.48 among such firm-years against 0.29 for others). That is a coding convention, not a disclosure failure, and it could produce the H2 reversal mechanically. The robustness run in §4.4 therefore drops those firm-years: the reversal shrinks and is no longer significant (OR 0.85, p = 0.240), so part of the H2 result is the convention and the rest is a null.

### 4.2 Scoring rules, definitions and deviations

| rule | value |
|---|---|
| ranking population | the 862 analysed firm-years (five-year windows of the 31 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score |
| AI_SCORE with a missing layer | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 595, 1: 165, 2: 65, 3: 31, 4: 6} |
| firm-years with L2 from 0/1/2 characteristics | {0: 90, 1: 2, 2: 770} |
| firm-years with L3 from 0/1/2 characteristics | {0: 352, 1: 415, 2: 95} |
| firm-years with 1/2/3 layers in AI_SCORE | {0: 49, 1: 237, 2: 416, 3: 160} |
| AUD_OPIN definition | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |
| RESTATE definition | 8-K Item 4.02 or a 10-K/A that restates the financial statements |

Deviations recorded for this battery: none: AUD_OPIN and RESTATE coded as the design defines them.

### 4.3 H1–H3

| hypothesis | layer_score | firm-years / firms / sets | fraud firm-years | OR per SD [95 % CI] | p (model-based) | p Holm | OR 95 % CI, firm-clustered | p firm-clustered | p Holm, firm-clustered | direction | supported (design rule: direction + Holm p < 0.05) | supported with firm-clustered SE |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| H1 | L1_SCORE | 187 / 63 / 17 | 53 | 1.61 [1.04, 2.49] | 0.031 | 0.062 | [0.77, 3.38] | 0.206 | 0.459 | as predicted | no | no |
| H2 | L2_SCORE | 517 / 117 / 25 | 107 | 0.80 [0.63, 1.02] | 0.075 | 0.075 | [0.49, 1.31] | 0.374 | 0.459 | OPPOSITE | no | no |
| H3 | L3_SCORE | 284 / 71 / 18 | 81 | 1.70 [1.22, 2.37] | 0.002 | 0.006 | [0.82, 3.51] | 0.153 | 0.459 | as predicted | yes | no |

Both error estimates are shown because the design asks for firm-clustered errors and the first battery reported model-based ones. The firm-clustered errors are about twice the model-based ones: the layer scores change little from year to year within a firm (CEO duality rarely changes; amounts are stated in the same firms each year), so the five years of one firm are far from five independent observations. The firm-clustered column is the design's test.

### 4.4 H2 re-runs and the single characteristics

| hypothesis | variant | layer_score | firm-years / sets | OR per SD [95 % CI] | p | p firm-clustered |
|---|---|---|---|---|---|---|
| H2 | without disclosure-only cases (design re-run) | L2_SCORE | 338 / 17 | 0.72 [0.53, 0.99] | 0.042 | 0.270 |
| H2 | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE | 469 / 24 | 0.85 [0.66, 1.11] | 0.240 | 0.522 |
| H2 | all cases, firm-years with both disclosure characteristics observed (robustness) | L2_SCORE | 515 / 25 | 0.81 [0.63, 1.03] | 0.088 | 0.395 |
| H1 | single characteristic | RP_LEND | 58 / 8 | 0.96 [0.32, 2.85] | 0.942 | 0.962 |
| H1 | single characteristic | RP_PAY | 55 / 8 | 1.17 [0.56, 2.46] | 0.678 | 0.678 |
| H1 | single characteristic | RP_PURCH | 74 / 9 | 0.69 [0.26, 1.81] | 0.452 | 0.450 |
| H2 | single characteristic | RP_INCOMP | 517 / 25 | 0.75 [0.57, 0.99] | 0.039 | 0.346 |
| H2 | single characteristic | RP_VAGUE | 515 / 25 | 0.95 [0.75, 1.21] | 0.691 | 0.800 |
| H3 | single characteristic | BRD_NONIND | 54 / 6 | 3.38 [1.12, 10.20] | 0.031 | 0.376 |
| H3 | single characteristic | DUAL | 262 / 17 | 1.51 [1.08, 2.10] | 0.015 | 0.267 |

### 4.5 H4 by event year (conditional logit primary)

| event_year | layer_score | n_firm_years | n_matched_sets | mean_fraud | mean_matched | OR per SD | p | p firm-clustered | Mann–Whitney p (supplementary) |
|---|---|---|---|---|---|---|---|---|---|
| -5 | L1_SCORE | 21 | 7 | 0.547 | 0.564 | 1.006 | 0.99 | 0.99 | 0.524 |
| -5 | L2_SCORE | 98 | 22 | 0.458 | 0.524 | 0.67 | 0.154 | 0.222 | 0.933 |
| -5 | L3_SCORE | 43 | 13 | 0.565 | 0.492 | 1.566 | 0.375 | 0.447 | 0.092 |
| -4 | L1_SCORE | 22 | 7 | 0.526 | 0.483 | 26.08 | 0.092 | 0.522 | 0.335 |
| -4 | L2_SCORE | 89 | 20 | 0.446 | 0.507 | 0.72 | 0.224 | 0.212 | 0.916 |
| -4 | L3_SCORE | 49 | 15 | 0.568 | 0.499 | 1.367 | 0.415 | 0.393 | 0.115 |
| -3 | L1_SCORE | 25 | 9 | 0.46 | 0.451 | 2.38 | 0.207 | 0.245 | 0.504 |
| -3 | L2_SCORE | 95 | 22 | 0.481 | 0.506 | 1.027 | 0.916 | 0.916 | 0.704 |
| -3 | L3_SCORE | 58 | 17 | 0.634 | 0.49 | 1.816 | 0.088 | 0.091 | 0.005 |
| -2 | L1_SCORE | 29 | 9 | 0.522 | 0.427 | 5.473 | 0.075 | 0.225 | 0.084 |
| -2 | L2_SCORE | 95 | 22 | 0.436 | 0.506 | 0.715 | 0.231 | 0.314 | 0.937 |
| -2 | L3_SCORE | 55 | 16 | 0.567 | 0.477 | 1.566 | 0.205 | 0.216 | 0.117 |
| -1 | L1_SCORE | 24 | 7 | 0.499 | 0.472 | 1.217 | 0.751 | 0.76 | 0.355 |
| -1 | L2_SCORE | 85 | 21 | 0.448 | 0.515 | 0.879 | 0.64 | 0.697 | 0.929 |
| -1 | L3_SCORE | 42 | 14 | 0.518 | 0.459 | 1.561 | 0.327 | 0.429 | 0.077 |

| layer_score | design_rule_met_before_final_year | years_significant | tests_run |
|---|---|---|---|
| L1_SCORE | False |  | 5 |
| L2_SCORE | False |  | 5 |
| L3_SCORE | False |  | 5 |

### 4.6 H5 — Model A versus Model B with the design's AI risk score; timing at an equal false-alarm rate

| Quantity | Value |
|---|---|
| Model A (TRAD_INDEX + LEV + ROA), leave-one-set-out AUC | 0.448 |
| Model B (Model A + AI_SCORE), leave-one-set-out AUC | 0.519 |
| Gain B − A [set-bootstrap 95 % CI] | 0.071 [0.016, 0.123] |
| TRAD_INDEX alone (AUC) / AI_SCORE alone (AUC) | 0.603 / 0.528 |
| AI_SCORE in Model B, pooled logit, firm-clustered: coefficient per SD, OR 95 % CI, p | 0.167, 0.86-1.62, 0.296 |
| AI_SCORE in Model B, conditional logit: coefficient per SD, p (model-based), p (firm-clustered) | 0.294, 0.024, 0.188 |
| Firm-years / fraud firm-years / sets in Models A and B | 598 / 112 / 31 |
| AI rule at 5 % false-alarm rate: threshold, matched-firm rate, cases flagged / never flagged | 7.92, 0.051, 2 / 29 of 31 |
| Traditional rule at ≤ 5 % false-alarm rate | TRAD_INDEX >= 3 (matched-firm rate 0.014), flags 3 cases |
| AI rule at the SAME false-alarm rate: threshold, rate, cases flagged | 8.54, 0.014, 0 |
| Timing at equal false-alarm rate: AI earlier / same year / traditional earlier / neither flags | 0 / 0 / 3 / 28 |
| Union of the two rules: false-alarm rate, cases flagged; AI alone at that rate; traditional alone at that rate | 0.027, 3; 0; 3 (TRAD_INDEX >= 3) |

Design rule for H5:

| criterion | met |
|---|---|
| AI_SCORE significant in Model B (pooled, firm-clustered) | False |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) | True |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate) | False |

Lead time, worded as the review asks — the earliest window year in which the AI risk score separated the fraud firm from its matched firms (5 % matched-firm rate), beside the cases never flagged:

| case | stratum | earliest_window_year_separated_from_matched_firms | ai_years_flagged_5pct | window_years |
|---|---|---|---|---|
| AMERICAN_ELECT | disclosure_only |  | 0 | 5 |
| AMERICAN_EQUIT | disclosure_only |  | 0 | 5 |
| AMMO_INC_OUTDO | core |  | 0 | 5 |
| AULT_ALLIANCE | core |  | 0 | 5 |
| CEMTREX | core |  | 0 | 5 |
| CHINA_VALVES_T | core |  | 0 | 5 |
| CORPORATE_RESO | core |  | 0 | 4 |
| CO_DIAGNOSTICS | core |  | 0 | 5 |
| EAGLE_BANCORP | core |  | 0 | 5 |
| ENERGY_XXI | disclosure_only |  | 0 | 5 |
| FAT_BRANDS | core |  | 0 | 5 |
| FIRST_BANCORP_ | disclosure_only |  | 0 | 5 |
| GENERAL_EMPLOY | core |  | 0 | 5 |
| GULFPORT_ENERG | disclosure_only |  | 0 | 5 |
| IDEANOMICS_SEV | core |  | 0 | 5 |
| MANITEX_INTERN | core |  | 0 | 5 |
| MAXIMUS | disclosure_only |  | 0 | 5 |
| MUSCLEPHARM | core | -4.0 | 2 | 4 |
| OCWEN_FINANCIA | core |  | 0 | 5 |
| PREMIER_HOLDIN | core |  | 0 | 5 |
| PROVECTUS_BIOP | core |  | 0 | 5 |
| PUDA_COAL | core |  | 0 | 4 |
| QUADRANT_4_SYS | core | -5.0 | 3 | 5 |
| RCI_HOSPITALIT | disclosure_only |  | 0 | 5 |
| SAEXPLORATION_ | core |  | 0 | 5 |
| SHIFT4_PAYMENT | disclosure_only |  | 0 | 5 |
| SINGULARITY_FU | core |  | 0 | 5 |
| SKECHERS_U_S_A | disclosure_only |  | 0 | 5 |
| THE_GREENBRIER | disclosure_only |  | 0 | 5 |
| UNITED_DEVELOP | core |  | 0 | 5 |
| VALEANT_PHARMA | core |  | 0 | 5 |

### 4.7 P1 (descriptive, no significance claim)

| index | form_group | lending_sum | lending_count | sales_sum | sales_count | purchases_sum | purchases_count |
|---|---|---|---|---|---|---|---|
| 0 | both | 1 | 1 | 1 | 1 | 1 | 1 |
| 1 | corporate | 8 | 15 | 5 | 15 | 8 | 15 |
| 2 | disclosure-only (not in P1) | 4 | 10 | 1 | 10 | 3 | 10 |
| 3 | managerial | 3 | 5 | 1 | 5 | 1 | 5 |

### 4.8 A1–A3 on the design score

A1 — share of each firm-year's AI risk score by layer and characteristic (direct arithmetic; per firm-year in `a1_attribution_by_firm_year.csv`, with the named evidence, e.g. 'mainly DUAL and RP_INCOMP'):

| index | Unnamed: 0 | mean_share_all_firm_years | mean_share_fraud_firm_years | mean_share_flagged_fraud_firm_years |
|---|---|---|---|---|
| 0 | share_L1 | 0.124 | 0.165 | 0.0 |
| 1 | share_RP_LEND | 0.026 | 0.062 | 0.0 |
| 2 | share_RP_PAY | 0.035 | 0.057 | 0.0 |
| 3 | share_RP_SALES | 0.018 | 0.014 | 0.0 |
| 4 | share_RP_PURCH | 0.045 | 0.032 | 0.0 |
| 5 | share_L2 | 0.532 | 0.454 | 1.0 |
| 6 | share_RP_INCOMP | 0.276 | 0.2 | 0.51 |
| 7 | share_RP_VAGUE | 0.256 | 0.255 | 0.49 |
| 8 | share_L3 | 0.287 | 0.322 | 0.0 |
| 9 | share_BRD_NONIND | 0.048 | 0.069 | 0.0 |
| 10 | share_DUAL | 0.238 | 0.252 | 0.0 |

A2 — the division recalculated with each matched set left out in turn:

| quantity | value |
|---|---|
| firm_years | 862 |
| spearman_ai_score_full_vs_loso | 0.9994508498846516 |
| mean_abs_ai_score_change | 0.0378095768358698 |
| median_max_abs_layer_share_change | 0.0015330605510697 |
| share_largest_layer_unchanged | 0.9895591647331786 |
| share_named_evidence_unchanged | 0.980278422273782 |
| method | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

A3 — reading against theory, three design layers, fraud firm-years flagged by the AI rule:

| layer | agency_idea | mean_fraud | mean_matched | direction | flagged_fraud_firm_years_where_largest | flagged_fraud_firm_years | flagged_cases |
|---|---|---|---|---|---|---|---|
| L1 | financial (conflict of interest) | 0.51 | 0.476 | fraud firms higher (as predicted) | 0 | 5 | 2 |
| L2 | disclosure (information asymmetry) | 0.454 | 0.511 | fraud firms LOWER (against the prediction) | 5 | 5 | 2 |
| L3 | governance (weak monitoring) | 0.572 | 0.483 | fraud firms higher (as predicted) | 0 | 5 | 2 |

### 4.9 Power restated for the final sample

| matched_sets | odds_ratio_per_sd | power | reps | peers_per_set | years | firm_icc |
|---|---|---|---|---|---|---|
| 21.0 | 1.5 | 0.71 | 100.0 | 5.0 | 5.0 | 0.5 |
| 21.0 | 1.65 | 0.9 | 100.0 | 5.0 | 5.0 | 0.5 |
| 21.0 | 2.0 | 0.98 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 1.5 | 0.93 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 1.65 | 0.97 | 100.0 | 5.0 | 5.0 | 0.5 |
| 30.0 | 2.0 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 1.5 | 0.92 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 1.65 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |
| 40.0 | 2.0 | 1.0 | 100.0 | 5.0 | 5.0 | 0.5 |

Simulation under the conditional-logit model with five matched firms, five window years per firm, the layer score observed throughout and a within-firm correlation of 0.5, tested with firm-clustered errors at the 5 % level in the predicted direction (100 replications per cell). It replaces the design's 40-case figure. Because the layer tests actually use 16–24 informative sets and a fraction of the firm-years (amounts stated in 22 % of firm-years; board or duality in 32 %), their power is nearer the 21-set rows than the 30-set rows and lower where firm-years are missing. Non-significant results (H1 with firm-clustered errors, H5, the disclosure layer in H4) remain weak evidence of no difference.

## 5. M2 reliability — delivered for human coding

`data/M2_coding_workbook.xlsx`: 2,075 rows (10 % per variable, drawn at random on 8 October), one sheet per variable, the machine value and its evidence passage beside an empty `human_value` column, dropdowns for binary items, instructions and a line for the agreed threshold and signature. `python scripts/make_m2_workbook.py score --workbook …` computes Cohen's kappa for binary items and the share of amounts within 10 % (with bootstrap intervals) once the sheet is filled. The assistant's earlier figures (kappa ≥ 0.70; 90 % of amounts within 10 %) are a proposal only. Until M2 is done every result above rests on rule-based coding with evidence attached.

## 6. Exploratory section (kept apart from the design tests)

Everything here uses the fitted 36-input ensemble score or measures found after looking at the data. **The fitted score contains the traditional signals** (ICFR flags, going-concern opinion, auditor change, restatement, Big-4 status) and general financial ratios, so it cannot test whether the RPT layers add to the benchmark and plays no part in H5.

- Fitted score (trained on the 30 sets before Gulfport; Gulfport's firm-years unscored): AUC 0.66 alone; Model A + fitted score 0.57 against Model A 0.47; at its 5 % matched-firm threshold it flags 7 of 30 cases and never flags 24.
- First-battery results on the 21 core cases (unchanged, now exploratory): ensemble AUC 0.73 [0.63, 0.83]; 9 of 21 cases flagged, 12 never flagged; external validation on ten unseen three-report cases AUC 0.73; stress tests T1–T5; peer-text distance and year-on-year drift higher in fraud firm-years. Tables in `docs/run3_results/`.
- The 'abnormality' reading of the disclosure layer (drift, distance from peers) is an exploratory observation, not a restatement of H2.

## 7. H2 and H5 — what the results mean and the options (for discussion; nothing changed)

**H2.** Fraud firms' related-party text is, if anything, more complete and plainer than their matched firms'. Three readings, none of which changes the hypothesis: (i) the efficient-transaction prediction set out in design §11.1 — disclosure characteristics do not mark harmful RPTs; (ii) part of the reversal is the coding convention for 'no transactions' texts (§4.1); dropping those firm-years leaves a null; (iii) fraud firms *have* related-party transactions to describe, matched firms often do not, so completeness partly measures the presence of RPTs. The thesis can report (i) as the finding and (ii)–(iii) as the limits of the measure. If the researcher wants a disclosure measure that is not confounded by presence, it would be a new exploratory measure, labelled as such.

**H5.** The rank-averaged score mixes a layer that works in the predicted direction (governance), one that is observed in a third of firm-years (financial) and one that works against the prediction (disclosure); averaged, it does not add to the four traditional signals. Options for discussion: (a) report as is — the honest outcome of the design; (b) a pre-specified variant in the thesis's robustness section, e.g. the governance layer alone against the traditional index, clearly labelled as post hoc; (c) the fitted score as exploratory evidence that a model with more inputs separates fraud firms, without claiming added value over the benchmark. The assistant recommends (a) with (c) as the exploratory section, and will not implement (b) without the researcher's decision.

## 8. Wording adopted throughout

- Results are associations within matched sets; they identify fraud already under way, not fraud before it begins.
- 'Lead time' is the earliest window year in which the measure separated the fraud firm from its matched firms, always reported beside the number of cases never flagged.
- The 5 % matched-firm rate is a threshold fixed by construction, not an accuracy result; matched firms are not known to be clean.
- 'Supported' means direction as predicted and Holm-adjusted p < 0.05 with the design's firm-clustered errors.

## 9. Files

- Design battery: `scripts/design_tests_v2.py`; outputs `outputs/full_all/design_tests_v2/<sample>/` (summary.md and the CSVs named in this document; copies under `docs/design_tests_v2/`): `main31` (the main sample), `core21`, `all30`, `all36_threereport` and `main31_rankall`.
- Coding: `rpt_panel/inference_stats.py` (firm-clustered conditional logit), `rpt_panel/governance_coder.py` (modified-opinion rule), `scripts/code_audit_opinions.py` → `data/audit_opinions*.csv`; `SEC-EDGAR-Downloader/scripts/tenka_restatements.py` → `data_core/tenka_restatements.csv` (every 10-K/A read).
- Sample: `cases_core.csv` (31 cases + 145 matched firms; Gulfport and its peers merged from `cases_gulfport.csv` / `data_gulf/` by `scripts/merge_build_into_core.py`); `cases_sensitivity.csv` (three-report cases); screening report `docs/REPORT_Candidate_Screen_2026-10-08.docx`.
- M2: `data/M2_coding_workbook.xlsx`, `scripts/make_m2_workbook.py`.
- Thesis chapters regenerated on these results: `docs/THESIS_Methodology_and_Results.docx`; companies: `docs/THESIS_Companies_Used_in_the_Research.docx`.
