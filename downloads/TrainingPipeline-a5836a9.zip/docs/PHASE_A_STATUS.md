# Phase A status — sample construction (7 October 2026, evening)

## Method so far
1. **Candidate sources.** (a) The 2 October workbook (39 firms). (b) Text sweep of every SEC AAER release 2005–2024 (2,383 releases, PDFs extracted; releases with ≥ 3 related-party expressions reviewed). (c) EDGAR full-text search for issuers disclosing an SEC related-party action or investigation in their own 10-K/8-K/10-Q text (1,354 issuers matched, 89 on ≥ 2 query families, snippets under review). Candidate file: `SEC-EDGAR-Downloader/scripts/candidates_v02.csv` (52 rows).
2. **CIK verification and 10-K history** from EDGAR submissions for every candidate (`scripts/candidates_edgar_check.csv`).
3. **Revelation dates (D2)** from EDGAR full-text search of each firm's own filings (Item 4.02 non-reliance, audit-committee investigations, auditor resignations) plus documented public reports; each date carries a confidence level (`scripts/phase_a2_revelation_dates.py`, `scripts/phase_a_screen_v2.csv`).
4. **Universe (D10)**: all 12,615 EDGAR registrants in the candidates' 33 SIC codes (`scripts/universe_ciks_by_sic.csv`) with total assets by calendar year from the XBRL frames API, 4,611 firms with XBRL data from 2009 (`scripts/universe_assets_fy.csv`).

## Current screen (provisional revelation dates)

| Status | n | Firms |
|---|---|---|
| INCLUDE (accounting misstatement / misappropriation via RPT, ≥ 4 pre-revelation 10-Ks, window ≥ 2005) | 18 | Ault, Co-Diagnostics, Eagle Bancorp, Ocwen, Valeant, Manitex, Puda Coal, General Employment, SAExploration, Ideanomics, UDF IV, FAT Brands, MusclePharm, China Valves, Cemtrex, Quadrant 4, Provectus, Corporate Resource Services |
| CONFIRM_D1 (data fine; RPT centrality to confirm from the order) | 4 | Singularity Future Tech, Ammo/Outdoor Holding, Live Ventures, Northwest Biotherapeutics |
| STRATUM_DISCLOSURE_ONLY (kept as separate stratum, user decision 7 Oct) | 8 + Gulfport | Skechers, AEP, RCI Hospitality, Greenbrier, Energy XXI, Maximus, Shift4, First Bancorp NC; Gulfport needs a revelation date |
| FAIL_4_REPORTS (too few 10-Ks before revelation) | 13 | ProPetro, China Natural Gas, Ener1, Apple REIT Nine, China North East Petroleum, HLSS, ARCP, RINO, iFresh, ChinaCast, BioElectronics, HF Foods, Longfin |
| PRE_2005_WINDOW → extended tier (Layers 1 and 3 only) | 1 + sweep finds | infoUSA; plus Adelphia, Hollinger, Tyco, Enron, Refco, Buca, Natural Health Trends, Escala, Krispy Kreme, UTStarcom, Dyadic, Quest Resource |
| New leads being screened | 7 | China Ruitai, Prime Global Capital, RCS Capital, Whitney Information Network, and the 89-issuer discovery list |

**Gap to the design's 40 core cases: about 18 firms.** Three ways to close it, in order of preference: (1) finish the 89-issuer discovery review (expected to yield 5–15 post-2005 cases); (2) relax the four-report rule to three for firms whose fourth report is a 10-KSB or a transition report (adds China Natural Gas, Ener1, ARCP, HLSS, ChinaCast, iFresh, HF Foods as a sensitivity set); (3) accept a core of 25–30 with six peers each, as the design's §12 anticipated.

## Confidence of revelation dates
14 high (dated SEC filing or order), 22 medium (documented public event, URL to attach), 9 low (SEC action date as placeholder). All medium/low dates are listed with the verification needed in `phase_a_screen_v2.csv`; they must be confirmed before labels are final.

## Discovery review outcome (7 Oct, late)
- Issuer-filing discovery (89 issuers on ≥ 2 query families): no additional enforcement cases — the matches were boilerplate co-occurrences of "related party" and "SEC". Route closed.
- AAER 2005–2013 sweep: issuer cases found are pre-2005-window (UTStarcom, Dyadic, Quest Resource, Escala, Buca, NHTC, Adelphia, Hollinger, Tyco, Enron, Refco) → extended tier; China Ruitai (2013) to screen.
- CONFIRM_D1 resolved: Singularity (AAER-4557, related-party loan misaccounting) and Ammo (LR-26446 complaint: undisclosed de facto executive, undisclosed RPTs, restatement) → core; Live Ventures (not RPT) and Northwest Biotherapeutics (ICFR-only order) → excluded.
- Peer matching (D4) run: 127 of 129 rule-matched peers have ≥ 4 10-Ks in the window; four pre-XBRL-window cases matched with XBRL-era coverage plus EDGAR verification; Puda Coal matched on a hand-collected FY2010 size anchor.
- **Draft sample (`cases_core_draft.csv`): 20 core + 8 disclosure-only cases, ~130 peers.**
- Final discovery lever in progress: full-text sweep of all 5,086 SEC litigation releases 2010–2025 for related-party cases (civil actions are not in the AAER list).

## Phase A result (8 October 2026, 00:00)

`cases_core.csv` (dataset repo, copied to the training repo): **30 cases — 21 core + 9 disclosure-only — and 140 peers** (five per case by rule D4; four cases matched at the 2-digit SIC level because their 4-digit industries are thin; Puda Coal and American Equity on hand-collected / 2011 size anchors with EDGAR-verified 10-K coverage).

Discovery was exhausted at four systematic sources: the 2 Oct workbook, every AAER release 2005–2024 (2,383 texts), every SEC litigation release 2010–2025 (5,086 texts), and issuers' own filings (EDGAR full-text search). The last two added American Equity (disclosure stratum) and Premier Holding (core). Cases that fail the four-report rule once true revelation dates are used (17) are kept in `phase_a_screen_v2.csv` as the sensitivity set; pre-2005-window cases (13) form the extended tier for Layers 1 and 3.

**Against the design's 40 core cases: 21 core are available with ≥ 4 pre-revelation 10-Ks and windows after 2004.** The design's §12 anticipated this ("six of 31 did not have four annual reports"); the closure plan's response applies: core of 21 with five peers each (≈ 630 firm-years), the 17-case sensitivity set with a three-report rule, and the extended tier as robustness for the financial and disclosure layers. Power at 21 × 5 ≈ 105 fraud firm-years should be restated in the thesis.

Revelation-date confidence among the 30: 15 high, 9 medium, 6 low. Medium and low dates carry a `verify` note; they do not block the data build (the builder caches filings for the full 2004–2024 span, so a corrected date only re-labels).

## Next
- Review discovery snippets; add confirmed cases; read the four CONFIRM_D1 orders.
- Attach URLs to medium-confidence dates; search filings for the low-confidence ones.
- A4 matching: for each case, five peers from the universe by rule D4 (SIC-4 → SIC-3, nearest ln assets at FY(revelation − 1), 10-K every window year, no AAER match).
- Produce `cases_core.csv` and run the builder.
