# Early training results — pilot universe, FY2004–2024

Date: 8 October 2026, 08:15. Run: `python main.py all --config rpt_panel.hub_pilot2004.json`; outputs in `outputs/hub_pilot_2004/`. Dataset: the build that is currently on the Hub (`codewithdark/SEC-RPT-Panel`, version 2.0.0), which is the **pilot** cases file (five anchors and their hand-picked competitors), extended to FY2004–2024 by the 7 October Colab run. It is **not** the confirmatory sample: only 7 of the 170 firms in `cases_core.csv` are in it. The 170-firm build is running locally and its results follow in the main report.

These numbers are therefore an early, low-power reading of the pipeline on real filings. They are not thesis results.

## 1. Sample actually modelled

| | |
|---|---|
| Firm-years in the panel (primary 10-Ks, FY2004–2024) | 384 |
| Firms / clusters | 24 / 4 (Gulfport and its SIC-1311 peers are absent from this build) |
| Training firm-years (event time −5 … −1) | 107 |
| Positive (case) firm-years | 17 |
| RPT text source | DEF 14A 307, Item 13 body 32, RP note 4, none 41 |
| Features after dropping all-missing | 28 of 38 |

Dropped for missingness: the XBRL related-party amounts (`rpt_to_revenue`, `rp_receivables_to_assets`, `rp_sales_ratio`, `abnormal_rp_sales` and their z-scores: tagged in 3–14 % of firm-years only), `restatement_proxy`, and the four hand-collected governance variables (no governance file in this run; the rule-based coder built today fills `big4`, `ceo_duality`, `board_indep`, `ac_indep`, `auditor_change`, `going_concern_opinion` in the full run).

## 2. Discrimination (out-of-fold, leave-one-cluster-out)

| Model | OOF AUC | 95 % cluster-bootstrap CI | PR-AUC (prevalence 0.16) |
|---|---|---|---|
| Logit (pre-specified primary) | 0.37 | 0.12 – 0.50 | 0.16 |
| Random forest | 0.68 | 0.36 – 0.95 | 0.46 |
| XGBoost | 0.68 | 0.40 – 0.93 | 0.48 |
| Ensemble (mean probability; alert score) | 0.60 | 0.29 – 0.83 | 0.27 |
| Text TF-IDF only (nested) | 0.52 | 0.42 – 0.65 | 0.18 |

Reading: with four clusters each fold tests one case firm and its peers against a model trained on the other three. The tree models separate case from peer firm-years modestly (0.68) with intervals that include 0.5; the logit is below chance, which with 28 features on 107 rows and four folds is over-fitting, not a signal that the relationship is inverted. The text-only score is at chance. **Nothing here approaches the 80–85 % discussed earlier**, and nothing should be expected to on four clusters.

## 3. Stress tests

| Test | Result | Verdict |
|---|---|---|
| T1 specificity (H4): case-minus-peer vagueness gap, RPT text minus Item 1 | +0.044, Holm p = 0.088 | direction as hypothesised, not significant |
| T2 ablation (H2): AUC change when Layer 3 is removed | logit +0.15 (removing text *helps* the logit); RF −0.06; XGB −0.03 | disclosure layer carries the tree models' signal, destabilises the logit |
| T3 lead time (H3): first OOF alert to revelation at the 5 % clean-firm threshold | Ault 44 months (FY2019), Co-Diagnostics 7 months (FY2022); Skechers and ProPetro never flagged | 2 of 4 cases alerted early |
| T4 material-weakness persistence | Fisher p = 0.999 | no difference |
| T5 clean-firm FPR at threshold 0.646 | 4 / 90 = 4.4 % | passes the ≤ 5 % target by construction |

The T2 pattern is the most useful thing in this run: dropping the disclosure layer costs the tree models 3–6 AUC points and, in the random-forest ablation, dropping controls only collapses AUC to 0.43. The signal is in the RPT text and the ICFR flags, not in the size/age controls.

## 4. Explainability

- **Top attributions (mean |SHAP|, logit):** `rpt_indeterminate_ratio` (indeterminate quantifiers in the RPT text), `rpt_peer_text_distance` (the lexicon-free distance of the firm's RPT text from its peers' centroid; the novel feature), `listing_age`, `icfr_not_effective`, `rpt_fog_z`. For the tree models the ranking is dominated by the same text and ICFR features (full table: `explainability/attribution.csv`).
- **Stability:** RF and XGB rank features alike (Spearman 0.90); logit agrees with them only moderately (0.49). Within-model bootstrap rankings are stable (0.96–0.99).
- **Traceability:** 80 % of top-3 attributions (84 % for case firm-years) trace to a located filing passage or XBRL tag.
- **Text model vocabulary:** the risk-side terms are generic (`total compensation`, `license agreement`, `pursuant`, `accrued`) but two tokens — `jeffrey`, `dr` — show that the ≥ 3-firm vocabulary rule is not enough on a 24-firm panel; on the 170-firm build the rule binds harder, and a first-name stop list is being added as a precaution.

## 5. Mediation (P4, 1,000 cluster-bootstrap resamples)

No indirect effect is distinguishable from zero (all CIs include 0; e.g. material weakness → agency masking → label: indirect 0.28, CI −0.43 to 1.86). Two of six paths were skipped for insufficient data (related-party revenue is tagged in too few firm-years). Expected on 100 rows; reported for completeness.

## 6. What this early run tells us about the full run

1. The pipeline runs end to end on real filings without leakage (firm-level fold assertion, nested text stacking, fold-local imputation).
2. Discrimination is real but weak at 4 clusters; the 21-cluster core sample is the first test with any power.
3. Layer 1 as designed (XBRL related-party amounts) is mostly empty in SEC company-facts data; the full run will rely on the generic financial ratios plus the text and monitoring layers, and the RP-amount coder (hand/LLM) remains a Phase B task.
4. Layer 2 will be populated by the rule-based coder (pilot coverage: Big-4 94 %, auditor change 84 %, going-concern 100 %, CEO duality 63 %, audit-committee independence 44 %, board independence 18 % of firm-years), with a 10 % hand check still required before publication.

Figures: `outputs/hub_pilot_2004/figures/` (ROC, calibration, scores by event time, per-case SHAP waterfalls, z-score heatmap, drift).
