## Appendix 3.B — Glossary of terms, statistics and notation

| Term | Meaning in this study |
|---|---|
| Related party transaction (RPT) | A transaction between the reporting firm and a party that controls it, is controlled by it, or is one of its directors, officers, principal shareholders or their close family or affiliated entities (ASC 850; Regulation S-K Item 404). |
| AAER | SEC Accounting and Auditing Enforcement Release: the SEC's publication of an enforcement action involving accounting or auditing matters. |
| Litigation release (LR) | The SEC's publication of a civil court action; many RPT fraud cases appear here without an AAER. |
| Case firm / matched firm | A firm named in an RPT-related enforcement action / a firm from the same industry and size band with no enforcement, selected by rule D4. |
| Matched set (cluster) | One case firm and its matched firms; the unit of resampling and of cross-validation. |
| Firm-year | One annual report of one firm; the unit of analysis. |
| Event time | Fiscal year minus the revelation year; the window is event time −5 to −1. |
| Revelation date | First public event revealing the problem (8-K non-reliance, investigation, auditor resignation, short report, restatement or SEC action). |
| Primary filing | The first original annual report filed for a firm-year (amendments and duplicates are excluded). |
| Compustat fiscal-year rule | A fiscal year ending in January–May is assigned to the previous calendar year. |
| CIK | The SEC's Central Index Key, the firm identifier used throughout. |
| SIC | Standard Industrial Classification code (four digits); matching falls back to three and two digits. |
| XBRL company facts | Machine-readable financial statement values filed with the SEC (FY2009+); values are taken as first reported. |
| XBRL frames | Cross-sectional XBRL values (here total assets) for all registrants in a period; used for the matching universe. |
| Item 1 / 9A / 13 | Sections of Form 10-K: Business; Controls and Procedures (internal control over financial reporting); Certain Relationships and Related Transactions. |
| DEF 14A | The definitive proxy statement, which contains board, committee and related-person disclosures. |
| 8-K Item 4.01 / 4.02 | Current-report items for a change in the certifying accountant and for non-reliance on previously issued financial statements (restatement). |
| ICFR / material weakness | Internal control over financial reporting; a material weakness is a deficiency that creates a reasonable possibility of a material misstatement. |
| Big-4 | Deloitte, EY, KPMG, PwC. |
| Going-concern paragraph | Audit-report language raising substantial doubt about the firm's ability to continue as a going concern. |
| Vagueness ratio (V) | Share of words from the uncertainty and weak-modal word lists in the related-party text. |
| Agency masking (A) | Share of clauses whose agent is removed or backgrounded (agentless passive, nominalisation, existential), from a systemic-functional-linguistics analyser. |
| Fog index (F) | Gunning Fog readability: 0.4 × (average sentence length + 100 × share of words with three or more syllables). |
| Relabeling / indeterminate / transparency ratios | Lexicon measures of euphemistic terms, indeterminate quantifiers and fully specified sentences in the related-party text. |
| Drift (ΔV, ΔF) | Year-on-year change of a disclosure measure within the firm. |
| Boilerplate similarity | TF-IDF cosine similarity of the firm's related-party text with its own text a year earlier. |
| Specificity gap | V(related-party text) − V(Item 1) of the same filing. |
| Peer-relative z-score | (x_i − mean of the other firms in the cluster-year) ÷ their standard deviation, leave-one-out, label-free. |
| Peer text distance | 1 − cosine similarity between the firm's TF-IDF vector and the centroid of its cluster-year peers' vectors. |
| TF-IDF | Term frequency × inverse document frequency weighting of words and word pairs. |
| Text risk (stacked) | Out-of-fold probability from a TF-IDF logistic regression on the related-party text, fitted in nested grouped folds with a vocabulary limited to terms used by ≥ 3 firms. |
| Rank-average score | Each characteristic ranked to [0, 1] over all firm-years; layer score = mean of ranks; AI_SCORE = 10 × mean of layer scores (design document, steps 3–5). |
| TRAD_INDEX | Count of the four traditional signals (material weakness, going concern, auditor change, restatement), 0–4. |
| Logistic regression (logit) | Pr(y = 1) = 1 / (1 + exp(−x'β)); coefficients are log-odds; exp(β) is an odds ratio. |
| Conditional (fixed-effects) logit | Logit with a separate intercept per matched set, estimated by conditioning on the number of positives in each set so the intercepts drop out; only sets with both outcomes contribute. |
| Cluster-robust (sandwich) standard errors | Standard errors that allow arbitrary correlation of observations within a firm. |
| Winsorising | Replacing values beyond the 1st/99th percentile with those percentiles. |
| Standardised coefficient / odds ratio per SD | Effect of a one-standard-deviation increase of the predictor. |
| Holm adjustment | Step-down correction for multiple tests: the smallest p is compared with α/m, the next with α/(m−1), and so on. |
| Mann–Whitney U test | Non-parametric test of whether one group's values tend to exceed the other's; one-sided here. |
| Wilcoxon signed-rank test | Non-parametric paired test, used for within-filing differences (RPT text versus Item 1). |
| Fisher's exact test | Exact test of association in a 2×2 table; one-sided here. |
| Random forest | Average of many decision trees fitted on bootstrap samples with random feature subsets. |
| XGBoost | Gradient-boosted decision trees fitted stage-wise to the gradient of the logistic loss. |
| Ensemble (alert score) | Mean of the three models' predicted probabilities. |
| Leave-one-cluster-out (LOGO) | Cross-validation that holds out one matched set at a time. |
| Nested folds | Inner cross-validation inside each training fold, used so the stacked text score never comes from a model that saw the row it scores. |
| Out-of-fold (OOF) | Scores and SHAP values computed for rows by models that did not see them. |
| AUC | Area under the ROC curve = probability that a random positive scores above a random negative. |
| PR-AUC | Area under the precision–recall curve. |
| Cluster bootstrap | Resampling matched sets (or firms) with replacement to obtain percentile confidence intervals. |
| Threshold at 5 % FPR | The score above which at most 5 % of matched firm-years fall; fixed on out-of-fold scores. |
| Lead time | Months from the end of the first flagged fiscal year to the revelation date. |
| SHAP value | Shapley-value decomposition of a prediction into additive feature contributions. |
| Attribution stability | Spearman rank correlation of feature-importance rankings across models and across bootstrap resamples. |
| Traceability | Share of top-3 attributions that resolve to a located filing passage, signature, 8-K, XBRL tag or manifest entry. |
| Mediation (a, b, indirect) | a = effect of x on the mediator; b = effect of the mediator on the outcome given x; indirect = a × b; c′ = direct effect. |
| M1 / M2 / M3 | Measurement checks: coverage; reliability against human coding on a 10 % sample; distinctness of the layer scores. |
| A1 / A2 / A3 | Attribution checks: traceability; stability; reading of the dominant layer against theory. |
| Core / disclosure-only stratum | Cases where the RPT is the mechanism of misstatement or misappropriation / cases charged only for a disclosure failure. |
| External validation set | Ten three-report cases and their matched firms, never used in fitting. |
| Run 1 / 2 / 3 | Successive full runs: unbounded ratios; bounded ratios; bounded ratios plus coded characteristics, 8-K signals and every-year governance (final). |
