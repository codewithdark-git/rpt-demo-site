# Project closure plan — RPT fraud-risk PhD study

*7 October 2026. This is the single path from today to a submitted empirical chapter and a working paper. Domain decisions are made here (section 1) so that no step waits on expertise; the supervisor can veto any of them, and the pipeline parameters change accordingly.*

## 0. Where we are (one paragraph)

Two working codebases exist and are on GitHub: the dataset builder (`DatePreparedPipeline`) and the analysis pipeline (`TrainingPipeline`). They have been run end to end on a 30-firm pilot (5 fraud cases, 25 peers, 292 annual reports) and produce every table and figure the design asks for. The pilot's results are honest and modest (out-of-fold AUC ≈ 0.69 for tree models; two of four cases flagged 43–56 months before revelation; clean-firm false-alarm rate 4.4%). The client's research design of 6 October fixes the variables (eight RPT characteristics in three layers, a four-signal traditional benchmark, two controls) and the sample (40 fraud firms + 200 matched peers, five pre-revelation years). What remains is: the full sample, four small extractors the design needs, one run, and the writing.

## 1. Decisions made now (for supervisor sign-off, not for discussion)

| # | Decision | Rule adopted | Why |
|---|---|---|---|
| D1 | Inclusion rule for fraud firms | SEC enforcement action (AAER or litigation release) in which a related-party transaction is part of the **misstatement or misappropriation**. Disclosure-only cases (undisclosed perquisites/relationships with no accounting effect) are kept in a separate "disclosure-only" stratum and reported as the H2 robustness run, never pooled. | The pilot showed disclosure-only cases leave no trace in filed text (Skechers AUC 0.28); pooling them would dilute every test. |
| D2 | Revelation date | Earliest of: 8-K announcing an internal investigation, auditor resignation (Item 4.01), non-reliance on prior statements (Item 4.02), restatement announcement, or press report of the SEC/DOJ action; failing those, the SEC order date. Source URL recorded per firm. | The design's window starts from "when the fraud became public"; this makes it reproducible. |
| D3 | Window and label | Five fiscal years ending before the revelation fiscal year; `FRAUD = 1` for all five (firm-level, per the design). A sensitivity run uses `misconduct_period`. Firms with fewer than four 10-Ks in the window are dropped. | Follows the design and its §12 check. |
| D4 | Matching | Same 4-digit SIC (3-digit if fewer than five candidates), closest log total assets in the fiscal year before revelation, 10-K on file in every window year, no SEC enforcement of any kind (screened against all AAERs 1999–2026). Five peers per case. | Design §4; the screen uses the builder's matcher. |
| D5 | AI risk score | Each characteristic ranked 0–1 across all firm-years; layer score = mean rank within layer; **AI_SCORE = predicted probability from a three-coefficient logit (the three layer scores) fitted leave-one-matched-set-out**; also reported ×10 as the 0–10 index for descriptive use. | Reconciles §6 (rank average) with §4/H5 (fitted on other firms); keeps predictors at three. |
| D6 | Traditional index | ICFR_MW (Item 9A), AUD_OPIN (going-concern or modified opinion in the audit report), AUD_CHG (8-K Item 4.01), RESTATE (8-K Item 4.02 or 10-K/A restating); TRAD_INDEX = count 0–4. | Design §7. |
| D7 | False-alarm rate for timing (H5) | 5%, set on matched firm-years out-of-fold. | Pilot operated at 4.4%. |
| D8 | Multiple testing | Holm across H1–H3; H4 as one trend test per layer (score × event-time interaction) instead of 15 year-by-year tests; H5 reported unadjusted (one pre-specified test). | Design §10 asks for it; keeps H4 to three tests. |
| D9 | Measurement thresholds | M1: a characteristic is usable if available for ≥ 70% of firm-years in both groups; M2: Krippendorff's α ≥ 0.80 for amounts, ≥ 0.70 for the four disclosure items on a 10% stratified sample; M3: pairwise layer-score correlations < 0.70. | Common thresholds in content-analysis work. |
| D10 | Large universe | All 10-K filers in the fraud firms' 2-digit SIC groups, FY2005–2024, metadata + XBRL for all, raw text only for peers and for the universe scoring subset. Used for matching, industry-year baselines, the external alert rate, and an undetected-case screen — **not** for training labels. | ~40 positives bound what a model can learn; the universe answers the generalisation question instead. |
| D11 | Coding of amounts and disclosure items | LLM-assisted extraction from the related-party note and proxy section (Claude API, structured JSON output), with the 10% human check of D9. Numbers never imputed as zero; "amount not stated" scores the RP_INCOMP item. | Design §4 ("AI reads the filings… human check on a random subsample"). |
| D12 | Statistical model for H1–H3 | Conditional logit within matched sets (each case vs its five peers), controls LEV and ROA, SEs clustered by firm; pooled logit with clustered SEs as the secondary specification. | Design §10; both already implemented. |

## 2. The path, in order

### Phase A — Sample (weeks 1–2)
| Step | Who | Output |
|---|---|---|
| A1 Assemble the candidate list: 31 core + 16 new candidates from the 2 Oct workbook, plus a fresh sweep of AAERs 2010–2026 for "related party" (the builder's AAER manifest already holds 1,016 releases 2014–2024 with PDFs) | me | `candidates.csv` with SEC reference, misconduct years, RPT element, D1 classification |
| A2 Revelation dates by D2, with source URLs; ≥ 4 10-Ks check | me (EDGAR full-text search + 8-K index); you: nothing | `cases_core.csv` (cases only) |
| A3 Universe metadata: all 10-K filers in the cases' SIC-2 groups, FY2005–2024, manifests + XBRL (no raw text) | me, run in Colab (hours) | universe manifest on the Hub |
| A4 Matching by D4 → 5 peers per case | me (new `peers.py` matcher) | `cases_core.csv` with ~200 peers |
| A5 Supervisor sign-off on section 1 and the case list | you (send this document + `cases_core.csv`) | written confirmation |

### Phase B — Data (weeks 2–4)
| Step | Who | Output |
|---|---|---|
| B1 Build the panel: `bash build_and_publish.sh` with `CASES=cases_core.csv START=2005 END=2024` | you, in Colab (≈ 3 h, resumable) | `SEC-RPT-Panel` v2.1 on the Hub |
| B2 Add 8-K Items 4.01/4.02 and audit-report opinion extraction to the builder (AUD_OPIN, AUD_CHG, RESTATE) | me | builder release, re-run of B1 (cached filings, fast) |
| B3 Proxy coder for BRD_NONIND and DUAL (director table, "Chairman and CEO") | me | `governance.csv` in the dataset |
| B4 LLM coder for RP_LEND, RP_PAY, RP_SALES, RP_PURCH amounts and the four RP_INCOMP items from `rp_note.txt` + proxy section (D11) | me (code + run); you: provide an Anthropic API key or run the coder script | `rpt_amounts.csv` with per-field source quotes |
| B5 Reliability check M2: 10% stratified sample hand-coded | you or a research assistant, from a prepared spreadsheet with the quoted passages beside each field (≈ 140 filings × 8 fields; 2–3 days) | α per field; drop or hand-code any field under threshold |
| B6 Universe scoring subset: raw text for every universe firm-year in the window years (for the external alert rate) | me, Colab (2–4 days, resumable) | scored universe table |

### Phase C — Analysis (week 5)
| Step | Who | Output |
|---|---|---|
| C1 Add to the pipeline: rank-based layer scores and AI_SCORE (D5), TRAD_INDEX, H5 Model A/B, H4 trend test, universe alert rate (D10) | me | `TrainingPipeline` release |
| C2 `bash train_full.sh` | you (Colab or any machine, ≈ 1 h) | `outputs/full/`: all tables and figures |
| C3 Interpretation memo: what each hypothesis got, with the limits | me | `docs/RESULTS_MEMO.md` |

Pre-specified result tables (all produced by C2): sample and coverage (M1); reliability (M2); layer correlations (M3); descriptives by group and event year; H1–H3 conditional logits; H4 trend tests and the year-by-year figure; H5 Model A vs B, out-of-fold AUC with cluster-bootstrap CIs, timing comparison at 5% FAR; P1 cross-tabulation; A1 layer attributions, A2 refit stability, A3 dominant layer in flagged firms; universe alert rate by industry-year and the top-scored unflagged firms; robustness: without disclosure-only cases, with `misconduct_period`, peers-only baselines.

### Phase D — Writing (weeks 6–10)
| Deliverable | Content | Source of every number |
|---|---|---|
| Chapter 3 rewrite (methodology) | Sections 1–9 of the design, with D1–D12 as the operational rules; data sources and extraction; the leak-free validation design | `docs/REVIEW_…`, `README`, `dataset_qa.json` |
| Chapter 4 (results) | One subsection per objective: M1–M3, H1–H5, P1, A1–A3, universe alert rate, robustness | `outputs/full/tables/*.tex` and `figures/*.png`, inserted as produced |
| Chapter 5 (discussion and limits) | Three agency ideas against the results; detection not prediction; only disclosed RPTs observed; enforcement = detected fraud; US-only | `docs/RESULTS_MEMO.md` |
| Working paper (≈ 9,000 words) | Compressed Chapters 3–5 with 6 tables and 4 figures | same |
| Data paper / dataset card | SEC-RPT-Panel description, QA, label semantics | Hub README + `dataset_qa.json` |

I draft all four from the pipeline outputs; you and the supervisor edit. The literature chapter (RO1) already exists in the thesis; the only writing it needs is the bridge section the revision plan asked for and the §11.4 gap statement after the wider literature check (a deep-research pass over the five gap claims; half a day).

## 3. What you personally have to do

1. Send section 1 and `cases_core.csv` to the supervisor; collect a yes/no per decision (week 2).
2. Run two commands in Colab when asked (B1, then C2) with your HF token.
3. Arrange the 10% hand-coding check (B5) — 2–3 days of a research assistant's time, or your own; the spreadsheet comes with the quoted passages so no accounting judgement is needed beyond "is the number in this sentence the one in the cell".
4. Provide an Anthropic API key (or run the coder script yourself) for B4.
5. Read and edit the drafts in Phase D.

Everything else — candidate screening, revelation dates, matching, extractors, coders, the analysis, interpretation and the drafts — is on me.

## 4. Timeline and risk

Ten weeks to a complete empirical chapter and working paper, assuming supervisor answers within a week and the two Colab runs happen when asked. Risks and responses:

| Risk | Response |
|---|---|
| Fewer than 40 cases pass D1–D3 | Accept 30–35 cases with six peers each; the power statement in the design is restated at the achieved n. |
| M2 reliability fails for amounts | Hand-code the failing field for all cases and a 1:1 subsample of peers; report coverage honestly. |
| Results are null for H1 or H3 | They are reported as such; the design's §11.5 already says a null is informative. The writing does not depend on a positive result. |
| SEC rate limits slow the universe download | Metadata-first, raw text only for the scoring subset; resumable runs. |

## 5. Definition of done

- `SEC-RPT-Panel` v2.1 on the Hub with the full sample, QA report and dataset card.
- `outputs/full/` regenerated from one command, containing every table in section 2C.
- Chapters 3–5 drafted with every number traceable to a file in `outputs/full/`.
- Working paper draft and dataset card.
- Both repositories tagged `v2.1-confirmatory`.
