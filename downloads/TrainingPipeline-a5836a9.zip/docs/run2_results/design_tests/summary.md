# Design test battery — summary

Training window: 577 firm-years, 102 fraud firm-years, 21 matched sets.

## M1 coverage

| characteristic                                        | layer   | panel_column                         |   coverage_training_window | usable   |
|:------------------------------------------------------|:--------|:-------------------------------------|---------------------------:|:---------|
| RP_LEND (lending to related parties / assets)         | L1      | rp_receivables_to_assets             |                      0.102 | False    |
| RP_PAY (payables to related parties / assets)         | L1      | — not obtainable from XBRL/10-K text |                      0     | False    |
| RP_SALES (sales to related parties / sales)           | L1      | rp_sales_ratio                       |                      0.055 | False    |
| RP_PURCH (purchases from related parties / assets)    | L1      | — not obtainable from XBRL/10-K text |                      0     | False    |
| RP_INCOMP (incompleteness of the disclosure, 4 items) | L2      | — not obtainable from XBRL/10-K text |                      0     | False    |
| RP_VAGUE (vagueness of the RPT text)                  | L2      | rpt_vagueness                        |                      0.879 | True     |
| BRD_NONIND (1 - independent share of the board)       | L3      | board_indep                          |                      0.092 | False    |
| DUAL (CEO chairs the board)                           | L3      | ceo_duality                          |                      0.336 | False    |
| ICFR_MW (traditional signal)                          | TRAD    | material_weakness_reported           |                      0.905 | True     |
| AUD_OPIN (traditional signal)                         | TRAD    | going_concern_opinion                |                      0.971 | True     |
| AUD_CHG (traditional signal)                          | TRAD    | auditor_change                       |                      0.737 | True     |
| RESTATE (traditional signal)                          | TRAD    | restatement_proxy                    |                      0     | False    |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |      0.131 |     -0.114 |
| L2_SCORE |      0.131 |      1     |     -0.01  |
| L3_SCORE |     -0.114 |     -0.01  |      1     |

Columns used per layer: L1: rp_receivables_to_assets, earnings_cash_divergence (substitute), accruals (substitute); L2: rpt_vagueness, rpt_fog (substitute), rpt_agency_masking (substitute); L3: board_indep, ceo_duality

## H1–H3 (conditional logit within matched sets; Holm across three)

| hypothesis   | layer_score   | columns_used                                                                           |   cond_coef |   cond_se |   cond_p |   cond_odds_ratio_per_sd |   cond_n |   cond_clusters |   pooled_coef |   pooled_p |   cond_p_holm | supported   |
|:-------------|:--------------|:---------------------------------------------------------------------------------------|------------:|----------:|---------:|-------------------------:|---------:|----------------:|--------------:|-----------:|--------------:|:------------|
| H1           | L1_SCORE      | rp_receivables_to_assets; earnings_cash_divergence (substitute); accruals (substitute) |       0.114 |     0.16  |    0.475 |                    1.121 |      378 |              17 |         0.094 |      0.591 |         0.475 | False       |
| H2           | L2_SCORE      | rpt_vagueness; rpt_fog (substitute); rpt_agency_masking (substitute)                   |      -0.54  |     0.157 |    0.001 |                    0.583 |      336 |              17 |        -0.455 |      0.023 |         0.002 | False       |
| H3           | L3_SCORE      | board_indep; ceo_duality                                                               |       1.092 |     0.363 |    0.003 |                    2.979 |       89 |               9 |         0.535 |      0.062 |         0.005 | True        |

## H5 Model A vs Model B

| model_A_features        | model_B_features                 |   n |   n_fraud |   loco_auc_model_A |   loco_auc_model_B |   auc_gain_B_minus_A |   AI_SCORE_coef_model_B |   AI_SCORE_p_model_B |   ai_threshold_95pct_matched |   cases_ai_flags_earlier |   cases_same_year |   cases_trad_earlier |   cases_flagged_by_neither |   cases |   loco_auc_model_B2_ml |   auc_gain_B2_minus_A |   ML_SCORE_coef_model_B2 |   ML_SCORE_p_model_B2 |   auc_trad_index_alone |   auc_ml_score_alone_oof |   ml_threshold |   cases_ml_flags_earlier |   cases_ml_same_year |   cases_trad_earlier_than_ml | trad_rule_equal_fpr                       |   trad_ge1_matched_rate |   cases_ml_earlier_equal_fpr |   cases_same_year_equal_fpr |   cases_trad_earlier_equal_fpr |   cases_flagged_trad_equal_fpr |   cases_flagged_ml |
|:------------------------|:---------------------------------|----:|----------:|-------------------:|-------------------:|---------------------:|------------------------:|---------------------:|-----------------------------:|-------------------------:|------------------:|---------------------:|---------------------------:|--------:|-----------------------:|----------------------:|-------------------------:|----------------------:|-----------------------:|-------------------------:|---------------:|-------------------------:|---------------------:|-----------------------------:|:------------------------------------------|------------------------:|-----------------------------:|----------------------------:|-------------------------------:|-------------------------------:|-------------------:|
| TRAD_INDEX+leverage+roa | TRAD_INDEX+leverage+roa+AI_SCORE | 418 |        79 |              0.395 |              0.405 |                 0.01 |              -0.0565716 |             0.755707 |                        7.927 |                        0 |                 0 |                   17 |                          4 |      21 |                  0.644 |                 0.249 |                 0.645793 |            0.00105094 |                  0.597 |                     0.73 |          0.697 |                        2 |                    3 |                           13 | TRAD_INDEX >= 3 (matched-firm rate 0.006) |                   0.251 |                            7 |                           0 |                              1 |                              1 |                  7 |

## H4 by event year (Mann–Whitney, fraud > matched)

|   event_year | layer_score   |   n |   n_fraud |   mean_fraud |   mean_matched |   mannwhitney_p_greater |   cond_coef |   cond_p |
|-------------:|:--------------|----:|----------:|-------------:|---------------:|------------------------:|------------:|---------:|
|           -5 | L1_SCORE      | 112 |        19 |        0.512 |          0.501 |                   0.506 |       0.217 |    0.605 |
|           -5 | L2_SCORE      | 112 |        19 |        0.411 |          0.489 |                   0.927 |      -0.692 |    0.068 |
|           -5 | L3_SCORE      | 112 |        19 |        0.54  |          0.43  |                   0.154 |     nan     |  nan     |
|           -4 | L1_SCORE      | 118 |        21 |        0.499 |          0.442 |                   0.286 |       0.401 |    0.27  |
|           -4 | L2_SCORE      | 118 |        21 |        0.398 |          0.479 |                   0.901 |      -0.524 |    0.143 |
|           -4 | L3_SCORE      | 118 |        21 |        0.434 |          0.431 |                   0.5   |     nan     |  nan     |
|           -3 | L1_SCORE      | 118 |        21 |        0.473 |          0.43  |                   0.338 |       0.274 |    0.349 |
|           -3 | L2_SCORE      | 118 |        21 |        0.446 |          0.493 |                   0.738 |      -0.156 |    0.584 |
|           -3 | L3_SCORE      | 118 |        21 |        0.606 |          0.46  |                   0.121 |     nan     |  nan     |
|           -2 | L1_SCORE      | 118 |        21 |        0.534 |          0.492 |                   0.303 |       0.197 |    0.583 |
|           -2 | L2_SCORE      | 118 |        21 |        0.416 |          0.496 |                   0.952 |      -0.486 |    0.154 |
|           -2 | L3_SCORE      | 118 |        21 |        0.579 |          0.443 |                   0.134 |      20.171 |    0.996 |
|           -1 | L1_SCORE      | 111 |        20 |        0.359 |          0.514 |                   0.983 |      -0.31  |    0.426 |
|           -1 | L2_SCORE      | 111 |        20 |        0.393 |          0.505 |                   0.989 |      -0.901 |    0.038 |
|           -1 | L3_SCORE      | 111 |        20 |        0.381 |          0.435 |                   0.694 |     nan     |  nan     |

## P1 RPT types by form of fraud (cases with a tagged amount in any window year)

| form_group   |   lending_sum |   lending_count |   sales_sum |   sales_count |   any_rpt_amount_sum |   any_rpt_amount_count |
|:-------------|--------------:|----------------:|------------:|--------------:|---------------------:|-----------------------:|
| both/other   |             0 |               1 |           1 |             1 |                    1 |                      1 |
| corporate    |             6 |              15 |           5 |            15 |                    6 |                     15 |
| managerial   |             1 |               5 |           1 |             5 |                    1 |                      5 |

## A3 largest contributing layer in flagged fraud firm-years

| largest_layer    |   firm_years |
|:-----------------|-------------:|
| L3_disclosure    |            7 |
| L2_monitoring    |            3 |
| L4_peer_relative |            2 |
