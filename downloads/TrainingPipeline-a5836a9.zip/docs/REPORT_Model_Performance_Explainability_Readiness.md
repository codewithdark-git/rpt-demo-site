# Model performance, explainability and thesis-readiness — confirmatory sample (runs 1 and 2)

Date: 8 October 2026. Dataset: local build of `cases_core.csv` (170 firms, FY2004–2024, 2,585 filings, built 8 Oct 10:05, `SEC-EDGAR-Downloader/data_core`). Pipeline: `python main.py all --config rpt_panel.full.json --skip-download` (core stratum, leave-one-cluster-out over 21 clusters). **Run 2** (final; asset-scaled ratios bounded at fixed limits, §9) is in `outputs/full/` with its table dump `RESULTS.md` / `RESULTS.docx`; **run 1** (unbounded ratios) is archived in `outputs/full_run1_unbounded/` and `docs/run1_results/`. The all-strata configuration (30 clusters, `outputs/full_all/`) supplies the stratum comparison in §3.4. Where the two core runs differ, both numbers are given as run 2 / run 1; they differ by at most 0.02 on every headline.

## 1. Summary

- **Discrimination is real and moderate.** Out-of-fold AUC (leave-one-cluster-out, 21 clusters), run 2 / run 1: logit 0.69 / 0.71, random forest 0.73 / 0.73, XGBoost 0.72 / 0.73, ensemble alert score 0.73 [0.63, 0.83] / 0.74 [0.64, 0.83]. Every interval excludes 0.5. A nested, lexicon-free TF-IDF model on the related-party text alone reaches 0.67.
- **Not 80–85 %.** On a 21-case matched sample, 0.74 is what the data support. Excluding the three poorly size-matched clusters gives 0.76; restricting to firm-years with related-party text gives 0.75; FY2012–2024 alone gives 0.77. The 80–85 % figure discussed earlier is not reached by any honest cut of this sample.
- **At a 5 % clean-firm false-positive rate the alert flags 7 of 21 cases (run 2; 8 in run 1)** before revelation, median lead 41 / 36 months (range 5–53). The other cases are never flagged at that threshold; within-cluster AUC is ≥ 0.70 for 13 of 21 clusters and below 0.5 for 5.
- **Disclosure-only cases are not detectable with this feature set.** A model trained on all 30 clusters scores the core stratum at 0.70 and the disclosure-only stratum at 0.54 [0.38, 0.70] (§3.4). The model targets misstatement and misappropriation; disclosure omissions leave no trace in the financial, monitoring or text layers used here. This justifies the separate stratum and must be stated as a scope condition.
- **What carries the signal:** the peer-relative layer (dropping it costs XGBoost 8.5 AUC points, random forest 4.7), the related-party text (fog, year-on-year change in fog, peer text distance), Big-4 auditor status and material-weakness history. The novel `rpt_peer_text_distance` is significant within clusters (conditional logit OR 1.86 / 1.83 per SD, p = 0.009 / 0.012).
- **Two design hypotheses are not supported as stated:** H4 specificity (case-minus-peer gap in RPT-versus-Item-1 vagueness: p = 0.25) and P4 mediation (all indirect effects' CIs include zero). T4 is strongly supported (persistent material weakness in 37 % of case firm-years vs 11 % of peer firm-years, p < 0.001).
- **Explainability:** 95 % of top-3 attributions trace to a located filing passage, audit-report signature, XBRL tag or manifest entry (93 % for case firm-years); tree-model attribution rankings are stable (within-model Spearman 0.997) and agree with each other (0.82) but only moderately with the logit (0.45–0.55).
- **Readiness:** the pipeline, data and results are thesis-grade in structure (leak-free, pre-specified, reproducible, traceable), and the headline numbers are stable across the two runs. They are not yet thesis-final: the revelation-date verification, the 10 % hand check of the governance coder, the proxy-for-every-year builder change and the universe scoring must land first (§10).

## 2. Sample modelled

| | |
|---|---|
| Firm-years in the panel (primary 10-Ks, FY2004–2024) | 2,580 |
| Firms / clusters | 170 / 30 (21 core, 9 disclosure-only) |
| Training rows (core clusters, event time −5 … −1) | 577 |
| Positive firm-years | 102 (17.7 %) |
| Related-party text source | DEF 14A 1,374; Item 13 body 675; RP note 134; none 397 |
| Features used | 33 (of 41 candidates; 8 dropped for < 10 % coverage: the four XBRL related-party amount ratios and their z-scores, `restatement_proxy`, `board_indep`) |

Coverage of the layers in the training window: Layer 1 generic ratios 83–88 %; Layer 2 ICFR flags 90 %, Big-4 80 %, auditor change 74 %, going-concern 97 %, CEO duality 34 %, audit-committee independence 22 %; Layer 3 text 88 %; peer-relative z-scores 81–88 %.

## 3. H1 — discrimination (out of fold)

| Model | OOF AUC | 95 % cluster-bootstrap CI | PR-AUC | Per-cluster AUC median (range) |
|---|---|---|---|---|
| Logit (pre-specified primary) | 0.693 (run 1: 0.709) | 0.600 – 0.785 | 0.32 | 0.72 (0.32 – 1.00) |
| Random forest | 0.732 (0.733) | 0.622 – 0.836 | 0.30 | 0.82 (0.15 – 1.00) |
| XGBoost | 0.722 (0.728) | 0.617 – 0.816 | 0.32 | 0.79 (0.17 – 1.00) |
| Ensemble (mean probability; alert score) | 0.730 (0.740) | 0.628 – 0.828 | 0.32 | — |
| Text TF-IDF only (nested, ≥ 3-firm vocabulary) | 0.670 (0.670) | 0.563 – 0.765 | 0.26 | — |

Run-2 values with run-1 values in brackets; CIs and per-cluster ranges from run 2 (run 1 within 0.01).

Figure: `figures/fig_oof_roc.png`. The ROC curves of the four feature-based models lie on top of each other; the text-only curve sits below them but clear of chance.

### 3.1 Per-case detection (ensemble; run-1 threshold 0.688, run-2 threshold 0.697 = 5 % peer FPR)

| Within-cluster AUC ≥ 0.90 | 0.70 – 0.89 | 0.50 – 0.69 | < 0.50 |
|---|---|---|---|
| Corporate Resource Services, Eagle Bancorp, Ammo, FAT Brands, Singularity, Ault, China Valves | Co-Diagnostics, UDF IV, Valeant, General Employment, Manitex, Puda Coal | MusclePharm, Ideanomics, Provectus, Quadrant 4, SAExploration | Cemtrex, Premier Holding, Ocwen |

Flagged before revelation (first flagged fiscal year, months to revelation; run 1): Corporate Resource Services (FY2011, 41), China Valves (FY2007, 50), Provectus (FY2011, 50), FAT Brands (FY2019, 53), Co-Diagnostics (FY2020, 31), Singularity (FY2021, 21), General Employment (FY2013, 19), MusclePharm (FY2011, 5). Run 2 flags the same set except MusclePharm (median lead 41 months). Eagle Bancorp, Ammo and Ault separate perfectly from their own peers (AUC ≥ 0.96) yet never cross the pooled threshold: their whole cluster scores low, which is the argument for a within-cluster (peer-relative) alert rule in the thesis rather than a single pooled cut-off.

Ocwen is the clear failure (AUC 0.21): its peers are size-mismatched by 5 log points and its related-party text comes only from the RP note. It is one of the three clusters pre-specified for the matching-quality robustness run.

### 3.2 Robustness cuts (same OOF scores)

| Cut | Ensemble AUC | n |
|---|---|---|
| All core clusters | 0.740 | 577 |
| Excluding poorly size-matched clusters (Ocwen, Energy XXI, Singularity) | 0.758 | 532 |
| Firm-years with related-party text | 0.746 | 507 |
| Firm-years without text | 0.571 | 70 |
| FY2004–2011 | 0.671 | 131 |
| FY2012–2024 | 0.765 | 446 |
| High-confidence revelation dates (5 clusters) | 0.667 | — |
| Medium (12) / low (4) confidence | 0.755 / 0.790 | — |

The discrimination does not depend on the uncertain dates (if anything it is weaker on the best-dated cases), and it depends heavily on the text being available.

### 3.3 Score profile over event time

Mean ensemble score of case firm-years: 0.47 at t−5, 0.49 at t−4, 0.46 at t−3, 0.43 at t−2, 0.42 at t−1; peers: 0.31 → 0.25. Case scores are elevated throughout the window and do **not** escalate toward revelation; the gap to peers is roughly constant (figure `fig_scores_event_time.png`). For H3 this means the signal is a standing risk profile, not a countdown; the lead-time statistic should be read as "how early the standing profile crosses the threshold".

### 3.4 Case strata (all-strata run: 30 clusters, 833 firm-years, 147 positives, leave-one-cluster-out)

| Stratum | n rows | positives | clusters | Ensemble OOF AUC | 95 % CI | Logit | RF | XGB |
|---|---|---|---|---|---|---|---|---|
| Core (misstatement / misappropriation) | 577 | 102 | 21 | 0.703 | 0.622 – 0.781 | 0.663 | 0.711 | 0.690 |
| Disclosure-only | 256 | 45 | 9 | 0.539 | 0.380 – 0.701 | 0.595 | 0.490 | 0.481 |
| Pooled | 833 | 147 | 30 | 0.650 | 0.567 – 0.732 | 0.642 | 0.644 | 0.622 |

Training on all 30 clusters costs the core stratum three AUC points (0.73 → 0.70) and buys nothing for the disclosure-only stratum, which stays at chance. Source: `outputs/full_all/tables/oof_metrics_by_stratum.csv`.

## 4. Stress tests T1–T5

| Test | Result | Verdict |
|---|---|---|
| T1 specificity (H4) | RPT text is vaguer than Item 1 within cases (mean gap +0.063, p = 0.004) and within peers (+0.048, p < 0.001); case-minus-peer difference +0.015, Mann–Whitney p = 0.25 (Holm 0.25) | vagueness is a property of RPT disclosure in general, not of fraud firms specifically — H4 not supported |
| T2 ablation (H2) | Removing Layer 3 lexicon features: logit +0.049 (improves), RF +0.019, XGB +0.005 (run 2: +0.046, +0.018, +0.012). Removing Layer 4 peer-relative: RF −0.047, XGB −0.085, logit −0.008 (run 2: −0.048, −0.091, −0.009). Removing text stack: ≈ 0. Controls only: 0.52–0.61 | the lexicon layer as a block adds nothing beyond the other layers; the peer-relative layer is the one that matters for the tree models |
| T3 lead time (H3) | 8 of 21 cases flagged (run 2: 7); median 36 months (run 2: 41), range 5–53 | supported for the detected cases; 13–14 undetected at 5 % FPR |
| T4 MW persistence | persistent MW (two consecutive years) in 37.3 % of case vs 11.2 % of peer firm-years, Fisher p < 0.001 (Holm < 0.001); no escalation of next-year disclosure signals after persistence (p 0.59–0.96) | strongly supported for the level, not for escalation |
| T5 clean-firm FPR | 23 / 475 = 4.8 % at threshold 0.688 (run 2: 0.697) | passes (≤ 5 %) |

T4's p-value was 1.00 in the first write of this table because the Fisher 2×2 columns were ordered (not persistent, persistent), inverting the one-sided test. The code is fixed and covered by a direction test; the value above is the corrected one.

## 5. Primary inference — firm-clustered and conditional logit

Standardised regressors, winsorised at the 1st/99th percentiles, controls `ln_assets`, `leverage`, `roa`, `listing_age`; complete cases; conditional logit uses only clusters with both outcomes. Odds ratios per standard deviation.

| Layer | Term | Clustered logit OR (p) | Conditional logit OR (p) |
|---|---|---|---|
| L1 | earnings–cash divergence | 1.05 (0.83) | 1.17 (0.58) |
| L1 | accruals | 1.11 (0.46) | 1.60 (0.21) |
| L2 | Big-4 auditor | 0.36 (0.016) | 0.007 (0.006) |
| L2 | material weakness reported | 4.56 (0.076) | 12,054 (0.044) |
| L2 | auditor change | 1.44 (0.064) | 1.49 (0.22) |
| L2 | ICFR not effective | 0.70 (0.38) | 0.016 (0.003) |
| L3 (reduced) | RPT fog | 0.21 (< 0.001) | 0.13 (< 0.001) |
| L3 (reduced) | Δ RPT fog (year on year) | 1.48 (0.011) | 1.74 (0.022) |
| L3 (reduced) | specificity gap (RPT − Item 1 vagueness) | 0.87 (0.82) | 0.26 (0.006) |
| L3 (reduced) | RPT vagueness composite | 0.97 (0.97) | 1.88 (0.16) |
| L3 (reduced) | agency masking | 1.05 (0.87) | 1.20 (0.46) |
| L4 | RPT fog z (vs cluster-year peers) | 0.29 (0.002) | 0.32 (< 0.001) |
| L4 | **peer text distance** (novel) | 1.65 (0.063) | **1.83 (0.012)** |
| L4 | agency masking z | 0.85 (0.47) | 0.72 (0.067) |
| controls | listing age | 0.69–0.52 | 0.37–0.56 (p ≤ 0.002) |

Reading. (i) Case firms' related-party text is **less** complex (lower fog) than peers' and than their own Item 1, and it **becomes more complex year on year** — the level runs against the "obfuscation" reading of H2 while the drift supports it. (ii) The vagueness composite and its agency-masking component carry no independent association once fog and controls are in; the lexicon's power is in readability and drift, not in the hedging vocabulary. (iii) The peer-relative text distance is the only disclosure variable significant in both the pooled and the within-cluster specification with the hypothesised sign. (iv) Layer 2 behaves as the design expects: Big-4 protective, material weakness and auditor change risk-increasing; the conditional-logit coefficients for the ICFR flags are large and unstable (10 informative clusters, n = 157) and should be reported with that caveat. (v) The full L3 specification with the composite *and* its sub-components (`rpt_vagueness`, `rpt_relabeling`, `rpt_transparency`) is collinear (coefficients of ±12 with opposite signs) and should not be the thesis table; the reduced table above is.

Pseudo-R² of the clustered logits: L1 0.04, L2 0.24, L3 0.20, L4 0.20. Run-2 coefficients agree with the table (Big-4 OR 0.36, p = 0.012; material weakness OR 4.3, p = 0.073; peer text distance conditional OR 1.86, p = 0.009; RPT fog z conditional OR 0.33, p < 0.001); the full run-2 tables are in `outputs/full/RESULTS.md`.

## 6. P4 mediation (2,000 cluster-bootstrap resamples, firms resampled)

| Path | n | indirect | 95 % CI | status |
|---|---|---|---|---|
| ECD → vagueness → label | 452 | −0.003 | −0.046, 0.028 | not supported |
| ECD → agency masking → label | 452 | −0.004 | −0.037, 0.016 | not supported |
| RPT/revenue → vagueness → label | 34 | 0.10 | −0.29, 0.57 | too few tagged firm-years |
| RPT/revenue → agency masking → label | 34 | −0.01 | −1.24, 0.40 | too few tagged firm-years |
| MW reported → vagueness → label | 434 | −0.014 | −0.065, 0.044 | not supported |
| MW reported → agency masking → label | 434 | 0.009 | −0.019, 0.076 | not supported |

The mediation story (financial or control weakness → vaguer disclosure → enforcement) is not in the data. The direct paths from material weakness are positive (c′ ≈ 0.56–0.59); the disclosure lexicon does not transmit them.

## 7. Explainability

**Attribution (mean |SHAP|, out of fold).** Top five — logit: ECD z, ROA, ECD, accruals z, leverage (the financial ratios, which is where the unbounded outliers sit; see §9); random forest: RPT fog z, RPT fog, listing age, text risk, Big-4; XGBoost: RPT fog z, listing age, specificity gap, peer text distance, relabeling. Full table: `explainability/attribution.csv`; summary figure `explainability/fig_shap_summary.png`; one waterfall per case firm and model in `figures/fig_waterfall_<case>_<model>.png`.

**Stability.** Within-model bootstrap rank correlation: RF 0.997, XGB 0.997, logit 0.72 in run 1 and 0.94 in run 2 (bounding the ratios stabilised the logit's ranking as expected). Across models: RF–XGB 0.82 / 0.79, logit–RF 0.45 / 0.39, logit–XGB 0.55 / 0.55. The tree models tell one consistent story; the logit weights the financial ratios and Big-4 more heavily.

**Traceability (RO4).** 95.1 % (run 2: 95.3 %) of all top-3 attributions, 93.1 % (94.1 %) for case firm-years, resolve to a located source: audit-report signature (Big-4, auditor change; 100 %), related-party passage with the matched lexicon terms or masking patterns (96–100 %), peer-centroid comparison (100 %), Item 9A text (94 %), TF-IDF terms located in the text (70–100 %), XBRL tag and accession for the ratios, first annual report in the manifest for listing age. Table: `explainability/traceability.csv`.

**Text model vocabulary.** Risk-side terms are domain-plausible: `loan`, `loans`, `consulting services`, `advisory`, `owns`, `ventures`, `limited liability`, `acquisition`, `committee members`, `directors audit`. One surname (`mason`) and one product word (`tests`) still pass the ≥ 3-firm rule; honorifics and given names are now stop-listed, and a capitalisation-based proper-noun filter is the next step if names persist in run 2.

## 8. Data-quality findings that shape the thesis

1. **Layer 1 as designed is mostly empty.** The XBRL related-party amount tags are present in 3–14 % of firm-years; the design's RP_LEND/RP_PAY/RP_SALES/RP_PURCH variables cannot come from company-facts data and must be coded from the RP note (hand or LLM, Phase B), or Layer 1 must be re-specified around generic ratios.
2. **Proxy coverage.** The builder fetches a DEF 14A only when Item 13 is incorporated by reference (53 % of filings), which caps CEO duality and audit-committee coverage; fetching the proxy for every filing year is a cheap builder change.
3. **Unbounded ratios.** Peer firm-years with near-zero assets produce accruals of ±2,000 × assets and dominate standardised models (descriptives: peer accruals mean 100, sd 1,989). Run 2 bounds them.
4. **Three poorly size-matched clusters** (Ocwen, Energy XXI, Singularity) must be carried as a documented limitation with the robustness row in §3.2.

## 9. Changes made while running (pre-registered deviations to record)

| Change | Reason | Effect on inference |
|---|---|---|
| T4 Fisher table column order | inverted one-sided test | p 1.00 → < 0.001 |
| Regressors: winsorise 1/99, ≥ 50 % coverage, drop constants within informative clusters | every clustered logit fell back to a ridge path; conditional logit failed on a constant | tables in §5 |
| Mediation inputs winsorised | bootstrap SEs of 4.4 driven by outliers | §6 |
| Asset-scaled ratios bounded (ECD, accruals, ROA ±1; leverage 0–3) — **run 2** | §8.3 | headline AUCs unchanged within 0.02; logit attribution ranking stabilised (0.72 → 0.94) |
| Governance coder (rule-based, with evidence passages) replaces the missing hand-collected file | Layer 2 would otherwise be ICFR flags only | Big-4, auditor change, going concern, duality, AC independence enter |
| Case strata separated; LOGO over all clusters | design decision (disclosure-only as separate stratum) | core-only primary; disclosure-only stratum at chance (§3.4) |

## 10. Readiness verdict

**Ready now:** a reproducible, leak-free pipeline from EDGAR to tables and figures; a 21-cluster confirmatory result with cluster-bootstrap intervals; stress tests T1–T5; primary inference with firm-clustered and conditional logit; traceable attributions for 95 % of explanations; a documented sample-construction trail (candidate screen report). This is enough to draft Chapters 3 (data and method) and 4 (results) with the run-2 numbers.

**Must land before the numbers are final:** (1) verification of the 6 low- and 9 medium-confidence revelation dates — a date change moves a case's whole window; (2) the 10 % hand check of the governance coder (reliability statistic M2); (3) proxy fetch for every filing year, then re-run; (4) the universe scoring (decision D10) that gives the external alert rate — the generalisation evidence the client asked for.

**Should be said plainly in the thesis:** the model discriminates at AUC ≈ 0.74 with wide intervals; it flags about 40 % of cases three years ahead at a 5 % false-positive rate; the disclosure lexicon's hypothesised specificity and mediation are not supported; the peer-relative construction and the related-party text's readability and drift are where the contribution lies.

## 11. Run 3 (final, 9 October 2026) — what changed and what it showed

Run 3 adds to run 2: (a) the design's related-party characteristics coded by rule from the related-party notes and sections with evidence passages (`rpt_panel/rp_note_coder.py`; amounts in 7–16 % of window firm-years, the four-item incompleteness score in 88 %); (b) restatement and auditor-change flags from 8-K Items 4.02 and 4.01 via the submissions API (complete coverage); (c) a proxy statement linked to 85 % of filings (every-year fetch), lifting CEO duality to 52 % and audit-committee independence to 35 % coverage. The incompleteness item and the two 8-K flags entered the fitted model (35 features); the coded amounts stayed below the coverage cut-off and feed the design's layer scores instead.

| | Run 2 | Run 3 |
|---|---|---|
| Logit OOF AUC | 0.69 | 0.73 [0.63, 0.82] |
| Random forest | 0.73 | 0.73 [0.63, 0.83] |
| XGBoost | 0.72 | 0.71 [0.60, 0.80] |
| Ensemble | 0.73 | 0.73 [0.63, 0.83] |
| Cases flagged at 5 % clean-firm FPR | 7 / 21 | 9 / 21 (median lead 46 months, range 19–56) |
| Traceability (all / cases) | 95 % / 94 % | 96 % / 96 % |
| Logit attribution stability | 0.94 | 0.94 |
| Core stratum within the all-strata model / disclosure-only stratum | 0.70 / 0.54 | 0.72 / 0.52 |

Design battery on run 3 (`outputs/full/design_tests/`, `scripts/design_tests.py`): H1 supported on the firm-years with a stated amount (within-set OR 2.14 per SD, Holm p = 0.009, n = 147 / 13 sets); H2 reversed (OR 0.72, p = 0.04); H3 supported (OR 4.64, Holm p < 0.001, n = 180 / 12 sets); H4 supported for governance in years −3 and −2; H5 supported in strength (traditional index alone 0.64; adding the fitted score to it 0.66 vs 0.48 for the benchmark model, p = 0.002) and coverage (16 of 21 cases flagged by one or the other at comparable false-alarm rates) but not in timing. P1 remains a pattern on 5 managerial cases. External validation on 10 unseen three-report cases and 28 matched firms: AUC 0.73, matched-firm false-alarm rate 5.8 %, 1 of 10 cases over the pooled threshold.

The Layer 2 regression with every governance variable is now unstable (CEO duality and the restatement flag separate on 162 complete cases); the reduced high-coverage specification (`tables/logit_*_L2_monitoring_reduced.*`) keeps Big-4 protective (clustered OR 0.39, p = 0.013) with the 8-K flags positive but not significant. The revelation-date evidence pass (`SEC-EDGAR-Downloader/scripts/revelation_verification*.csv`) found candidate earlier disclosures for 13 of 15 medium/low-confidence cases; on reading the passages only Ault (8-K non-reliance, 18 October 2018) and Co-Diagnostics (10-Q/A restatement, 3 November 2020) merit review. No date was changed. The 10 % hand-check sample for M2 is drawn (`data/m2_hand_check_sample.csv`).
