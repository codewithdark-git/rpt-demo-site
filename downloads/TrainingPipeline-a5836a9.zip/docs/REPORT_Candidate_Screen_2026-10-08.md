# Candidate screen report — confirmatory sample for the RPT fraud-risk study

Date: 8 October 2026. Inputs: `SEC-EDGAR-Downloader/scripts/phase_a_screen_v2.csv` (51 screened candidates), `scripts/candidates_v02.csv` (58 raw candidates), `cases_core.csv` (final sample), the peer-matching files `scripts/peers_matched_*.csv`. Rules: decisions D1–D4 and D10 of `docs/PROJECT_CLOSURE_PLAN.md`, which implement the client's research design of 6 October 2026.

## 1. What the screen had to decide

The research design needs case firms whose SEC enforcement action involved related-party transactions (RPTs), observed for the five fiscal years before the misconduct became public, each matched to industry-and-size peers that were never subject to an enforcement action. Four rules were applied to every candidate, in this order:

1. **D1 inclusion.** The SEC order or complaint must describe an accounting misstatement or a misappropriation in which an RPT is the mechanism (class `misstatement`, `misappropriation`, or a combination). Cases where the only charge is a missing or incomplete RPT disclosure are a separate stratum (`disclosure_only`). Cases with no RPT element or with an internal-controls-only order are excluded.
2. **D2 revelation date.** The first public event that revealed the problem: an 8-K Item 4.02 non-reliance notice, an auditor resignation, an audit-committee investigation, a short-seller report, a restatement, or, when nothing earlier exists, the SEC action itself. Every date carries a confidence level (high = dated SEC filing or order; medium = documented public event still to be linked to a source document; low = SEC action date used as a placeholder).
3. **D3 window and four-report rule.** The assessment window is the five fiscal years before the revelation year. A case must have at least four annual reports (10-K, 10-K405, 10-KSB, 10-KT) in that window, and the window must start in 2005 or later so that Item 9A (SOX 404) exists and Layer 2 is observable.
4. **D4 peer matching.** Five peers per case from the EDGAR universe of the case's industry (same 4-digit SIC, falling back to 3- and 2-digit), nearest in log total assets in the fiscal year before revelation, with a 10-K in every window year and no AAER match.

## 2. Where the candidates came from

| Source | Candidates | What it contributed |
|---|---|---|
| Client workbook of 2 October 2026 | 39 | the starting list, including the five pilot anchors |
| Every SEC AAER release 2005–2024 (2,383 documents, full text) | 14 new | mostly pre-2005 windows (extended tier) and the D1 confirmations |
| Every SEC litigation release 2010–2025 (5,086 documents, full text) | 2 new | American Equity (disclosure stratum), Premier Holding (core) |
| Issuers' own filings via EDGAR full-text search (1,354 issuers, 89 on ≥ 2 query families) | 0 new | all hits were boilerplate co-occurrences of "related party" and "SEC" |

Fifty-eight candidates were recorded; 51 reached the screen (seven were duplicates, foreign private issuers without 10-Ks, or had no identifiable issuer).

## 3. Screen outcome

| Status | n | Firms |
|---|---|---|
| **INCLUDE (core)** | **21** | Ault Alliance, Co-Diagnostics, Eagle Bancorp, Ocwen, Valeant, Manitex, Singularity Future Technology, Puda Coal, General Employment, SAExploration, Ideanomics, UDF IV, FAT Brands, Ammo/Outdoor Holding, MusclePharm, China Valves, Cemtrex, Quadrant 4, Provectus, Corporate Resource Services, Premier Holding |
| **STRATUM_DISCLOSURE_ONLY** | **9** | Skechers, American Electric Power, RCI Hospitality, Greenbrier, Energy XXI, Maximus, Shift4, First Bancorp (NC), American Equity |
| FAIL_4_REPORTS (sensitivity set) | 17 | ProPetro, China Natural Gas, Ener1, Apple REIT Nine, China North East Petroleum, HLSS, ARCP, RINO, iFresh, ChinaCast, BioElectronics, HF Foods, Longfin, TVI, Proteonomix, Electronic Game Card, China Ruitai |
| PRE_2005_WINDOW (extended tier) | 1 (+12 from the AAER sweep) | infoUSA; Adelphia, Hollinger, Tyco, Enron, Refco, Buca, Natural Health Trends, Escala, Krispy Kreme, UTStarcom, Dyadic, Quest Resource |
| EXCLUDE_D1 | 2 | Live Ventures (no RPT element), Northwest Biotherapeutics (controls-only order) |
| NEED_REVELATION_DATE | 1 | Gulfport Energy (disclosure-only; order date not yet established) |

### 3.1 The 21 core cases

| Case | SIC | D1 class | Revelation date | Confidence | Window | 10-Ks | AAER |
|---|---|---|---|---|---|---|---|
| Ault Alliance | 3533 | misappropriation + misstatement | 2023-04-14 | medium | 2018–2022 | 5 | AAER-4440 |
| Co-Diagnostics | 3841 | misstatement | 2023-07-05 | low | 2018–2022 | 5 | AAER-4428 |
| Eagle Bancorp | 6022 | misstatement | 2017-12-01 | medium | 2012–2016 | 5 | AAER-4321 |
| Ocwen Financial | 6162 | disclosure + misstatement | 2014-08-18 | high | 2009–2013 | 5 | AAER-3733 |
| Valeant Pharmaceuticals | 2834 | misstatement | 2015-10-21 | medium | 2010–2014 | 5 | — (LR) |
| Manitex International | 3559 | misstatement | 2018-04-03 | high | 2013–2017 | 5 | — |
| Singularity Future Technology | 4731 | misstatement | 2023-03-06 | high | 2018–2022 | 5 | AAER-4557 |
| Puda Coal | 1221 | misappropriation | 2011-04-08 | medium | 2006–2010 | 4 | — (LR) |
| General Employment Enterprises | 7361 | misstatement | 2015-04-30 | low | 2010–2014 | 5 | — (LR) |
| SAExploration Holdings | 1382 | misstatement | 2019-08-15 | medium | 2014–2018 | 5 | — |
| Ideanomics | 3711 | misstatement | 2018-08-28 | medium | 2013–2017 | 5 | AAER-4512 |
| United Development Funding IV | 6798 | misstatement | 2015-12-10 | medium | 2010–2014 | 5 | — (LR-24185) |
| FAT Brands | 5812 | misappropriation | 2024-05-10 | low | 2019–2023 | 5 | — (LR-26001) |
| Ammo Inc / Outdoor Holding | 7389 | disclosure + misstatement | 2024-07-29 | medium | 2019–2023 | 5 | — (LR-26446) |
| MusclePharm | 2834 | disclosure + misstatement | 2012-05-14 | high | 2007–2011 | 4 | — |
| China Valves Technology | 3490 | misstatement | 2012-02-28 | high | 2007–2011 | 5 | — |
| Cemtrex | 1700 | misappropriation | 2017-02-22 | medium | 2012–2016 | 5 | — |
| Quadrant 4 System | 3669 | misappropriation | 2016-09-23 | medium | 2011–2015 | 5 | — |
| Provectus Biopharmaceuticals | 2834 | misappropriation | 2016-02-29 | medium | 2011–2015 | 5 | — |
| Corporate Resource Services | 7363 | misstatement | 2015-02-10 | medium | 2010–2014 | 4 | AAER-4007 |
| Premier Holding Corp | 4911 | misstatement | 2017-12-04 | low | 2012–2016 | 5 | — (LR-24000) |

Eleven of the 21 are small or micro-cap issuers, three are Chinese reverse mergers (Puda, China Valves, Singularity's predecessor), two are financials (Eagle, Ocwen), one is a non-traded REIT (UDF IV). That spread is a strength for generalisation but a weakness for peer matching (Section 4).

### 3.2 Disclosure-only stratum (9)

Skechers (2024, high), American Electric Power (2020, medium), RCI Hospitality (2020, low), Greenbrier (2023, high), Energy XXI (2016, medium), Maximus (2023, high), Shift4 (2025, high), First Bancorp NC (2015, high), American Equity (2010, high). These are kept out of the primary test (the dependent construct is misstatement or misappropriation) and analysed as a second stratum: the hypothesis there is weaker — a disclosure failure need not leave a trace in the financial layer — and the thesis should say so.

## 4. Peer matching outcome

140 peers, all EDGAR-verified (10-K on file for the window years). Per case: minimum 3, median 5, maximum 5.

| Match level | Peers | Cases |
|---|---|---|
| 4-digit SIC | 123 | 26 |
| 3-digit SIC | 5 | General Employment |
| 2-digit SIC | 12 | Ocwen, Skechers, Greenbrier |

Size match: median absolute gap in log total assets 0.40 (a factor of 1.5), interquartile range 0.07–0.91. Three clusters are poorly size-matched and must be flagged in the thesis: Ocwen (mean gap 5.4 log points — the mortgage-servicing SIC has almost no registrants of Ocwen's size), Energy XXI (3.8) and Singularity (2.8). A robustness run without these three clusters is pre-specified in the closure plan.

Three cases have only three peers (Ocwen, MusclePharm, Puda Coal) because the industry pool with full 10-K coverage in the window is thin. Puda Coal's size anchor is hand-collected from its FY2010 10-K (XBRL did not cover it); American Equity's peers are anchored on 2011 assets because the XBRL frames begin in 2009 and its window is 2005–2009.

## 5. What is provisional

Revelation dates among the 30 cases: 15 high, 9 medium, 6 low confidence. The low-confidence rows use the SEC action date as a placeholder and may move earlier by one to three years once an earlier disclosure (SEC inquiry, audit-committee review) is found in the firm's 8-K/10-Q text. Each would shift that case's window and could change which fiscal years are labelled 1. The verification list:

| Firm | Confidence | What to check |
|---|---|---|
| Co-Diagnostics | low | 8-K/10-Q 2021–2023 for an SEC-inquiry disclosure |
| General Employment | low | 2011–2014 filings for an SEC-inquiry disclosure |
| FAT Brands | low | 2021–2023 10-Q/10-K for the DOJ/SEC investigation disclosure |
| Premier Holding | low | 2016–2017 8-Ks for an SEC-inquiry disclosure |
| RCI Hospitality (stratum 2) | low | 2019 10-K/10-Q for the SEC subpoena |
| Ault Alliance | medium | FY2021 10-K for an earlier SEC-investigation disclosure |
| Eagle Bancorp, Valeant, Cemtrex, Provectus, SAExploration, Ideanomics, UDF IV, Puda Coal, AEP, Energy XXI, Ammo | medium | attach the source document (8-K accession, report URL, order number) already identified in `phase_a_screen_v2.csv` |

Two D1 confirmations remain open: Corporate Resource Services (was the issuer itself charged, or only Tri-State?) and Ammo (confirm the misstatement element in Order 33-11397). Both are in the core on the current reading of the complaints.

None of this blocks the data build: filings are collected for FY2004–2024 regardless of the window, so a corrected date only re-labels firm-years.

## 6. Implications for the thesis and the paper

- **Sample size.** The design asked for 40 core cases; 21 exist under its own rules after an exhaustive search of every AAER (2005–2024) and litigation release (2010–2025). Section 12 of the design anticipated the shortfall. The thesis should restate power for 21 cases × 5 peers (about 105 case firm-years against 525 peer firm-years) and treat the 17-case sensitivity set (three-report rule) and the 13-case extended tier (pre-2005 windows; financial and text layers only) as robustness analyses, not as part of the confirmatory test.
- **Generalisation ("many more companies").** The way to test the model on many companies is not to add them as labelled cases — there are no more verified RPT cases — but to score the labelled-free EDGAR universe of the 33 industries (12,615 registrants; 4,611 with XBRL assets) and report the external alert rate at the 5 % clean-firm false-positive threshold (decision D10). That is the thesis's generalisation evidence and it is already supported by the universe files built in Phase A.
- **Heterogeneity.** With 21 cases across 18 industries, the within-cluster peer comparison is what makes the test meaningful; pooled cross-industry comparisons should not be the headline.
- **Disclosure-only stratum.** Report separately; do not merge into the core count.

## 7. Readiness verdict

The candidate screen is complete and reproducible (`scripts/phase_a2_revelation_dates.py` regenerates the screen; `scripts/build_cases_core.py` and `scripts/finalize_phase_a.py` regenerate the sample). The sample is fit to build the dataset and to run the confirmatory model. It is not yet fit to publish: the 6 low- and 9 medium-confidence revelation dates and the two open D1 confirmations must be closed, and the three poorly size-matched clusters must be carried as a documented limitation with a robustness run.
