# Companies used in the research

This document lists every firm in the study: the 31 qualifying RPT-fraud cases of the main sample (21 misstatement/misappropriation, 10 disclosure-only including Gulfport Energy, approved on 10 October 2026; all FRAUD = 1 in the design tests) with their rule-matched firms, the 10 external-validation cases with theirs, and the five pilot anchors with the hand-picked competitors used in the pilot. Facts are taken from the project's own files: the cases files, the Phase A screen (`scripts/phase_a_screen_v2.csv`), the candidate notes (`scripts/candidates_v02.csv`), the matching tables (`scripts/peers_matched_*.csv`), the EDGAR company tables of the builds, and the run-3 model outputs. Matching rule D4: same four-digit SIC code (fallback three-, then two-digit), nearest log total assets in the fiscal year before revelation, a 10-K on file in every window year, and no SEC accounting enforcement match. 'Gap in ln(assets)' is the absolute difference between the matched firm's and the case's log total assets at the anchor year (0.69 = a factor of two).

## Summary

| Group | Cases | Matched firms | Firm-years FY2004–2024 |
|---|---|---|---|
| Main sample: RPT misstatement / misappropriation | 21 | 97 | 272 cases + 2,151 matched (all 30 sets) |
| Main sample: disclosure-only (stratum label kept for the design's second H2 run) | 10 | 48 | (included above) |
| External validation (three annual reports in the window) | 10 | 28 | 549 |
| Pilot anchors (first study) | 5 | 25 | 384 (FY2004–2024 pilot build) |

## Part A — Main sample, misstatement or misappropriation cases (21)

### 1. Ammo Inc (Outdoor Holding)

| Item | Value |
|---|---|
| CIK | 0001015383 |
| EDGAR name | Outdoor Holding Co |
| SIC | 7389 — Services-Business Services, NEC |
| State of incorporation / fiscal year end | DE / 0331 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Transactions benefiting an undisclosed de facto executive and his family |
| Misconduct years / enforcement year | 2017-2022 / 2025 |
| Enforcement references | LR-26446 complaint (2025): undisclosed de facto executive (Larson) 2017-2022, undisclosed related-party transactions with him/family, accounting errors; restatement FY2022-FY2024 filed 2025-05-20; special committee disclosed 2024-07 |
| First public revelation (D2) | 2024-07-29 — 10-K FY2024 delayed; audit-committee investigation (FTS) |
| Revelation-date confidence | medium — to verify: D1 to confirm from LR-26446 / Order 33-11397 |
| Assessment window (five fiscal years before revelation) | 2019-2023 |
| Annual reports in the window / on file FY2004–2024 | 5 / 17 (2008–2024) |
| Screening notes | LR-26446 complaint (2025): undisclosed de facto executive (Larson) 2017-2022, undisclosed related-party transactions with him/family, accounting errors; restatement FY2022-FY2024 filed 2025-05-20; special committee disclosed 2024-07 |
| Model result (run 3, out of fold) | within-set AUC 0.917; case-year mean score 0.437 vs matched 0.177; max 0.676; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Nutex Health Inc. | 0001479681 | 7389 | sic4 | 0.01 | 2023 | $398 m | 5 |
| Steel Connect LLC | 0000914712 | 7389 | sic4 | 0.02 | 2023 | $411 m | 5 |
| Rimini Street, Inc. | 0001635282 | 7389 | sic4 | 0.03 | 2023 | $394 m | 5 |
| Phreesia, Inc. | 0001412408 | 7389 | sic4 | 0.07 | 2023 | $375 m | 5 |
| Edgio, Inc. | 0001391127 | 7389 | sic4 | 0.12 | 2023 | $453 m | 4 |

### 2. Ault Alliance

| Item | Value |
|---|---|
| CIK | 0000896493 |
| EDGAR name | Hyperscale Data, Inc. |
| SIC | 3533 — Oil & Gas Field Machinery & Equipment |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation+misstatement |
| RPT element (from the enforcement documents) | CEO debt repayment booked as consulting fees; related-entity loans and investments |
| Misconduct years / enforcement year | 2016-2022 / 2023 |
| Enforcement references | AAER-4440 |
| First public revelation (D2) | 2023-04-14 — 10-K FY2022 discloses SEC subpoena / special committee (FTS hit) |
| Revelation-date confidence | medium — to verify: check FY2021 10-K (filed 2022) for an earlier SEC-investigation disclosure |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 17 (2008–2024) |
| Screening notes | AAER-4440 confirmed; revelation 2023-08-15 provisional |
| Model result (run 3, out of fold) | within-set AUC 0.96; case-year mean score 0.506 vs matched 0.177; max 0.636; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Solaris Energy Infrastructure, Inc. | 0001697500 | 3533 | sic4 | 0.19 | 2022 | $463 m | 5 |
| FORUM ENERGY TECHNOLOGIES, INC. | 0001401257 | 3533 | sic4 | 0.40 | 2022 | $835 m | 5 |
| Innovex International, Inc. | 0001042893 | 3533 | sic4 | 0.55 | 2022 | $970 m | 5 |
| OIL STATES INTERNATIONAL, INC | 0001121484 | 3533 | sic4 | 0.64 | 2022 | $1.1 bn | 5 |
| Cactus, Inc. | 0001699136 | 3533 | sic4 | 0.69 | 2022 | $1.1 bn | 5 |

### 3. Cemtrex

| Item | Value |
|---|---|
| CIK | 0001435064 |
| EDGAR name | CEMTREX INC |
| SIC | 1700 — Construction - Special Trade Contractors |
| State of incorporation / fiscal year end | DE / 0930 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | Controlling shareholder misappropriated >$7m of investor funds |
| Misconduct years / enforcement year | 2016-2018 / 2021 |
| Enforcement references | Whether RPT disclosure was charged |
| First public revelation (D2) | 2017-02-22 — Short report alleging hidden insider dealing and related-party transactions |
| Revelation-date confidence | medium — to verify: attach URL; press release 2021-132 |
| Assessment window (five fiscal years before revelation) | 2012-2016 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2009–2024) |
| Screening notes | Whether RPT disclosure was charged |
| Model result (run 3, out of fold) | within-set AUC 0.442; case-year mean score 0.361 vs matched 0.42; max 0.508; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| LIME ENERGY CO. | 0001065860 | 1700 | sic4 | 0.04 | 2016 | $50 m | 4 |
| SUNation Energy, Inc. | 0000022701 | 1700 | sic4 | 0.34 | 2016 | $73 m | 5 |
| China Advanced Construction Materials Group, Inc | 0001392363 | 1700 | sic4 | 0.60 | 2016 | $95 m | 5 |
| Real Goods Solar, Inc. | 0001425565 | 1700 | sic4 | 1.28 | 2016 | $14 m | 5 |
| LAYNE CHRISTENSEN CO | 0000888504 | 1700 | sic4 | 2.21 | 2016 | $473 m | 5 |

### 4. China Valves Technology

| Item | Value |
|---|---|
| CIK | 0001080360 |
| EDGAR name | CHINA VALVES TECHNOLOGY, INC |
| SIC | 3490 — Miscellaneous Fabricated Metal Products |
| State of incorporation / fiscal year end | NV / 0930 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Concealed true seller and role of related parties in an acquisition |
| Misconduct years / enforcement year | 2010-2011 / 2014 |
| Enforcement references | LR-23096 |
| First public revelation (D2) | 2012-02-28 — 8-K Item 4.02 non-reliance and investigation (FTS) |
| Revelation-date confidence | high — to verify: LR-23096 2014-09-29 |
| Assessment window (five fiscal years before revelation) | 2007-2011 |
| Annual reports in the window / on file FY2004–2024 | 5 / 5 (2007–2011) |
| Screening notes | LR-23096 |
| Model result (run 3, out of fold) | within-set AUC 0.944; case-year mean score 0.657 vs matched 0.362; max 0.763; flagged years 2 (first FY2007) |

**Matched firms (4)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| HELIOS TECHNOLOGIES, INC. | 0001024795 | 3490 | sic4 | 0.60 | 2011 | $168 m | 5 |
| Shengkai Innovations, Inc. | 0001327364 | 3490 | sic4 | 0.76 | 2011 | $143 m | 4 |
| CIRCOR INTERNATIONAL INC | 0001091883 | 3490 | sic4 | 0.86 | 2011 | $723 m | 5 |
| BEFUT International Co., Ltd. | 0001328888 | 3490 | sic4 | 0.89 | 2011 | $126 m | 4 |

### 5. Co-Diagnostics

| Item | Value |
|---|---|
| CIK | 0001692415 |
| EDGAR name | Co-Diagnostics, Inc. |
| SIC | 3841 — Surgical & Medical Instruments & Apparatus |
| State of incorporation / fiscal year end | UT / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-party licence and compensation arrangements misstated |
| Misconduct years / enforcement year | 2018-2020 / 2023 |
| Enforcement references | AAER-4428 |
| First public revelation (D2) | 2023-07-05 — SEC order 33-11209 (AAER-4428); no earlier filing found |
| Revelation-date confidence | low — to verify: search 8-K/10-Q 2021-2023 for SEC inquiry disclosure |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 8 (2017–2024) |
| Screening notes | AAER-4428 confirmed 2023-07-05 |
| Model result (run 3, out of fold) | within-set AUC 0.9; case-year mean score 0.553 vs matched 0.228; max 0.789; flagged years 1 (first FY2020) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| UTAH MEDICAL PRODUCTS INC | 0000706698 | 3841 | sic4 | 0.01 | 2022 | $124 m | 5 |
| Venus Concept Inc. | 0001409269 | 3841 | sic4 | 0.02 | 2022 | $125 m | 5 |
| DarioHealth Corp. | 0001533998 | 3841 | sic4 | 0.03 | 2022 | $119 m | 5 |
| Intersect ENT, Inc. | 0001271214 | 3841 | sic4 | 0.03 | 2022 | $127 m | 4 |
| Neuronetics, Inc. | 0001227636 | 3841 | sic4 | 0.05 | 2022 | $117 m | 5 |

### 6. Corporate Resource Services

| Item | Value |
|---|---|
| CIK | 0000943110 |
| EDGAR name | Corporate Resource Services, Inc. |
| SIC | 7363 — Services-Help Supply Services |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-party arrangements with Tri-State Employment (controlled by major shareholder) misstated; auditor charged |
| Misconduct years / enforcement year | 2012-2014 / 2018 |
| Enforcement references | AAER-4007 |
| First public revelation (D2) | 2015-02-10 — Disclosure of Tri-State unpaid payroll taxes / going concern |
| Revelation-date confidence | medium — to verify: D1: issuer not charged? confirm |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 4 / 6 (2008–2013) |
| Screening notes | Auditor release AAER-4007 (Crowe); issuer collapsed 2015; check for issuer order and 10-K history |
| Model result (run 3, out of fold) | within-set AUC 1.0; case-year mean score 0.751 vs matched 0.203; max 0.872; flagged years 3 (first FY2011) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Star Equity Holdings, Inc. | 0001210708 | 7363 | sic4 | 0.28 | 2014 | $140 m | 5 |
| CROSS COUNTRY HEALTHCARE INC | 0001141103 | 7363 | sic4 | 0.57 | 2014 | $325 m | 5 |
| KFORCE INC | 0000930420 | 7363 | sic4 | 0.68 | 2014 | $364 m | 5 |
| CDI CORP | 0000018396 | 7363 | sic4 | 0.70 | 2014 | $372 m | 5 |
| BARRETT BUSINESS SERVICES INC | 0000902791 | 7363 | sic4 | 0.90 | 2014 | $452 m | 5 |

### 7. Eagle Bancorp

| Item | Value |
|---|---|
| CIK | 0001050441 |
| EDGAR name | EAGLE BANCORP INC |
| SIC | 6022 — State Commercial Banks |
| State of incorporation / fiscal year end | MD / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Loans to related parties (founder/CEO entities) misstated and undisclosed |
| Misconduct years / enforcement year | 2015-2018 / 2022 |
| Enforcement references | AAER-4321 |
| First public revelation (D2) | 2017-12-01 — Aurelius Value short report alleging undisclosed related-party loans; 8-K 2019-07-17 confirms investigations |
| Revelation-date confidence | medium — to verify: attach report URL; order AAER-4321 2022-08-16 |
| Assessment window (five fiscal years before revelation) | 2012-2016 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | AAER-4321 (2022-08-16) issuer order confirmed in sweep: undisclosed related-party loans to CEO's family trusts, 2015-2018 |
| Model result (run 3, out of fold) | within-set AUC 1.0; case-year mean score 0.477 vs matched 0.154; max 0.582; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Ameris Bancorp | 0000351569 | 6022 | sic4 | 0.00 | 2016 | $6.9 bn | 5 |
| S&T BANCORP INC | 0000719220 | 6022 | sic4 | 0.01 | 2016 | $6.9 bn | 5 |
| FIRST FINANCIAL BANKSHARES INC | 0000036029 | 6022 | sic4 | 0.01 | 2016 | $6.8 bn | 5 |
| YADKIN FINANCIAL Corp | 0001366367 | 6022 | sic4 | 0.05 | 2016 | $7.2 bn | 5 |
| OFG BANCORP | 0001030469 | 6022 | sic4 | 0.06 | 2016 | $6.5 bn | 5 |

### 8. FAT Brands

| Item | Value |
|---|---|
| CIK | 0001705012 |
| EDGAR name | Fat Brands, Inc |
| SIC | 5812 — Retail-Eating  Places |
| State of incorporation / fiscal year end | DE / 1228 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | ~$27m of company cash spent on CEO's personal expenses disguised as loans to his company |
| Misconduct years / enforcement year | 2017-2021 / 2024 |
| Enforcement references | LR-26001 |
| First public revelation (D2) | 2024-05-10 — SEC complaint LR-26001 (placeholder); DOJ/SEC investigation disclosed earlier |
| Revelation-date confidence | low — to verify: search 2021-2023 10-Q/10-K for investigation disclosure |
| Assessment window (five fiscal years before revelation) | 2019-2023 |
| Annual reports in the window / on file FY2004–2024 | 5 / 8 (2017–2024) |
| Screening notes | LR-26001 |
| Model result (run 3, out of fold) | within-set AUC 0.96; case-year mean score 0.657 vs matched 0.158; max 0.78; flagged years 2 (first FY2019) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| CARROLS RESTAURANT GROUP, INC. | 0000809248 | 5812 | sic4 | 0.14 | 2023 | $1.6 bn | 5 |
| Dine Brands Global, Inc. | 0000049754 | 5812 | sic4 | 0.23 | 2023 | $1.7 bn | 5 |
| BJs RESTAURANTS INC | 0001013488 | 5812 | sic4 | 0.29 | 2023 | $1.0 bn | 5 |
| PAPA JOHNS INTERNATIONAL INC | 0000901491 | 5812 | sic4 | 0.46 | 2023 | $875 m | 5 |
| CRACKER BARREL OLD COUNTRY STORE, INC | 0001067294 | 5812 | sic4 | 0.47 | 2023 | $2.2 bn | 5 |

### 9. General Employment Enterprises

| Item | Value |
|---|---|
| CIK | 0000040570 |
| EDGAR name | GEE Group Inc. |
| SIC | 7361 — Services-Employment Agencies |
| State of incorporation / fiscal year end | IL / 0930 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-party asset transactions misstated |
| Misconduct years / enforcement year | 2009-2010 / 2015 |
| Enforcement references | — |
| First public revelation (D2) | 2015-04-30 — SEC complaint (placeholder); misconduct 2009-2010 |
| Revelation-date confidence | low — to verify: search 2011-2014 filings for SEC inquiry disclosure |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2009–2024) |
| Screening notes | — |
| Model result (run 3, out of fold) | within-set AUC 0.768; case-year mean score 0.54 vs matched 0.315; max 0.847; flagged years 2 (first FY2013) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| HireQuest, Inc. | 0001140102 | 7363 | sic3 | 1.07 | 2014 | $28 m | 5 |
| DLH Holdings Corp. | 0000785557 | 7363 | sic3 | 1.13 | 2014 | $30 m | 5 |
| IGEN NETWORKS CORP | 0001393540 | 7363 | sic3 | 2.10 | 2014 | $1 m | 5 |
| CTPARTNERS EXECUTIVE SEARCH INC. | 0001439199 | 7361 | sic3 | 2.26 | 2014 | $92 m | 5 |
| Startek, Inc. | 0001031029 | 7363 | sic3 | 2.28 | 2014 | $94 m | 5 |

### 10. Ideanomics (Seven Stars Cloud)

| Item | Value |
|---|---|
| CIK | 0000837852 |
| EDGAR name | IDEANOMICS, INC. |
| SIC | 3711 — Motor Vehicles & Passenger Car Bodies |
| State of incorporation / fiscal year end | NV / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Chairman hid personal interest in counterparties receiving cash and stock |
| Misconduct years / enforcement year | 2017-2019 / 2024 |
| Enforcement references | AAER-4512 |
| First public revelation (D2) | 2018-08-28 — 10-K/A restating FY2017 (FTS restatement + related party) |
| Revelation-date confidence | medium — to verify: AAER-4512 2024-08-09; confirm the 10-K/A content |
| Assessment window (five fiscal years before revelation) | 2013-2017 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2008–2023) |
| Screening notes | AAER-4512 (2024-08-09) confirmed; undisclosed related parties Tiger Sports/Beijing Financial, 2017-2018 misstatements |
| Model result (run 3, out of fold) | within-set AUC 0.617; case-year mean score 0.472 vs matched 0.351; max 0.741; flagged years 2 (first FY2013) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| BOLLINGER INNOVATIONS, INC. | 0001499961 | 3711 | sic4 | 0.67 | 2017 | $32 m | 5 |
| Workhorse Group Inc. | 0001425287 | 3711 | sic4 | 1.35 | 2017 | $17 m | 5 |
| Kandi Technologies Group, Inc. | 0001316517 | 3711 | sic4 | 1.93 | 2017 | $438 m | 5 |
| Leo Motors, Inc. | 0001356564 | 3711 | sic4 | 2.70 | 2017 | $4 m | 4 |
| FEDERAL SIGNAL CORP /DE/ | 0000277509 | 3711 | sic4 | 2.75 | 2017 | $992 m | 5 |

### 11. Manitex International

| Item | Value |
|---|---|
| CIK | 0001302028 |
| EDGAR name | Manitex International, Inc. |
| SIC | 3559 — Special Industry Machinery, NEC |
| State of incorporation / fiscal year end | MI / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related entities used in accounting scheme |
| Misconduct years / enforcement year | 2013-2018 / 2020 |
| Enforcement references | Misconduct years from the order |
| First public revelation (D2) | 2018-04-03 — 10-K/A FY2016 with restatement and non-reliance (FTS); earlier 8-K likely Feb/Mar 2018 |
| Revelation-date confidence | high — to verify: find the original Item 4.02 8-K |
| Assessment window (five fiscal years before revelation) | 2013-2017 |
| Annual reports in the window / on file FY2004–2024 | 5 / 20 (2004–2023) |
| Screening notes | Misconduct years from the order |
| Model result (run 3, out of fold) | within-set AUC 0.792; case-year mean score 0.385 vs matched 0.22; max 0.526; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| AMTECH SYSTEMS INC | 0000720500 | 3559 | sic4 | 0.26 | 2017 | $173 m | 5 |
| Energy Recovery, Inc. | 0001421517 | 3559 | sic4 | 0.31 | 2017 | $164 m | 5 |
| ULTRATECH INC | 0000909791 | 3559 | sic4 | 0.63 | 2017 | $424 m | 4 |
| INTEVAC INC | 0001001902 | 3559 | sic4 | 0.67 | 2017 | $115 m | 5 |
| AXCELIS TECHNOLOGIES INC | 0001113232 | 3559 | sic4 | 0.77 | 2017 | $488 m | 5 |

### 12. MusclePharm

| Item | Value |
|---|---|
| CIK | 0001415684 |
| EDGAR name | MusclePharm Corp |
| SIC | 2834 — Pharmaceutical Preparations |
| State of incorporation / fiscal year end | NV / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Undisclosed related-party transactions with a major customer; perquisites |
| Misconduct years / enforcement year | 2010-2013 / 2015 |
| Enforcement references | Press release 2015-179 |
| First public revelation (D2) | 2012-05-14 — 8-K Item 4.02 non-reliance (FTS, 8-K/A 2012-05-25) |
| Revelation-date confidence | high — to verify: Press release 2015-179 |
| Assessment window (five fiscal years before revelation) | 2007-2011 |
| Annual reports in the window / on file FY2004–2024 | 4 / 13 (2008–2021) |
| Screening notes | Press release 2015-179 |
| Model result (run 3, out of fold) | within-set AUC 0.625; case-year mean score 0.546 vs matched 0.465; max 0.594; flagged years 0 |

**Matched firms (3)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| iBio, Inc. | 0001420720 | 2834 | sic4 | 0.01 | 2011 | $5 m | 4 |
| Lite Strategy, Inc. | 0001262104 | 2834 | sic4 | 0.03 | 2011 | $5 m | 5 |
| BIOVEST INTERNATIONAL INC | 0000704384 | 2834 | sic4 | 0.04 | 2011 | $5 m | 5 |

### 13. Ocwen Financial

| Item | Value |
|---|---|
| CIK | 0000873860 |
| EDGAR name | ONITY GROUP INC. |
| SIC | 6162 — Mortgage Bankers & Loan Correspondents |
| State of incorporation / fiscal year end | FL / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Misstated related-party recusal disclosures (Altisource) |
| Misconduct years / enforcement year | 2012-2014 / 2016 |
| Enforcement references | AAER-3733 |
| First public revelation (D2) | 2014-08-18 — 10-K/A restating FY2013 (Erbey recusal / Altisource); NY DFS letter 2014-08-04 public |
| Revelation-date confidence | high — to verify: AAER-3733 2016-01-20 |
| Assessment window (five fiscal years before revelation) | 2009-2013 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | AAER-3733 (2016-01-20) confirmed |
| Model result (run 3, out of fold) | within-set AUC 0.2; case-year mean score 0.118 vs matched 0.445; max 0.186; flagged years 0 |

**Matched firms (3)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| DITECH HOLDING Corp | 0001040719 | 6162 | sic2 | 0.79 | 2013 | $17.4 bn | 5 |
| PSM HOLDINGS INC | 0001362180 | 6162 | sic2 | 5.92 | 2013 | $21 m | 5 |
| MOPALS.COM, INC. | 0001222218 | 6162 | sic2 | 9.43 | 2013 | $638,398 | 5 |

### 14. Premier Holding Corp

| Item | Value |
|---|---|
| CIK | 0001030916 |
| EDGAR name | PREMIER HOLDING CORP. |
| SIC | 4911 — Electric Services |
| State of incorporation / fiscal year end | NV / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Series of sham transactions with related parties to create the appearance of an active business |
| Misconduct years / enforcement year | 2012-2015 / 2017 |
| Enforcement references | LR-24000 (2017-12-04), LR-25021 (2021); company and CEO Letcavage charged |
| First public revelation (D2) | 2017-12-04 — SEC complaint LR-24000 (placeholder); check 2016-2017 8-Ks |
| Revelation-date confidence | low — to verify: search filings for an SEC inquiry disclosure |
| Assessment window (five fiscal years before revelation) | 2012-2016 |
| Annual reports in the window / on file FY2004–2024 | 5 / 9 (2009–2017) |
| Screening notes | LR-24000 (2017-12-04), LR-25021 (2021); company and CEO Letcavage charged |
| Model result (run 3, out of fold) | within-set AUC 0.44; case-year mean score 0.346 vs matched 0.389; max 0.474; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Bimergen Energy Corp | 0001066764 | 4911 | sic4 | 0.45 | 2016 | $4 m | 5 |
| Ocean Power Technologies, Inc. | 0001378140 | 4911 | sic4 | 0.87 | 2016 | $16 m | 5 |
| SUMMER ENERGY HOLDINGS INC | 0001396633 | 4911 | sic4 | 1.06 | 2016 | $20 m | 5 |
| P10 Industries, Inc. | 0001044435 | 4911 | sic4 | 1.31 | 2016 | $2 m | 5 |
| EnSync, Inc. | 0001140310 | 4911 | sic4 | 1.37 | 2016 | $27 m | 5 |

### 15. Provectus Biopharmaceuticals

| Item | Value |
|---|---|
| CIK | 0000315545 |
| EDGAR name | PROVECTUS BIOPHARMACEUTICALS, INC. |
| SIC | 2834 — Pharmaceutical Preparations |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | $3.2m cash advances and reimbursements to CEO for personal use |
| Misconduct years / enforcement year | 2011-2015 / 2017 |
| Enforcement references | Advances to an insider |
| First public revelation (D2) | 2016-02-29 — CEO resigns amid audit-committee review of expense reimbursements |
| Revelation-date confidence | medium — to verify: attach 8-K |
| Assessment window (five fiscal years before revelation) | 2011-2015 |
| Annual reports in the window / on file FY2004–2024 | 5 / 17 (2008–2024) |
| Screening notes | Advances to an insider |
| Model result (run 3, out of fold) | within-set AUC 0.672; case-year mean score 0.445 vs matched 0.311; max 0.78; flagged years 1 (first FY2011) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Perspective Therapeutics, Inc. | 0000728387 | 2834 | sic4 | 0.01 | 2015 | $21 m | 5 |
| CHEMBIO DIAGNOSTICS, INC. | 0001092662 | 2834 | sic4 | 0.02 | 2015 | $21 m | 5 |
| Statera Biopharma, Inc. | 0001318641 | 2834 | sic4 | 0.02 | 2015 | $21 m | 5 |
| Altimmune, Inc. | 0001326190 | 2834 | sic4 | 0.03 | 2015 | $20 m | 5 |
| MIX 1 LIFE, INC. | 0001501112 | 2834 | sic4 | 0.09 | 2015 | $22 m | 5 |

### 16. Puda Coal

| Item | Value |
|---|---|
| CIK | 0001162747 |
| EDGAR name | Puda Coal, Inc. |
| SIC | 1221 — Bituminous Coal & Lignite Surface Mining |
| State of incorporation / fiscal year end | — / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | Chairman transferred subsidiary to himself |
| Misconduct years / enforcement year | 2009-2010 / 2012 |
| Enforcement references | Reverse merger; FY2010 10-K may be missing |
| First public revelation (D2) | 2011-04-08 — Alfred Little research report: chairman transferred subsidiary to himself |
| Revelation-date confidence | medium — to verify: 8-K auditor resignation / non-reliance 2011-07-18 confirms |
| Assessment window (five fiscal years before revelation) | 2006-2010 |
| Annual reports in the window / on file FY2004–2024 | 4 / 4 (2007–2010) |
| Screening notes | Reverse merger; FY2010 10-K may be missing |
| Model result (run 3, out of fold) | within-set AUC 0.733; case-year mean score 0.398 vs matched 0.3; max 0.438; flagged years 0 |

**Matched firms (3)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| WESTMORELAND COAL Co | 0000106455 | 1221 | sic4 | 0.72 | 2010 | $750 m | 5 |
| James River Coal CO | 0001297720 | 1221 | sic4 | 0.76 | 2010 | $785 m | 5 |
| ALLIANCE RESOURCE PARTNERS LP | 0001086600 | 1221 | sic4 | 1.41 | 2010 | $1.5 bn | 5 |

### 17. Quadrant 4 System

| Item | Value |
|---|---|
| CIK | 0000878802 |
| EDGAR name | Quadrant 4 System Corp |
| SIC | 3669 — Communications Equipment, NEC |
| State of incorporation / fiscal year end | IL / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | CEO and CFO misappropriated >$4m and hid liabilities |
| Misconduct years / enforcement year | 2012-2016 / 2017 |
| Enforcement references | Whether RPT disclosure was charged |
| First public revelation (D2) | 2016-09-23 — 10-K/A revising Item 13 related-party disclosure (FTS); CEO/CFO charged 2016-11 |
| Revelation-date confidence | medium |
| Assessment window (five fiscal years before revelation) | 2011-2015 |
| Annual reports in the window / on file FY2004–2024 | 5 / 11 (2005–2015) |
| Screening notes | Whether RPT disclosure was charged |
| Model result (run 3, out of fold) | within-set AUC 0.416; case-year mean score 0.175 vs matched 0.262; max 0.261; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| WIRELESS TELECOM GROUP INC | 0000878828 | 3669 | sic4 | 0.06 | 2015 | $35 m | 5 |
| VICON INDUSTRIES INC /NY/ | 0000310056 | 3669 | sic4 | 0.12 | 2015 | $33 m | 5 |
| ID SYSTEMS INC | 0000049615 | 3669 | sic4 | 0.19 | 2015 | $44 m | 5 |
| Track Group, Inc. | 0001045942 | 3669 | sic4 | 0.35 | 2015 | $52 m | 5 |
| ITERIS, INC. | 0000350868 | 3669 | sic4 | 0.48 | 2015 | $59 m | 5 |

### 18. SAExploration Holdings

| Item | Value |
|---|---|
| CIK | 0001514732 |
| EDGAR name | SAExploration Holdings, Inc. |
| SIC | 1382 — Oil & Gas Field Exploration Services |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | ~$140m contracts with company controlled by CEO/CFO; ~$100m improperly recorded as revenue |
| Misconduct years / enforcement year | 2015-2019 / 2020 |
| Enforcement references | Press release 2020-251 |
| First public revelation (D2) | 2019-08-15 — 8-K: audit-committee investigation and non-reliance |
| Revelation-date confidence | medium — to verify: attach accession; 10-K/A 2020-02-07 (FTS) |
| Assessment window (five fiscal years before revelation) | 2014-2018 |
| Annual reports in the window / on file FY2004–2024 | 5 / 9 (2011–2019) |
| Screening notes | Press release 2020-251 |
| Model result (run 3, out of fold) | within-set AUC 0.5; case-year mean score 0.319 vs matched 0.332; max 0.578; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| TRANSATLANTIC PETROLEUM LTD. | 0001092289 | 1382 | sic4 | 0.26 | 2018 | $133 m | 5 |
| DAWSON GEOPHYSICAL CO | 0000799165 | 1382 | sic4 | 0.39 | 2018 | $151 m | 5 |
| ION GEOPHYSICAL CORP | 0000866609 | 1382 | sic4 | 1.05 | 2018 | $293 m | 5 |
| Ridgewood Energy O Fund LLC | 0001315061 | 1382 | sic4 | 1.14 | 2018 | $33 m | 5 |
| SEITEL INC | 0000750813 | 1382 | sic4 | 1.21 | 2018 | $344 m | 4 |

### 19. Singularity Future Technology

| Item | Value |
|---|---|
| CIK | 0001422892 |
| EDGAR name | Singularity Future Technology Ltd. |
| SIC | 4731 — Arrangement of  Transportation of  Freight & Cargo |
| State of incorporation / fiscal year end | — / 0630 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Accounting-treatment and control failure involving related entities |
| Misconduct years / enforcement year | 2021 / 2025 |
| Enforcement references | AAER-4557 |
| First public revelation (D2) | 2023-03-06 — 8-K/A Item 4.02 non-reliance: related-party loan receivable misaccounted |
| Revelation-date confidence | high — to verify: D1 to confirm from 2025 order |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2009–2024) |
| Screening notes | AAER-4557 (2025-01-17) confirmed: incorrect accounting for ~$4.6m related-party loan receivable; 8-K/A non-reliance 2023-03-06 |
| Model result (run 3, out of fold) | within-set AUC 0.99; case-year mean score 0.614 vs matched 0.199; max 0.786; flagged years 1 (first FY2021) |

**Matched firms (4)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Unique Logistics International, Inc. | 0001281845 | 4731 | sic4 | 0.88 | 2022 | $93 m | 5 |
| RADIANT LOGISTICS, INC | 0001171155 | 4731 | sic4 | 2.49 | 2022 | $470 m | 5 |
| FORWARD AIR CORP | 0000912728 | 4731 | sic4 | 3.44 | 2022 | $1.2 bn | 5 |
| Hub Group, Inc. | 0000940942 | 4731 | sic4 | 4.28 | 2022 | $2.8 bn | 5 |

### 20. United Development Funding IV

| Item | Value |
|---|---|
| CIK | 0001440292 |
| EDGAR name | United Development Funding IV |
| SIC | 6798 — Real Estate Investment Trusts |
| State of incorporation / fiscal year end | MD / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Loans to developers used to repay affiliated fund UDF III undisclosed |
| Misconduct years / enforcement year | 2011-2015 / 2018 |
| Enforcement references | LR-24185 |
| First public revelation (D2) | 2015-12-10 — Anonymous (Hayman Capital) posts alleging Ponzi-like affiliate lending; FBI raid 2016-02-18 |
| Revelation-date confidence | medium — to verify: LR-24185 2018-07-03 |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 5 / 6 (2009–2014) |
| Screening notes | LR-24185 |
| Model result (run 3, out of fold) | within-set AUC 0.692; case-year mean score 0.261 vs matched 0.21; max 0.41; flagged years 0 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Lightstone Value Plus REIT I, Inc. | 0001296884 | 6798 | sic4 | 0.01 | 2014 | $674 m | 5 |
| PREFERRED APARTMENT COMMUNITIES INC | 0001481832 | 6798 | sic4 | 0.01 | 2014 | $691 m | 4 |
| INDEPENDENCE REALTY TRUST, INC. | 0001466085 | 6798 | sic4 | 0.02 | 2014 | $694 m | 5 |
| SIGNATURE OFFICE REIT INC | 0001256069 | 6798 | sic4 | 0.06 | 2014 | $640 m | 5 |
| Whitestone REIT | 0001175535 | 6798 | sic4 | 0.07 | 2014 | $634 m | 5 |

### 21. Valeant Pharmaceuticals

| Item | Value |
|---|---|
| CIK | 0000885590 |
| EDGAR name | Bausch Health Companies Inc. |
| SIC | 2834 — Pharmaceutical Preparations |
| State of incorporation / fiscal year end | NJ / 1231 |
| Stratum | Main sample — RPT misstatement or misappropriation |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Undisclosed related entity (Philidor) consolidated revenue |
| Misconduct years / enforcement year | 2014-2015 / 2020 |
| Enforcement references | Confirm 10-K filer throughout (Canadian issuer filed 10-K) |
| First public revelation (D2) | 2015-10-21 — Citron report on Philidor; 8-K ad hoc committee 2015-10-26 |
| Revelation-date confidence | medium — to verify: attach URLs |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2009–2024) |
| Screening notes | Confirm 10-K filer throughout (Canadian issuer filed 10-K) |
| Model result (run 3, out of fold) | within-set AUC 0.744; case-year mean score 0.374 vs matched 0.188; max 0.716; flagged years 1 (first FY2011) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| BRISTOL MYERS SQUIBB CO | 0000014272 | 2834 | sic4 | 0.25 | 2014 | $33.7 bn | 5 |
| ELI LILLY & Co | 0000059478 | 2834 | sic4 | 0.32 | 2014 | $36.3 bn | 5 |
| CELGENE CORP /DE/ | 0000816284 | 2834 | sic4 | 0.42 | 2014 | $17.3 bn | 5 |
| ABBOTT LABORATORIES | 0000001800 | 2834 | sic4 | 0.45 | 2014 | $41.2 bn | 5 |
| MYLAN INC. | 0000069499 | 2834 | sic4 | 0.50 | 2014 | $15.9 bn | 5 |

## Part B — Main sample, disclosure-only cases (10)

These firms were charged for a missing or incomplete related-party disclosure. Under the design they are RPT-fraud firms (FRAUD = 1) and are part of the main sample in every test; the design's second H2 run leaves them out. The exploratory fitted score places them at chance within the stratum (AUC 0.52).

### 22. American Electric Power

| Item | Value |
|---|---|
| CIK | 0000004904 |
| EDGAR name | AMERICAN ELECTRIC POWER CO INC |
| SIC | 4911 — Electric Services |
| State of incorporation / fiscal year end | NY / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed payments to a political non-profit |
| Misconduct years / enforcement year | 2019 / 2025 |
| Enforcement references | AAER-4558 |
| First public revelation (D2) | 2020-07-21 — HB6 scandal public (FirstEnergy arrests); AEP payments reported shortly after |
| Revelation-date confidence | medium — to verify: disclosure-only stratum; attach press URL |
| Assessment window (five fiscal years before revelation) | 2015-2019 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | AAER-4558 (2025-01-17) confirmed; undisclosed related-party payments to 501(c)(4) |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| EDISON INTERNATIONAL | 0000827052 | 4911 | sic4 | 0.16 | 2019 | $64.4 bn | 5 |
| DOMINION ENERGY, INC | 0000715957 | 4911 | sic4 | 0.31 | 2019 | $103.8 bn | 5 |
| ENTERGY CORP /DE/ | 0000065984 | 4911 | sic4 | 0.38 | 2019 | $51.7 bn | 5 |
| Tennessee Valley Authority | 0001376986 | 4911 | sic4 | 0.41 | 2019 | $50.2 bn | 5 |
| NEXTERA ENERGY INC | 0000753308 | 4911 | sic4 | 0.44 | 2019 | $117.7 bn | 5 |

### 23. American Equity Investment Life

| Item | Value |
|---|---|
| CIK | 0001039828 |
| EDGAR name | American National Group Inc. |
| SIC | 6311 — Life Insurance |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Misleading disclosure of a related-party transaction (CEO) in the 2006 proxy statement |
| Misconduct years / enforcement year | 2006 / 2010 |
| Enforcement references | LR-21431 (2010-03-03): company, CEO Noble and CFO Waugaman charged; disclosure case |
| First public revelation (D2) | 2010-03-03 — SEC complaint LR-21431 (company, CEO, CFO) on the 2006 proxy related-party disclosure; no earlier public revelation found |
| Revelation-date confidence | high — to verify: disclosure-only stratum |
| Assessment window (five fiscal years before revelation) | 2005-2009 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | LR-21431 (2010-03-03): company, CEO Noble and CFO Waugaman charged; disclosure case |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| REINSURANCE GROUP OF AMERICA INC | 0000898174 | 6311 | sic4 | 0.02 | 2011 | $31.6 bn | 5 |
| PHOENIX COMPANIES INC/DE | 0001129633 | 6311 | sic4 | 0.36 | 2011 | $21.5 bn | 5 |
| Empower Annuity Insurance Co of America | 0000744455 | 6311 | sic4 | 0.45 | 2011 | $48.2 bn | 5 |
| DELAWARE LIFE INSURANCE CO | 0000745544 | 6311 | sic4 | 0.45 | 2011 | $48.2 bn | 5 |
| PROTECTIVE LIFE INSURANCE CO | 0000310826 | 6311 | sic4 | 0.52 | 2011 | $52.0 bn | 5 |

### 24. Energy XXI

| Item | Value |
|---|---|
| CIK | 0001343719 |
| EDGAR name | Energy XXI Ltd |
| SIC | 1382 — Oil & Gas Field Exploration Services |
| State of incorporation / fiscal year end | Bermuda / 0630 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | CEO undisclosed personal loans from vendors and a board candidate; perquisites |
| Misconduct years / enforcement year | 2010-2014 / 2018 |
| Enforcement references | Press release 2018-133 |
| First public revelation (D2) | 2016-10-28 — 10-K/A: audit / special committee investigation of CEO loans (FTS) |
| Revelation-date confidence | medium — to verify: disclosure-only stratum; check 2016-04 8-K (CEO departure) |
| Assessment window (five fiscal years before revelation) | 2011-2015 |
| Annual reports in the window / on file FY2004–2024 | 5 / 10 (2007–2016) |
| Screening notes | Press release 2018-133 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| SARATOGA RESOURCES INC /TX | 0001096339 | 1382 | sic4 | 3.12 | 2015 | $78 m | 4 |
| EFLO ENERGY, INC. | 0001448806 | 1382 | sic4 | 3.52 | 2015 | $52 m | 4 |
| HII Technologies, Inc. | 0001085254 | 1382 | sic4 | 3.86 | 2015 | $37 m | 4 |
| RIDGEWOOD ENERGY V FUND LLC | 0001385662 | 1382 | sic4 | 4.21 | 2015 | $26 m | 5 |
| RIDGEWOOD ENERGY Y FUND LLC | 0001434070 | 1382 | sic4 | 4.24 | 2015 | $26 m | 5 |

### 25. First Bancorp (NC)

| Item | Value |
|---|---|
| CIK | 0000811589 |
| EDGAR name | FIRST BANCORP /NC/ |
| SIC | 6022 — State Commercial Banks |
| State of incorporation / fiscal year end | NC / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Failed to disclose related-party transactions involving family of COO and CLO; no RPT controls |
| Misconduct years / enforcement year | 2011-2013 / 2015 |
| Enforcement references | AAER-3660 |
| First public revelation (D2) | 2015-06-01 — AAER-3660; no prior revelation |
| Revelation-date confidence | high — to verify: disclosure-only stratum |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | AAER-3660 (2015-06-01); likely excluded under D1 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| ENTERPRISE FINANCIAL SERVICES CORP | 0001025835 | 6022 | sic4 | 0.02 | 2014 | $3.3 bn | 5 |
| HUDSON VALLEY HOLDING CORP | 0000722256 | 6022 | sic4 | 0.03 | 2014 | $3.1 bn | 5 |
| MAINSOURCE FINANCIAL GROUP | 0000720002 | 6022 | sic4 | 0.03 | 2014 | $3.1 bn | 5 |
| SEACOAST BANKING CORP OF FLORIDA | 0000730708 | 6022 | sic4 | 0.04 | 2014 | $3.1 bn | 5 |
| FIDELITY SOUTHERN CORP | 0000822662 | 6022 | sic4 | 0.04 | 2014 | $3.1 bn | 5 |

### 26. Gulfport Energy

| Item | Value |
|---|---|
| CIK | 0000874499 |
| EDGAR name | GULFPORT ENERGY CORP |
| SIC | 1311 — Crude Petroleum & Natural Gas |
| State of incorporation / fiscal year end | — / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | CEO perquisites and one related-party payment |
| Misconduct years / enforcement year | 2014-2018 / 2021 |
| Enforcement references | Rel. 33-10930 (not on the AAER list) |
| First public revelation (D2) | 2018-11-01 — 10-Q Q3 2018 (0001628280-18-013345): Audit Committee informed Sept 2018 of undisclosed CEO aircraft use and personal charges; CEO stepped down 2018-10-29 |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2013-2017 |
| Annual reports in the window / on file FY2004–2024 | 5 / 18 (2007–2024) |
| Screening notes | Order 33-10930 (24 Feb 2021) not on the AAER list; revelation date established 10 Oct 2026 from the Q3 2018 10-Q; approved as the 31st case |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| SM Energy Co | 0000893538 | 1311 | sic4 | 0.06 | 2017 | $6.2 bn | 5 |
| California Resources Corp | 0001609253 | 1311 | sic4 | 0.07 | 2017 | $6.2 bn | 4 |
| RSP Permian, Inc. | 0001588216 | 1311 | sic4 | 0.08 | 2017 | $6.3 bn | 5 |
| Chord Energy Corp | 0001486159 | 1311 | sic4 | 0.13 | 2017 | $6.6 bn | 5 |
| NEWFIELD EXPLORATION CO /DE/ | 0000912750 | 1311 | sic4 | 0.16 | 2017 | $5.0 bn | 5 |

### 27. Maximus

| Item | Value |
|---|---|
| CIK | 0001032220 |
| EDGAR name | MAXIMUS, INC. |
| SIC | 7389 — Services-Business Services, NEC |
| State of incorporation / fiscal year end | VA / 0930 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed employment of executive's siblings |
| Misconduct years / enforcement year | 2019-2021 / 2023 |
| Enforcement references | Order 34-98351 |
| First public revelation (D2) | 2023-09-11 — SEC order 34-98351; no prior revelation |
| Revelation-date confidence | high — to verify: disclosure-only stratum |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | Order 34-98351 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| MONEYGRAM INTERNATIONAL INC | 0001273931 | 7389 | sic4 | 0.06 | 2022 | $4.5 bn | 5 |
| Lyft, Inc. | 0001759509 | 7389 | sic4 | 0.07 | 2022 | $4.6 bn | 4 |
| MSCI Inc. | 0001408198 | 7389 | sic4 | 0.17 | 2022 | $5.0 bn | 5 |
| CONDUENT Inc | 0001677703 | 7389 | sic4 | 0.17 | 2022 | $3.6 bn | 5 |
| TRINET GROUP, INC. | 0000937098 | 7389 | sic4 | 0.21 | 2022 | $3.4 bn | 5 |

### 28. RCI Hospitality Holdings

| Item | Value |
|---|---|
| CIK | 0000935419 |
| EDGAR name | RCI HOSPITALITY HOLDINGS, INC. |
| SIC | 5812 — Retail-Eating  Places |
| State of incorporation / fiscal year end | TX / 0930 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed related-party transactions with CEO's father and brother; perquisites |
| Misconduct years / enforcement year | 2014-2019 / 2020 |
| Enforcement references | Order 34-89935 |
| First public revelation (D2) | 2020-09-21 — SEC order 34-89935 (placeholder); SEC subpoena disclosed in 2019 filings? |
| Revelation-date confidence | low — to verify: disclosure-only stratum; search 2019 10-K/10-Q |
| Assessment window (five fiscal years before revelation) | 2015-2019 |
| Annual reports in the window / on file FY2004–2024 | 5 / 16 (2009–2024) |
| Screening notes | Order 34-89935 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| NOODLES & Co | 0001275158 | 5812 | sic4 | 0.00 | 2019 | $379 m | 5 |
| POTBELLY CORP | 0001195734 | 5812 | sic4 | 0.12 | 2019 | $333 m | 5 |
| CHUY'S HOLDINGS, INC. | 0001524931 | 5812 | sic4 | 0.17 | 2019 | $446 m | 5 |
| DENNY'S Corp | 0000852772 | 5812 | sic4 | 0.20 | 2019 | $460 m | 5 |
| Habit Restaurants, Inc. | 0001617977 | 5812 | sic4 | 0.24 | 2019 | $478 m | 5 |

### 29. Shift4 Payments

| Item | Value |
|---|---|
| CIK | 0001794669 |
| EDGAR name | Shift4 Payments, Inc. |
| SIC | 7389 — Services-Business Services, NEC |
| State of incorporation / fiscal year end | — / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed employment of and commissions to executives' relatives |
| Misconduct years / enforcement year | 2020-2023 / 2025 |
| Enforcement references | Order 34-102146 |
| First public revelation (D2) | 2025-01-10 — SEC order 34-102146; no prior revelation |
| Revelation-date confidence | high — to verify: disclosure-only stratum |
| Assessment window (five fiscal years before revelation) | 2020-2024 |
| Annual reports in the window / on file FY2004–2024 | 5 / 5 (2020–2024) |
| Screening notes | Order 34-102146 |

**Matched firms (4)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Claritev Corp | 0001793229 | 7389 | sic4 | 0.02 | 2024 | $5.2 bn | 5 |
| CBIZ, Inc. | 0000944148 | 7389 | sic4 | 0.12 | 2024 | $4.5 bn | 5 |
| ZILLOW GROUP, INC. | 0001617640 | 7389 | sic4 | 0.14 | 2024 | $5.8 bn | 5 |
| HEALTHEQUITY, INC. | 0001428336 | 7389 | sic4 | 0.37 | 2024 | $3.5 bn | 5 |

### 30. Skechers U.S.A.

| Item | Value |
|---|---|
| CIK | 0001065837 |
| EDGAR name | SKECHERS USA INC |
| SIC | 3140 — Footwear, (No Rubber) |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed employment of relatives; consulting relationship; executive loans > $120k |
| Misconduct years / enforcement year | 2019-2022 / 2024 |
| Enforcement references | Order 34-99693 2024-03-07; not on AAER listing |
| First public revelation (D2) | 2024-03-07 — SEC settled order 34-99693; no prior public revelation |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2019-2023 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | Order 34-99693 2024-03-07; not on AAER listing |

**Matched firms (4)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| WOLVERINE WORLD WIDE INC /DE/ | 0000110471 | 3140 | sic2 | 1.30 | 2023 | $2.1 bn | 5 |
| CALERES INC | 0000014707 | 3140 | sic2 | 1.42 | 2023 | $1.8 bn | 5 |
| STEVEN MADDEN, LTD. | 0000913241 | 3140 | sic2 | 1.72 | 2023 | $1.3 bn | 5 |
| ROCKY BRANDS, INC. | 0000895456 | 3140 | sic2 | 2.76 | 2023 | $479 m | 5 |

### 31. The Greenbrier Companies

| Item | Value |
|---|---|
| CIK | 0000923120 |
| EDGAR name | GREENBRIER COMPANIES INC |
| SIC | 3743 — Railroad Equipment |
| State of incorporation / fiscal year end | OR / 0831 |
| Stratum | Main sample — disclosure-only |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | CEO received ~$1.6m from company charter payments for his aircraft; perquisites |
| Misconduct years / enforcement year | 2017-2021 / 2023 |
| Enforcement references | Press release 2023-43 |
| First public revelation (D2) | 2023-03-02 — SEC settled order; no prior revelation |
| Revelation-date confidence | high — to verify: disclosure-only stratum |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | Press release 2023-43 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| OSHKOSH CORP | 0000775158 | 3711 | sic2 | 0.70 | 2022 | $7.7 bn | 5 |
| TRINITY INDUSTRIES INC | 0000099780 | 3743 | sic2 | 0.83 | 2022 | $8.7 bn | 5 |
| Fisker Inc./DE | 0001720990 | 3711 | sic2 | 0.92 | 2022 | $1.5 bn | 5 |
| REV Group, Inc. | 0001687221 | 3711 | sic2 | 1.04 | 2022 | $1.3 bn | 5 |
| Nikola Corp | 0001731289 | 3711 | sic2 | 1.13 | 2022 | $1.2 bn | 5 |

## Part C — External validation cases (10)

Cases that fail the design's four-report rule but have three annual reports in the window. They and their matched firms were never used in fitting; the final model was applied to them once (AUC 0.73, matched-firm false-alarm rate 5.8 %).

### 32. American Realty Capital Properties

| Item | Value |
|---|---|
| CIK | 0001507385 |
| EDGAR name | VEREIT, Inc. |
| SIC | 6798 — Real Estate Investment Trusts |
| State of incorporation / fiscal year end | — / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-party payments to manager's affiliates; AFFO misstatement |
| Misconduct years / enforcement year | 2013-2014 / 2020 |
| Enforcement references | ~3 firm-years |
| First public revelation (D2) | 2014-10-29 — phase_a_screen_v2 |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2009-2013 |
| Annual reports in the window / on file FY2004–2024 | 3 / 10 (2011–2020) |
| Screening notes | ~3 firm-years |
| External validation (never used in fitting) | max score 0.566; flagged years 0; matched-firm window rows 25 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| DUKE REALTY CORP | 0000783280 | 6798 |  |  |  |  | 5 |
| ALEXANDRIA REAL ESTATE EQUITIES, INC. | 0001035443 | 6798 |  |  |  |  | 5 |
| EQUINIX INC | 0001101239 | 6798 |  |  |  |  | 5 |
| ANWORTH MORTGAGE ASSET CORP | 0001047884 | 6798 |  |  |  |  | 5 |
| CHIMERA INVESTMENT CORP | 0001409493 | 6798 |  |  |  |  | 5 |

### 33. Apple REIT Nine

| Item | Value |
|---|---|
| CIK | 0001418121 |
| EDGAR name | Apple Hospitality REIT, Inc. |
| SIC | 6798 — Real Estate Investment Trusts |
| State of incorporation / fiscal year end | VA / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Related-party fees and transactions with adviser |
| Misconduct years / enforcement year | 2008-2012 / 2014 |
| Enforcement references | AAER-3535 (2014-02-12) confirmed (Apple REIT Six-Nine joint order) |
| First public revelation (D2) | 2011-05-27 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: AAER-3535 2014-02-12 |
| Assessment window (five fiscal years before revelation) | 2006-2010 |
| Annual reports in the window / on file FY2004–2024 | 3 / 17 (2008–2024) |
| Screening notes | AAER-3535 (2014-02-12) confirmed (Apple REIT Six-Nine joint order) |
| External validation (never used in fitting) | max score 0.513; flagged years 0; matched-firm window rows 24 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Public Storage | 0001393311 | 6798 |  |  |  |  | 4 |
| KIMCO REALTY CORP | 0000879101 | 6798 |  |  |  |  | 5 |
| AVALONBAY COMMUNITIES INC | 0000915912 | 6798 |  |  |  |  | 5 |
| WEYERHAEUSER CO | 0000106535 | 6798 |  |  |  |  | 5 |
| AMERICAN TOWER CORP /MA/ | 0001053507 | 6798 |  |  |  |  | 5 |

### 34. China Natural Gas

| Item | Value |
|---|---|
| CIK | 0001120830 |
| EDGAR name | China Natural Gas, Inc. |
| SIC | 4923 — Natural Gas Transmisison & Distribution |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Undisclosed related-party loan |
| Misconduct years / enforcement year | 2008;2010 / 2012 |
| Enforcement references | Reverse merger; ICFR missing first years |
| First public revelation (D2) | 2010-08-20 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: verify which filing first disclosed the loan |
| Assessment window (five fiscal years before revelation) | 2005-2009 |
| Annual reports in the window / on file FY2004–2024 | 3 / 6 (2007–2012) |
| Screening notes | Reverse merger; ICFR missing first years |
| External validation (never used in fitting) | max score 0.643; flagged years 0; matched-firm window rows 5 |

**Matched firms (1)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| CONSTELLATION ENERGY GROUP INC | 0001004440 | 4911 |  |  |  |  | 5 |

### 35. China North East Petroleum

| Item | Value |
|---|---|
| CIK | 0000787251 |
| EDGAR name | CHINA NORTH EAST PETROLEUM HOLDINGS LTD |
| SIC | 1311 — Crude Petroleum & Natural Gas |
| State of incorporation / fiscal year end | NV / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | Transfers to CEO and family; related-party loans |
| Misconduct years / enforcement year | 2009 / 2012 |
| Enforcement references | Reverse merger |
| First public revelation (D2) | 2010-03-08 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: check 2010-05/06 8-Ks for the transfers |
| Assessment window (five fiscal years before revelation) | 2005-2009 |
| Annual reports in the window / on file FY2004–2024 | 3 / 4 (2007–2010) |
| Screening notes | Reverse merger |
| External validation (never used in fitting) | max score 0.612; flagged years 0; matched-firm window rows 25 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| ULTRA PETROLEUM CORP | 0001022646 | 1311 |  |  |  |  | 5 |
| SABINE OIL & GAS CORP | 0000038079 | 1311 |  |  |  |  | 5 |
| Coterra Energy Inc. | 0000858470 | 1311 |  |  |  |  | 5 |
| ENERGEN CORP | 0000277595 | 1311 |  |  |  |  | 5 |
| CIMAREX ENERGY CO | 0001168054 | 1311 |  |  |  |  | 5 |

### 36. ChinaCast Education

| Item | Value |
|---|---|
| CIK | 0001261888 |
| EDGAR name | CHINACAST EDUCATION CORP |
| SIC | 8200 — Services-Educational Services |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | $41m of offering proceeds moved to subsidiary secretly 50% owned by CEO |
| Misconduct years / enforcement year | 2011-2012 / 2013 |
| Enforcement references | Press release 2013-200 |
| First public revelation (D2) | 2012-04-02 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: attach 8-K |
| Assessment window (five fiscal years before revelation) | 2007-2011 |
| Annual reports in the window / on file FY2004–2024 | 3 / 3 (2008–2010) |
| Screening notes | Press release 2013-200 |
| External validation (never used in fitting) | max score 0.520; flagged years 0; matched-firm window rows 5 |

**Matched firms (1)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| AMERICAN PUBLIC EDUCATION INC | 0001201792 | 8200 |  |  |  |  | 5 |

### 37. Ener1

| Item | Value |
|---|---|
| CIK | 0000895642 |
| EDGAR name | ENER1 INC |
| SIC | 3690 — Miscellaneous Electrical Machinery, Equipment & Supplies |
| State of incorporation / fiscal year end | FL / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-entity revenue and asset valuation (Think) |
| Misconduct years / enforcement year | 2010 / 2016 |
| Enforcement references | — |
| First public revelation (D2) | 2011-08-15 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: attach accession |
| Assessment window (five fiscal years before revelation) | 2006-2010 |
| Annual reports in the window / on file FY2004–2024 | 3 / 3 (2008–2010) |
| Screening notes | — |
| External validation (never used in fitting) | max score 0.590; flagged years 0; matched-firm window rows  |

**Matched firms (0)**


### 38. HF Foods Group

| Item | Value |
|---|---|
| CIK | 0001680873 |
| EDGAR name | HF Foods Group Inc. |
| SIC | 5140 — Wholesale-Groceries & Related Products |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misappropriation+misstatement |
| RPT element (from the enforcement documents) | CEO misappropriated ~$3.4m through related-party transactions; false RPT and compensation disclosures |
| Misconduct years / enforcement year | 2018-2020 / 2024 |
| Enforcement references | AAER-4506 (2024-06-06); public from Aug 2018 -> fails the 4-report rule unless window relaxed |
| First public revelation (D2) | 2020-03-23 — phase_a_screen_v2 |
| Revelation-date confidence | high — to verify: AAER-4506 2024-06-06 |
| Assessment window (five fiscal years before revelation) | 2015-2019 |
| Annual reports in the window / on file FY2004–2024 | 3 / 8 (2017–2024) |
| Screening notes | AAER-4506 (2024-06-06); public from Aug 2018 -> fails the 4-report rule unless window relaxed |
| External validation (never used in fitting) | max score 0.895; flagged years 1 (FY2019); matched-firm window rows 25 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| DOMINOS PIZZA INC | 0001286681 | 5140 |  |  |  |  | 5 |
| SYSCO CORP | 0000096021 | 5140 |  |  |  |  | 5 |
| ALKALINE WATER Co INC | 0001532390 | 5140 |  |  |  |  | 5 |
| RAVE RESTAURANT GROUP, INC. | 0000718332 | 5140 |  |  |  |  | 5 |
| Cuentas Inc. | 0001424657 | 5140 |  |  |  |  | 5 |

### 39. Home Loan Servicing Solutions

| Item | Value |
|---|---|
| CIK | 0001513161 |
| EDGAR name | HOME LOAN SERVICING SOLUTIONS, LTD. |
| SIC | 6162 — Mortgage Bankers & Loan Correspondents |
| State of incorporation / fiscal year end | Cayman Islands / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Misstated related-party recusal disclosures |
| Misconduct years / enforcement year | 2012-2014 / 2015 |
| Enforcement references | AAER-3713 (2015-10-05) confirmed |
| First public revelation (D2) | 2015-03-02 — phase_a_screen_v2 |
| Revelation-date confidence | medium — to verify: AAER-3713 2015-10-05 |
| Assessment window (five fiscal years before revelation) | 2010-2014 |
| Annual reports in the window / on file FY2004–2024 | 3 / 3 (2012–2014) |
| Screening notes | AAER-3713 (2015-10-05) confirmed |
| External validation (never used in fitting) | max score 0.602; flagged years 0; matched-firm window rows 3 |

**Matched firms (1)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Nationstar Mortgage Holdings Inc. | 0001520566 | 6162 |  |  |  |  | 3 |

### 40. RINO International

| Item | Value |
|---|---|
| CIK | 0001394220 |
| EDGAR name | JOIN Entertainment Holdings, Inc. |
| SIC | 3569 — General Industrial Machinery & Equipment, NEC |
| State of incorporation / fiscal year end | NV / 1231 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misappropriation |
| RPT element (from the enforcement documents) | Funds diverted to CEO/chairman; fictitious contracts |
| Misconduct years / enforcement year | 2008-2010 / 2013 |
| Enforcement references | ~3 firm-years |
| First public revelation (D2) | 2010-11-10 — phase_a_screen_v2 |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2005-2009 |
| Annual reports in the window / on file FY2004–2024 | 3 / 3 (2007–2009) |
| Screening notes | ~3 firm-years |
| External validation (never used in fitting) | max score 0.590; flagged years 0; matched-firm window rows  |

**Matched firms (0)**


### 41. iFresh

| Item | Value |
|---|---|
| CIK | 0001681941 |
| EDGAR name | iFresh Inc |
| SIC | 5411 — Retail-Grocery Stores |
| State of incorporation / fiscal year end | DE / 0331 |
| Stratum | External validation (three-report rule) |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | >$12m paid to company owned by CEO's brother; undisclosed related-party receivables 18-54% of receivables |
| Misconduct years / enforcement year | 2016-2020 / 2022 |
| Enforcement references | LR-25404; LR-25735 |
| First public revelation (D2) | 2022-05-31 — phase_a_screen_v2 |
| Revelation-date confidence | low — to verify: search 2020-2021 filings |
| Assessment window (five fiscal years before revelation) | 2017-2021 |
| Annual reports in the window / on file FY2004–2024 | 3 / 4 (2016–2019) |
| Screening notes | LR-25404; LR-25735 |
| External validation (never used in fitting) | max score 0.549; flagged years 0; matched-firm window rows 25 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Natural Grocers by Vitamin Cottage, Inc. | 0001547459 | 5411 |  |  |  |  | 5 |
| VILLAGE SUPER MARKET INC | 0000103595 | 5411 |  |  |  |  | 5 |
| WEIS MARKETS INC | 0000105418 | 5411 |  |  |  |  | 5 |
| INGLES MARKETS INC | 0000050493 | 5411 |  |  |  |  | 5 |
| Sprouts Farmers Market, Inc. | 0001575515 | 5411 |  |  |  |  | 5 |

## Part D — Pilot anchors (5) and their hand-picked competitors

The pilot (October 2026, FY2014–2024 then FY2004–2024) used five anchors from the client's workbook with competitors chosen by hand from the research design rather than by rule. Three of the anchors (Ault Alliance, Co-Diagnostics, Skechers) are in the main sample above; Gulfport was dated from its own filings on 10 October 2026 and approved as the 31st case (Part B); ProPetro fails the four-report rule (two annual reports before revelation) and stays out. Pilot results are reported separately in the thesis as the development stage.

### 42. Ault Alliance, Inc. (now Hyperscale Data)

| Item | Value |
|---|---|
| CIK | 0000896493 |
| EDGAR name | Hyperscale Data, Inc. |
| SIC | 3533 — Oil & Gas Field Machinery & Equipment |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Pilot anchor |
| Form of RPT fraud (D1 class) | misappropriation+misstatement |
| RPT element (from the enforcement documents) | CEO debt repayment booked as consulting fees; related-entity loans and investments |
| Misconduct years / enforcement year | 2016-2022 / 2023 |
| Enforcement references | AAER-4440 |
| First public revelation (D2) | 2023-08-15 — SEC administrative order 33-11222 (AAER-4440). Check 10-K/8-K for an earlier subpoena or investigation disclosure. |
| Revelation-date confidence | medium — to verify: check FY2021 10-K (filed 2022) for an earlier SEC-investigation disclosure |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 17 (2008–2024) |
| Screening notes | AAER-4440 confirmed; revelation 2023-08-15 provisional |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| ITERIS, INC. | 0000350868 | 3669 | hand-picked competitor |  |  |  | 5 |
| TRANSACT TECHNOLOGIES INC | 0001017303 | 3577 | hand-picked competitor |  |  |  | 0 |
| KEY TRONIC CORP | 0000719733 | 3672 | hand-picked competitor |  |  |  | 0 |
| AstroNova, Inc. | 0000008146 | 3577 | hand-picked competitor |  |  |  | 0 |
| CPI Card Group Inc. | 0001641614 | 2750 | hand-picked competitor |  |  |  | 0 |

### 43. ProPetro Holding Corp.

| Item | Value |
|---|---|
| CIK | 0001680247 |
| EDGAR name | ProPetro Holding Corp. |
| SIC | 1389 — Oil & Gas Field Services, NEC |
| State of incorporation / fiscal year end | TX / 1231 |
| Stratum | Pilot anchor |
| Form of RPT fraud (D1 class) | disclosure+misstatement |
| RPT element (from the enforcement documents) | Undisclosed related-party transactions and perquisites; audit-committee review 2019 |
| Misconduct years / enforcement year | 2017-2018 / 2021 |
| Enforcement references | AAER-4268 |
| First public revelation (D2) | 2019-08-08 — 8-K announcing delayed 10-Q and audit-committee review of related-party transactions and perquisites; SEC order 33-11008 of 2021-11-22 (AAER-4268). Verify exact 8-K date. |
| Revelation-date confidence | medium — to verify: attach 8-K accession |
| Assessment window (five fiscal years before revelation) | 2014-2018 |
| Annual reports in the window / on file FY2004–2024 | 0 / 0 (–) |
| Screening notes | AAER-4268 confirmed 2021-11-22; only 2 pre-revelation 10-Ks |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Liberty Energy Inc. | 0001694028 | 1389 | hand-picked competitor |  |  |  | 0 |
| NEXTIER OILFIELD SOLUTIONS INC. | 0001688476 | 1389 | hand-picked competitor |  |  |  | 0 |
| RPC INC | 0000742278 | 1389 | hand-picked competitor |  |  |  | 0 |
| Nine Energy Service, Inc. | 0001532286 | 1389 | hand-picked competitor |  |  |  | 0 |
| PATTERSON UTI ENERGY INC | 0000889900 | 1381 | hand-picked competitor |  |  |  | 0 |

### 44. Co-Diagnostics, Inc.

| Item | Value |
|---|---|
| CIK | 0001692415 |
| EDGAR name | Co-Diagnostics, Inc. |
| SIC | 3841 — Surgical & Medical Instruments & Apparatus |
| State of incorporation / fiscal year end | UT / 1231 |
| Stratum | Pilot anchor |
| Form of RPT fraud (D1 class) | misstatement |
| RPT element (from the enforcement documents) | Related-party licence and compensation arrangements misstated |
| Misconduct years / enforcement year | 2018-2020 / 2023 |
| Enforcement references | AAER-4428 |
| First public revelation (D2) | 2023-07-05 — SEC order 33-11209 of 2023-07-05 (AAER-4428) used as the revelation date; replace if an earlier 8-K or 10-K disclosure exists. |
| Revelation-date confidence | low — to verify: search 8-K/10-Q 2021-2023 for SEC inquiry disclosure |
| Assessment window (five fiscal years before revelation) | 2018-2022 |
| Annual reports in the window / on file FY2004–2024 | 5 / 8 (2017–2024) |
| Screening notes | AAER-4428 confirmed 2023-07-05 |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| ORASURE TECHNOLOGIES INC | 0001116463 | 3841 | hand-picked competitor |  |  |  | 0 |
| BIODESIX INC | 0001439725 | 8071 | hand-picked competitor |  |  |  | 0 |
| Quanterix Corp | 0001503274 | 3826 | hand-picked competitor |  |  |  | 0 |
| CHEMBIO DIAGNOSTICS, INC. | 0001092662 | 2834 | hand-picked competitor |  |  |  | 5 |
| MERIDIAN BIOSCIENCE INC | 0000794172 | 2835 | hand-picked competitor |  |  |  | 0 |

### 45. Gulfport Energy Corp.

| Item | Value |
|---|---|
| CIK | 0000874499 |
| EDGAR name | GULFPORT ENERGY CORP |
| SIC | 1311 — Crude Petroleum & Natural Gas |
| State of incorporation / fiscal year end | — / 1231 |
| Stratum | Pilot anchor |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | CEO perquisites and one related-party payment |
| Misconduct years / enforcement year | 2014-2018 / 2021 |
| Enforcement references | Order 33-10930 (24 Feb 2021) not on the AAER list; revelation date established 10 Oct 2026 from the Q3 2018 10-Q; approved as the 31st case |
| First public revelation (D2) |  — SEC order 2021. Check FY2019 10-K / 2019-2020 8-Ks for the first disclosure of the CEO perquisite and related-party review. |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2013-2017 |
| Annual reports in the window / on file FY2004–2024 | 5 / 18 (2007–2024) |
| Screening notes | Order 33-10930 (24 Feb 2021) not on the AAER list; revelation date established 10 Oct 2026 from the Q3 2018 10-Q; approved as the 31st case |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Matador Resources Co | 0001520006 | 1311 | hand-picked competitor |  |  |  | 0 |
| CIMAREX ENERGY CO | 0001168054 | 1311 | hand-picked competitor |  |  |  | 5 |
| PDC ENERGY, INC. | 0000077877 | 1311 | hand-picked competitor |  |  |  | 0 |
| SM Energy Co | 0000893538 | 1311 | hand-picked competitor |  |  |  | 5 |
| Callon Petroleum Co | 0000928022 | 1311 | hand-picked competitor |  |  |  | 0 |

### 46. Skechers U.S.A., Inc.

| Item | Value |
|---|---|
| CIK | 0001065837 |
| EDGAR name | SKECHERS USA INC |
| SIC | 3140 — Footwear, (No Rubber) |
| State of incorporation / fiscal year end | DE / 1231 |
| Stratum | Pilot anchor |
| Form of RPT fraud (D1 class) | disclosure_only |
| RPT element (from the enforcement documents) | Undisclosed employment of relatives; consulting relationship; executive loans > $120k |
| Misconduct years / enforcement year | 2019-2022 / 2024 |
| Enforcement references | Order 34-99693 2024-03-07; not on AAER listing |
| First public revelation (D2) | 2024-03-07 — SEC settled order 34-99693 (press release 2024-33). No prior public revelation found. |
| Revelation-date confidence | high |
| Assessment window (five fiscal years before revelation) | 2019-2023 |
| Annual reports in the window / on file FY2004–2024 | 5 / 21 (2004–2024) |
| Screening notes | Order 34-99693 2024-03-07; not on AAER listing |

**Matched firms (5)**

| Matched firm | CIK | SIC | Match level | Gap in ln(assets) | Size anchor year | Firm assets at anchor | 10-Ks in window |
|---|---|---|---|---|---|---|---|
| Crocs, Inc. | 0001334036 | 3021 | hand-picked competitor |  |  |  | 0 |
| DECKERS OUTDOOR CORP | 0000910521 | 3021 | hand-picked competitor |  |  |  | 0 |
| STEVEN MADDEN, LTD. | 0000913241 | 3140 | hand-picked competitor |  |  |  | 5 |
| WOLVERINE WORLD WIDE INC /DE/ | 0000110471 | 3140 | hand-picked competitor |  |  |  | 5 |
| NIKE, Inc. | 0000320187 | 3021 | hand-picked competitor |  |  |  | 0 |

## Part E — Index of all firms

| # | Firm | CIK | Role | Set |
|---|---|---|---|---|
| 1 | Ault Alliance | 0000896493 | case | main sample |
| 2 | Co-Diagnostics | 0001692415 | case | main sample |
| 3 | Skechers U.S.A. | 0001065837 | case | main sample |
| 4 | Eagle Bancorp | 0001050441 | case | main sample |
| 5 | Ocwen Financial | 0000873860 | case | main sample |
| 6 | Valeant Pharmaceuticals | 0000885590 | case | main sample |
| 7 | Manitex International | 0001302028 | case | main sample |
| 8 | American Electric Power | 0000004904 | case | main sample |
| 9 | Singularity Future Technology | 0001422892 | case | main sample |
| 10 | Puda Coal | 0001162747 | case | main sample |
| 11 | General Employment Enterprises | 0000040570 | case | main sample |
| 12 | SAExploration Holdings | 0001514732 | case | main sample |
| 13 | Ideanomics (Seven Stars Cloud) | 0000837852 | case | main sample |
| 14 | RCI Hospitality Holdings | 0000935419 | case | main sample |
| 15 | The Greenbrier Companies | 0000923120 | case | main sample |
| 16 | Energy XXI | 0001343719 | case | main sample |
| 17 | Maximus | 0001032220 | case | main sample |
| 18 | United Development Funding IV | 0001440292 | case | main sample |
| 19 | FAT Brands | 0001705012 | case | main sample |
| 20 | Shift4 Payments | 0001794669 | case | main sample |
| 21 | Ammo Inc (Outdoor Holding) | 0001015383 | case | main sample |
| 22 | MusclePharm | 0001415684 | case | main sample |
| 23 | China Valves Technology | 0001080360 | case | main sample |
| 24 | Cemtrex | 0001435064 | case | main sample |
| 25 | Quadrant 4 System | 0000878802 | case | main sample |
| 26 | Provectus Biopharmaceuticals | 0000315545 | case | main sample |
| 27 | First Bancorp (NC) | 0000811589 | case | main sample |
| 28 | Corporate Resource Services | 0000943110 | case | main sample |
| 29 | American Equity Investment Life | 0001039828 | case | main sample |
| 30 | Premier Holding Corp | 0001030916 | case | main sample |
| 31 | Solaris Energy Infrastructure, Inc. | 0001697500 | peer of AULT_ALLIANCE | main sample |
| 32 | FORUM ENERGY TECHNOLOGIES, INC. | 0001401257 | peer of AULT_ALLIANCE | main sample |
| 33 | Innovex International, Inc. | 0001042893 | peer of AULT_ALLIANCE | main sample |
| 34 | OIL STATES INTERNATIONAL, INC | 0001121484 | peer of AULT_ALLIANCE | main sample |
| 35 | Cactus, Inc. | 0001699136 | peer of AULT_ALLIANCE | main sample |
| 36 | UTAH MEDICAL PRODUCTS INC | 0000706698 | peer of CO_DIAGNOSTICS | main sample |
| 37 | Venus Concept Inc. | 0001409269 | peer of CO_DIAGNOSTICS | main sample |
| 38 | DarioHealth Corp. | 0001533998 | peer of CO_DIAGNOSTICS | main sample |
| 39 | Intersect ENT, Inc. | 0001271214 | peer of CO_DIAGNOSTICS | main sample |
| 40 | Neuronetics, Inc. | 0001227636 | peer of CO_DIAGNOSTICS | main sample |
| 41 | WOLVERINE WORLD WIDE INC /DE/ | 0000110471 | peer of SKECHERS_U_S_A | main sample |
| 42 | CALERES INC | 0000014707 | peer of SKECHERS_U_S_A | main sample |
| 43 | STEVEN MADDEN, LTD. | 0000913241 | peer of SKECHERS_U_S_A | main sample |
| 44 | ROCKY BRANDS, INC. | 0000895456 | peer of SKECHERS_U_S_A | main sample |
| 45 | Ameris Bancorp | 0000351569 | peer of EAGLE_BANCORP | main sample |
| 46 | S&T BANCORP INC | 0000719220 | peer of EAGLE_BANCORP | main sample |
| 47 | FIRST FINANCIAL BANKSHARES INC | 0000036029 | peer of EAGLE_BANCORP | main sample |
| 48 | YADKIN FINANCIAL Corp | 0001366367 | peer of EAGLE_BANCORP | main sample |
| 49 | OFG BANCORP | 0001030469 | peer of EAGLE_BANCORP | main sample |
| 50 | BRISTOL MYERS SQUIBB CO | 0000014272 | peer of VALEANT_PHARMA | main sample |
| 51 | ELI LILLY & Co | 0000059478 | peer of VALEANT_PHARMA | main sample |
| 52 | CELGENE CORP /DE/ | 0000816284 | peer of VALEANT_PHARMA | main sample |
| 53 | ABBOTT LABORATORIES | 0000001800 | peer of VALEANT_PHARMA | main sample |
| 54 | MYLAN INC. | 0000069499 | peer of VALEANT_PHARMA | main sample |
| 55 | AMTECH SYSTEMS INC | 0000720500 | peer of MANITEX_INTERN | main sample |
| 56 | Energy Recovery, Inc. | 0001421517 | peer of MANITEX_INTERN | main sample |
| 57 | ULTRATECH INC | 0000909791 | peer of MANITEX_INTERN | main sample |
| 58 | INTEVAC INC | 0001001902 | peer of MANITEX_INTERN | main sample |
| 59 | AXCELIS TECHNOLOGIES INC | 0001113232 | peer of MANITEX_INTERN | main sample |
| 60 | EDISON INTERNATIONAL | 0000827052 | peer of AMERICAN_ELECT | main sample |
| 61 | DOMINION ENERGY, INC | 0000715957 | peer of AMERICAN_ELECT | main sample |
| 62 | ENTERGY CORP /DE/ | 0000065984 | peer of AMERICAN_ELECT | main sample |
| 63 | Tennessee Valley Authority | 0001376986 | peer of AMERICAN_ELECT | main sample |
| 64 | NEXTERA ENERGY INC | 0000753308 | peer of AMERICAN_ELECT | main sample |
| 65 | Unique Logistics International, Inc. | 0001281845 | peer of SINGULARITY_FU | main sample |
| 66 | RADIANT LOGISTICS, INC | 0001171155 | peer of SINGULARITY_FU | main sample |
| 67 | FORWARD AIR CORP | 0000912728 | peer of SINGULARITY_FU | main sample |
| 68 | Hub Group, Inc. | 0000940942 | peer of SINGULARITY_FU | main sample |
| 69 | HireQuest, Inc. | 0001140102 | peer of GENERAL_EMPLOY | main sample |
| 70 | DLH Holdings Corp. | 0000785557 | peer of GENERAL_EMPLOY | main sample |
| 71 | IGEN NETWORKS CORP | 0001393540 | peer of GENERAL_EMPLOY | main sample |
| 72 | CTPARTNERS EXECUTIVE SEARCH INC. | 0001439199 | peer of GENERAL_EMPLOY | main sample |
| 73 | Startek, Inc. | 0001031029 | peer of GENERAL_EMPLOY | main sample |
| 74 | TRANSATLANTIC PETROLEUM LTD. | 0001092289 | peer of SAEXPLORATION_ | main sample |
| 75 | DAWSON GEOPHYSICAL CO | 0000799165 | peer of SAEXPLORATION_ | main sample |
| 76 | ION GEOPHYSICAL CORP | 0000866609 | peer of SAEXPLORATION_ | main sample |
| 77 | Ridgewood Energy O Fund LLC | 0001315061 | peer of SAEXPLORATION_ | main sample |
| 78 | SEITEL INC | 0000750813 | peer of SAEXPLORATION_ | main sample |
| 79 | BOLLINGER INNOVATIONS, INC. | 0001499961 | peer of IDEANOMICS_SEV | main sample |
| 80 | Workhorse Group Inc. | 0001425287 | peer of IDEANOMICS_SEV | main sample |
| 81 | Kandi Technologies Group, Inc. | 0001316517 | peer of IDEANOMICS_SEV | main sample |
| 82 | Leo Motors, Inc. | 0001356564 | peer of IDEANOMICS_SEV | main sample |
| 83 | FEDERAL SIGNAL CORP /DE/ | 0000277509 | peer of IDEANOMICS_SEV | main sample |
| 84 | NOODLES & Co | 0001275158 | peer of RCI_HOSPITALIT | main sample |
| 85 | POTBELLY CORP | 0001195734 | peer of RCI_HOSPITALIT | main sample |
| 86 | CHUY'S HOLDINGS, INC. | 0001524931 | peer of RCI_HOSPITALIT | main sample |
| 87 | DENNY'S Corp | 0000852772 | peer of RCI_HOSPITALIT | main sample |
| 88 | Habit Restaurants, Inc. | 0001617977 | peer of RCI_HOSPITALIT | main sample |
| 89 | OSHKOSH CORP | 0000775158 | peer of THE_GREENBRIER | main sample |
| 90 | TRINITY INDUSTRIES INC | 0000099780 | peer of THE_GREENBRIER | main sample |
| 91 | Fisker Inc./DE | 0001720990 | peer of THE_GREENBRIER | main sample |
| 92 | REV Group, Inc. | 0001687221 | peer of THE_GREENBRIER | main sample |
| 93 | Nikola Corp | 0001731289 | peer of THE_GREENBRIER | main sample |
| 94 | SARATOGA RESOURCES INC /TX | 0001096339 | peer of ENERGY_XXI | main sample |
| 95 | EFLO ENERGY, INC. | 0001448806 | peer of ENERGY_XXI | main sample |
| 96 | HII Technologies, Inc. | 0001085254 | peer of ENERGY_XXI | main sample |
| 97 | RIDGEWOOD ENERGY V FUND LLC | 0001385662 | peer of ENERGY_XXI | main sample |
| 98 | RIDGEWOOD ENERGY Y FUND LLC | 0001434070 | peer of ENERGY_XXI | main sample |
| 99 | MONEYGRAM INTERNATIONAL INC | 0001273931 | peer of MAXIMUS | main sample |
| 100 | Lyft, Inc. | 0001759509 | peer of MAXIMUS | main sample |
| 101 | MSCI Inc. | 0001408198 | peer of MAXIMUS | main sample |
| 102 | CONDUENT Inc | 0001677703 | peer of MAXIMUS | main sample |
| 103 | TRINET GROUP, INC. | 0000937098 | peer of MAXIMUS | main sample |
| 104 | Lightstone Value Plus REIT I, Inc. | 0001296884 | peer of UNITED_DEVELOP | main sample |
| 105 | PREFERRED APARTMENT COMMUNITIES INC | 0001481832 | peer of UNITED_DEVELOP | main sample |
| 106 | INDEPENDENCE REALTY TRUST, INC. | 0001466085 | peer of UNITED_DEVELOP | main sample |
| 107 | SIGNATURE OFFICE REIT INC | 0001256069 | peer of UNITED_DEVELOP | main sample |
| 108 | Whitestone REIT | 0001175535 | peer of UNITED_DEVELOP | main sample |
| 109 | CARROLS RESTAURANT GROUP, INC. | 0000809248 | peer of FAT_BRANDS | main sample |
| 110 | Dine Brands Global, Inc. | 0000049754 | peer of FAT_BRANDS | main sample |
| 111 | BJs RESTAURANTS INC | 0001013488 | peer of FAT_BRANDS | main sample |
| 112 | PAPA JOHNS INTERNATIONAL INC | 0000901491 | peer of FAT_BRANDS | main sample |
| 113 | CRACKER BARREL OLD COUNTRY STORE, INC | 0001067294 | peer of FAT_BRANDS | main sample |
| 114 | Claritev Corp | 0001793229 | peer of SHIFT4_PAYMENT | main sample |
| 115 | CBIZ, Inc. | 0000944148 | peer of SHIFT4_PAYMENT | main sample |
| 116 | ZILLOW GROUP, INC. | 0001617640 | peer of SHIFT4_PAYMENT | main sample |
| 117 | HEALTHEQUITY, INC. | 0001428336 | peer of SHIFT4_PAYMENT | main sample |
| 118 | Nutex Health Inc. | 0001479681 | peer of AMMO_INC_OUTDO | main sample |
| 119 | Steel Connect LLC | 0000914712 | peer of AMMO_INC_OUTDO | main sample |
| 120 | Rimini Street, Inc. | 0001635282 | peer of AMMO_INC_OUTDO | main sample |
| 121 | Phreesia, Inc. | 0001412408 | peer of AMMO_INC_OUTDO | main sample |
| 122 | Edgio, Inc. | 0001391127 | peer of AMMO_INC_OUTDO | main sample |
| 123 | LIME ENERGY CO. | 0001065860 | peer of CEMTREX | main sample |
| 124 | SUNation Energy, Inc. | 0000022701 | peer of CEMTREX | main sample |
| 125 | China Advanced Construction Materials Group, Inc | 0001392363 | peer of CEMTREX | main sample |
| 126 | Real Goods Solar, Inc. | 0001425565 | peer of CEMTREX | main sample |
| 127 | LAYNE CHRISTENSEN CO | 0000888504 | peer of CEMTREX | main sample |
| 128 | WIRELESS TELECOM GROUP INC | 0000878828 | peer of QUADRANT_4_SYS | main sample |
| 129 | VICON INDUSTRIES INC /NY/ | 0000310056 | peer of QUADRANT_4_SYS | main sample |
| 130 | ID SYSTEMS INC | 0000049615 | peer of QUADRANT_4_SYS | main sample |
| 131 | Track Group, Inc. | 0001045942 | peer of QUADRANT_4_SYS | main sample |
| 132 | ITERIS, INC. | 0000350868 | peer of QUADRANT_4_SYS | main sample |
| 133 | Perspective Therapeutics, Inc. | 0000728387 | peer of PROVECTUS_BIOP | main sample |
| 134 | CHEMBIO DIAGNOSTICS, INC. | 0001092662 | peer of PROVECTUS_BIOP | main sample |
| 135 | Statera Biopharma, Inc. | 0001318641 | peer of PROVECTUS_BIOP | main sample |
| 136 | Altimmune, Inc. | 0001326190 | peer of PROVECTUS_BIOP | main sample |
| 137 | MIX 1 LIFE, INC. | 0001501112 | peer of PROVECTUS_BIOP | main sample |
| 138 | ENTERPRISE FINANCIAL SERVICES CORP | 0001025835 | peer of FIRST_BANCORP_ | main sample |
| 139 | HUDSON VALLEY HOLDING CORP | 0000722256 | peer of FIRST_BANCORP_ | main sample |
| 140 | MAINSOURCE FINANCIAL GROUP | 0000720002 | peer of FIRST_BANCORP_ | main sample |
| 141 | SEACOAST BANKING CORP OF FLORIDA | 0000730708 | peer of FIRST_BANCORP_ | main sample |
| 142 | FIDELITY SOUTHERN CORP | 0000822662 | peer of FIRST_BANCORP_ | main sample |
| 143 | Star Equity Holdings, Inc. | 0001210708 | peer of CORPORATE_RESO | main sample |
| 144 | CROSS COUNTRY HEALTHCARE INC | 0001141103 | peer of CORPORATE_RESO | main sample |
| 145 | KFORCE INC | 0000930420 | peer of CORPORATE_RESO | main sample |
| 146 | CDI CORP | 0000018396 | peer of CORPORATE_RESO | main sample |
| 147 | BARRETT BUSINESS SERVICES INC | 0000902791 | peer of CORPORATE_RESO | main sample |
| 148 | DITECH HOLDING Corp | 0001040719 | peer of OCWEN_FINANCIA | main sample |
| 149 | PSM HOLDINGS INC | 0001362180 | peer of OCWEN_FINANCIA | main sample |
| 150 | MOPALS.COM, INC. | 0001222218 | peer of OCWEN_FINANCIA | main sample |
| 151 | iBio, Inc. | 0001420720 | peer of MUSCLEPHARM | main sample |
| 152 | Lite Strategy, Inc. | 0001262104 | peer of MUSCLEPHARM | main sample |
| 153 | BIOVEST INTERNATIONAL INC | 0000704384 | peer of MUSCLEPHARM | main sample |
| 154 | HELIOS TECHNOLOGIES, INC. | 0001024795 | peer of CHINA_VALVES_T | main sample |
| 155 | Shengkai Innovations, Inc. | 0001327364 | peer of CHINA_VALVES_T | main sample |
| 156 | CIRCOR INTERNATIONAL INC | 0001091883 | peer of CHINA_VALVES_T | main sample |
| 157 | BEFUT International Co., Ltd. | 0001328888 | peer of CHINA_VALVES_T | main sample |
| 158 | WESTMORELAND COAL Co | 0000106455 | peer of PUDA_COAL | main sample |
| 159 | James River Coal CO | 0001297720 | peer of PUDA_COAL | main sample |
| 160 | ALLIANCE RESOURCE PARTNERS LP | 0001086600 | peer of PUDA_COAL | main sample |
| 161 | Bimergen Energy Corp | 0001066764 | peer of PREMIER_HOLDIN | main sample |
| 162 | Ocean Power Technologies, Inc. | 0001378140 | peer of PREMIER_HOLDIN | main sample |
| 163 | SUMMER ENERGY HOLDINGS INC | 0001396633 | peer of PREMIER_HOLDIN | main sample |
| 164 | P10 Industries, Inc. | 0001044435 | peer of PREMIER_HOLDIN | main sample |
| 165 | EnSync, Inc. | 0001140310 | peer of PREMIER_HOLDIN | main sample |
| 166 | REINSURANCE GROUP OF AMERICA INC | 0000898174 | peer of AMERICAN_EQUIT | main sample |
| 167 | PHOENIX COMPANIES INC/DE | 0001129633 | peer of AMERICAN_EQUIT | main sample |
| 168 | Empower Annuity Insurance Co of America | 0000744455 | peer of AMERICAN_EQUIT | main sample |
| 169 | DELAWARE LIFE INSURANCE CO | 0000745544 | peer of AMERICAN_EQUIT | main sample |
| 170 | PROTECTIVE LIFE INSURANCE CO | 0000310826 | peer of AMERICAN_EQUIT | main sample |
| 171 | Gulfport Energy | 0000874499 | case | main sample |
| 172 | SM Energy Co | 0000893538 | peer of GULFPORT_ENERG | main sample |
| 173 | California Resources Corp | 0001609253 | peer of GULFPORT_ENERG | main sample |
| 174 | RSP Permian, Inc. | 0001588216 | peer of GULFPORT_ENERG | main sample |
| 175 | Chord Energy Corp | 0001486159 | peer of GULFPORT_ENERG | main sample |
| 176 | NEWFIELD EXPLORATION CO /DE/ | 0000912750 | peer of GULFPORT_ENERG | main sample |
| 177 | China Natural Gas | 0001120830 | case | external validation |
| 178 | Ener1 | 0000895642 | case | external validation |
| 179 | Apple REIT Nine | 0001418121 | case | external validation |
| 180 | China North East Petroleum | 0000787251 | case | external validation |
| 181 | Home Loan Servicing Solutions | 0001513161 | case | external validation |
| 182 | American Realty Capital Properties | 0001507385 | case | external validation |
| 183 | RINO International | 0001394220 | case | external validation |
| 184 | iFresh | 0001681941 | case | external validation |
| 185 | ChinaCast Education | 0001261888 | case | external validation |
| 186 | HF Foods Group | 0001680873 | case | external validation |
| 187 | Nationstar Mortgage Holdings Inc. | 0001520566 | peer of HOME_LOAN_SERV | external validation |
| 188 | DUKE REALTY CORP | 0000783280 | peer of AMERICAN_REALT | external validation |
| 189 | ALEXANDRIA REAL ESTATE EQUITIES, INC. | 0001035443 | peer of AMERICAN_REALT | external validation |
| 190 | EQUINIX INC | 0001101239 | peer of AMERICAN_REALT | external validation |
| 191 | ANWORTH MORTGAGE ASSET CORP | 0001047884 | peer of AMERICAN_REALT | external validation |
| 192 | CHIMERA INVESTMENT CORP | 0001409493 | peer of AMERICAN_REALT | external validation |
| 193 | Natural Grocers by Vitamin Cottage, Inc. | 0001547459 | peer of IFRESH | external validation |
| 194 | VILLAGE SUPER MARKET INC | 0000103595 | peer of IFRESH | external validation |
| 195 | WEIS MARKETS INC | 0000105418 | peer of IFRESH | external validation |
| 196 | INGLES MARKETS INC | 0000050493 | peer of IFRESH | external validation |
| 197 | Sprouts Farmers Market, Inc. | 0001575515 | peer of IFRESH | external validation |
| 198 | DOMINOS PIZZA INC | 0001286681 | peer of HF_FOODS_GROUP | external validation |
| 199 | SYSCO CORP | 0000096021 | peer of HF_FOODS_GROUP | external validation |
| 200 | ALKALINE WATER Co INC | 0001532390 | peer of HF_FOODS_GROUP | external validation |
| 201 | RAVE RESTAURANT GROUP, INC. | 0000718332 | peer of HF_FOODS_GROUP | external validation |
| 202 | Cuentas Inc. | 0001424657 | peer of HF_FOODS_GROUP | external validation |
| 203 | AMERICAN PUBLIC EDUCATION INC | 0001201792 | peer of CHINACAST_EDUC | external validation |
| 204 | CONSTELLATION ENERGY GROUP INC | 0001004440 | peer of CHINA_NATURAL | external validation |
| 205 | Public Storage | 0001393311 | peer of APPLE_REIT_NIN | external validation |
| 206 | KIMCO REALTY CORP | 0000879101 | peer of APPLE_REIT_NIN | external validation |
| 207 | AVALONBAY COMMUNITIES INC | 0000915912 | peer of APPLE_REIT_NIN | external validation |
| 208 | WEYERHAEUSER CO | 0000106535 | peer of APPLE_REIT_NIN | external validation |
| 209 | AMERICAN TOWER CORP /MA/ | 0001053507 | peer of APPLE_REIT_NIN | external validation |
| 210 | ULTRA PETROLEUM CORP | 0001022646 | peer of CHINA_NORTH_EA | external validation |
| 211 | SABINE OIL & GAS CORP | 0000038079 | peer of CHINA_NORTH_EA | external validation |
| 212 | Coterra Energy Inc. | 0000858470 | peer of CHINA_NORTH_EA | external validation |
| 213 | ENERGEN CORP | 0000277595 | peer of CHINA_NORTH_EA | external validation |
| 214 | CIMAREX ENERGY CO | 0001168054 | peer of CHINA_NORTH_EA | external validation |
| 215 | Ault Alliance, Inc. (now Hyperscale Data) | 0000896493 | case | pilot |
| 216 | Iteris Inc. | 0000350868 | peer of AULT | pilot |
| 217 | TRANSACT TECHNOLOGIES INC | 0001017303 | peer of AULT | pilot |
| 218 | KEY TRONIC CORP | 0000719733 | peer of AULT | pilot |
| 219 | AstroNova Inc. | 0000008146 | peer of AULT | pilot |
| 220 | CPI Card Group Inc. | 0001641614 | peer of AULT | pilot |
| 221 | ProPetro Holding Corp. | 0001680247 | case | pilot |
| 222 | Liberty Energy Inc. | 0001694028 | peer of PUMP | pilot |
| 223 | NexTier Oilfield Solutions Inc. | 0001688476 | peer of PUMP | pilot |
| 224 | RPC INC | 0000742278 | peer of PUMP | pilot |
| 225 | Nine Energy Service, Inc. | 0001532286 | peer of PUMP | pilot |
| 226 | PATTERSON UTI ENERGY INC | 0000889900 | peer of PUMP | pilot |
| 227 | Co-Diagnostics, Inc. | 0001692415 | case | pilot |
| 228 | ORASURE TECHNOLOGIES INC | 0001116463 | peer of CODX | pilot |
| 229 | BIODESIX INC | 0001439725 | peer of CODX | pilot |
| 230 | Quanterix Corp | 0001503274 | peer of CODX | pilot |
| 231 | Chembio Diagnostics Inc. | 0001092662 | peer of CODX | pilot |
| 232 | Meridian Bioscience Inc. | 0000794172 | peer of CODX | pilot |
| 233 | Gulfport Energy Corp. | 0000874499 | case | pilot |
| 234 | Matador Resources Co | 0001520006 | peer of GPOR | pilot |
| 235 | Cimarex Energy Co | 0001168054 | peer of GPOR | pilot |
| 236 | PDC Energy Inc. | 0000077877 | peer of GPOR | pilot |
| 237 | SM Energy Co | 0000893538 | peer of GPOR | pilot |
| 238 | Callon Petroleum Co | 0000928022 | peer of GPOR | pilot |
| 239 | Skechers U.S.A., Inc. | 0001065837 | case | pilot |
| 240 | Crocs, Inc. | 0001334036 | peer of SKX | pilot |
| 241 | DECKERS OUTDOOR CORP | 0000910521 | peer of SKX | pilot |
| 242 | STEVEN MADDEN, LTD. | 0000913241 | peer of SKX | pilot |
| 243 | WOLVERINE WORLD WIDE INC /DE/ | 0000110471 | peer of SKX | pilot |
| 244 | NIKE, Inc. | 0000320187 | peer of SKX | pilot |