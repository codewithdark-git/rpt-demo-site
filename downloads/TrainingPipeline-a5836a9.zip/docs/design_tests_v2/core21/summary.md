# Design test battery (v2) — core21

Analysed firm-years: 577 (102 fraud firm-years) in 21 matched sets: 21 RPT-fraud cases (FRAUD = 1; strata {'core': 21}) and 97 matched firms.
AUD_OPIN: modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report. RESTATE: 8-K Item 4.02 or a 10-K/A that restates the financial statements.

## M1 coverage by group (selection on the outcome where the Fisher p is small)

| characteristic                | layer   | panel_column                                                                              |   coverage_all |   coverage_fraud_firm_years |   coverage_matched_firm_years |   fisher_p_coverage_differs |   n_fraud_observed |   n_matched_observed |
|:------------------------------|:--------|:------------------------------------------------------------------------------------------|---------------:|----------------------------:|------------------------------:|----------------------------:|-------------------:|---------------------:|
| RP_LEND                       | L1      | rp_lend_to_assets                                                                         |          0.146 |                       0.284 |                         0.116 |                       0     |                 29 |                   55 |
| RP_PAY                        | L1      | rp_pay_to_assets                                                                          |          0.156 |                       0.324 |                         0.12  |                       0     |                 33 |                   57 |
| RP_SALES                      | L1      | rp_sales_to_revenue                                                                       |          0.068 |                       0.127 |                         0.055 |                       0.015 |                 13 |                   26 |
| RP_PURCH                      | L1      | rp_purch_to_assets                                                                        |          0.156 |                       0.196 |                         0.147 |                       0.23  |                 20 |                   70 |
| RP_INCOMP                     | L2      | rp_incomp                                                                                 |          0.882 |                       0.922 |                         0.874 |                       0.235 |                 94 |                  415 |
| RP_VAGUE                      | L2      | rpt_vagueness                                                                             |          0.879 |                       0.922 |                         0.869 |                       0.181 |                 94 |                  413 |
| BRD_NONIND                    | L3      | board_indep                                                                               |          0.142 |                       0.225 |                         0.124 |                       0.012 |                 23 |                   59 |
| DUAL                          | L3      | ceo_duality                                                                               |          0.522 |                       0.461 |                         0.535 |                       0.191 |                 47 |                  254 |
| ICFR_MW (traditional signal)  | TRAD    | material_weakness_reported                                                                |          0.905 |                       0.765 |                         0.935 |                     nan     |                 78 |                  444 |
| AUD_OPIN (traditional signal) | TRAD    | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |          0.971 |                       0.99  |                         0.966 |                     nan     |                101 |                  459 |
| AUD_CHG (traditional signal)  | TRAD    | auditor_change_8k                                                                         |          1     |                       1     |                         1     |                     nan     |                102 |                  475 |
| RESTATE (traditional signal)  | TRAD    | 8-K Item 4.02 or a 10-K/A that restates the financial statements                          |          1     |                       1     |                         1     |                     nan     |                102 |                  475 |

## Text source by group

| fraud_aaer_label   |   none |   rp_note |   rpt_disclosure |   n |   share_stating_no_transactions |
|:-------------------|-------:|----------:|-----------------:|----:|--------------------------------:|
| fraud firm-years   |  0.078 |     0.608 |            0.314 | 102 |                           0.029 |
| matched firm-years |  0.126 |     0.4   |            0.474 | 475 |                           0.057 |

## Scoring rules

| rule                                            | value                                                                                                                                      |
|:------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------|
| ranking population                              | the 577 analysed firm-years (five-year windows of the 21 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic       | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score             |
| AI_SCORE with a missing layer                   | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE                                                  |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 391, 1: 106, 2: 48, 3: 27, 4: 5}                                                                                                       |
| firm-years with L2 from 0/1/2 characteristics   | {0: 68, 1: 2, 2: 507}                                                                                                                      |
| firm-years with L3 from 0/1/2 characteristics   | {0: 250, 1: 271, 2: 56}                                                                                                                    |
| firm-years with 1/2/3 layers in AI_SCORE        | {0: 36, 1: 167, 2: 267, 3: 107}                                                                                                            |
| AUD_OPIN definition                             | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report                                                  |
| RESTATE definition                              | 8-K Item 4.02 or a 10-K/A that restates the financial statements                                                                           |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |      0     |      0.099 |
| L2_SCORE |      0     |      1     |     -0.068 |
| L3_SCORE |      0.099 |     -0.068 |      1     |

## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)

| hypothesis   | variant   | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |   p_holm |   p_holm_firm_cluster | direction_as_predicted   | supported_design_rule   | supported_firm_cluster   |
|:-------------|:----------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|---------:|----------------------:|:-------------------------|:------------------------|:-------------------------|
| H1           | all cases | L1_SCORE      |            147 |               13 |        49 |                   44 |         0.684 |               1.982 |       1.202 |        3.27  | 0.255 |          0.007 |             0.413 |            0.097 |                    0.883 |                     4.453 |    0.015 |                 0.195 | True                     | True                    | False                    |
| H2           | all cases | L2_SCORE      |            338 |               17 |        78 |                   73 |        -0.321 |               0.725 |       0.53  |        0.991 | 0.159 |          0.044 |             0.293 |            0.273 |                    0.408 |                     1.288 |    0.044 |                 0.273 | False                    | False                   | False                    |
| H3           | all cases | L3_SCORE      |            180 |               12 |        45 |                   46 |         1.45  |               4.265 |       2.339 |        7.776 | 0.307 |          0     |             0.727 |            0.046 |                    1.025 |                    17.74  |    0     |                 0.138 | True                     | True                    | False                    |

## H2 re-runs and single-characteristic tests

| hypothesis   | variant                                                                                                      | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |      se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |
|:-------------|:-------------------------------------------------------------------------------------------------------------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|--------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|
| H2           | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE      |            304 |               16 |        73 |                   70 |        -0.306 |               0.736 |       0.53  |        1.023 |   0.168 |          0.068 |             0.284 |            0.281 |                    0.422 |                     1.285 |
| H2           | all cases, firm-years with both disclosure characteristics observed (robustness)                             | L2_SCORE      |            336 |               17 |        78 |                   73 |        -0.313 |               0.732 |       0.535 |        1.001 |   0.16  |          0.05  |             0.295 |            0.289 |                    0.411 |                     1.303 |
| H1           | single characteristic                                                                                        | RP_LEND       |             51 |                7 |        20 |                   27 |        -0.063 |               0.939 |       0.291 |        3.031 |   0.598 |          0.916 |             0.932 |            0.946 |                    0.151 |                     5.837 |
| H1           | single characteristic                                                                                        | RP_PAY        |             41 |                6 |        17 |                   30 |         0.346 |               1.414 |       0.506 |        3.953 |   0.525 |          0.509 |             0.578 |            0.549 |                    0.456 |                     4.389 |
| H1           | single characteristic                                                                                        | RP_SALES      |              0 |              nan |       nan |                  nan |       nan     |             nan     |     nan     |      nan     | nan     |        nan     |           nan     |          nan     |                  nan     |                   nan     |
| H1           | single characteristic                                                                                        | RP_PURCH      |             53 |                6 |        20 |                   17 |        -0.576 |               0.562 |       0.091 |        3.49  |   0.931 |          0.537 |             1.453 |            0.692 |                    0.033 |                     9.693 |
| H2           | single characteristic                                                                                        | RP_INCOMP     |            338 |               17 |        78 |                   73 |        -0.631 |               0.532 |       0.366 |        0.774 |   0.191 |          0.001 |             0.413 |            0.127 |                    0.237 |                     1.197 |
| H2           | single characteristic                                                                                        | RP_VAGUE      |            336 |               17 |        78 |                   73 |         0.129 |               1.138 |       0.861 |        1.504 |   0.142 |          0.363 |             0.219 |            0.555 |                    0.741 |                     1.748 |
| H3           | single characteristic                                                                                        | BRD_NONIND    |             35 |                4 |        10 |                   22 |         1.213 |               3.363 |       0.745 |       15.177 |   0.769 |          0.115 |             1.869 |            0.516 |                    0.086 |                   130.993 |
| H3           | single characteristic                                                                                        | DUAL          |            159 |               11 |        40 |                   41 |         1.274 |               3.576 |       2.023 |        6.322 |   0.291 |          0     |             0.589 |            0.03  |                    1.128 |                    11.336 |

## H4 by event year (conditional logit primary; Mann–Whitney supplementary)

|   event_year | layer_score   |   n_firm_years |   n_matched_sets |   n_fraud |   mean_fraud |   mean_matched |   cond_coef |   cond_or_per_sd |   cond_p |   cond_p_firm_cluster |   mannwhitney_p_greater | significant_as_predicted_cond   |
|-------------:|:--------------|---------------:|-----------------:|----------:|-------------:|---------------:|------------:|-----------------:|---------:|----------------------:|------------------------:|:--------------------------------|
|           -5 | L1_SCORE      |             21 |                7 |        19 |        0.595 |          0.557 |       0.031 |            1.032 |    0.952 |                 0.951 |                   0.357 | False                           |
|           -5 | L2_SCORE      |             61 |               14 |        19 |        0.442 |          0.512 |      -0.357 |            0.7   |    0.329 |                 0.406 |                   0.915 | False                           |
|           -5 | L3_SCORE      |              0 |                0 |        19 |        0.576 |          0.472 |     nan     |          nan     |  nan     |               nan     |                   0.097 | False                           |
|           -4 | L1_SCORE      |             19 |                6 |        21 |        0.599 |          0.458 |       5.525 |          250.862 |    0.157 |                 0.651 |                   0.107 | False                           |
|           -4 | L2_SCORE      |             63 |               14 |        21 |        0.424 |          0.511 |      -0.496 |            0.609 |    0.19  |                 0.206 |                   0.946 | False                           |
|           -4 | L3_SCORE      |             28 |                9 |        21 |        0.561 |          0.482 |       1.467 |            4.337 |    0.144 |                 0.475 |                   0.227 | False                           |
|           -3 | L1_SCORE      |             20 |                7 |        21 |        0.494 |          0.421 |       0.724 |            2.063 |    0.252 |                 0.212 |                   0.298 | False                           |
|           -3 | L2_SCORE      |             69 |               16 |        21 |        0.468 |          0.529 |      -0.047 |            0.954 |    0.879 |                 0.88  |                   0.871 | False                           |
|           -3 | L3_SCORE      |             37 |               11 |        21 |        0.695 |          0.496 |       1.548 |            4.703 |    0.033 |                 0.087 |                   0.008 | True                            |
|           -2 | L1_SCORE      |             26 |                8 |        21 |        0.531 |          0.419 |       2.012 |            7.476 |    0.078 |                 0.282 |                   0.045 | False                           |
|           -2 | L2_SCORE      |             64 |               15 |        21 |        0.401 |          0.508 |      -0.737 |            0.478 |    0.062 |                 0.133 |                   0.965 | False                           |
|           -2 | L3_SCORE      |             34 |               10 |        21 |        0.674 |          0.469 |       2.6   |           13.461 |    0.052 |                 0.461 |                   0.019 | False                           |
|           -1 | L1_SCORE      |             17 |                5 |        20 |        0.481 |          0.448 |       1.325 |            3.761 |    0.493 |                 0.502 |                   0.326 | False                           |
|           -1 | L2_SCORE      |             56 |               14 |        20 |        0.46  |          0.519 |      -0.148 |            0.863 |    0.675 |                 0.722 |                   0.856 | False                           |
|           -1 | L3_SCORE      |             23 |                8 |        20 |        0.548 |          0.469 |       2.021 |            7.548 |    0.155 |                 0.633 |                   0.118 | False                           |

| layer_score   | design_rule_met_before_final_year   |   years_significant |   tests_run |
|:--------------|:------------------------------------|--------------------:|------------:|
| L1_SCORE      | False                               |                 nan |           5 |
| L2_SCORE      | False                               |                 nan |           5 |
| L3_SCORE      | True                                |                  -3 |           5 |

## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate

|                                             | 0                                |
|:--------------------------------------------|:---------------------------------|
| model_A                                     | TRAD_INDEX+leverage+roa          |
| model_B                                     | TRAD_INDEX+leverage+roa+AI_SCORE |
| n_firm_years                                | 395                              |
| n_fraud_firm_years                          | 76                               |
| n_matched_sets                              | 21                               |
| loso_auc_model_A                            | 0.484                            |
| loso_auc_model_B                            | 0.562                            |
| auc_gain_B_minus_A                          | 0.079                            |
| auc_gain_ci_low                             | 0.023                            |
| auc_gain_ci_high                            | 0.136                            |
| auc_trad_index_alone                        | 0.638                            |
| auc_ai_score_alone                          | 0.541                            |
| AI_SCORE_coef_per_sd_model_B_pooled         | 0.2293423671602002               |
| AI_SCORE_or_ci_pooled                       | 0.85-1.86                        |
| AI_SCORE_p_model_B_pooled_firm_cluster      | 0.25355941915858904              |
| AI_SCORE_coef_per_sd_model_B_conditional    | 0.5238140167929564               |
| AI_SCORE_p_model_B_conditional              | 0.0015174793569813093            |
| AI_SCORE_p_model_B_conditional_firm_cluster | 0.07923927069814951              |
| ai_threshold_5pct_far                       | 8.158                            |
| ai_far_at_5pct_rule                         | 0.051                            |
| trad_rule_equal_far                         | TRAD_INDEX >= 3                  |
| trad_far                                    | 0.019                            |
| ai_threshold_equal_far                      | 8.483                            |
| ai_far_equal_rule                           | 0.021                            |
| cases                                       | 21                               |
| cases_flagged_ai_5pct                       | 1                                |
| cases_never_flagged_ai_5pct                 | 20                               |
| cases_flagged_ai_equal_far                  | 0                                |
| cases_flagged_trad_equal_far                | 3                                |
| cases_ai_earlier_equal_far                  | 0                                |
| cases_same_year_equal_far                   | 0                                |
| cases_trad_earlier_equal_far                | 3                                |
| cases_flagged_by_neither_equal_far          | 18                               |
| earliest_ai_year_median_5pct                | -4.0                             |
| union_far                                   | 0.038                            |
| cases_flagged_union                         | 3                                |
| cases_flagged_ai_alone_at_union_far         | 0                                |
| cases_flagged_trad_alone_at_union_far       | 3                                |
| trad_rule_at_union_far                      | TRAD_INDEX >= 3                  |
| trad_ge1_matched_rate                       | 0.295                            |

|                                                                                                                 |   met |
|:----------------------------------------------------------------------------------------------------------------|------:|
| AI_SCORE significant in Model B (pooled, firm-clustered)                                                        |     0 |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) |     1 |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)         |     0 |

## Timing by case

| case           | stratum   |   ai_first_year_5pct_far |   ai_first_year_equal_far |   trad_ge3_first_year |   trad_ge1_first_year | ai_earlier_equal_far   | same_year_equal_far   | trad_earlier_equal_far   | flagged_by_neither_equal_far   |   ai_years_flagged_5pct |   window_years |
|:---------------|:----------|-------------------------:|--------------------------:|----------------------:|----------------------:|:-----------------------|:----------------------|:-------------------------|:-------------------------------|------------------------:|---------------:|
| AMMO_INC_OUTDO | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AULT_ALLIANCE  | core      |                      nan |                       nan |                    -5 |                    -5 | False                  | False                 | True                     | False                          |                       0 |              5 |
| CEMTREX        | core      |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CHINA_VALVES_T | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CORPORATE_RESO | core      |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| CO_DIAGNOSTICS | core      |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| EAGLE_BANCORP  | core      |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FAT_BRANDS     | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| GENERAL_EMPLOY | core      |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| IDEANOMICS_SEV | core      |                      nan |                       nan |                    -4 |                    -4 | False                  | False                 | True                     | False                          |                       0 |              5 |
| MANITEX_INTERN | core      |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| MUSCLEPHARM    | core      |                       -4 |                       nan |                    -3 |                    -4 | False                  | False                 | True                     | False                          |                       2 |              4 |
| OCWEN_FINANCIA | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PREMIER_HOLDIN | core      |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PROVECTUS_BIOP | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PUDA_COAL      | core      |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| QUADRANT_4_SYS | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SAEXPLORATION_ | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SINGULARITY_FU | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| UNITED_DEVELOP | core      |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              5 |
| VALEANT_PHARMA | core      |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |

## P1 RPT types by form of fraud (descriptive)

| form_group   |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |
|:-------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|
| both         |             1 |               1 |           1 |             1 |               1 |                 1 |
| corporate    |             8 |              15 |           5 |            15 |               8 |                15 |
| managerial   |             3 |               5 |           1 |             5 |               1 |                 5 |

## A1 attribution summary (share of AI_SCORE)

|                  |   mean_share_all_firm_years |   mean_share_fraud_firm_years |   mean_share_flagged_fraud_firm_years |
|:-----------------|----------------------------:|------------------------------:|--------------------------------------:|
| share_L1         |                       0.129 |                         0.206 |                                 0     |
| share_RP_LEND    |                       0.032 |                         0.072 |                                 0     |
| share_RP_PAY     |                       0.043 |                         0.077 |                                 0     |
| share_RP_SALES   |                       0.015 |                         0.019 |                                 0     |
| share_RP_PURCH   |                       0.04  |                         0.039 |                                 0     |
| share_L2         |                       0.53  |                         0.48  |                                 1     |
| share_RP_INCOMP  |                       0.274 |                         0.193 |                                 0.437 |
| share_RP_VAGUE   |                       0.256 |                         0.286 |                                 0.563 |
| share_L3         |                       0.278 |                         0.265 |                                 0     |
| share_BRD_NONIND |                       0.049 |                         0.059 |                                 0     |
| share_DUAL       |                       0.23  |                         0.206 |                                 0     |

## A2 stability (leave one matched set out)

|                                   | 0                                                                                                                                 |
|:----------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| firm_years                        | 577                                                                                                                               |
| spearman_ai_score_full_vs_loso    | 0.9993134006083488                                                                                                                |
| mean_abs_ai_score_change          | 0.05394799214575924                                                                                                               |
| median_max_abs_layer_share_change | 0.0020138711016504107                                                                                                             |
| share_largest_layer_unchanged     | 0.9826689774696707                                                                                                                |
| share_named_evidence_unchanged    | 0.9809358752166378                                                                                                                |
| method                            | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

## A3 layers in the flagged fraud firm-years

| layer   | agency_idea                        |   mean_fraud |   mean_matched | direction                                  |   flagged_fraud_firm_years_where_largest |   flagged_fraud_firm_years |   flagged_cases |
|:--------|:-----------------------------------|-------------:|---------------:|:-------------------------------------------|-----------------------------------------:|---------------------------:|----------------:|
| L1      | financial (conflict of interest)   |        0.54  |          0.456 | fraud firms higher (as predicted)          |                                        0 |                          2 |               1 |
| L2      | disclosure (information asymmetry) |        0.439 |          0.516 | fraud firms LOWER (against the prediction) |                                        2 |                          2 |               1 |
| L3      | governance (weak monitoring)       |        0.616 |          0.478 | fraud firms higher (as predicted)          |                                        0 |                          2 |               1 |

## EXPLORATORY — fitted 36-input score

|                                    | 0                                                                                                                                                                                                                                  |
|:-----------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| note                               | EXPLORATORY: the fitted ensemble score uses 36 inputs including ICFR, audit-opinion, auditor-change and restatement signals, Big-4 status and general financial ratios; it cannot test whether the RPT layers add to the benchmark |
| loso_auc_model_A                   | 0.489                                                                                                                                                                                                                              |
| loso_auc_model_A_plus_fitted_score | 0.647                                                                                                                                                                                                                              |
| auc_fitted_score_alone_oof         | 0.716                                                                                                                                                                                                                              |
| fitted_threshold                   | 0.695                                                                                                                                                                                                                              |
| fitted_far_matched                 | 0.048                                                                                                                                                                                                                              |
| cases_flagged_fitted               | 7                                                                                                                                                                                                                                  |
| cases_never_flagged_fitted         | 14                                                                                                                                                                                                                                 |

## Deviations

- none
