# Design test battery (v2) — all31_gulfport

Analysed firm-years: 862 (152 fraud firm-years) in 31 matched sets: 31 RPT-fraud cases (FRAUD = 1; strata {'core': 21, 'disclosure_only': 10}) and 145 matched firms.
AUD_OPIN: modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report. RESTATE: 8-K Item 4.02 or a 10-K/A that restates the financial statements.

## M1 coverage by group (selection on the outcome where the Fisher p is small)

| characteristic                | layer   | panel_column                                                                              |   coverage_all |   coverage_fraud_firm_years |   coverage_matched_firm_years |   fisher_p_coverage_differs |   n_fraud_observed |   n_matched_observed |
|:------------------------------|:--------|:------------------------------------------------------------------------------------------|---------------:|----------------------------:|------------------------------:|----------------------------:|-------------------:|---------------------:|
| RP_LEND                       | L1      | rp_lend_to_assets                                                                         |          0.118 |                       0.276 |                         0.085 |                       0     |                 42 |                   60 |
| RP_PAY                        | L1      | rp_pay_to_assets                                                                          |          0.125 |                       0.27  |                         0.094 |                       0     |                 41 |                   67 |
| RP_SALES                      | L1      | rp_sales_to_revenue                                                                       |          0.077 |                       0.099 |                         0.072 |                       0.244 |                 15 |                   51 |
| RP_PURCH                      | L1      | rp_purch_to_assets                                                                        |          0.158 |                       0.158 |                         0.158 |                       1     |                 24 |                  112 |
| RP_INCOMP                     | L2      | rp_incomp                                                                                 |          0.896 |                       0.908 |                         0.893 |                       0.663 |                138 |                  634 |
| RP_VAGUE                      | L2      | rpt_vagueness                                                                             |          0.893 |                       0.908 |                         0.89  |                       0.664 |                138 |                  632 |
| BRD_NONIND                    | L3      | board_indep                                                                               |          0.15  |                       0.243 |                         0.13  |                       0.001 |                 37 |                   92 |
| DUAL                          | L3      | ceo_duality                                                                               |          0.552 |                       0.599 |                         0.542 |                       0.21  |                 91 |                  385 |
| ICFR_MW (traditional signal)  | TRAD    | material_weakness_reported                                                                |          0.918 |                       0.822 |                         0.938 |                     nan     |                125 |                  666 |
| AUD_OPIN (traditional signal) | TRAD    | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |          0.973 |                       0.993 |                         0.969 |                     nan     |                151 |                  688 |
| AUD_CHG (traditional signal)  | TRAD    | auditor_change_8k                                                                         |          1     |                       1     |                         1     |                     nan     |                152 |                  710 |
| RESTATE (traditional signal)  | TRAD    | 8-K Item 4.02 or a 10-K/A that restates the financial statements                          |          1     |                       1     |                         1     |                     nan     |                152 |                  710 |

## Text source by group

| fraud_aaer_label   |   none |   rp_note |   rpt_disclosure |   n |   share_stating_no_transactions |
|:-------------------|-------:|----------:|-----------------:|----:|--------------------------------:|
| fraud firm-years   |  0.092 |     0.553 |            0.355 | 152 |                           0.059 |
| matched firm-years |  0.107 |     0.413 |            0.48  | 710 |                           0.052 |

## Scoring rules

| rule                                            | value                                                                                                                                      |
|:------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------|
| ranking population                              | the 862 analysed firm-years (five-year windows of the 31 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic       | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score             |
| AI_SCORE with a missing layer                   | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE                                                  |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 595, 1: 165, 2: 65, 3: 31, 4: 6}                                                                                                       |
| firm-years with L2 from 0/1/2 characteristics   | {0: 90, 1: 2, 2: 770}                                                                                                                      |
| firm-years with L3 from 0/1/2 characteristics   | {0: 352, 1: 415, 2: 95}                                                                                                                    |
| firm-years with 1/2/3 layers in AI_SCORE        | {0: 49, 1: 237, 2: 416, 3: 160}                                                                                                            |
| AUD_OPIN definition                             | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report                                                  |
| RESTATE definition                              | 8-K Item 4.02 or a 10-K/A that restates the financial statements                                                                           |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |     -0.018 |     -0.005 |
| L2_SCORE |     -0.018 |      1     |     -0.121 |
| L3_SCORE |     -0.005 |     -0.121 |      1     |

## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)

| hypothesis   | variant   | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |   p_holm |   p_holm_firm_cluster | direction_as_predicted   | supported_design_rule   | supported_firm_cluster   |
|:-------------|:----------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|---------:|----------------------:|:-------------------------|:------------------------|:-------------------------|
| H1           | all cases | L1_SCORE      |            187 |               17 |        63 |                   53 |         0.478 |               1.613 |       1.045 |        2.49  | 0.222 |          0.031 |             0.378 |            0.206 |                    0.769 |                     3.383 |    0.062 |                 0.459 | True                     | False                   | False                    |
| H2           | all cases | L2_SCORE      |            517 |               25 |       117 |                  107 |        -0.221 |               0.801 |       0.628 |        1.023 | 0.125 |          0.075 |             0.249 |            0.374 |                    0.492 |                     1.306 |    0.075 |                 0.459 | False                    | False                   | False                    |
| H3           | all cases | L3_SCORE      |            284 |               18 |        71 |                   81 |         0.53  |               1.699 |       1.216 |        2.373 | 0.171 |          0.002 |             0.371 |            0.153 |                    0.821 |                     3.514 |    0.006 |                 0.459 | True                     | True                    | False                    |

## H2 re-runs and single-characteristic tests

| hypothesis   | variant                                                                                                      | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |      se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |
|:-------------|:-------------------------------------------------------------------------------------------------------------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|--------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|
| H2           | without disclosure-only cases (design re-run)                                                                | L2_SCORE      |            338 |               17 |        78 |                   73 |        -0.326 |               0.722 |       0.527 |        0.988 |   0.16  |          0.042 |             0.295 |            0.27  |                    0.405 |                     1.288 |
| H2           | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE      |            469 |               24 |       111 |                   98 |        -0.157 |               0.855 |       0.658 |        1.11  |   0.133 |          0.24  |             0.245 |            0.522 |                    0.529 |                     1.381 |
| H2           | all cases, firm-years with both disclosure characteristics observed (robustness)                             | L2_SCORE      |            515 |               25 |       117 |                  107 |        -0.213 |               0.808 |       0.633 |        1.032 |   0.125 |          0.088 |             0.251 |            0.395 |                    0.494 |                     1.321 |
| H1           | single characteristic                                                                                        | RP_LEND       |             58 |                8 |        22 |                   35 |        -0.041 |               0.96  |       0.324 |        2.848 |   0.555 |          0.942 |             0.85  |            0.962 |                    0.182 |                     5.079 |
| H1           | single characteristic                                                                                        | RP_PAY        |             55 |                8 |        22 |                   36 |         0.157 |               1.17  |       0.557 |        2.458 |   0.379 |          0.678 |             0.378 |            0.678 |                    0.558 |                     2.453 |
| H1           | single characteristic                                                                                        | RP_SALES      |              0 |              nan |       nan |                  nan |       nan     |             nan     |     nan     |      nan     | nan     |        nan     |           nan     |          nan     |                  nan     |                   nan     |
| H1           | single characteristic                                                                                        | RP_PURCH      |             74 |                9 |        29 |                   21 |        -0.368 |               0.692 |       0.265 |        1.807 |   0.49  |          0.452 |             0.488 |            0.45  |                    0.266 |                     1.8   |
| H2           | single characteristic                                                                                        | RP_INCOMP     |            517 |               25 |       117 |                  107 |        -0.287 |               0.751 |       0.572 |        0.985 |   0.139 |          0.039 |             0.304 |            0.346 |                    0.414 |                     1.362 |
| H2           | single characteristic                                                                                        | RP_VAGUE      |            515 |               25 |       117 |                  107 |        -0.049 |               0.952 |       0.749 |        1.211 |   0.122 |          0.691 |             0.193 |            0.8   |                    0.653 |                     1.389 |
| H3           | single characteristic                                                                                        | BRD_NONIND    |             54 |                6 |        15 |                   36 |         1.217 |               3.376 |       1.118 |       10.196 |   0.564 |          0.031 |             1.375 |            0.376 |                    0.228 |                    50.029 |
| H3           | single characteristic                                                                                        | DUAL          |            262 |               17 |        66 |                   76 |         0.411 |               1.508 |       1.082 |        2.102 |   0.17  |          0.015 |             0.37  |            0.267 |                    0.73  |                     3.115 |

## H4 by event year (conditional logit primary; Mann–Whitney supplementary)

|   event_year | layer_score   |   n_firm_years |   n_matched_sets |   n_fraud |   mean_fraud |   mean_matched |   cond_coef |   cond_or_per_sd |   cond_p |   cond_p_firm_cluster |   mannwhitney_p_greater | significant_as_predicted_cond   |
|-------------:|:--------------|---------------:|-----------------:|----------:|-------------:|---------------:|------------:|-----------------:|---------:|----------------------:|------------------------:|:--------------------------------|
|           -5 | L1_SCORE      |             21 |                7 |        29 |        0.547 |          0.564 |       0.006 |            1.006 |    0.99  |                 0.99  |                   0.524 | False                           |
|           -5 | L2_SCORE      |             98 |               22 |        29 |        0.458 |          0.524 |      -0.4   |            0.67  |    0.154 |                 0.222 |                   0.933 | False                           |
|           -5 | L3_SCORE      |             43 |               13 |        29 |        0.565 |          0.492 |       0.448 |            1.566 |    0.375 |                 0.447 |                   0.092 | False                           |
|           -4 | L1_SCORE      |             22 |                7 |        31 |        0.526 |          0.483 |       3.261 |           26.08  |    0.092 |                 0.522 |                   0.335 | False                           |
|           -4 | L2_SCORE      |             89 |               20 |        31 |        0.446 |          0.507 |      -0.329 |            0.72  |    0.224 |                 0.212 |                   0.916 | False                           |
|           -4 | L3_SCORE      |             49 |               15 |        31 |        0.568 |          0.499 |       0.313 |            1.367 |    0.415 |                 0.393 |                   0.115 | False                           |
|           -3 | L1_SCORE      |             25 |                9 |        31 |        0.46  |          0.451 |       0.867 |            2.38  |    0.207 |                 0.245 |                   0.504 | False                           |
|           -3 | L2_SCORE      |             95 |               22 |        31 |        0.481 |          0.506 |       0.026 |            1.027 |    0.916 |                 0.916 |                   0.704 | False                           |
|           -3 | L3_SCORE      |             58 |               17 |        31 |        0.634 |          0.49  |       0.597 |            1.816 |    0.088 |                 0.091 |                   0.005 | False                           |
|           -2 | L1_SCORE      |             29 |                9 |        31 |        0.522 |          0.427 |       1.7   |            5.473 |    0.075 |                 0.225 |                   0.084 | False                           |
|           -2 | L2_SCORE      |             95 |               22 |        31 |        0.436 |          0.506 |      -0.336 |            0.715 |    0.231 |                 0.314 |                   0.937 | False                           |
|           -2 | L3_SCORE      |             55 |               16 |        31 |        0.567 |          0.477 |       0.448 |            1.566 |    0.205 |                 0.216 |                   0.117 | False                           |
|           -1 | L1_SCORE      |             24 |                7 |        30 |        0.499 |          0.472 |       0.196 |            1.217 |    0.751 |                 0.76  |                   0.355 | False                           |
|           -1 | L2_SCORE      |             85 |               21 |        30 |        0.448 |          0.515 |      -0.129 |            0.879 |    0.64  |                 0.697 |                   0.929 | False                           |
|           -1 | L3_SCORE      |             42 |               14 |        30 |        0.518 |          0.459 |       0.445 |            1.561 |    0.327 |                 0.429 |                   0.077 | False                           |

| layer_score   | design_rule_met_before_final_year   |   years_significant |   tests_run |
|:--------------|:------------------------------------|--------------------:|------------:|
| L1_SCORE      | False                               |                 nan |           5 |
| L2_SCORE      | False                               |                 nan |           5 |
| L3_SCORE      | False                               |                 nan |           5 |

## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate

|                                             | 0                                |
|:--------------------------------------------|:---------------------------------|
| model_A                                     | TRAD_INDEX+leverage+roa          |
| model_B                                     | TRAD_INDEX+leverage+roa+AI_SCORE |
| n_firm_years                                | 598                              |
| n_fraud_firm_years                          | 112                              |
| n_matched_sets                              | 31                               |
| loso_auc_model_A                            | 0.448                            |
| loso_auc_model_B                            | 0.519                            |
| auc_gain_B_minus_A                          | 0.071                            |
| auc_gain_ci_low                             | 0.02                             |
| auc_gain_ci_high                            | 0.124                            |
| auc_trad_index_alone                        | 0.603                            |
| auc_ai_score_alone                          | 0.528                            |
| AI_SCORE_coef_per_sd_model_B_pooled         | 0.16682030637099707              |
| AI_SCORE_or_ci_pooled                       | 0.86-1.62                        |
| AI_SCORE_p_model_B_pooled_firm_cluster      | 0.29558688773990116              |
| AI_SCORE_coef_per_sd_model_B_conditional    | 0.294322027947906                |
| AI_SCORE_p_model_B_conditional              | 0.023608458479007086             |
| AI_SCORE_p_model_B_conditional_firm_cluster | 0.18790897875734824              |
| ai_threshold_5pct_far                       | 7.92                             |
| ai_far_at_5pct_rule                         | 0.051                            |
| trad_rule_equal_far                         | TRAD_INDEX >= 3                  |
| trad_far                                    | 0.014                            |
| ai_threshold_equal_far                      | 8.543                            |
| ai_far_equal_rule                           | 0.014                            |
| cases                                       | 31                               |
| cases_flagged_ai_5pct                       | 2                                |
| cases_never_flagged_ai_5pct                 | 29                               |
| cases_flagged_ai_equal_far                  | 0                                |
| cases_flagged_trad_equal_far                | 3                                |
| cases_ai_earlier_equal_far                  | 0                                |
| cases_same_year_equal_far                   | 0                                |
| cases_trad_earlier_equal_far                | 3                                |
| cases_flagged_by_neither_equal_far          | 28                               |
| earliest_ai_year_median_5pct                | -4.5                             |
| union_far                                   | 0.027                            |
| cases_flagged_union                         | 3                                |
| cases_flagged_ai_alone_at_union_far         | 0                                |
| cases_flagged_trad_alone_at_union_far       | 3                                |
| trad_rule_at_union_far                      | TRAD_INDEX >= 3                  |
| trad_ge1_matched_rate                       | 0.242                            |

|                                                                                                                 |   met |
|:----------------------------------------------------------------------------------------------------------------|------:|
| AI_SCORE significant in Model B (pooled, firm-clustered)                                                        |     0 |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) |     1 |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)         |     0 |

## Timing by case

| case           | stratum         |   ai_first_year_5pct_far |   ai_first_year_equal_far |   trad_ge3_first_year |   trad_ge1_first_year | ai_earlier_equal_far   | same_year_equal_far   | trad_earlier_equal_far   | flagged_by_neither_equal_far   |   ai_years_flagged_5pct |   window_years |
|:---------------|:----------------|-------------------------:|--------------------------:|----------------------:|----------------------:|:-----------------------|:----------------------|:-------------------------|:-------------------------------|------------------------:|---------------:|
| AMERICAN_ELECT | disclosure_only |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_EQUIT | disclosure_only |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMMO_INC_OUTDO | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AULT_ALLIANCE  | core            |                      nan |                       nan |                    -5 |                    -5 | False                  | False                 | True                     | False                          |                       0 |              5 |
| CEMTREX        | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CHINA_VALVES_T | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CORPORATE_RESO | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| CO_DIAGNOSTICS | core            |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| EAGLE_BANCORP  | core            |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| ENERGY_XXI     | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FAT_BRANDS     | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FIRST_BANCORP_ | disclosure_only |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| GENERAL_EMPLOY | core            |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| GULFPORT_ENERG | disclosure_only |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| IDEANOMICS_SEV | core            |                      nan |                       nan |                    -4 |                    -4 | False                  | False                 | True                     | False                          |                       0 |              5 |
| MANITEX_INTERN | core            |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| MAXIMUS        | disclosure_only |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| MUSCLEPHARM    | core            |                       -4 |                       nan |                    -3 |                    -4 | False                  | False                 | True                     | False                          |                       2 |              4 |
| OCWEN_FINANCIA | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PREMIER_HOLDIN | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PROVECTUS_BIOP | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PUDA_COAL      | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| QUADRANT_4_SYS | core            |                       -5 |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       3 |              5 |
| RCI_HOSPITALIT | disclosure_only |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SAEXPLORATION_ | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SHIFT4_PAYMENT | disclosure_only |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SINGULARITY_FU | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SKECHERS_U_S_A | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| THE_GREENBRIER | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| UNITED_DEVELOP | core            |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              5 |
| VALEANT_PHARMA | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |

## P1 RPT types by form of fraud (descriptive)

| form_group                  |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |
|:----------------------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|
| both                        |             1 |               1 |           1 |             1 |               1 |                 1 |
| corporate                   |             8 |              15 |           5 |            15 |               8 |                15 |
| disclosure-only (not in P1) |             4 |              10 |           1 |            10 |               3 |                10 |
| managerial                  |             3 |               5 |           1 |             5 |               1 |                 5 |

## A1 attribution summary (share of AI_SCORE)

|                  |   mean_share_all_firm_years |   mean_share_fraud_firm_years |   mean_share_flagged_fraud_firm_years |
|:-----------------|----------------------------:|------------------------------:|--------------------------------------:|
| share_L1         |                       0.124 |                         0.165 |                                  0    |
| share_RP_LEND    |                       0.026 |                         0.062 |                                  0    |
| share_RP_PAY     |                       0.035 |                         0.057 |                                  0    |
| share_RP_SALES   |                       0.018 |                         0.014 |                                  0    |
| share_RP_PURCH   |                       0.045 |                         0.032 |                                  0    |
| share_L2         |                       0.532 |                         0.454 |                                  1    |
| share_RP_INCOMP  |                       0.276 |                         0.2   |                                  0.51 |
| share_RP_VAGUE   |                       0.256 |                         0.255 |                                  0.49 |
| share_L3         |                       0.287 |                         0.322 |                                  0    |
| share_BRD_NONIND |                       0.048 |                         0.069 |                                  0    |
| share_DUAL       |                       0.238 |                         0.252 |                                  0    |

## A2 stability (leave one matched set out)

|                                   | 0                                                                                                                                 |
|:----------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| firm_years                        | 862                                                                                                                               |
| spearman_ai_score_full_vs_loso    | 0.9994508498846517                                                                                                                |
| mean_abs_ai_score_change          | 0.03780957683586982                                                                                                               |
| median_max_abs_layer_share_change | 0.001533060551069776                                                                                                              |
| share_largest_layer_unchanged     | 0.9895591647331786                                                                                                                |
| share_named_evidence_unchanged    | 0.9802784222737819                                                                                                                |
| method                            | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

## A3 layers in the flagged fraud firm-years

| layer   | agency_idea                        |   mean_fraud |   mean_matched | direction                                  |   flagged_fraud_firm_years_where_largest |   flagged_fraud_firm_years |   flagged_cases |
|:--------|:-----------------------------------|-------------:|---------------:|:-------------------------------------------|-----------------------------------------:|---------------------------:|----------------:|
| L1      | financial (conflict of interest)   |        0.51  |          0.476 | fraud firms higher (as predicted)          |                                        0 |                          5 |               2 |
| L2      | disclosure (information asymmetry) |        0.454 |          0.511 | fraud firms LOWER (against the prediction) |                                        5 |                          5 |               2 |
| L3      | governance (weak monitoring)       |        0.572 |          0.483 | fraud firms higher (as predicted)          |                                        0 |                          5 |               2 |

## Deviations

- none
