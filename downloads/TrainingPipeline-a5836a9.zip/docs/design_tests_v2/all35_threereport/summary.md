# Design test battery (v2) — all35_threereport

Analysed firm-years: 972 (162 fraud firm-years) in 35 matched sets: 35 RPT-fraud cases (FRAUD = 1; strata {'core': 21, 'disclosure_only': 9, 'sensitivity_3_reports': 5}) and 165 matched firms.
AUD_OPIN: modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report. RESTATE: 8-K Item 4.02 or a 10-K/A that restates the financial statements.

## M1 coverage by group (selection on the outcome where the Fisher p is small)

| characteristic                | layer   | panel_column                                                                              |   coverage_all |   coverage_fraud_firm_years |   coverage_matched_firm_years |   fisher_p_coverage_differs |   n_fraud_observed |   n_matched_observed |
|:------------------------------|:--------|:------------------------------------------------------------------------------------------|---------------:|----------------------------:|------------------------------:|----------------------------:|-------------------:|---------------------:|
| RP_LEND                       | L1      | rp_lend_to_assets                                                                         |          0.117 |                       0.272 |                         0.086 |                       0     |                 44 |                   70 |
| RP_PAY                        | L1      | rp_pay_to_assets                                                                          |          0.119 |                       0.272 |                         0.089 |                       0     |                 44 |                   72 |
| RP_SALES                      | L1      | rp_sales_to_revenue                                                                       |          0.076 |                       0.105 |                         0.07  |                       0.143 |                 17 |                   57 |
| RP_PURCH                      | L1      | rp_purch_to_assets                                                                        |          0.159 |                       0.154 |                         0.16  |                       0.907 |                 25 |                  130 |
| RP_INCOMP                     | L2      | rp_incomp                                                                                 |          0.888 |                       0.877 |                         0.89  |                       0.588 |                142 |                  721 |
| RP_VAGUE                      | L2      | rpt_vagueness                                                                             |          0.886 |                       0.877 |                         0.888 |                       0.685 |                142 |                  719 |
| BRD_NONIND                    | L3      | board_indep                                                                               |          0.133 |                       0.228 |                         0.114 |                       0     |                 37 |                   92 |
| DUAL                          | L3      | ceo_duality                                                                               |          0.528 |                       0.562 |                         0.521 |                       0.389 |                 91 |                  422 |
| ICFR_MW (traditional signal)  | TRAD    | material_weakness_reported                                                                |          0.919 |                       0.796 |                         0.943 |                     nan     |                129 |                  764 |
| AUD_OPIN (traditional signal) | TRAD    | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |          0.976 |                       0.994 |                         0.973 |                     nan     |                161 |                  788 |
| AUD_CHG (traditional signal)  | TRAD    | auditor_change_8k                                                                         |          1     |                       1     |                         1     |                     nan     |                162 |                  810 |
| RESTATE (traditional signal)  | TRAD    | 8-K Item 4.02 or a 10-K/A that restates the financial statements                          |          1     |                       1     |                         1     |                     nan     |                162 |                  810 |

## Text source by group

| fraud_aaer_label   |   none |   rp_note |   rpt_disclosure |   n |   share_stating_no_transactions |
|:-------------------|-------:|----------:|-----------------:|----:|--------------------------------:|
| fraud firm-years   |  0.123 |     0.568 |            0.309 | 162 |                           0.056 |
| matched firm-years |  0.11  |     0.426 |            0.464 | 810 |                           0.056 |

## Scoring rules

| rule                                            | value                                                                                                                                      |
|:------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------|
| ranking population                              | the 972 analysed firm-years (five-year windows of the 35 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic       | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score             |
| AI_SCORE with a missing layer                   | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE                                                  |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 666, 1: 199, 2: 67, 3: 34, 4: 6}                                                                                                       |
| firm-years with L2 from 0/1/2 characteristics   | {0: 109, 1: 2, 2: 861}                                                                                                                     |
| firm-years with L3 from 0/1/2 characteristics   | {0: 420, 1: 462, 2: 90}                                                                                                                    |
| firm-years with 1/2/3 layers in AI_SCORE        | {0: 69, 1: 257, 2: 474, 3: 172}                                                                                                            |
| AUD_OPIN definition                             | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report                                                  |
| RESTATE definition                              | 8-K Item 4.02 or a 10-K/A that restates the financial statements                                                                           |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |     -0.076 |     -0.048 |
| L2_SCORE |     -0.076 |      1     |     -0.127 |
| L3_SCORE |     -0.048 |     -0.127 |      1     |

## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)

| hypothesis   | variant   | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |   p_holm |   p_holm_firm_cluster | direction_as_predicted   | supported_design_rule   | supported_firm_cluster   |
|:-------------|:----------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|---------:|----------------------:|:-------------------------|:------------------------|:-------------------------|
| H1           | all cases | L1_SCORE      |            211 |               18 |        68 |                   58 |         0.34  |               1.405 |       0.946 |        2.088 | 0.202 |          0.092 |             0.319 |            0.286 |                    0.752 |                     2.627 |    0.136 |                 0.573 | True                     | False                   | False                    |
| H2           | all cases | L2_SCORE      |            565 |               27 |       129 |                  110 |        -0.221 |               0.802 |       0.633 |        1.017 | 0.121 |          0.068 |             0.24  |            0.358 |                    0.501 |                     1.284 |    0.136 |                 0.573 | False                    | False                   | False                    |
| H3           | all cases | L3_SCORE      |            304 |               20 |        77 |                   81 |         0.739 |               2.094 |       1.451 |        3.022 | 0.187 |          0     |             0.415 |            0.075 |                    0.928 |                     4.727 |    0     |                 0.225 | True                     | True                    | False                    |

## H2 re-runs and single-characteristic tests

| hypothesis   | variant                                                                                                      | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |
|:-------------|:-------------------------------------------------------------------------------------------------------------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|
| H2           | without disclosure-only cases (design re-run)                                                                | L2_SCORE      |            400 |               20 |        93 |                   81 |        -0.267 |               0.765 |       0.573 |        1.023 | 0.148 |          0.07  |             0.269 |            0.32  |                    0.452 |                     1.296 |
| H2           | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE      |            510 |               26 |       123 |                  101 |        -0.149 |               0.862 |       0.669 |        1.11  | 0.129 |          0.249 |             0.236 |            0.529 |                    0.542 |                     1.369 |
| H2           | all cases, firm-years with both disclosure characteristics observed (robustness)                             | L2_SCORE      |            563 |               27 |       129 |                  110 |        -0.213 |               0.808 |       0.637 |        1.024 | 0.121 |          0.078 |             0.241 |            0.377 |                    0.503 |                     1.297 |
| H1           | single characteristic                                                                                        | RP_LEND       |             64 |                9 |        24 |                   37 |        -0.003 |               0.997 |       0.338 |        2.936 | 0.551 |          0.995 |             0.846 |            0.997 |                    0.19  |                     5.232 |
| H1           | single characteristic                                                                                        | RP_PAY        |             59 |                9 |        24 |                   39 |         0.161 |               1.174 |       0.545 |        2.533 | 0.392 |          0.682 |             0.396 |            0.685 |                    0.54  |                     2.554 |
| H1           | single characteristic                                                                                        | RP_SALES      |             23 |                5 |        11 |                   13 |        -0.103 |               0.902 |       0.281 |        2.895 | 0.595 |          0.863 |             0.508 |            0.84  |                    0.333 |                     2.443 |
| H1           | single characteristic                                                                                        | RP_PURCH      |             83 |                9 |        31 |                   22 |        -0.706 |               0.494 |       0.098 |        2.479 | 0.823 |          0.391 |             1.192 |            0.554 |                    0.048 |                     5.108 |
| H2           | single characteristic                                                                                        | RP_INCOMP     |            565 |               27 |       129 |                  110 |        -0.321 |               0.726 |       0.554 |        0.949 | 0.137 |          0.019 |             0.295 |            0.277 |                    0.407 |                     1.293 |
| H2           | single characteristic                                                                                        | RP_VAGUE      |            563 |               27 |       129 |                  110 |         0.013 |               1.013 |       0.808 |        1.271 | 0.116 |          0.908 |             0.187 |            0.943 |                    0.703 |                     1.461 |
| H3           | single characteristic                                                                                        | BRD_NONIND    |             54 |                6 |        15 |                   36 |         1.591 |               4.907 |       1.157 |       20.81  | 0.737 |          0.031 |             2.081 |            0.445 |                    0.083 |                   289.85  |
| H3           | single characteristic                                                                                        | DUAL          |            277 |               19 |        71 |                   76 |         0.553 |               1.739 |       1.228 |        2.463 | 0.178 |          0.002 |             0.398 |            0.164 |                    0.798 |                     3.792 |

## H4 by event year (conditional logit primary; Mann–Whitney supplementary)

|   event_year | layer_score   |   n_firm_years |   n_matched_sets |   n_fraud |   mean_fraud |   mean_matched |   cond_coef |   cond_or_per_sd |   cond_p |   cond_p_firm_cluster |   mannwhitney_p_greater | significant_as_predicted_cond   |
|-------------:|:--------------|---------------:|-----------------:|----------:|-------------:|---------------:|------------:|-----------------:|---------:|----------------------:|------------------------:|:--------------------------------|
|           -5 | L1_SCORE      |             21 |                7 |        29 |        0.556 |          0.557 |      -0.013 |            0.987 |    0.979 |                 0.979 |                   0.504 | False                           |
|           -5 | L2_SCORE      |            100 |               22 |        29 |        0.459 |          0.526 |      -0.345 |            0.708 |    0.197 |                 0.251 |                   0.942 | False                           |
|           -5 | L3_SCORE      |             43 |               13 |        29 |        0.569 |          0.489 |       0.435 |            1.545 |    0.386 |                 0.418 |                   0.078 | False                           |
|           -4 | L1_SCORE      |             22 |                7 |        31 |        0.536 |          0.505 |       4.095 |           60.01  |    0.129 |                 0.676 |                   0.428 | False                           |
|           -4 | L2_SCORE      |             90 |               20 |        31 |        0.453 |          0.507 |      -0.195 |            0.823 |    0.435 |                 0.439 |                   0.894 | False                           |
|           -4 | L3_SCORE      |             46 |               14 |        31 |        0.563 |          0.503 |       0.527 |            1.693 |    0.229 |                 0.226 |                   0.162 | False                           |
|           -3 | L1_SCORE      |             31 |               11 |        35 |        0.485 |          0.456 |       0.827 |            2.286 |    0.142 |                 0.339 |                   0.368 | False                           |
|           -3 | L2_SCORE      |            102 |               23 |        35 |        0.463 |          0.504 |      -0.049 |            0.952 |    0.846 |                 0.85  |                   0.823 | False                           |
|           -3 | L3_SCORE      |             61 |               18 |        35 |        0.637 |          0.498 |       0.732 |            2.079 |    0.056 |                 0.061 |                   0.006 | False                           |
|           -2 | L1_SCORE      |             36 |               11 |        34 |        0.514 |          0.414 |       0.442 |            1.556 |    0.39  |                 0.466 |                   0.051 | False                           |
|           -2 | L2_SCORE      |            102 |               23 |        34 |        0.427 |          0.509 |      -0.444 |            0.642 |    0.125 |                 0.21  |                   0.972 | False                           |
|           -2 | L3_SCORE      |             56 |               16 |        34 |        0.572 |          0.485 |       0.64  |            1.897 |    0.111 |                 0.145 |                   0.084 | False                           |
|           -1 | L1_SCORE      |             31 |                9 |        33 |        0.475 |          0.458 |       0.16  |            1.174 |    0.754 |                 0.734 |                   0.382 | False                           |
|           -1 | L2_SCORE      |             92 |               22 |        33 |        0.448 |          0.511 |      -0.165 |            0.848 |    0.533 |                 0.59  |                   0.932 | False                           |
|           -1 | L3_SCORE      |             44 |               14 |        33 |        0.519 |          0.463 |       0.974 |            2.647 |    0.134 |                 0.339 |                   0.087 | False                           |

| layer_score   | design_rule_met_before_final_year   |   years_significant |   tests_run |
|:--------------|:------------------------------------|--------------------:|------------:|
| L1_SCORE      | False                               |                 nan |           5 |
| L2_SCORE      | False                               |                 nan |           5 |
| L3_SCORE      | False                               |                 nan |           5 |

## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate

|                                             | 0                                |
|:--------------------------------------------|:---------------------------------|
| model_A                                     | TRAD_INDEX+leverage+roa          |
| model_B                                     | TRAD_INDEX+leverage+roa+AI_SCORE |
| n_firm_years                                | 665                              |
| n_fraud_firm_years                          | 115                              |
| n_matched_sets                              | 35                               |
| loso_auc_model_A                            | 0.488                            |
| loso_auc_model_B                            | 0.532                            |
| auc_gain_B_minus_A                          | 0.043                            |
| auc_gain_ci_low                             | -0.01                            |
| auc_gain_ci_high                            | 0.094                            |
| auc_trad_index_alone                        | 0.599                            |
| auc_ai_score_alone                          | 0.523                            |
| AI_SCORE_coef_per_sd_model_B_pooled         | 0.16396198623000463              |
| AI_SCORE_or_ci_pooled                       | 0.87-1.59                        |
| AI_SCORE_p_model_B_pooled_firm_cluster      | 0.28618532047681344              |
| AI_SCORE_coef_per_sd_model_B_conditional    | 0.3353199324188102               |
| AI_SCORE_p_model_B_conditional              | 0.008880795464044997             |
| AI_SCORE_p_model_B_conditional_firm_cluster | 0.12745722136917848              |
| ai_threshold_5pct_far                       | 7.757                            |
| ai_far_at_5pct_rule                         | 0.051                            |
| trad_rule_equal_far                         | TRAD_INDEX >= 3                  |
| trad_far                                    | 0.014                            |
| ai_threshold_equal_far                      | 8.506                            |
| ai_far_equal_rule                           | 0.014                            |
| cases                                       | 35                               |
| cases_flagged_ai_5pct                       | 3                                |
| cases_never_flagged_ai_5pct                 | 32                               |
| cases_flagged_ai_equal_far                  | 1                                |
| cases_flagged_trad_equal_far                | 3                                |
| cases_ai_earlier_equal_far                  | 1                                |
| cases_same_year_equal_far                   | 0                                |
| cases_trad_earlier_equal_far                | 3                                |
| cases_flagged_by_neither_equal_far          | 31                               |
| earliest_ai_year_median_5pct                | -4.0                             |
| union_far                                   | 0.026                            |
| cases_flagged_union                         | 4                                |
| cases_flagged_ai_alone_at_union_far         | 2                                |
| cases_flagged_trad_alone_at_union_far       | 3                                |
| trad_rule_at_union_far                      | TRAD_INDEX >= 3                  |
| trad_ge1_matched_rate                       | 0.241                            |

|                                                                                                                 |   met |
|:----------------------------------------------------------------------------------------------------------------|------:|
| AI_SCORE significant in Model B (pooled, firm-clustered)                                                        |     0 |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) |     0 |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)         |     0 |

## Timing by case

| case           | stratum               |   ai_first_year_5pct_far |   ai_first_year_equal_far |   trad_ge3_first_year |   trad_ge1_first_year | ai_earlier_equal_far   | same_year_equal_far   | trad_earlier_equal_far   | flagged_by_neither_equal_far   |   ai_years_flagged_5pct |   window_years |
|:---------------|:----------------------|-------------------------:|--------------------------:|----------------------:|----------------------:|:-----------------------|:----------------------|:-------------------------|:-------------------------------|------------------------:|---------------:|
| AMERICAN_ELECT | disclosure_only       |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_EQUIT | disclosure_only       |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_REALT | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| AMMO_INC_OUTDO | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| APPLE_REIT_NIN | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| AULT_ALLIANCE  | core                  |                      nan |                       nan |                    -5 |                    -5 | False                  | False                 | True                     | False                          |                       0 |              5 |
| CEMTREX        | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CHINA_NORTH_EA | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| CHINA_VALVES_T | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CORPORATE_RESO | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| CO_DIAGNOSTICS | core                  |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| EAGLE_BANCORP  | core                  |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| ENERGY_XXI     | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FAT_BRANDS     | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FIRST_BANCORP_ | disclosure_only       |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| GENERAL_EMPLOY | core                  |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| HF_FOODS_GROUP | sensitivity_3_reports |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              3 |
| IDEANOMICS_SEV | core                  |                      nan |                       nan |                    -4 |                    -4 | False                  | False                 | True                     | False                          |                       0 |              5 |
| IFRESH         | sensitivity_3_reports |                       -4 |                        -4 |                   nan |                    -4 | True                   | False                 | False                    | False                          |                       1 |              3 |
| MANITEX_INTERN | core                  |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| MAXIMUS        | disclosure_only       |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| MUSCLEPHARM    | core                  |                       -4 |                       nan |                    -3 |                    -4 | False                  | False                 | True                     | False                          |                       2 |              4 |
| OCWEN_FINANCIA | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PREMIER_HOLDIN | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PROVECTUS_BIOP | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PUDA_COAL      | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| QUADRANT_4_SYS | core                  |                       -5 |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       3 |              5 |
| RCI_HOSPITALIT | disclosure_only       |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SAEXPLORATION_ | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SHIFT4_PAYMENT | disclosure_only       |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SINGULARITY_FU | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SKECHERS_U_S_A | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| THE_GREENBRIER | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| UNITED_DEVELOP | core                  |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              5 |
| VALEANT_PHARMA | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |

## P1 RPT types by form of fraud (descriptive)

| form_group                  |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |
|:----------------------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|
| both                        |             2 |               2 |           2 |             2 |               1 |                 2 |
| corporate                   |             8 |              18 |           6 |            18 |               9 |                18 |
| disclosure-only (not in P1) |             4 |               9 |           1 |             9 |               2 |                 9 |
| managerial                  |             3 |               6 |           1 |             6 |               1 |                 6 |

## A1 attribution summary (share of AI_SCORE)

|                  |   mean_share_all_firm_years |   mean_share_fraud_firm_years |   mean_share_flagged_fraud_firm_years |
|:-----------------|----------------------------:|------------------------------:|--------------------------------------:|
| share_L1         |                       0.127 |                         0.169 |                                   0   |
| share_RP_LEND    |                       0.027 |                         0.064 |                                   0   |
| share_RP_PAY     |                       0.033 |                         0.058 |                                   0   |
| share_RP_SALES   |                       0.02  |                         0.016 |                                   0   |
| share_RP_PURCH   |                       0.047 |                         0.031 |                                   0   |
| share_L2         |                       0.529 |                         0.436 |                                   1   |
| share_RP_INCOMP  |                       0.274 |                         0.189 |                                   0.5 |
| share_RP_VAGUE   |                       0.255 |                         0.247 |                                   0.5 |
| share_L3         |                       0.273 |                         0.302 |                                   0   |
| share_BRD_NONIND |                       0.045 |                         0.064 |                                   0   |
| share_DUAL       |                       0.228 |                         0.238 |                                   0   |

## A2 stability (leave one matched set out)

|                                   | 0                                                                                                                                 |
|:----------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| firm_years                        | 972                                                                                                                               |
| spearman_ai_score_full_vs_loso    | 0.9995588583425474                                                                                                                |
| mean_abs_ai_score_change          | 0.03439669556320517                                                                                                               |
| median_max_abs_layer_share_change | 0.0011569706089128995                                                                                                             |
| share_largest_layer_unchanged     | 0.9948559670781894                                                                                                                |
| share_named_evidence_unchanged    | 0.9886831275720165                                                                                                                |
| method                            | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

## A3 layers in the flagged fraud firm-years

| layer   | agency_idea                        |   mean_fraud |   mean_matched | direction                                  |   flagged_fraud_firm_years_where_largest |   flagged_fraud_firm_years |   flagged_cases |
|:--------|:-----------------------------------|-------------:|---------------:|:-------------------------------------------|-----------------------------------------:|---------------------------:|----------------:|
| L1      | financial (conflict of interest)   |        0.511 |          0.473 | fraud firms higher (as predicted)          |                                        0 |                          6 |               3 |
| L2      | disclosure (information asymmetry) |        0.45  |          0.511 | fraud firms LOWER (against the prediction) |                                        6 |                          6 |               3 |
| L3      | governance (weak monitoring)       |        0.575 |          0.488 | fraud firms higher (as predicted)          |                                        0 |                          6 |               3 |

## Deviations

- none
