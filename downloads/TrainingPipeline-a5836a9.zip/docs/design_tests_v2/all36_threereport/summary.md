# Design test battery (v2) — all36_threereport

Analysed firm-years: 1001 (167 fraud firm-years) in 36 matched sets: 36 RPT-fraud cases (FRAUD = 1; strata {'core': 21, 'disclosure_only': 10, 'sensitivity_3_reports': 5}) and 170 matched firms.
AUD_OPIN: modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report. RESTATE: 8-K Item 4.02 or a 10-K/A that restates the financial statements.

## M1 coverage by group (selection on the outcome where the Fisher p is small)

| characteristic                | layer   | panel_column                                                                              |   coverage_all |   coverage_fraud_firm_years |   coverage_matched_firm_years |   fisher_p_coverage_differs |   n_fraud_observed |   n_matched_observed |
|:------------------------------|:--------|:------------------------------------------------------------------------------------------|---------------:|----------------------------:|------------------------------:|----------------------------:|-------------------:|---------------------:|
| RP_LEND                       | L1      | rp_lend_to_assets                                                                         |          0.114 |                       0.263 |                         0.084 |                       0     |                 44 |                   70 |
| RP_PAY                        | L1      | rp_pay_to_assets                                                                          |          0.116 |                       0.263 |                         0.086 |                       0     |                 44 |                   72 |
| RP_SALES                      | L1      | rp_sales_to_revenue                                                                       |          0.076 |                       0.102 |                         0.071 |                       0.199 |                 17 |                   59 |
| RP_PURCH                      | L1      | rp_purch_to_assets                                                                        |          0.161 |                       0.156 |                         0.162 |                       0.908 |                 26 |                  135 |
| RP_INCOMP                     | L2      | rp_incomp                                                                                 |          0.889 |                       0.88  |                         0.891 |                       0.686 |                147 |                  743 |
| RP_VAGUE                      | L2      | rpt_vagueness                                                                             |          0.887 |                       0.88  |                         0.888 |                       0.789 |                147 |                  741 |
| BRD_NONIND                    | L3      | board_indep                                                                               |          0.135 |                       0.222 |                         0.118 |                       0.001 |                 37 |                   98 |
| DUAL                          | L3      | ceo_duality                                                                               |          0.536 |                       0.575 |                         0.529 |                       0.308 |                 96 |                  441 |
| ICFR_MW (traditional signal)  | TRAD    | material_weakness_reported                                                                |          0.921 |                       0.802 |                         0.945 |                     nan     |                134 |                  788 |
| AUD_OPIN (traditional signal) | TRAD    | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |          0.977 |                       0.994 |                         0.974 |                     nan     |                166 |                  812 |
| AUD_CHG (traditional signal)  | TRAD    | auditor_change_8k                                                                         |          1     |                       1     |                         1     |                     nan     |                167 |                  834 |
| RESTATE (traditional signal)  | TRAD    | 8-K Item 4.02 or a 10-K/A that restates the financial statements                          |          1     |                       1     |                         1     |                     nan     |                167 |                  834 |

## Text source by group

| fraud_aaer_label   |   none |   rp_note |   rpt_disclosure |   n |   share_stating_no_transactions |
|:-------------------|-------:|----------:|-----------------:|----:|--------------------------------:|
| fraud firm-years   |  0.12  |     0.551 |            0.329 | 167 |                           0.054 |
| matched firm-years |  0.109 |     0.417 |            0.474 | 834 |                           0.054 |

## Scoring rules

| rule                                            | value                                                                                                                                       |
|:------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------|
| ranking population                              | the 1001 analysed firm-years (five-year windows of the 36 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic       | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score              |
| AI_SCORE with a missing layer                   | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE                                                   |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 689, 1: 203, 2: 69, 3: 34, 4: 6}                                                                                                        |
| firm-years with L2 from 0/1/2 characteristics   | {0: 111, 1: 2, 2: 888}                                                                                                                      |
| firm-years with L3 from 0/1/2 characteristics   | {0: 425, 1: 480, 2: 96}                                                                                                                     |
| firm-years with 1/2/3 layers in AI_SCORE        | {0: 70, 1: 259, 2: 497, 3: 175}                                                                                                             |
| AUD_OPIN definition                             | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report                                                   |
| RESTATE definition                              | 8-K Item 4.02 or a 10-K/A that restates the financial statements                                                                            |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |     -0.081 |     -0.063 |
| L2_SCORE |     -0.081 |      1     |     -0.126 |
| L3_SCORE |     -0.063 |     -0.126 |      1     |

## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)

| hypothesis   | variant   | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |   p_holm |   p_holm_firm_cluster | direction_as_predicted   | supported_design_rule   | supported_firm_cluster   |
|:-------------|:----------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|---------:|----------------------:|:-------------------------|:------------------------|:-------------------------|
| H1           | all cases | L1_SCORE      |            214 |               19 |        70 |                   59 |         0.384 |               1.468 |       0.993 |        2.172 | 0.2   |          0.054 |             0.315 |            0.223 |                    0.792 |                     2.723 |    0.109 |                 0.452 | True                     | False                   | False                    |
| H2           | all cases | L2_SCORE      |            579 |               28 |       132 |                  115 |        -0.19  |               0.827 |       0.655 |        1.043 | 0.119 |          0.109 |             0.234 |            0.417 |                    0.522 |                     1.309 |    0.109 |                 0.452 | False                    | False                   | False                    |
| H3           | all cases | L3_SCORE      |            318 |               21 |        80 |                   86 |         0.534 |               1.706 |       1.222 |        2.383 | 0.17  |          0.002 |             0.372 |            0.151 |                    0.823 |                     3.536 |    0.005 |                 0.452 | True                     | True                    | False                    |

## H2 re-runs and single-characteristic tests

| hypothesis   | variant                                                                                                      | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |
|:-------------|:-------------------------------------------------------------------------------------------------------------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|
| H2           | without disclosure-only cases (design re-run)                                                                | L2_SCORE      |            400 |               20 |        93 |                   81 |        -0.265 |               0.767 |       0.574 |        1.024 | 0.148 |          0.072 |             0.268 |            0.323 |                    0.453 |                     1.298 |
| H2           | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE      |            524 |               27 |       126 |                  106 |        -0.118 |               0.889 |       0.694 |        1.139 | 0.126 |          0.353 |             0.23  |            0.61  |                    0.566 |                     1.397 |
| H2           | all cases, firm-years with both disclosure characteristics observed (robustness)                             | L2_SCORE      |            577 |               28 |       132 |                  115 |        -0.183 |               0.833 |       0.66  |        1.051 | 0.119 |          0.124 |             0.236 |            0.438 |                    0.524 |                     1.322 |
| H1           | single characteristic                                                                                        | RP_LEND       |             64 |                9 |        24 |                   37 |        -0.003 |               0.997 |       0.338 |        2.936 | 0.551 |          0.995 |             0.846 |            0.997 |                    0.19  |                     5.232 |
| H1           | single characteristic                                                                                        | RP_PAY        |             59 |                9 |        24 |                   39 |         0.161 |               1.174 |       0.545 |        2.533 | 0.392 |          0.682 |             0.396 |            0.685 |                    0.54  |                     2.554 |
| H1           | single characteristic                                                                                        | RP_SALES      |             23 |                5 |        11 |                   13 |        -0.103 |               0.902 |       0.281 |        2.895 | 0.595 |          0.863 |             0.508 |            0.84  |                    0.333 |                     2.444 |
| H1           | single characteristic                                                                                        | RP_PURCH      |             86 |               10 |        33 |                   23 |        -0.306 |               0.736 |       0.319 |        1.697 | 0.426 |          0.472 |             0.376 |            0.415 |                    0.352 |                     1.538 |
| H2           | single characteristic                                                                                        | RP_INCOMP     |            579 |               28 |       132 |                  115 |        -0.304 |               0.738 |       0.568 |        0.958 | 0.133 |          0.023 |             0.287 |            0.291 |                    0.42  |                     1.296 |
| H2           | single characteristic                                                                                        | RP_VAGUE      |            577 |               28 |       132 |                  115 |         0.033 |               1.034 |       0.827 |        1.293 | 0.114 |          0.77  |             0.185 |            0.857 |                    0.719 |                     1.486 |
| H3           | single characteristic                                                                                        | BRD_NONIND    |             54 |                6 |        15 |                   36 |         1.568 |               4.796 |       1.155 |       19.923 | 0.727 |          0.031 |             2.104 |            0.456 |                    0.078 |                   296.639 |
| H3           | single characteristic                                                                                        | DUAL          |            291 |               20 |        74 |                   81 |         0.429 |               1.535 |       1.107 |        2.129 | 0.167 |          0.01  |             0.368 |            0.244 |                    0.746 |                     3.16  |

## H4 by event year (conditional logit primary; Mann–Whitney supplementary)

|   event_year | layer_score   |   n_firm_years |   n_matched_sets |   n_fraud |   mean_fraud |   mean_matched |   cond_coef |   cond_or_per_sd |   cond_p |   cond_p_firm_cluster |   mannwhitney_p_greater | significant_as_predicted_cond   |
|-------------:|:--------------|---------------:|-----------------:|----------:|-------------:|---------------:|------------:|-----------------:|---------:|----------------------:|------------------------:|:--------------------------------|
|           -5 | L1_SCORE      |             21 |                7 |        30 |        0.555 |          0.553 |      -0.013 |            0.987 |    0.98  |                 0.98  |                   0.478 | False                           |
|           -5 | L2_SCORE      |            103 |               23 |        30 |        0.456 |          0.522 |      -0.362 |            0.696 |    0.17  |                 0.226 |                   0.949 | False                           |
|           -5 | L3_SCORE      |             46 |               14 |        30 |        0.556 |          0.492 |       0.259 |            1.296 |    0.573 |                 0.598 |                   0.114 | False                           |
|           -4 | L1_SCORE      |             22 |                7 |        32 |        0.534 |          0.502 |       3.854 |           47.166 |    0.118 |                 0.643 |                   0.409 | False                           |
|           -4 | L2_SCORE      |             93 |               21 |        32 |        0.46  |          0.505 |      -0.167 |            0.846 |    0.497 |                 0.5   |                   0.861 | False                           |
|           -4 | L3_SCORE      |             49 |               15 |        32 |        0.55  |          0.506 |       0.318 |            1.375 |    0.416 |                 0.393 |                   0.215 | False                           |
|           -3 | L1_SCORE      |             31 |               11 |        36 |        0.485 |          0.457 |       0.829 |            2.292 |    0.139 |                 0.335 |                   0.362 | False                           |
|           -3 | L2_SCORE      |            105 |               24 |        36 |        0.473 |          0.503 |       0.012 |            1.012 |    0.962 |                 0.963 |                   0.756 | False                           |
|           -3 | L3_SCORE      |             64 |               19 |        36 |        0.623 |          0.499 |       0.559 |            1.75  |    0.102 |                 0.098 |                   0.01  | False                           |
|           -2 | L1_SCORE      |             36 |               11 |        35 |        0.513 |          0.418 |       0.45  |            1.569 |    0.38  |                 0.457 |                   0.07  | False                           |
|           -2 | L2_SCORE      |            105 |               24 |        35 |        0.437 |          0.508 |      -0.326 |            0.722 |    0.229 |                 0.311 |                   0.954 | False                           |
|           -2 | L3_SCORE      |             59 |               17 |        35 |        0.557 |          0.487 |       0.448 |            1.565 |    0.207 |                 0.225 |                   0.116 | False                           |
|           -1 | L1_SCORE      |             31 |                9 |        34 |        0.504 |          0.454 |       0.18  |            1.197 |    0.735 |                 0.715 |                   0.247 | False                           |
|           -1 | L2_SCORE      |             94 |               23 |        34 |        0.448 |          0.515 |      -0.18  |            0.835 |    0.492 |                 0.554 |                   0.946 | False                           |
|           -1 | L3_SCORE      |             46 |               15 |        34 |        0.51  |          0.466 |       0.444 |            1.559 |    0.346 |                 0.463 |                   0.118 | False                           |

| layer_score   | design_rule_met_before_final_year   |   years_significant |   tests_run |
|:--------------|:------------------------------------|--------------------:|------------:|
| L1_SCORE      | False                               |                 nan |           5 |
| L2_SCORE      | False                               |                 nan |           5 |
| L3_SCORE      | False                               |                 nan |           5 |

## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate

|                                             | 0                                |
|:--------------------------------------------|:---------------------------------|
| model_A                                     | TRAD_INDEX+leverage+roa          |
| model_B                                     | TRAD_INDEX+leverage+roa+AI_SCORE |
| n_firm_years                                | 679                              |
| n_fraud_firm_years                          | 120                              |
| n_matched_sets                              | 36                               |
| loso_auc_model_A                            | 0.488                            |
| loso_auc_model_B                            | 0.513                            |
| auc_gain_B_minus_A                          | 0.025                            |
| auc_gain_ci_low                             | -0.019                           |
| auc_gain_ci_high                            | 0.069                            |
| auc_trad_index_alone                        | 0.595                            |
| auc_ai_score_alone                          | 0.521                            |
| AI_SCORE_coef_per_sd_model_B_pooled         | 0.1392567305602644               |
| AI_SCORE_or_ci_pooled                       | 0.86-1.54                        |
| AI_SCORE_p_model_B_pooled_firm_cluster      | 0.3533904865642533               |
| AI_SCORE_coef_per_sd_model_B_conditional    | 0.29882026120872435              |
| AI_SCORE_p_model_B_conditional              | 0.017068386876293175             |
| AI_SCORE_p_model_B_conditional_firm_cluster | 0.16347504300830273              |
| ai_threshold_5pct_far                       | 7.763                            |
| ai_far_at_5pct_rule                         | 0.05                             |
| trad_rule_equal_far                         | TRAD_INDEX >= 3                  |
| trad_far                                    | 0.013                            |
| ai_threshold_equal_far                      | 8.515                            |
| ai_far_equal_rule                           | 0.013                            |
| cases                                       | 36                               |
| cases_flagged_ai_5pct                       | 3                                |
| cases_never_flagged_ai_5pct                 | 33                               |
| cases_flagged_ai_equal_far                  | 1                                |
| cases_flagged_trad_equal_far                | 3                                |
| cases_ai_earlier_equal_far                  | 1                                |
| cases_same_year_equal_far                   | 0                                |
| cases_trad_earlier_equal_far                | 3                                |
| cases_flagged_by_neither_equal_far          | 32                               |
| earliest_ai_year_median_5pct                | -4.0                             |
| union_far                                   | 0.025                            |
| cases_flagged_union                         | 4                                |
| cases_flagged_ai_alone_at_union_far         | 2                                |
| cases_flagged_trad_alone_at_union_far       | 3                                |
| trad_rule_at_union_far                      | TRAD_INDEX >= 3                  |
| trad_ge1_matched_rate                       | 0.236                            |

|                                                                                                                 |   met |
|:----------------------------------------------------------------------------------------------------------------|------:|
| AI_SCORE significant in Model B (pooled, firm-clustered)                                                        |     0 |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) |     0 |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)         |     0 |

## Timing by case

| case           | stratum               |   ai_first_year_5pct_far |   ai_first_year_equal_far |   trad_ge3_first_year |   trad_ge1_first_year | ai_earlier_equal_far   | same_year_equal_far   | trad_earlier_equal_far   | flagged_by_neither_equal_far   |   ai_years_flagged_5pct |   window_years |
|:---------------|:----------------------|-------------------------:|--------------------------:|----------------------:|----------------------:|:-----------------------|:----------------------|:-------------------------|:-------------------------------|------------------------:|---------------:|
| AMERICAN_ELECT | disclosure_only       |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_EQUIT | disclosure_only       |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_REALT | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| AMMO_INC_OUTDO | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| APPLE_REIT_NIN | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| AULT_ALLIANCE  | core                  |                      nan |                       nan |                    -5 |                    -5 | False                  | False                 | True                     | False                          |                       0 |              5 |
| CEMTREX        | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CHINA_NORTH_EA | sensitivity_3_reports |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              3 |
| CHINA_VALVES_T | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CORPORATE_RESO | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| CO_DIAGNOSTICS | core                  |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| EAGLE_BANCORP  | core                  |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| ENERGY_XXI     | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FAT_BRANDS     | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FIRST_BANCORP_ | disclosure_only       |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| GENERAL_EMPLOY | core                  |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| GULFPORT_ENERG | disclosure_only       |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| HF_FOODS_GROUP | sensitivity_3_reports |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              3 |
| IDEANOMICS_SEV | core                  |                      nan |                       nan |                    -4 |                    -4 | False                  | False                 | True                     | False                          |                       0 |              5 |
| IFRESH         | sensitivity_3_reports |                       -4 |                        -4 |                   nan |                    -4 | True                   | False                 | False                    | False                          |                       1 |              3 |
| MANITEX_INTERN | core                  |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| MAXIMUS        | disclosure_only       |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| MUSCLEPHARM    | core                  |                       -4 |                       nan |                    -3 |                    -4 | False                  | False                 | True                     | False                          |                       2 |              4 |
| OCWEN_FINANCIA | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PREMIER_HOLDIN | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PROVECTUS_BIOP | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PUDA_COAL      | core                  |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| QUADRANT_4_SYS | core                  |                       -5 |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       3 |              5 |
| RCI_HOSPITALIT | disclosure_only       |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SAEXPLORATION_ | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SHIFT4_PAYMENT | disclosure_only       |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SINGULARITY_FU | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SKECHERS_U_S_A | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| THE_GREENBRIER | disclosure_only       |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| UNITED_DEVELOP | core                  |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              5 |
| VALEANT_PHARMA | core                  |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |

## P1 RPT types by form of fraud (descriptive)

| form_group                  |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |
|:----------------------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|
| both                        |             2 |               2 |           2 |             2 |               1 |                 2 |
| corporate                   |             8 |              18 |           6 |            18 |               9 |                18 |
| disclosure-only (not in P1) |             4 |              10 |           1 |            10 |               3 |                10 |
| managerial                  |             3 |               6 |           1 |             6 |               1 |                 6 |

## A1 attribution summary (share of AI_SCORE)

|                  |   mean_share_all_firm_years |   mean_share_fraud_firm_years |   mean_share_flagged_fraud_firm_years |
|:-----------------|----------------------------:|------------------------------:|--------------------------------------:|
| share_L1         |                       0.126 |                         0.167 |                                 0     |
| share_RP_LEND    |                       0.026 |                         0.062 |                                 0     |
| share_RP_PAY     |                       0.032 |                         0.056 |                                 0     |
| share_RP_SALES   |                       0.02  |                         0.015 |                                 0     |
| share_RP_PURCH   |                       0.048 |                         0.033 |                                 0     |
| share_L2         |                       0.527 |                         0.441 |                                 1     |
| share_RP_INCOMP  |                       0.272 |                         0.192 |                                 0.496 |
| share_RP_VAGUE   |                       0.255 |                         0.249 |                                 0.504 |
| share_L3         |                       0.277 |                         0.302 |                                 0     |
| share_BRD_NONIND |                       0.045 |                         0.062 |                                 0     |
| share_DUAL       |                       0.232 |                         0.24  |                                 0     |

## A2 stability (leave one matched set out)

|                                   | 0                                                                                                                                 |
|:----------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| firm_years                        | 1001                                                                                                                              |
| spearman_ai_score_full_vs_loso    | 0.9995887949101978                                                                                                                |
| mean_abs_ai_score_change          | 0.033187640848493134                                                                                                              |
| median_max_abs_layer_share_change | 0.0011879111529913555                                                                                                             |
| share_largest_layer_unchanged     | 0.996003996003996                                                                                                                 |
| share_named_evidence_unchanged    | 0.981018981018981                                                                                                                 |
| method                            | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

## A3 layers in the flagged fraud firm-years

| layer   | agency_idea                        |   mean_fraud |   mean_matched | direction                                  |   flagged_fraud_firm_years_where_largest |   flagged_fraud_firm_years |   flagged_cases |
|:--------|:-----------------------------------|-------------:|---------------:|:-------------------------------------------|-----------------------------------------:|---------------------------:|----------------:|
| L1      | financial (conflict of interest)   |        0.516 |          0.472 | fraud firms higher (as predicted)          |                                        0 |                          6 |               3 |
| L2      | disclosure (information asymmetry) |        0.454 |          0.51  | fraud firms LOWER (against the prediction) |                                        6 |                          6 |               3 |
| L3      | governance (weak monitoring)       |        0.562 |          0.49  | fraud firms higher (as predicted)          |                                        0 |                          6 |               3 |

## Deviations

- none
