# Design test battery (v2) — all30

Analysed firm-years: 833 (147 fraud firm-years) in 30 matched sets: 30 RPT-fraud cases (FRAUD = 1; strata {'core': 21, 'disclosure_only': 9}) and 140 matched firms.
AUD_OPIN: modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report. RESTATE: 8-K Item 4.02 or a 10-K/A that restates the financial statements.

## M1 coverage by group (selection on the outcome where the Fisher p is small)

| characteristic                | layer   | panel_column                                                                              |   coverage_all |   coverage_fraud_firm_years |   coverage_matched_firm_years |   fisher_p_coverage_differs |   n_fraud_observed |   n_matched_observed |
|:------------------------------|:--------|:------------------------------------------------------------------------------------------|---------------:|----------------------------:|------------------------------:|----------------------------:|-------------------:|---------------------:|
| RP_LEND                       | L1      | rp_lend_to_assets                                                                         |          0.122 |                       0.286 |                         0.087 |                       0     |                 42 |                   60 |
| RP_PAY                        | L1      | rp_pay_to_assets                                                                          |          0.13  |                       0.279 |                         0.098 |                       0     |                 41 |                   67 |
| RP_SALES                      | L1      | rp_sales_to_revenue                                                                       |          0.077 |                       0.102 |                         0.071 |                       0.231 |                 15 |                   49 |
| RP_PURCH                      | L1      | rp_purch_to_assets                                                                        |          0.156 |                       0.156 |                         0.156 |                       1     |                 23 |                  107 |
| RP_INCOMP                     | L2      | rp_incomp                                                                                 |          0.894 |                       0.905 |                         0.892 |                       0.768 |                133 |                  612 |
| RP_VAGUE                      | L2      | rpt_vagueness                                                                             |          0.892 |                       0.905 |                         0.889 |                       0.662 |                133 |                  610 |
| BRD_NONIND                    | L3      | board_indep                                                                               |          0.148 |                       0.252 |                         0.125 |                       0     |                 37 |                   86 |
| DUAL                          | L3      | ceo_duality                                                                               |          0.543 |                       0.585 |                         0.534 |                       0.274 |                 86 |                  366 |
| ICFR_MW (traditional signal)  | TRAD    | material_weakness_reported                                                                |          0.915 |                       0.816 |                         0.936 |                     nan     |                120 |                  642 |
| AUD_OPIN (traditional signal) | TRAD    | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report |          0.972 |                       0.993 |                         0.968 |                     nan     |                146 |                  664 |
| AUD_CHG (traditional signal)  | TRAD    | auditor_change_8k                                                                         |          1     |                       1     |                         1     |                     nan     |                147 |                  686 |
| RESTATE (traditional signal)  | TRAD    | 8-K Item 4.02 or a 10-K/A that restates the financial statements                          |          1     |                       1     |                         1     |                     nan     |                147 |                  686 |

## Text source by group

| fraud_aaer_label   |   none |   rp_note |   rpt_disclosure |   n |   share_stating_no_transactions |
|:-------------------|-------:|----------:|-----------------:|----:|--------------------------------:|
| fraud firm-years   |  0.095 |     0.571 |            0.333 | 147 |                           0.061 |
| matched firm-years |  0.108 |     0.423 |            0.469 | 686 |                           0.054 |

## Scoring rules

| rule                                            | value                                                                                                                                      |
|:------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------|
| ranking population                              | the 833 analysed firm-years (five-year windows of the 30 matched sets); firm-years outside the windows and the external set are not ranked |
| layer score with a missing characteristic       | mean of the 0-1 ranks of the characteristics observed for that firm-year; a layer with no observed characteristic has no score             |
| AI_SCORE with a missing layer                   | 10 x mean of the layer scores that exist; a firm-year with no layer score has no AI_SCORE                                                  |
| firm-years with L1 from 1/2/3/4 characteristics | {0: 572, 1: 161, 2: 63, 3: 31, 4: 6}                                                                                                       |
| firm-years with L2 from 0/1/2 characteristics   | {0: 88, 1: 2, 2: 743}                                                                                                                      |
| firm-years with L3 from 0/1/2 characteristics   | {0: 347, 1: 397, 2: 89}                                                                                                                    |
| firm-years with 1/2/3 layers in AI_SCORE        | {0: 48, 1: 235, 2: 393, 3: 157}                                                                                                            |
| AUD_OPIN definition                             | modified (qualified, adverse, disclaimer) or going-concern opinion, from the audit report                                                  |
| RESTATE definition                              | 8-K Item 4.02 or a 10-K/A that restates the financial statements                                                                           |

## M3 layer-score correlations

|          |   L1_SCORE |   L2_SCORE |   L3_SCORE |
|:---------|-----------:|-----------:|-----------:|
| L1_SCORE |      1     |     -0.013 |      0.008 |
| L2_SCORE |     -0.013 |      1     |     -0.122 |
| L3_SCORE |      0.008 |     -0.122 |      1     |

## H1–H3 (conditional logit within matched sets; OR per SD; model-based and firm-clustered; Holm across the three)

| hypothesis   | variant   | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |    se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |   p_holm |   p_holm_firm_cluster | direction_as_predicted   | supported_design_rule   | supported_firm_cluster   |
|:-------------|:----------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|---------:|----------------------:|:-------------------------|:------------------------|:-------------------------|
| H1           | all cases | L1_SCORE      |            184 |               16 |        61 |                   52 |         0.43  |               1.537 |       0.99  |        2.387 | 0.224 |          0.055 |             0.387 |            0.266 |                    0.721 |                     3.28  |    0.089 |                 0.532 | True                     | False                   | False                    |
| H2           | all cases | L2_SCORE      |            503 |               24 |       114 |                  102 |        -0.255 |               0.775 |       0.604 |        0.994 | 0.127 |          0.045 |             0.256 |            0.318 |                    0.469 |                     1.279 |    0.089 |                 0.532 | False                    | False                   | False                    |
| H3           | all cases | L3_SCORE      |            270 |               17 |        68 |                   76 |         0.741 |               2.098 |       1.452 |        3.033 | 0.188 |          0     |             0.419 |            0.077 |                    0.923 |                     4.77  |    0     |                 0.231 | True                     | True                    | False                    |

## H2 re-runs and single-characteristic tests

| hypothesis   | variant                                                                                                      | layer_score   |   n_firm_years |   n_matched_sets |   n_firms |   n_fraud_firm_years |   coef_per_sd |   odds_ratio_per_sd |   or_ci_low |   or_ci_high |        se |   p_unadjusted |   se_firm_cluster |   p_firm_cluster |   or_ci_low_firm_cluster |   or_ci_high_firm_cluster |
|:-------------|:-------------------------------------------------------------------------------------------------------------|:--------------|---------------:|-----------------:|----------:|---------------------:|--------------:|--------------------:|------------:|-------------:|----------:|---------------:|------------------:|-----------------:|-------------------------:|--------------------------:|
| H2           | without disclosure-only cases (design re-run)                                                                | L2_SCORE      |            338 |               17 |        78 |                   73 |        -0.328 |         0.72        |       0.526 |        0.986 |     0.16  |          0.04  |             0.296 |            0.267 |                    0.404 |                     1.286 |
| H2           | all cases, excluding firm-years whose text states that there were no related-party transactions (robustness) | L2_SCORE      |            455 |               23 |       108 |                   93 |        -0.193 |         0.825       |       0.631 |        1.078 |     0.136 |          0.158 |             0.252 |            0.444 |                    0.504 |                     1.351 |
| H2           | all cases, firm-years with both disclosure characteristics observed (robustness)                             | L2_SCORE      |            501 |               24 |       114 |                  102 |        -0.247 |         0.781       |       0.609 |        1.003 |     0.127 |          0.052 |             0.257 |            0.337 |                    0.472 |                     1.293 |
| H1           | single characteristic                                                                                        | RP_LEND       |             58 |                8 |        22 |                   35 |        -0.04  |         0.96        |       0.324 |        2.848 |     0.555 |          0.942 |             0.85  |            0.962 |                    0.182 |                     5.077 |
| H1           | single characteristic                                                                                        | RP_PAY        |             55 |                8 |        22 |                   36 |         0.157 |         1.17        |       0.557 |        2.458 |     0.379 |          0.678 |             0.378 |            0.678 |                    0.558 |                     2.453 |
| H1           | single characteristic                                                                                        | RP_SALES      |             14 |                3 |         7 |                   11 |        36.669 |         8.41912e+15 |       0     |      inf     | 11732.8   |          0.998 |          2896.99  |            0.99  |                    0     |                   inf     |
| H1           | single characteristic                                                                                        | RP_PURCH      |             71 |                8 |        27 |                   20 |        -0.92  |         0.398       |       0.05  |        3.192 |     1.062 |          0.386 |             2.029 |            0.65  |                    0.007 |                    21.239 |
| H2           | single characteristic                                                                                        | RP_INCOMP     |            503 |               24 |       114 |                  102 |        -0.304 |         0.738       |       0.558 |        0.977 |     0.143 |          0.034 |             0.313 |            0.331 |                    0.4   |                     1.362 |
| H2           | single characteristic                                                                                        | RP_VAGUE      |            501 |               24 |       114 |                  102 |        -0.073 |         0.929       |       0.728 |        1.186 |     0.124 |          0.555 |             0.195 |            0.707 |                    0.634 |                     1.362 |
| H3           | single characteristic                                                                                        | BRD_NONIND    |             54 |                6 |        15 |                   36 |         1.227 |         3.411       |       1.119 |       10.394 |     0.569 |          0.031 |             1.337 |            0.359 |                    0.248 |                    46.877 |
| H3           | single characteristic                                                                                        | DUAL          |            248 |               16 |        63 |                   71 |         0.54  |         1.715       |       1.204 |        2.444 |     0.181 |          0.003 |             0.4   |            0.177 |                    0.783 |                     3.756 |

## H4 by event year (conditional logit primary; Mann–Whitney supplementary)

|   event_year | layer_score   |   n_firm_years |   n_matched_sets |   n_fraud |   mean_fraud |   mean_matched |   cond_coef |   cond_or_per_sd |   cond_p |   cond_p_firm_cluster |   mannwhitney_p_greater | significant_as_predicted_cond   |
|-------------:|:--------------|---------------:|-----------------:|----------:|-------------:|---------------:|------------:|-----------------:|---------:|----------------------:|------------------------:|:--------------------------------|
|           -5 | L1_SCORE      |             21 |                7 |        28 |        0.548 |          0.569 |       0.006 |            1.006 |    0.991 |                 0.991 |                   0.545 | False                           |
|           -5 | L2_SCORE      |             95 |               21 |        28 |        0.461 |          0.529 |      -0.38  |            0.684 |    0.181 |                 0.247 |                   0.929 | False                           |
|           -5 | L3_SCORE      |             40 |               12 |        28 |        0.579 |          0.488 |       0.647 |            1.909 |    0.257 |                 0.346 |                   0.06  | False                           |
|           -4 | L1_SCORE      |             22 |                7 |        30 |        0.528 |          0.486 |       3.442 |           31.26  |    0.097 |                 0.55  |                   0.352 | False                           |
|           -4 | L2_SCORE      |             86 |               19 |        30 |        0.439 |          0.51  |      -0.364 |            0.695 |    0.189 |                 0.181 |                   0.94  | False                           |
|           -4 | L3_SCORE      |             46 |               14 |        30 |        0.582 |          0.496 |       0.517 |            1.676 |    0.229 |                 0.229 |                   0.081 | False                           |
|           -3 | L1_SCORE      |             25 |                9 |        30 |        0.461 |          0.45  |       0.867 |            2.38  |    0.208 |                 0.249 |                   0.492 | False                           |
|           -3 | L2_SCORE      |             92 |               21 |        30 |        0.471 |          0.507 |      -0.036 |            0.964 |    0.888 |                 0.888 |                   0.778 | False                           |
|           -3 | L3_SCORE      |             55 |               16 |        30 |        0.649 |          0.488 |       0.76  |            2.139 |    0.05  |                 0.064 |                   0.003 | False                           |
|           -2 | L1_SCORE      |             29 |                9 |        30 |        0.524 |          0.422 |       1.694 |            5.44  |    0.074 |                 0.214 |                   0.073 | False                           |
|           -2 | L2_SCORE      |             92 |               21 |        30 |        0.425 |          0.507 |      -0.459 |            0.632 |    0.126 |                 0.215 |                   0.96  | False                           |
|           -2 | L3_SCORE      |             52 |               15 |        30 |        0.583 |          0.474 |       0.649 |            1.913 |    0.108 |                 0.143 |                   0.084 | False                           |
|           -1 | L1_SCORE      |             24 |                7 |        29 |        0.465 |          0.476 |       0.177 |            1.193 |    0.767 |                 0.774 |                   0.522 | False                           |
|           -1 | L2_SCORE      |             83 |               20 |        29 |        0.448 |          0.511 |      -0.112 |            0.894 |    0.688 |                 0.738 |                   0.914 | False                           |
|           -1 | L3_SCORE      |             40 |               13 |        29 |        0.528 |          0.456 |       0.95  |            2.585 |    0.129 |                 0.313 |                   0.054 | False                           |

| layer_score   | design_rule_met_before_final_year   |   years_significant |   tests_run |
|:--------------|:------------------------------------|--------------------:|------------:|
| L1_SCORE      | False                               |                 nan |           5 |
| L2_SCORE      | False                               |                 nan |           5 |
| L3_SCORE      | False                               |                 nan |           5 |

## H5 Model A vs Model B with the design AI_SCORE; timing at an equal false-alarm rate

|                                             | 0                                |
|:--------------------------------------------|:---------------------------------|
| model_A                                     | TRAD_INDEX+leverage+roa          |
| model_B                                     | TRAD_INDEX+leverage+roa+AI_SCORE |
| n_firm_years                                | 584                              |
| n_fraud_firm_years                          | 107                              |
| n_matched_sets                              | 30                               |
| loso_auc_model_A                            | 0.455                            |
| loso_auc_model_B                            | 0.538                            |
| auc_gain_B_minus_A                          | 0.083                            |
| auc_gain_ci_low                             | 0.029                            |
| auc_gain_ci_high                            | 0.141                            |
| auc_trad_index_alone                        | 0.608                            |
| auc_ai_score_alone                          | 0.53                             |
| AI_SCORE_coef_per_sd_model_B_pooled         | 0.19483614838878377              |
| AI_SCORE_or_ci_pooled                       | 0.88-1.68                        |
| AI_SCORE_p_model_B_pooled_firm_cluster      | 0.23517876083629508              |
| AI_SCORE_coef_per_sd_model_B_conditional    | 0.3356227324685541               |
| AI_SCORE_p_model_B_conditional              | 0.011827324141440868             |
| AI_SCORE_p_model_B_conditional_firm_cluster | 0.1448197409197962               |
| ai_threshold_5pct_far                       | 7.915                            |
| ai_far_at_5pct_rule                         | 0.051                            |
| trad_rule_equal_far                         | TRAD_INDEX >= 3                  |
| trad_far                                    | 0.015                            |
| ai_threshold_equal_far                      | 8.537                            |
| ai_far_equal_rule                           | 0.015                            |
| cases                                       | 30                               |
| cases_flagged_ai_5pct                       | 2                                |
| cases_never_flagged_ai_5pct                 | 28                               |
| cases_flagged_ai_equal_far                  | 0                                |
| cases_flagged_trad_equal_far                | 3                                |
| cases_ai_earlier_equal_far                  | 0                                |
| cases_same_year_equal_far                   | 0                                |
| cases_trad_earlier_equal_far                | 3                                |
| cases_flagged_by_neither_equal_far          | 27                               |
| earliest_ai_year_median_5pct                | -4.5                             |
| union_far                                   | 0.028                            |
| cases_flagged_union                         | 3                                |
| cases_flagged_ai_alone_at_union_far         | 1                                |
| cases_flagged_trad_alone_at_union_far       | 3                                |
| trad_rule_at_union_far                      | TRAD_INDEX >= 3                  |
| trad_ge1_matched_rate                       | 0.248                            |

|                                                                                                                 |   met |
|:----------------------------------------------------------------------------------------------------------------|------:|
| AI_SCORE significant in Model B (pooled, firm-clustered)                                                        |     0 |
| Model B separates fraud firms better than Model A on firms it was not fitted to (gain > 0, interval excludes 0) |     1 |
| AI flag earlier than the traditional flag in more fraud firms than the reverse (equal false-alarm rate)         |     0 |

## Timing by case

| case           | stratum         |   ai_first_year_5pct_far |   ai_first_year_equal_far |   trad_ge3_first_year |   trad_ge1_first_year | ai_earlier_equal_far   | same_year_equal_far   | trad_earlier_equal_far   | flagged_by_neither_equal_far   |   ai_years_flagged_5pct |   window_years |
|:---------------|:----------------|-------------------------:|--------------------------:|----------------------:|----------------------:|:-----------------------|:----------------------|:-------------------------|:-------------------------------|------------------------:|---------------:|
| AMERICAN_ELECT | disclosure_only |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMERICAN_EQUIT | disclosure_only |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AMMO_INC_OUTDO | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| AULT_ALLIANCE  | core            |                      nan |                       nan |                    -5 |                    -5 | False                  | False                 | True                     | False                          |                       0 |              5 |
| CEMTREX        | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CHINA_VALVES_T | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| CORPORATE_RESO | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| CO_DIAGNOSTICS | core            |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| EAGLE_BANCORP  | core            |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| ENERGY_XXI     | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FAT_BRANDS     | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| FIRST_BANCORP_ | disclosure_only |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| GENERAL_EMPLOY | core            |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| IDEANOMICS_SEV | core            |                      nan |                       nan |                    -4 |                    -4 | False                  | False                 | True                     | False                          |                       0 |              5 |
| MANITEX_INTERN | core            |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| MAXIMUS        | disclosure_only |                      nan |                       nan |                   nan |                   nan | False                  | False                 | False                    | True                           |                       0 |              5 |
| MUSCLEPHARM    | core            |                       -4 |                       nan |                    -3 |                    -4 | False                  | False                 | True                     | False                          |                       2 |              4 |
| OCWEN_FINANCIA | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PREMIER_HOLDIN | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PROVECTUS_BIOP | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| PUDA_COAL      | core            |                      nan |                       nan |                   nan |                    -4 | False                  | False                 | False                    | True                           |                       0 |              4 |
| QUADRANT_4_SYS | core            |                       -5 |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       3 |              5 |
| RCI_HOSPITALIT | disclosure_only |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SAEXPLORATION_ | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SHIFT4_PAYMENT | disclosure_only |                      nan |                       nan |                   nan |                    -3 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SINGULARITY_FU | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |
| SKECHERS_U_S_A | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| THE_GREENBRIER | disclosure_only |                      nan |                       nan |                   nan |                    -1 | False                  | False                 | False                    | True                           |                       0 |              5 |
| UNITED_DEVELOP | core            |                      nan |                       nan |                   nan |                    -2 | False                  | False                 | False                    | True                           |                       0 |              5 |
| VALEANT_PHARMA | core            |                      nan |                       nan |                   nan |                    -5 | False                  | False                 | False                    | True                           |                       0 |              5 |

## P1 RPT types by form of fraud (descriptive)

| form_group                  |   lending_sum |   lending_count |   sales_sum |   sales_count |   purchases_sum |   purchases_count |
|:----------------------------|--------------:|----------------:|------------:|--------------:|----------------:|------------------:|
| both                        |             1 |               1 |           1 |             1 |               1 |                 1 |
| corporate                   |             8 |              15 |           5 |            15 |               8 |                15 |
| disclosure-only (not in P1) |             4 |               9 |           1 |             9 |               2 |                 9 |
| managerial                  |             3 |               5 |           1 |             5 |               1 |                 5 |

## A1 attribution summary (share of AI_SCORE)

|                  |   mean_share_all_firm_years |   mean_share_fraud_firm_years |   mean_share_flagged_fraud_firm_years |
|:-----------------|----------------------------:|------------------------------:|--------------------------------------:|
| share_L1         |                       0.125 |                         0.167 |                                 0     |
| share_RP_LEND    |                       0.027 |                         0.064 |                                 0     |
| share_RP_PAY     |                       0.036 |                         0.059 |                                 0     |
| share_RP_SALES   |                       0.018 |                         0.015 |                                 0     |
| share_RP_PURCH   |                       0.044 |                         0.029 |                                 0     |
| share_L2         |                       0.535 |                         0.449 |                                 1     |
| share_RP_INCOMP  |                       0.278 |                         0.197 |                                 0.514 |
| share_RP_VAGUE   |                       0.257 |                         0.253 |                                 0.486 |
| share_L3         |                       0.282 |                         0.322 |                                 0     |
| share_BRD_NONIND |                       0.048 |                         0.072 |                                 0     |
| share_DUAL       |                       0.234 |                         0.251 |                                 0     |

## A2 stability (leave one matched set out)

|                                   | 0                                                                                                                                 |
|:----------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
| firm_years                        | 833                                                                                                                               |
| spearman_ai_score_full_vs_loso    | 0.9993166976833531                                                                                                                |
| mean_abs_ai_score_change          | 0.039535302094318894                                                                                                              |
| median_max_abs_layer_share_change | 0.0013936878626393812                                                                                                             |
| share_largest_layer_unchanged     | 0.992797118847539                                                                                                                 |
| share_named_evidence_unchanged    | 0.9711884753901561                                                                                                                |
| method                            | ranks recomputed without each matched set in turn; the held-out firm-years scored against the remaining firm-years' distributions |

## A3 layers in the flagged fraud firm-years

| layer   | agency_idea                        |   mean_fraud |   mean_matched | direction                                  |   flagged_fraud_firm_years_where_largest |   flagged_fraud_firm_years |   flagged_cases |
|:--------|:-----------------------------------|-------------:|---------------:|:-------------------------------------------|-----------------------------------------:|---------------------------:|----------------:|
| L1      | financial (conflict of interest)   |        0.505 |          0.477 | fraud firms higher (as predicted)          |                                        0 |                          5 |               2 |
| L2      | disclosure (information asymmetry) |        0.449 |          0.513 | fraud firms LOWER (against the prediction) |                                        5 |                          5 |               2 |
| L3      | governance (weak monitoring)       |        0.586 |          0.48  | fraud firms higher (as predicted)          |                                        0 |                          5 |               2 |

## EXPLORATORY — fitted 36-input score

|                                    | 0                                                                                                                                                                                                                                  |
|:-----------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| note                               | EXPLORATORY: the fitted ensemble score uses 36 inputs including ICFR, audit-opinion, auditor-change and restatement signals, Big-4 status and general financial ratios; it cannot test whether the RPT layers add to the benchmark |
| loso_auc_model_A                   | 0.471                                                                                                                                                                                                                              |
| loso_auc_model_A_plus_fitted_score | 0.566                                                                                                                                                                                                                              |
| auc_fitted_score_alone_oof         | 0.655                                                                                                                                                                                                                              |
| fitted_threshold                   | 0.695                                                                                                                                                                                                                              |
| fitted_far_matched                 | 0.05                                                                                                                                                                                                                               |
| cases_flagged_fitted               | 7                                                                                                                                                                                                                                  |
| cases_never_flagged_fitted         | 23                                                                                                                                                                                                                                 |

## Deviations

- none
