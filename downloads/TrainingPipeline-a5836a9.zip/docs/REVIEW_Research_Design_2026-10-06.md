# Review of "RPT Research Design – 06.10.26"

*Prepared 7 October 2026 against the design draft of 6 October (revised the same evening). Comments are grounded in the pilot build of the SEC-RPT-Panel dataset (30 firms, 292 10-Ks, FY2014–2024) and the leave-one-cluster-out pilot run, so each point says what the data have already shown.*

## 1. Overall view

The design is coherent and testable: one question, four objectives answered in four different ways, hypotheses only where a difference is predicted (RO3), pre-stated success criteria for every item, and candid limits (detection not prediction; association not cause; matched firms not known clean). The three-layer agency framing, the ten-events-per-predictor rule and the fit-on-other-firms rule are the right disciplines for 40 cases. The points below are about feasibility of measurement and about using a large firm universe correctly, not about the logic.

## 2. What the pilot build already tells us about measurement (RO2)

| Design element | Evidence from the pilot build | Implication |
|---|---|---|
| Item 13 as a source for RP_INCOMP / RP_VAGUE | 88% of Item 13 sections are one sentence incorporating the proxy statement by reference | The DEF 14A "Certain Relationships and Related Transactions" section must be the primary text source; the builder already does this fallback (`rpt_text_source = def14a` for 247 of 292 filings). Say so in §6. |
| RP amounts from the related-party note | The note is extractable in 26% of 10-Ks by heading; XBRL company facts carry **no** usable RPT amount for any of the 30 firms (`RelatedPartyTransactionAmountsOfTransaction`, `DueFromRelatedParties*` are dimensional and absent) | RP_LEND, RP_PAY, RP_SALES, RP_PURCH will come almost entirely from AI/hand coding of note text and proxy text, exactly as §4 anticipates. Budget M2 (reliability) accordingly; set the agreement threshold (e.g. Krippendorff's α ≥ 0.80 for amounts, ≥ 0.70 for the four disclosure items) before coding. |
| ICFR_MW from Item 9A | Available for 97% of filings; the pilot's flags (not-effective, weakness reported, weakness remediated) agree with hand checks on Ault FY2018–20, TransAct FY2019–21, Key Tronic FY2021 | Fine as a traditional signal. Note that ICFR reporting starts FY2004/FY2007, which bounds the window. |
| AUD_OPIN, AUD_CHG, RESTATE | Not yet extracted. Audit-opinion language (going concern, modified) is in the 10-K audit report; auditor change needs 8-K Item 4.01; restatement needs 8-K Item 4.02 and 10-K/A | Add 8-K collection to the data plan; the builder currently fetches 10-K and DEF 14A only. Without these three, TRAD_INDEX collapses to ICFR_MW and H5 is weaker than intended. |
| BRD_NONIND, DUAL from the proxy | Not yet extracted; the proxy text is already downloaded for 286 filings | Feasible with a rule/AI coder on the DEF 14A director table; include in M2. |
| Coverage per firm | Four of the five pilot anchors have ≥ 4 pre-revelation 10-Ks; ProPetro has 2 | The §12 check ("≥ 4 annual reports before the fraud became public") is binding: of 31 candidates checked on 2 October, 6 failed it. Expect to screen more than 40 to keep 40. |

## 3. Questions for the client

1. **Revelation date.** The window is "five fiscal years before the fraud became public". Who fixes that date and from which document (first 8-K/press release/restatement announcement, not the AAER date)? In the pilot, two of five anchors had no documented revelation date; one cluster had to be labelled unknown. This is the single most important hand-collected field.
2. **Disclosure-only cases.** Several recent SEC RPT actions (e.g. Skechers 2024, Maximus 2023, Shift4 2025) charge *non-disclosure* of related-party arrangements, not misstatement. In the pilot the model could not separate such a case from its peers (AUC 0.28) because the fraud left no trace in the text that *was* filed. Should these be (a) excluded, (b) kept and analysed separately as the H2 robustness run already proposes, or (c) kept and treated as the population of interest? The inclusion rule "RPT central to the fraud" needs to state this.
3. **FRAUD = 1 in every window year.** Where the misconduct began inside the window (e.g. misconduct 2019–2022, window 2017–2021), the first years are pre-misconduct. Is that intended (a firm-level label) or should `misconduct_period` be used for a sensitivity run? The dataset already carries both.
4. **Rank-average score vs fitted model.** §6 defines the AI risk score as a rank average of the eight characteristics, while §4 and H5 say the score is "produced by a model fitted to other firms". Which is it? A rank average needs no fitting and cannot be "fitted without the matched set"; a fitted logit (one coefficient per layer score) can. Recommend: rank-average layer scores as *inputs*, a three-coefficient logit fitted leave-one-matched-set-out as the AI_SCORE. That keeps the predictor count at three and makes A2 (stability across refits) meaningful.
5. **Matching variables.** "Industry, size and year" — which SIC level (4-digit with 3-digit fallback?), which size measure (total assets in the year before revelation?), and must a matched firm have a 10-K in every window year? The pilot used hand-picked competitors; for 200 peers an explicit rule is needed, and the firm universe below makes it possible.
6. **Matched firms "with no SEC enforcement".** Screened how? The builder's AAER matcher (whole-name, every release 1999–2026) can screen any candidate list automatically; recommend stating that the screen covers all AAERs, not only RPT ones.
7. **Thresholds for M1/M2** and the pre-registered false-alarm rate for H5 timing ("equal false-alarm rate in matched firms") — propose 5%, which is what the pilot used (observed 4.4%).
8. **Multiple testing.** §10 adjusts for three tests (H1–H3). H4 runs each layer in each of five years (15 tests) and H5 adds two; say how those are handled (e.g. H4 as a trend test across years rather than five separate tests).

## 4. Suggestions to improve the design

1. **Use a large firm universe, but not as training labels.** With ~40 enforcement cases the number of positives, not the number of firms, limits what a model can learn; adding thousands of non-enforcement firm-years to training would mostly teach the model the base rate. A large universe is valuable in four other roles, all of which the current pipeline can support:
   - *Matching pool*: draw the 200 peers by rule from all 10-K filers in the cases' industries (≈ 1,500–2,500 firms FY2005–2024) instead of hand-picking.
   - *Industry-year baselines*: compute abnormal related sales/lending as residuals against the industry-year, which the design's Table 1 implies but which needs more than five peers per cell.
   - *External false-alarm rate and generalisation test*: score every non-enforcement firm-year in the universe with the model fitted on the 240-firm panel and report the alert rate, by industry and year. This is the honest answer to "does the model generalise": it must not fire on 5% of the market.
   - *Undetected-case screen*: the highest-scoring universe firms become a documented list for future enforcement follow-up — a contribution in itself and a response to the "matched firms are not known clean" limit.
   The thesis can then report both the matched-set tests (H1–H5) and the universe-level alert rate, which is what reviewers will ask for.
2. **State the text source explicitly** (§6): DEF 14A related-party section first, Item 13 body when substantive, related-party note appended. Report the share from each source (coverage check M1 already covers this).
3. **Add the RP note word count and text availability as reported variables**, and treat text under a minimum length as missing, not as zero vagueness. (The pilot found zero-inflated scores were a measurement artefact of table-of-contents text.)
4. **Add a peer-relative version of each layer score** (deviation from the firm's own matched set, leave-one-out). It operationalises "relative to matched non-fraud peers" in RO3 directly and proved informative in the pilot.
5. **Lexicon-free check for RP_VAGUE**: alongside the Loughran–McDonald ratio, report a vocabulary-restricted TF-IDF model fitted on other matched sets. If it agrees with the lexicon it strengthens H2; the pilot showed such a model must exclude firm-specific names or it memorises identity.
6. **Pre-register the alert rule for H5 timing**: threshold fixed at the 5% false-alarm rate on matched firm-years out-of-fold; first year the score crosses it is the AI flag; first year any traditional signal is present is the traditional flag; compare medians and sign test. This is implemented and ran in the pilot (T3/T5).
7. **Power statement**: the simulation assumes 40 × 5 = 200 fraud firm-years; with the ≥ 4-reports rule some firms contribute 4. Report power at 160 and 200 fraud-years.
8. **References to confirm** (§12): add Kohlbeck & Mayhew (2017) and Fang et al. (2018) as the two anchors for "type of RPT matters more than presence"; the Chen & Elder and Hasnan et al. entries need full citations before the gap claim in §11.4 is stated as firm.

## 5. What the pipeline already provides for this design

| Design item | Status in `DatePreparedPipeline` / `TrainingPipeline` |
|---|---|
| 10-K, DEF 14A, AAER collection; event-time labels from a revelation date; ≥ 4-reports screen | Implemented; `cases.csv` drives it |
| Item 13 / proxy / RP note text, LM-style uncertainty ratio, Fog, ICFR flags, XBRL as first reported | Implemented |
| RP_LEND, RP_PAY, RP_SALES, RP_PURCH amounts | Text extracted; **amount coding (AI + human check) to build** |
| RP_INCOMP (four disclosure items) | **To build** (rule/AI coder on the RPT text) |
| BRD_NONIND, DUAL | Proxy text downloaded; **coder to build** (currently a hand-collected CSV) |
| AUD_OPIN, AUD_CHG, RESTATE | **8-K collection and audit-report parsing to build** |
| Rank-average layer scores, 3-coefficient logit fitted leave-one-set-out, clustered SEs | Logit/clustered SEs implemented; **layer-score construction to add** (a small change) |
| H4 by year, H5 Model A/B and timing at 5% FAR, A1–A3 attributions and refit stability | Implemented (T1–T5, mediation, SHAP stability/traceability); H5 Model A/B comparison **to add** |
| Large-universe matching pool and external alert rate | **To build**: `--universe-sic` download mode and a `score_universe` step |

## 6. Effort and data-volume estimate for the full study

- 240 firms × ~5–6 10-Ks + proxies ≈ 1,400 filings: ~3 hours of SEC download at the fair-access limit; one Colab session with `--resume-from-hub`.
- Industry universe for matching and the alert-rate test (≈ 2,000 firms × 10–20 years ≈ 25,000–35,000 filings): 2–4 days of download at the SEC limit, resumable across sessions; ~40–60 GB of raw text. Metadata-only (manifests, XBRL) for the whole universe is far cheaper (hours) and is enough for matching; raw text is needed only for the scored subset.
- AI coding of amounts and disclosure items for ~1,400 filings is the main cost; the human-check subsample for M2 should be fixed in advance (e.g. 10% stratified by layer and by case/peer).
