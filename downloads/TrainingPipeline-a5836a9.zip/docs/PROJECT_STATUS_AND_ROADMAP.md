# Project Status & Roadmap — RPT Fraud PhD

_Audit date: 2026-10-06. Sources: the Google Drive design documents listed below, a full read of this repository, and a live check of the Hugging Face dataset and SEC EDGAR._

## 1. What the thesis is supposed to do (source of truth)

| Document (Drive) | Date | Role |
|---|---|---|
| `PhD proposal V01_11503077 - annual review 10102025.docx` | Oct 2025 | Original proposal: RQ1–RQ3, cost-benefit analysis, interviews. **Superseded.** |
| `Thesis_Revision_Plan.docx` | 25 Sep 2026 | Current research questions: one overarching RQ, RO1–RO5, pilot H1–H4, stress tests T1–T5, confirmatory study of 40 fraud firms, 200 peers and ~1,200 firm-years, plus a Cox model |
| `V02 - RPT_Objectives_Variables_and_Sample_Data_Availability_v2.xlsx` | 2 Oct 2026 | Current variable map: P1–P5 across 3 layers. Two-tier sample: 31 core firms (post-2005, all three layers) plus 8 reserve and 11 extended firms |
| `Paper_Draft_v5.pdf` | Apr 2026 | Pilot write-up: 29 firms, 145 firm-years, 2018–2022 |

**Overarching RQ.** How can observable financial, governance and disclosure characteristics associated with RPTs support earlier identification of elevated fraud risk and more timely forensic investigation?

**Design.** A matched case-control study at the firm-year level. The case group is firms named in an RPT-related AAER. The comparison group is SIC-, size- and year-matched peers. The variables fall into three layers:

1. **Financial.** RPT/revenue, RP receivables/assets, abnormal related sales, earnings–cash divergence, accruals.
2. **Monitoring.** ICFR material weaknesses (Item 9A), restatements (8-K Item 4.02), board and audit-committee independence, CEO duality, Big-4 auditor or auditor change (DEF 14A / 8-K Item 4.01).
3. **Concealment.** Vagueness V, SFL agency masking A, Fog index and drift, all measured on **Item 13 plus the RP note, with the DEF 14A when Item 13 is incorporated by reference**. Item 1 is the specificity baseline.

Event time runs t−5…t−1 from the **first public revelation**, not from the AAER date.

## 2. Where we actually are

### The headline: existing pilot results are artefacts, not evidence
The numbers in Paper_Draft_v5 and in Chapter 3 come from this pipeline: AUC 0.83, Sobel z = 4.71, Ault RPT/Revenue at 663× the peer mean, and 22 MW periods. **None of them can be used.**

| # | Issue | Evidence | Effect |
|---|---|---|---|
| 1 | The target CIK `0000089649` does not exist. Ault Alliance is **`0000896493`**, now Hyperscale Data, with SIC **3533** (not 3679). Peer CIKs are wrong too. | `core/config.py:95,114-120`, `core/config.json`; EDGAR returns 404 for the configured CIK | EDGAR fetches fail, so the pipeline silently falls back to **stub 10-K texts** |
| 2 | Hardcoded financials are returned for *whichever firm is the target* | `financial/feature_extractor.py:30-207, 238`; `data/edgar_client.py:476, 492-598` | In pilot mode every firm, Nike included, gets Ault's numbers. The stub texts contain the exact phrases the lexicon searches for. |
| 3 | Mediation SEs are invented: `se = abs(coef) * 0.15` | `ml/mediation_analysis.py:195, 231` | Every path gets z = 6.67, so Sobel z ≈ 4.71 by construction. That is why the draft reports z = 4.71 and −4.71. |
| 4 | Leakage | Per-firm labels (`ml/feature_matrix.py:169`); 5-year slope features copied onto every year (:166,185); "ault/horne/milton" in the SFL lexicon (`nlp/sfl_analyser.py:64-74`); a row-level train/test split; risk scores, SHAP and lead time computed in-sample (`ml/fraud_model.py`) | The models can recognise the firm rather than detect fraud |
| 5 | Governance and ICFR variables are never measured | No Item 9A or DEF 14A parsing. CEO duality, Big-4, restatement and MW periods are hardcoded. "4 ICFR periods per year" is wrong because ICFR is assessed annually. | Layer 2 does not exist yet |
| 6 | Item 13 text is wrong | The regex takes the first match, usually the table of contents (`data/filing_parser.py:229`). Item 13 is normally "incorporated by reference to the proxy". | This is the **root cause of the zero-inflation** the reviewer flagged |
| 7 | Plumbing | `combined_feature_matrix.csv` is overwritten; the AAER cache is polluted with BATCH_ records; `strict_real_data` drops HF filings; `run_companies.py` local mode reads an empty list; 3 copies of the composite and 4 peer lists | The outputs cannot be reproduced |

Tests: 66 of 67 pass, but they check hardcoded constants and hand-written texts, so they cannot catch any of the above.

### The Hugging Face dataset (`alphatechlogics/SEC-EDGAR-Download`)
- It covers **fiscal 2024–2026 only**, about 5,180 firms and 12.7k 10-Ks.
  - None of the 2018–2022 pilot window is in it, and none of the 2005–2022 core-sample windows.
  - Ault, ProPetro, Co-Diagnostics and Gulfport appear only for 2024–25, labelled 0. Skechers is absent.
- `fraud_labels.csv` was built by substring-matching AAER list pages, which produces false positives:
  - Copa Holdings is matched to 40+ AAERs via the word "CPA".
  - KTCC, one of your *clean* peers, is labelled fraud.
  - The labels are not RPT-specific.
- `nlp_scores.csv`: **97% of Item 13 sections are about 9 words** ("incorporated by reference…").

**Conclusion:** in its current form the dataset cannot support the thesis design. Use it only as a peer-universe list, or rebuild it for the CIK-years you need (Phase 1).

#### Root causes in the dataset builder (`D:\alpha\SEC-EDGAR-Downloader`, audited 2026-10-06)

| Defect | Effect on the published dataset | Fixed in branch `fix/thesis-panel-v2` |
|---|---|---|
| The universe is `company_tickers.json` (currently listed firms only) | Survivorship bias: delisted fraud firms are missing (e.g. Iteris, Skechers, Puda Coal, Enron) | `--cases-csv` drives the universe by CIK |
| One universe row per ticker class | 22% duplicate panel rows | Dedupe by CIK |
| Item-heading regex takes the first match | `item13.txt` is the table-of-contents line in ~97% of filings | Line-anchored headings; longest section wins |
| Item 13 "incorporated by reference" is never followed to the proxy | No real RPT text for most firms | DEF 14A related-party section used as fallback (`rpt_disclosure.txt`) |
| AAER page parsed with a ±260-character text window | Dates and release numbers belong to the neighbouring row; respondents mixed | Parsed row by row from the HTML table |
| AAER pagination ignored | Only the first 100 releases per year are captured | All pages fetched |
| `release_url` never found | No release text; matching relies on listing snippets | Release PDF downloaded |
| Matching by ticker and substring | False positives (Copa "CPA", KTCC); not RPT-specific | Whole-party name match plus a review file; final labels come from the verified cases file |
| Label = AAER release year | Post-detection label, which leaks | `fraud_aaer_label` = case firm-years in the t−5…t−1 pre-revelation window; `event_time` |
| 10-KSB excluded; year = report-date year | Small and reverse-merger firms missing before 2009; FYE Jan–May mislabelled | 10-KSB/10-KT included; Compustat fiscal year |
| Missing text scored as 0 | Zero-inflation in Fog and vagueness | Blank scores plus `text_available` flag |
| No Item 9A, RP note or financials | Layers 1 and 2 absent | `item9a.txt` + ICFR flags, `rp_note.txt`, XBRL as first reported |

## 2b. Status after the 6 October 2026 rebuild

**Done (both repos pushed to GitHub: `codewithdark-git/DatePreparedPipeline` branch `fix/thesis-panel-v2`, `codewithdark-git/TrainingPipeline` branch `rpt-panel-v2`):**

- Dataset builder v2: every defect in the table above is fixed; `run_pipeline.py` is the single Colab entry point; `--upload` publishes to `alphatechlogics/SEC-RPT-Panel` with a dataset card and `dataset_qa.json`; `--resume-from-hub` makes runs restartable. 37 tests.
- Pilot `cases.csv`: 5 anchors + 25 peers, FY2014–2024. Confirmed AAER numbers: Ault AAER-4440 (2023-08-15), ProPetro AAER-4268 (2021-11-22), Co-Diagnostics AAER-4428 (2023-07-05). Gulfport and Skechers orders are not on the SEC AAER listing and still need numbers; **Gulfport has no revelation date yet, so its cluster is labelled unknown (excluded from training) until you supply one.**
- Research repo: the `rpt_panel` package replaces the legacy stack (now in `legacy/`, not runnable; fabricated-data modules deleted). 24 tests including known-answer tests on the real Ault FY2018 filing and leakage tests.

**Open for the user:** verify the five revelation dates; AAER numbers for GPOR/SKX; `governance_manual.csv` (board/audit-committee independence, CEO duality, Big 4 from DEF 14A); inclusion rule for the confirmatory sample.

## 2c. First honest pilot results (6 Oct 2026, `outputs/pilot`, copied to `docs/pilot_results/`)

Panel: 30 firms, 292 primary 10-Ks FY2014–2024; related-party text for 92% of firm-years (247 from DEF 14A, 21 from Item 13, 5 from the RP note). Training window: 107 firm-years, 17 case firm-years, 4 clusters (Gulfport excluded: no revelation date). 21 features (RPT-amount ratios and governance items dropped for missingness).

| Result | Value | Reading |
|---|---|---|
| H1 OOF AUC (leave-one-cluster-out) | logit 0.52 [0.19, 0.70]; RF 0.69 [0.41, 0.93]; XGB 0.73 [0.44, 0.92] | discrimination exists for trees, CIs are wide (n = 4 clusters) |
| Per-cluster (RF) | AULT 0.98, CODX 0.88, PUMP 0.47, SKX 0.42 | signal is strong for the two accounting-fraud anchors, absent for the disclosure-only (SKX) and short-history (PUMP, 2 pre-revelation 10-Ks) anchors |
| H2 / T2 ablation | removing L3 disclosure: logit −0.08, RF −0.20, XGB −0.15 AUC; removing L1 or L2: ≈ 0 or positive | the disclosure layer carries the incremental information |
| H4 / T1 specificity | case RPT−Item 1 vagueness gap 0.100 vs peers 0.046; p = 0.044 (Holm 0.088) | vagueness is concentrated in related-party text, more so for cases |
| H3 / T3 lead time (logit, threshold 0.85) | AULT first alert FY2018 → 56 months before revelation; CODX FY2019 → 43 months; SKX, PUMP never flagged | median 49.5 months for flagged cases |
| T4 MW persistence | Fisher p = 0.999 | no case–peer difference in ICFR persistence in this sample |
| T5 clean-firm FPR | 4/90 = 4.4% at threshold 0.85 | passes the ≤ 5% target |
| P4 mediation (1,000 cluster-bootstrap reps) | all indirect-effect CIs include 0 | no evidence that V or A mediates L1/L2 → enforcement |
| RO4 stability | within-model ρ 0.95–0.996; across models 0.35–0.47 (logit vs trees), 0.91 (RF vs XGB) | rankings are stable within a model class, less so across classes |
| RO4 traceability | 87% of top-3 attributions (94% for cases) map to a located passage or XBRL tag | |

Top features (logit mean |SHAP|): `rpt_indeterminate_ratio`, `rpt_fog`, `rpt_agency_masking`, `ln_assets`, `icfr_not_effective`.

How to write this up: a feasibility pilot that supports H2 and H4, gives suggestive evidence for H1 and H3 on two anchors, and finds no support for T4 and P4; every limitation (4 clusters, 17 positives, missing RPT-amount tags, no governance variables yet) is a declared boundary condition, and the confirmatory sample is what tests the hypotheses.

### Round 2 (same evening): peer-relative features, nested text stacking, peer textual anomaly, mean ensemble

Added as model inputs: leave-one-out, label-free cluster-year z-scores (`*_z`, group `L4_peer_relative`); a stacked TF-IDF text-risk score fitted in nested grouped folds with the vocabulary restricted to terms used by ≥ 3 firms (so it cannot memorise names); the novel `rpt_peer_text_distance` (cosine distance of a firm's RPT text to its cluster-year peers' centroid); a pre-specified mean-probability ensemble as the alert score; a calibration figure.

| | Round 1 (21 features) | Round 2 (28 features) |
|---|---|---|
| OOF AUC logit | 0.52 | 0.39 |
| OOF AUC RF | 0.69 [0.41, 0.93] | 0.69 [0.38, 0.95] |
| OOF AUC XGB | 0.73 [0.44, 0.92] | 0.68 [0.42, 0.93] |
| text-only TF-IDF | — | 0.52 |
| ensemble (alert) | — | 0.61 |
| per-cluster RF: AULT / CODX / PUMP / SKX | 0.98 / 0.88 / 0.47 / 0.42 | 0.99 / 0.91 / 0.68 / 0.28 |
| T3 lead time (alert score, thr 0.68) | AULT 56 m, CODX 43 m | AULT 56 m; CODX max 0.66 < thr |
| T5 clean FPR | 4.4% | 4.4% |
| traceability | 87% | 89% |

**Verdict: discrimination did not improve, and the thesis should say so.** With 17 positive firm-years in 4 clusters, adding features mostly adds variance (logit worsens); trees are flat at ≈ 0.69; the text model, once stopped from keying on firm names, carries little signal by itself; the ensemble is dragged down by logit. What the round did deliver: the ProPetro cluster becomes partly separable (0.47 → 0.68), the disclosure layer remains the layer whose removal costs the most (T2), peer-relative text distance and the z-scores rank in the top 8 attributions, and the text model's risk terms are now disclosure vocabulary (`license agreement`, `total compensation`, `accrued`, `committee shall`) rather than people.

**The 80–85% question.** No honest path to that on this pilot: Skechers is a disclosure-omission case with nothing to detect in the text that *was* disclosed (RF 0.28), and ProPetro has two pre-revelation 10-Ks. The levers that can legitimately move the confirmatory result are sample-side, not model-side: (1) 25–31 cases with the inclusion rule "RPT used in the accounting misstatement" (drop disclosure-only cases or analyse them separately); (2) hand-collected RPT amounts from `rp_note.txt` so Layer 1 is populated (`rpt_to_revenue` is empty in XBRL for all five anchors); (3) `governance_manual.csv`; (4) with ≥ 10 clusters, nested hyper-parameter selection inside folds (regularisation for logit, depth/leaf for trees) becomes feasible without optimism. Expect AUC in the 0.7–0.8 range to be a strong result at this scale; a reported 0.85 on four clusters would be a sign of leakage, not success.

## 3. Roadmap to finish faster

The revision plan has already removed the slowest parts of the original proposal: interviews, cross-sector cost-benefit analysis and the EU/UK comparison. Keep them out. What remains is **one clean data panel and one honest pipeline**.

### Phase 0 — Freeze decisions (≈1 week)
- [ ] **Window:** five years before the *first public revelation*. Hand-collect the revelation date per firm from the 8-K or press release.
- [ ] **Inclusion rule:** what counts as "RPT-related"? This decides AEP, Singularity and the 4 "insider misappropriation" reserve firms.
- [ ] **Sample:** Option A from V02 (core ≈31 firms plus extended ≈11 for robustness on Layers 1 and 3). Accept 25–31 core firms rather than chasing 40. State this openly; it is defensible.
- [ ] **Data access:** ask the library about **WRDS** (Compustat, Audit Analytics, ISS/BoardEx). Audit Analytics gives ICFR, restatements and auditor changes directly, which saves months of hand-collection. If WRDS is not available, use XBRL company-facts plus Item 9A parsing.

### Phase 1 — Real data panel (≈3–4 weeks)
- [ ] Fix the CIKs: Ault is `0000896493`. Verify every anchor and peer CIK against `company_tickers.json` and remove the hardcoded fallbacks in `data/company_registry.py`.
- [ ] Peer matching: same SIC-4 (fall back to SIC-3), closest total assets in t−1, and a 10-K filer every window year. Use 5 peers per case. Wire in the existing `ml/propensity_matching.py` or nearest-neighbour matching.
- [ ] Download for every case and peer firm-year: the 10-K, the **DEF 14A**, 8-K Items 4.01/4.02, and XBRL company facts.
- [ ] Rebuild the HF dataset for exactly those CIK-years. Version it, for example `v2-thesis-panel`, and keep the per-filing raw text plus `item13_or_proxy.txt`.
- [ ] Build labels from a hand-verified `cases.csv`: CIK, AAER number, misconduct years, revelation date, RPT element, source URL. Use the V02 workbook as the input, not the scraped `fraud_labels.csv`.

### Phase 2 — Correct the codebase (≈2–3 weeks, can overlap with Phase 1)
Delete or quarantine the following:
- `AULT_KNOWN_FINANCIALS` and `PEER_KNOWN_FINANCIALS`
- the stub texts
- the hardcoded LaTeX "AAER 4440" table
- the Ault names in the lexicons
- the `0.15·|coef|` SEs

Make `strict_real_data=True` the default and fail loudly when data is missing.

Then rebuild these pieces:
1. **Text:** take Item 13 from the body (skip the TOC). If the 10-K incorporates it by reference, use the DEF 14A "Certain Relationships and Related Transactions" section. Record the word count. Mark texts under N words as *missing*, not 0.
2. **Layer 2:** parse Item 9A for "not effective" and the count of material weaknesses (annual). Parse DEF 14A for board independence and CEO duality. Get the auditor name and changes from the audit report or 8-K 4.01.
3. **Financials:** use XBRL tags (RelatedPartyTransaction*, DueFromRelatedParties*, Revenues, Assets, NetIncomeLoss, NetCashProvidedByOperatingActivities). Hand-collect where they are missing and keep a provenance column.
4. **Modelling:**
   - Use a time-varying label: firm-year in the t−5…t−1 window = 1.
   - Remove the look-ahead shape features; use lagged changes only.
   - Use **GroupKFold by firm** (leave-one-case-cluster-out). Fit the scaler inside the folds.
   - Compute risk scores and SHAP out-of-fold.
   - Use conditional logit or logit with firm-clustered SEs as the primary inference; ML is secondary (per the revision plan).
5. **Mediation:** bootstrap the indirect effect (1,000+ resamples, cluster bootstrap by firm). Frame it as "consistent with", not causal.
6. **Stress tests T1–T5:** run them on out-of-fold scores, apply a multiple-testing correction, and label them hypothesis-generating.
7. One entry point (`main.py`), one config, one peer list. Delete the duplicate loops in `run_companies.py` and `batch_runner.py`, or reduce them to thin wrappers.
8. Tests: replace the constant checks with known-answer tests on real filings, for example Ault's FY2019 10-K Item 13 and its Item 9A result.

### Phase 3 — Re-run the pilot and rewrite Chapter 3 (≈2 weeks)
- Re-run the same 5 anchors with correctly matched peers on real data.
- Replace every number in Chapter 3 and Paper_Draft_v5. Expect lower AUCs; that is fine for a feasibility pilot.
- Report text coverage (how many firm-years had real RPT text). This turns the zero-inflation criticism into a documented boundary condition.

### Phase 4 — Confirmatory study (Chapter 4) (≈6–8 weeks)
- Run the core sample (≈25–31 cases × 5 peers ≈ 150–190 firms, ≈ 750–950 firm-years), plus the extended tier as robustness.
- Main tests: H1–H4 / P1–P5, Cox time-to-revelation, SHAP stability and traceability (RO4).

### Suggested order of work this month
1. Phase 0 decisions and the WRDS question.
2. Fix the CIKs, remove the stubs and fabricated values, and add strict mode, so nothing fake can leak again.
3. DEF 14A plus Item 9A extraction for the 5 pilot anchors, then re-run the pilot.
